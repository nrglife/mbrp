import URI from 'urijs';
import base64 from '../../../../utilities/base64';
import Hashes from 'jshashes';
import { DEFAULT_CONFIG } from '../constants';
import Config from 'react-native-config';
import { IHeaderURL } from '../../components/header/header.component';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AppConfigStore from '../../../../stores/AppConfigStore';
import { IocTypesMobile, IocContainer } from '../../../../iocTypes';

export const AuthConfig = () => {
  return {
    CLIENT_ID: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['CIAM_CLIENT_ID'],
    CLIENT_SECRET: '',
    ...DEFAULT_CONFIG()
  };
};

export const generateRandomNonce: (length: number) => string = (length: number) => {
  const POSSIBLE_RANDOM_STRING = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let text = '';
  for (let i = 0; i < length; i++) {
    text += POSSIBLE_RANDOM_STRING.charAt(Math.floor(Math.random() * POSSIBLE_RANDOM_STRING.length));
  }
  return text;
};

export const getParams = (silent: boolean) => {
  const redirectUri = silent ? AuthConfig().SILENT_REDIRECT_URI : AuthConfig().REDIRECT_URI;
  //get nonce from async storage if exist
  //const nonce = Async.get('nonce') || generateRandomNonce(15);
  const nonce = generateRandomNonce(15);
  AsyncStorage.setItem('nonce', nonce);
  //save nonce from async storage if wasnt exist
  //if(Async.get('nonce')) Async.set('nonce', nonce);

  const code_challenge = _generateSHA256String(code_verifier);

  const params = {
    scope: AuthConfig().SCOPE,
    response_type: AuthConfig().RESPONSE_TYPE,
    redirect_uri: AuthConfig().REDIRECT_URI,
    code_challenge,
    code_challenge_method: AuthConfig().CODE_CHALLENGE_METHOD,
    nonce,
    client_id: AuthConfig().CLIENT_ID
  };

  return silent ? Object.assign({}, params, { prompt: 'none' }) : params;
};

export const _generateBase64String = (str: string) => {
  return base64.encode(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};

export const _generateSHA256String = (str: string | Promise<string>) => {
  let SHA256 = new Hashes.SHA256();
  return SHA256.b64(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};


export const code_verifier = generateRandomNonce(60);

// used by gotoPingLogin with no argument, by updateTokenSilently with `silent` as `true`
export const generateCIAMUri = (silent: boolean = false) => {
  const finalParams = getParams(silent);

  const query = Object.keys(finalParams)
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(finalParams[k])}`)
    .join('&');

  return `${AuthConfig().URL}?${query}`;
};

export const parseUrl: (rawUrl: string) => IHeaderURL = (rawUrl: string) => {
  if (!rawUrl) {
    return null;
  }

  const urlAndParams = rawUrl.split('?');
  const params = urlAndParams[1] || null;
  const urlParts = urlAndParams[0].split('/');

  return {
    protocol: urlParts[0].startsWith('https') ? 'https' : 'http',
    domain: urlParts[2],
    endpoints: urlParts.slice(3),
    params
  };
};

export const getCodeForExchange = (redirectUri: string) => {
  const url = new URI(redirectUri);
  const urlParams = url.search(true);
  const code = urlParams.code;

  return code;
};

export const SOURCE = {
  uri: generateCIAMUri()
};

export const getAccessToken = async (code: string) => {
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    Accept: 'application/json',
    'cache-control': 'no-cache'
  };

  let body = `client_id=${AuthConfig().CLIENT_ID}&code_verifier=${code_verifier}&code=${code}&redirect_uri=${AuthConfig().REDIRECT_URI}&grant_type=authorization_code`;
  // console.log('requesting access token: ', body);
  try {
    const res = await fetch(AuthConfig().TOKEN_URI, {
      headers,
      body: body,
      method: 'POST'
    });
    const responseText = await res.text();
    // print to log (only on "debug all" mode) the tokens we get in the response
    // console.log(`Token body sent to server - ${body}`, body.split('&'));
    // console.log(`Token details from server response - ${responseText}`);

    const accessTokenDetails = JSON.parse(responseText);
      return accessTokenDetails;
  } catch (error) {
    throw new Error("Log-in failed can't get access token with error: " + error.message);
  }
};
