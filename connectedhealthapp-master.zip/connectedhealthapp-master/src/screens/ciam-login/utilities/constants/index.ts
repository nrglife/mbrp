import Config from 'react-native-config';
import { IocTypesMobile , IocContainer} from '../../../../iocTypes';
import AppConfigStore from "../../../../stores/AppConfigStore";
import { AUTH_DOMAINS } from './authDomains';



export const DEFAULT_CONFIG =  ()=>{
  return {
  SCOPE: 'openid profile',
  RESPONSE_TYPE: 'code',
  REDIRECT_URI: 'healthapp://login-result',
  SILENT_REDIRECT_URI: 'healthapp://login-result',
  URL: `${AUTH_DOMAINS[IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] ? IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] : 'development']}/as/authorization.oauth2`,
  SERVER: `${AUTH_DOMAINS[IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] ? IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] : 'development']}/ext/sso`,
  LOGOUT_URI: `${AUTH_DOMAINS[IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] ? IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] : 'development']}/idp/startSLO.ping`,
  TOKEN_URI: `${AUTH_DOMAINS[IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] ? IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig['APP_ENV'] : 'development']}/as/token.oauth2`,
  CODE_CHALLENGE_METHOD: 'S256'
  }
};
