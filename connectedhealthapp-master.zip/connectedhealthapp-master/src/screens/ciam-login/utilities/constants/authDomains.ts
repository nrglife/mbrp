export enum AUTH_DOMAINS {
    development = 'https://sso-test.changehealthcare.com',
    qa = 'https://sso-test.changehealthcare.com',
    testing = 'https://sso-test.changehealthcare.com',
    cert = 'https://sso-cert.changehealthcare.com',
    production = 'https://sso.changehealthcare.com'
  }