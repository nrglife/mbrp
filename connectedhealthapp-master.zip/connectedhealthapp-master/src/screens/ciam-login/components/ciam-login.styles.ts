import { StyleSheet } from 'react-native';
//globals styles
import { globals } from '../../../globals';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  }
});
