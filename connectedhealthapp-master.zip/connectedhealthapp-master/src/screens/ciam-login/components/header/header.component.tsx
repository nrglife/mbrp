import React, { FC } from 'react';
import { Text, View } from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { useStores } from '../../../../hooks/useStores';
import { styles as styleCreator } from './header.styles';

export interface IHeaderURL {
  protocol: string;
  domain: string;
  endpoints: string[];
  params: string;
}

interface WebViewHeaderUrlProps {
  url: IHeaderURL;
}
export const WebViewHeaderUrl: FC<WebViewHeaderUrlProps> = ({ url }) => {
  if (!url) return null;
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);

  const isSecure = url.protocol === 'https';

  return (
    <View style={styles.container}>
      {isSecure && <FontAwesome size={16} name="lock" color="#63ae75" />}
      <Text allowFontScaling={false} numberOfLines={1} style={[styles.url, isSecure && styles.urlSecure, brandingStore.textStyles.styleSmallSemiBold]}>
        {url.domain}
      </Text>
    </View>
  );
};
