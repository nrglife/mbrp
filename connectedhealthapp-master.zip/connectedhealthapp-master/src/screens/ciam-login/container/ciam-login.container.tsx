import React, { FC, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Button, Keyboard, Linking, TouchableOpacity, TouchableWithoutFeedback, useWindowDimensions, View, TextInput } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';

// 3rd party
import { StackActions, useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

// developed
import { CIAMLoginComponent } from '../components/ciam-login.component';
import { AuthConfig, getAccessToken, getCodeForExchange, parseUrl, SOURCE } from '../utilities/auth';
import { IHeaderURL, WebViewHeaderUrl } from '../components/header/header.component';
import { EnrollmentNavigationRoutes, LoginNavigationRoutes } from '../../../routes';
import { useStores } from '../../../hooks/useStores';
import { ENROLLED_KEY } from '../../../utilities/async-storage-keys';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../../components/Loader';
import { ErrorContainer, ErrorContainerProps } from '../../enrollment/containers';
import { observer } from 'mobx-react';
import withDevScreenLoadSupport from '../../../HOCs/withDevScreenLoadSupport';
import WebView from 'react-native-webview';
import { IocContainer, IocTypesMobile } from '../../../iocTypes';

import { ConsentApi, EnrollmentApi } from '@healthcareapp/connected-health-common-services';

import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { i18nReloadTranslations } from '../../../../i18n';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

export enum EnrollmentStatuses {
  Pending = 'Pending',
  InvitationCodeValidated = 'InvitationCodeValidated',
  PersonalInfoValidated = 'PersonalInfoValidated',
  PassCodeSent = 'PassCodeSent',
  PassCodeValidated = 'PassCodeValidated',
  Enrolled = 'Enrolled'
}

export type EnrollmentStatus = { isEnrolled: boolean; isUnauthorized: boolean; status: string; isSkipped: boolean };

interface LoginErrorProps extends ErrorContainerProps {
  buttonText: string;
  buttonClickHandler: () => void;
}
const LoginError: FC<LoginErrorProps> = ({ title, messageBody, buttonText, buttonClickHandler, ...props }) => {
  const { generalStore } = useStores();
  const { t } = useTranslation('translation');

  const contactUsHandler = useCallback(() => {
    generalStore.contactUsSheetRef.current.open();
  }, [generalStore.contactUsSheetRef]);

  return (
    <ErrorContainer
      title={title || t(LocaleKeys.errors.something_went_wrong)}
      messageBody={messageBody || t(LocaleKeys.errors.unable_to_log_you_in)}
      ok={{
        label: buttonText,
        func: buttonClickHandler
      }}
      footer={{
        pt1: t(LocaleKeys.errors.for_help),
        onClick: contactUsHandler,
        link: t(LocaleKeys.errors.contact_us)
      }}
      {...props}
    />
  );
};

const debug = false;
interface CIAMLoginContainerProps {
  onDeveloperAreaPressHandler: () => {};
}
const CIAMLoginContainer: FC<CIAMLoginContainerProps> = observer(({ onDeveloperAreaPressHandler }) => {
  const { generalStore, payerStore, brandingStore, imageStore, appConfigStore } = useStores();
  const [isWebViewLoading, setIsWebViewLoading] = useState(true);
  //const [isWebViewReloading, setIsWebViewReloading] = useState(false);
  const [isLoginError, setLoginError] = useState<boolean>(false);

  const [isNotEnrolled, setNotEnrolled] = useState<boolean>(false);
  const [loginErrorTitle, setLoginErrorTitle] = useState<string>('');
  const [loginErrorMessageBody, setLoginErrorMessageBody] = useState<string>('');
  const inputRef = useRef<TextInput>();
  const contactUsHandler = () => {
    generalStore.contactUsSheetRef.current.open();
  };
  const onContactUs = useCallback(contactUsHandler, [generalStore.contactUsSheetRef]);

  const navigation = useNavigation();

  const navigateTo = useCallback(
    (route: EnrollmentNavigationRoutes) => {
      navigation.dispatch(StackActions.push(route));
      //navigation.dispatch(StackActions.replace(route));
    },
    [navigation]
  );

  const [webViewKey, setWebViewKey] = useState<number>(1);
  const [headerURL, setHeaderURL] = useState<IHeaderURL | null>(null);

  const { t } = useTranslation('translation');
  // const { isLoading } = useAppCheckVersion();
  //const isIos = useIsIOS();
  const { width, height } = useWindowDimensions();
  const webref = useRef<WebView>(null);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerShown: !isLoginError,
      headerTitle: () => <WebViewHeaderUrl url={headerURL} />,
      headerLeft: () => (
        <TouchableWithoutFeedback
          onPress={() => {
            onDeveloperAreaPressHandler();
          }}>
          <View style={{ width: 30, height: 30 }} />
        </TouchableWithoutFeedback>
      ),
      headerRight: () => (
        <TouchableOpacity onPress={() => onWebViewReload()}>
          <AntDesign name="reload1" color="#307cf6" size={22} style={{ marginEnd: 10 }} />
        </TouchableOpacity>
      )
    });
  }, [navigation, headerURL, isLoginError, onDeveloperAreaPressHandler]);

  let webErrorTimeOutIDs = useRef<NodeJS.Timeout[]>([]);

  const onWebViewReload = () => {
    setWebViewKey(prevKey => prevKey + 1);
    //setIsWebViewReloading(true);
  };

  /**
   *
   * @param code POST SIGN IN
   *
   */

  const getConsent = useCallback(async () => {
    generalStore.setConsentInProgress(false);
    try {
      const response = await IocContainer.get<ConsentApi>(IocTypesMobile.ConsentApi).getConsent({ errorHandlerParam: navigateTo });

      if (!response || !response.data) {
        throw new Error('getConsent EMPTY RESPONSE');
      }

      const data = response.data;

      if (response.status === HTTP_STATUS_CODES.SUCCESS && data?.data?.consentFlag === true) {
        // userStore.setUserToken({ isEnrolled: true, isConsent: true, hashResponse: hashParams });
        generalStore.setIsTokenAvailable(true);
        !!data?.data?.consentedAt && generalStore.setConsentDate(data?.data?.consentedAt);

        // setIsWebViewLoading(false);
        // navigateToAppRouter(); // Navigate home
      } else if (data?.success) {
        generalStore.setConsentInProgress(true);
        generalStore.setIsTokenAvailable(true);
        // userStore.setUserToken({ isEnrolled: true, isConsent: false, hashResponse: hashParams });
        setIsWebViewLoading(false);

        navigation.dispatch(StackActions.replace(LoginNavigationRoutes.TermsAndConditions /*, { token: token }*/));
      } else {
        throw { message: 'consent error' };
      }
    } catch (error) {
      if (error.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        setIsWebViewLoading(false);
        setLoginError(true);
        generalStore.logout();
      } else {
        setIsWebViewLoading(false);
        setLoginError(false);
        generalStore.logout();
        onWebViewReload();
      }
      // userStore.setUserToken({ isEnrolled: true, isConsent: null, hashResponse: hashParams });
    }
  }, [generalStore, navigateTo, navigation]);

  const getEnrollment = useCallback(async () => {
    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).getEnrollment({});

      if (!response || !response.data) {
        throw new Error('getEnrollment EMPTY RESPONSE');
      }

      const data = response.data;

      if (response.status === HTTP_STATUS_CODES.SUCCESS && data?.data?.enrollmentStatus === EnrollmentStatuses.Enrolled) {
        const firstCustomerId = data?.data?.customerId[0];
        if (!!firstCustomerId) {
          await payerStore.loadPayerFullData(firstCustomerId, { loadConfig: true, waitForAllLoadingTasks: true, loadTheme: true, loadImageLogos: true, loadDocuments: false, useStorageCache: false });
          await i18nReloadTranslations();
        }
        getConsent();
      } else if (data?.success) {
        //userStore.setUserToken({ isEnrolled: false, isConsent: null, hashResponse: hashParams });
        setIsWebViewLoading(false);
        setLoginErrorTitle('You are not enrolled');
        setLoginErrorMessageBody('You are not enrolled to Connected Health yet, Please enroll.');
        setNotEnrolled(true);
        setLoginError(true);
        generalStore.logout();
      } else {
        throw { message: 'enrollment error' };
      }
    } catch (error) {
      //userStore.setUserToken({ isEnrolled: null, isConsent: null, hashResponse: hashParams });
      console.log('getEnrollment ERROR ', error);
      setIsWebViewLoading(false);
      setLoginError(true);
      generalStore.logout();
    }
  }, [imageStore, brandingStore, payerStore, generalStore, getConsent]);

  const _exchangeCode = useCallback(
    async (code: string) => {
      try {
        setIsWebViewLoading(true);
        const accessTokenDetails = await getAccessToken(code);

        if (accessTokenDetails && !accessTokenDetails.error) {
          //console.log({ ...accessTokenDetails });
          if (generalStore.isValidToken(accessTokenDetails)) {
            generalStore.setTokens(accessTokenDetails);
            getEnrollment();
          } else {
            throw { message: 'token is invalid' };
          }
        } else {
          throw { message: 'error in getting the token' };
        }
      } catch (err) {
        // console.log(err);
        setIsWebViewLoading(false);
        setLoginError(true);
        generalStore.logout();
      }
    },
    [generalStore, getEnrollment]
  );
  const linkHandler = useCallback(
    ({ url }) => {
      // setIsWebViewLoading(false);
      if (url.startsWith(AuthConfig().REDIRECT_URI)) {
        inputRef.current.focus();
        Keyboard.dismiss();
        const code = getCodeForExchange(url);
        _exchangeCode(code);
      } else {
        setIsWebViewLoading(false);
      }
    },
    [_exchangeCode]
  );

  useEffect(() => {
    const subscribe = Linking.addEventListener('url', linkHandler);
    return () => subscribe.remove();
  }, [linkHandler]);

  const openExternalLink = (req: any) => {
    return !!req && !!req.url && req.url.search('https://') !== -1;
  };

  const _onWebViewError = () => {
    // in case net::ERR_NAME_NOT_RESOLVED error:
    // Android: after this method -> _onWebViewLoadEnd called
    // iOS: this method is NOT called -> _onWebViewLoadEnd called

    setIsWebViewLoading(false);
  };

  const _onWebViewLoadStart = ({ nativeEvent }) => {
    setIsWebViewLoading(true);

    let timeout = !isNaN(+appConfigStore.appConfig['APP_WEBVIEW_SIGNIN_LOAD_TIMEOUT']) ? Number(appConfigStore.appConfig['APP_WEBVIEW_SIGNIN_LOAD_TIMEOUT']) : 25 * 1000;

    const id = setTimeout(() => {
      _onWebViewError();
    }, timeout);

    webErrorTimeOutIDs.current.push(id);

    const parsedUrl = parseUrl(nativeEvent.url);
    setHeaderURL(parsedUrl);
  };

  const _onWebViewLoadEnd = ({ nativeEvent }) => {
    if (generalStore.logoutRequest) {
      generalStore.clearLogoutRequest();
      return;
    }

    if ((nativeEvent.domain && nativeEvent.domain === 'NSURLErrorDomain') || (nativeEvent.description && nativeEvent.description === 'net::ERR_NAME_NOT_RESOLVED')) {
      return;
    }

    // this check is for android
    if (!nativeEvent.url.startsWith(AuthConfig().REDIRECT_URI)) {
      setIsWebViewLoading(false);
      //setIsWebViewReloading(false);
    }

    clearTimeOut();
  };

  const clearTimeOut = useCallback(() => {
    for (const timeOutID of webErrorTimeOutIDs.current) {
      // console.log('Clear web view time out error function - id - ', timeOutID);
      clearTimeout(timeOutID);
    }
  }, [webErrorTimeOutIDs]);

  useEffect(() => {
    return clearTimeOut;
  }, [clearTimeOut]);

  const onButtonClickHandler = () => {
    setIsWebViewLoading(true);
    setLoginError(null);
    onWebViewReload();
  };

  const navigateToEnrollment = () => {
    AsyncStorage.removeItem(ENROLLED_KEY);
    generalStore.setEnrollmentComplete(false);
  };

  return (
    <>
      <TextInput style={{ position: 'absolute', opacity: 0 }} ref={inputRef}></TextInput>
      {debug ? <Button title={'next'} onPress={() => navigation.dispatch(StackActions.replace(LoginNavigationRoutes.TermsAndConditions))}></Button> : null}
      {isLoginError ? (
        <LoginError
          title={loginErrorTitle}
          messageBody={loginErrorMessageBody}
          buttonText={isNotEnrolled ? 'Enroll' : 'OK'}
          buttonClickHandler={isNotEnrolled ? navigateToEnrollment : onButtonClickHandler}
          footer={{
            pt1: t(LocaleKeys.errors.for_help),
            onClick: onContactUs,
            link: t(LocaleKeys.errors.contact_us)
          }}
        />
      ) : (
        <CIAMLoginComponent
          key={`ciam-login_${webViewKey}`}
          source={generalStore.logoutRequest ? { uri: AuthConfig().LOGOUT_URI } : SOURCE}
          ref={webref}
          webViewStyles={{ height, width }}
          onShouldStartLoadWithRequest={openExternalLink}
          onError={_onWebViewError}
          onLoadStart={_onWebViewLoadStart}
          onLoadEnd={_onWebViewLoadEnd}
          renderLoadingComponent={<Loader isLoading={isWebViewLoading} />}
        />
      )}
    </>
  );
});
export default withDevScreenLoadSupport(CIAMLoginContainer);
