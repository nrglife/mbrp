import { ImageStyle, StyleSheet, TextStyle, ViewStyle } from 'react-native';
import { globals } from '../../../../globals';

import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    mainContainer: { flex: 1 },
    container: { flex: 1, alignItems: 'center', padding: 30 },
    logoAndTitleContainer: { marginTop: 124, paddingHorizontal: 20, justifyContent: 'center', alignItems: 'center' },
    textStyle: { marginTop: 16, textAlign: 'center', color: store.currentTheme.tooltip }
  });
};
