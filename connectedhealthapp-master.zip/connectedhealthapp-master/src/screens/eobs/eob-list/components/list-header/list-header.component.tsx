import React from 'react';
import { View, Text } from 'react-native';
import { useStores } from '../../../../../hooks/useStores';

import { styles as styleCreator } from './list-header.styles';
import { Blink } from '../../../../../components/AppSkeletonText';

export const ListHeader = () => {
  const { brandingStore, delegateStore } = useStores();
  const styles = styleCreator(brandingStore, delegateStore);
  return (
    <View style={[styles.sectionContainer]}>
      <Text style={[styles.textStyle, brandingStore.textStyles.styleXSmallRegular]}>Keep track of your annual healthcare spending, insurance coverage, and deductible status.</Text>
    </View>
  );
};
