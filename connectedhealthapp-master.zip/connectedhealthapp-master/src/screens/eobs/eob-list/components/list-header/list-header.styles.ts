import { DelegateStore } from '@healthcareapp/connected-health-common-services';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { StyleSheet } from 'react-native';
import { DELEGATE_SELECTOR_HEIGHT } from '../../../../../components/DelegationPickerContainer/delegation-picker.container';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile, delegateStore: DelegateStore) => {
  return StyleSheet.create({
    sectionContainer: {
      paddingHorizontal: 20,
      paddingTop: 15,
      paddingBottom:10,
      marginTop: (delegateStore.state == DelegateStoreState.Running || delegateStore.state == DelegateStoreState.RunningShowError) && delegateStore.delegateMenu ? DELEGATE_SELECTOR_HEIGHT : 0
    },
    textStyle: { color: '#656C73' }
  });
};
