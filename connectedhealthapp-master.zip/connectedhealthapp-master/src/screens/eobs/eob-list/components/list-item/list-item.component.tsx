import React, { FC } from 'react';
import { GestureResponderEvent, Platform, Text, TouchableOpacity, View } from 'react-native';
import { EOBStore } from '@healthcareapp/connected-health-common-services';
import { EobDate } from '../eob-date/eob-date.component';
import { EOBPrice } from '../../../components/eob-price/eob-price.component';

import { styles as styleCreator } from './list-item.styles';
import { useStores } from '../../../../../hooks/useStores';
import { CHTouchableOpacity } from '../../../../../components';

const PractinionerName: FC<{ practitionerName: string }> = ({ practitionerName = '' }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  if (!practitionerName) return <Text style={[styles.unavailableTextStyle, brandingStore.textStyles.styleLargeRegular]}>Practitioner unavailable</Text>;
  return <Text style={[styles.nameTextStyle, brandingStore.textStyles.styleLargeSemiBold]}>{practitionerName}</Text>;
};

interface ListItemProps {
  item: EOBStore;
  onSelected: (event: GestureResponderEvent) => void;
  isLoading: boolean;
  last?: boolean;
}

export const ListItem: FC<ListItemProps> = ({ item, onSelected, last }) => {
  const { brandingStore } = useStores();

  const styles = styleCreator(brandingStore);

  return (
    <CHTouchableOpacity style={styles.touchableOpacity} pressedColor={brandingStore.currentTheme.backgroundMedium} pressedColorOpacity={0.5} onPress={onSelected}>
      <View style={styles.listItemSectionContainer}>
        <View style={styles.listItemContainer}>
          <View style={styles.singleRow}>
            <View style={styles.leftSectionContainer}>
              <PractinionerName practitionerName={item.performingPractitionerFullName} />
            </View>
            <View style={styles.rightSectionContainer}>
            <EOBPrice 
              amount={item.estimatedBalance?.amount} 
              isComplete={item.estimatedBalance?.isComplete}
              isContainUnknownCurrency={item.estimatedBalance?.isContainUnknownCurrency}
              isForeignCurrencyExist={item.isForeignCurrencyExist} />
            </View>
          </View>
          <View style={[styles.singleRow, { marginTop: 4 }]}>
            <View style={styles.leftSectionContainer}>
              {!!item.patientName ? (
                <Text style={[styles.userNameTextStyle, brandingStore.textStyles.styleSmallRegular]}>{`for ${item.patientName}`}</Text>
              ) : (
                <Text style={[styles.userNameTextStyle, brandingStore.textStyles.styleSmallRegular]}>
                  <Text style={[styles.userNameTextStyle, brandingStore.textStyles.styleSmallRegular]}>for</Text>{' '}
                  <Text style={[styles.unavailableTextStyle, brandingStore.textStyles.styleSmallRegular]}>Member unavailable</Text>
                </Text>
              )}
            </View>
            <View style={styles.rightSectionContainer}>
              <EobDate type="list" date={item.EOBDate} seperator={'\n- '} />
            </View>
          </View>
        </View>
      </View>
      {!last ? (
        <View
          style={{
            marginLeft: 20,
            borderBottomColor: 'grey',
            borderBottomWidth: Platform.OS === 'android' ? 1 : 0.5
          }}
        />
      ) : null}
    </CHTouchableOpacity>
  );
};
