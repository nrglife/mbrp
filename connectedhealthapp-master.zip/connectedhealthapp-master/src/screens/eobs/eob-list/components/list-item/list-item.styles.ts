import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    touchableOpacity: { backgroundColor: store.currentTheme.white },
    listItemSectionContainer: { paddingLeft: 20, paddingRight: 15, paddingBottom: 15, paddingTop: 19, flexDirection: 'row' },
    listItemContainer: { flexDirection: 'column' },
    leftSectionContainer: { flexGrow: 0, flexBasis: '60%', paddingRight: 5 },
    nameTextStyle: {
      color: store.currentTheme.blackMain
    },
    userNameTextStyle: {
      marginTop: 0,
      color: store.currentTheme.tooltip
    },
    rightSectionContainer: { alignItems: 'flex-end', flexGrow: 0, flexBasis: '40%', paddingLeft: 5 },
    unavailableTextStyle: {
      fontStyle: 'italic',
      color: store.currentTheme.label
    },
    singleRow: { flexDirection: 'row', width: '100%', alignItems: 'flex-start' }
  });
};
