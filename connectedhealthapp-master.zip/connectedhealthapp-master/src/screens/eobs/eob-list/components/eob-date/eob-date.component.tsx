import React, { FC } from 'react';
import { Text } from 'react-native';
import { Period } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { styles as styleCreator } from './eob-date.styles';
import { formattedDate } from './utils';
import { useStores } from '../../../../../hooks/useStores';

interface EobDateProps {
  date: Period;
  seperator: string;
  type: 'list' | 'details';
}

export const EobDate: FC<EobDateProps> = ({ type, date, seperator = ' - ' }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <Text style={type === 'details' ? [styles.dateTextStyleDetails, brandingStore.textStyles.styleLargeSemiBold] : [styles.dateTextStyleList, brandingStore.textStyles.styleSmallRegular]}>
      {formattedDate(date, seperator)}
    </Text>
  );
};
