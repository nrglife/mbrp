import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    dateTextStyleList: {
      color: store.currentTheme.tooltip,
      textAlign: 'right'
    },
    dateTextStyleDetails: {
      color: store.currentTheme.blackMain,
      textAlign: 'right'
    }
  });
};
