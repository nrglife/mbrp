import { formatDate, isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import { Period } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';

export const formattedDate = (date: Period, separator: string = ' ') => {
  if (typeof date === 'string') {
    return isValidDate(date) ? formatDate(date, 'MMM DD, YYYY') : null;
  }
  if (typeof date === 'object') {
    if (!isValidDate(date?.start) && !isValidDate(date?.end)) return '';
    if (!isValidDate(date?.start)) {
      // return end date because there is no start date
      return `${formatDate(date?.end, 'MMM DD, YYYY')}`;
    }
    if (!isValidDate(date?.end)) {
      // return start date because there is no end date
      return `${formatDate(date?.start, 'MMM DD, YYYY')}`;
    }
    // return BOTH end date and start date
    if (formatDate(date?.start) === formatDate(date?.end)) {
      return `${formatDate(date?.start, 'MMM DD, YYYY')}`;
    }
    return `${[formatDate(date?.start, 'MMM DD, YYYY'), formatDate(date?.end, 'MMM DD, YYYY')].join(separator)}`;
  }

  return null;
};
