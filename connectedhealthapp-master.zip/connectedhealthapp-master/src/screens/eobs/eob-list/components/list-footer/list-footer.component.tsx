import React, { FC } from 'react';
import { View } from 'react-native';

import { styles } from './list-footer.styles';
import { Questions } from '../../../components/questions.component';

interface ListFooterProps {}
export const ListFooter: FC<ListFooterProps> = props => {
  return (
    <View style={styles.container}>
      <Questions />
    </View>
  );
};
