import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: { paddingLeft: 19, paddingBottom: 42, paddingTop: 43, backgroundColor: 'white' }
});
