import React, { FC } from 'react';
import { View, Text } from 'react-native';
import { useStores } from '../../../../../hooks/useStores';
import { BrandingTheme } from '../../../../../stores/BrandingStoreMobile';

import { styles as styleCreator } from './list-column-header.styles';
import { Blink } from '../../../../../components/AppSkeletonText';

export const ListColumnHeader: FC<{ theme: BrandingTheme; isLoading: boolean }> = ({ theme, isLoading }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <View style={[styles.listItemHeaderContainerStyle, { backgroundColor: theme.backgroundLight }]}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={[styles.text, brandingStore.textStyles.styleXSmallRegularCaps]}>service</Text>
        <Text style={[styles.text, brandingStore.textStyles.styleXSmallRegularCaps]}>total balance</Text>
      </View>
    </View>
  );
};
