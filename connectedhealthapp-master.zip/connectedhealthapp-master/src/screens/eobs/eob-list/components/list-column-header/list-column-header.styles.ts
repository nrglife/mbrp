import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';


export const styles =  (store: BrandingStoreMobile)=>{


  return StyleSheet.create({
    listItemHeaderContainerStyle: {
      paddingTop: 10,
      paddingLeft: 20,
      paddingRight: 15,
      paddingBottom: 7
    },
    text: {  color: store.currentTheme.tooltip }

})
}
