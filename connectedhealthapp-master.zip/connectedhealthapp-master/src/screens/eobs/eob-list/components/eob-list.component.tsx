import React, { FC, useEffect, useState } from 'react';
import { observer } from 'mobx-react';
import { Text, View, ActivityIndicator, FlatList, RefreshControl, GestureResponderEvent, Image, Platform, ViewStyle, TouchableOpacity, NativeSyntheticEvent, NativeScrollEvent } from 'react-native';
import { NavigationProp } from '../../../../models/navigation';
import { styles as stylesCreator } from './eob-list.styles';
import { styles as itemStylesCreator } from './list-item/list-item.styles';
import { useStores } from '../../../../hooks/useStores';
import { ListItem } from './list-item/list-item.component';
import { ListHeader } from './list-header/list-header.component';
import { EOBStore, EOBStoreType } from '@healthcareapp/connected-health-common-services';
import { EmptyList } from '../../../../components/empty-list/empty-list.component';
import { ListColumnHeader } from './list-column-header/list-column-header.component';
import images from '../../../../assets/images/images';
import { Blink } from '../../../../components/AppSkeletonText';
import { EOBPrice } from '../../components/eob-price/eob-price.component';
import { EobDate } from './eob-date/eob-date.component';
import { styles as styleCreator } from './list-item/list-item.styles';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';
import { IocContainer, IocTypesMobile } from '../../../../iocTypes';
import AppConfigStore from '../../../../stores/AppConfigStore';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { NextPageSkeletonWrapper } from '../../../../components';

interface EobListProps extends NavigationProp {
  eobs: null | EOBStore[];
  isLoading: boolean;
  onRefresh: () => void;
  isRefreshing: boolean;
  loadingNextPage: boolean;
  apiErrorNextPage: boolean;
  onScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
  onSelected: (event: GestureResponderEvent, eob: EOBStoreType) => void;
}

export const EobList: FC<EobListProps> = observer(({ navigate, onSelected, isRefreshing, onRefresh, eobs, isLoading, loadingNextPage, apiErrorNextPage, onScroll }) => {
  const { brandingStore, eobsListStore, appConfigStore, delegateStore } = useStores();
  const { t } = useTranslation('translation');
  const textStyles = brandingStore.textStyles;
  const styles = stylesCreator(brandingStore);
  const itemStyles = itemStylesCreator(brandingStore);
  const eobsData = eobs && eobs.length > 0 ? [{ uuid: 'header' }, ...eobs] : [];

  const renderItem = (item, index, isLoading, last) => {
    if (index === 0) {
      return <ListColumnHeader isLoading={isLoading} theme={brandingStore.currentTheme} />;
    }
    return <ListItem isLoading={isLoading} onSelected={event => onSelected(event, item)} item={item} last={last} />;
  };

  const [onEndReachedCalledDuringMomentum, setOnEndReachedCalledDuringMomentum] = useState(false);
  return (
    <View style={[styles.mainContainer, { backgroundColor: brandingStore.currentTheme.backgroundLight }]}>
      {!isLoading ? (
        <FlatList
          bounces={true}
          onScroll={onScroll}
          keyboardShouldPersistTaps="always"
          style={{ display: !isLoading ? 'flex' : 'none' }}
          ListEmptyComponent={() => (
            <EmptyList>
              <View style={styles.logoAndTitleContainer}>
                <Image source={delegateStore.isMemberConsentIn12HoursRange ? images.clock : images.no_content} resizeMode="cover" style={{ tintColor: brandingStore.currentTheme.tooltip }} />
                <Text style={[styles.textStyle, textStyles.styleSmallSemiBold]}>
                  {delegateStore.isMemberConsentIn12HoursRange ? t(LocaleKeys.errors.data_still_loading) : t(LocaleKeys.errors.no_eobs_to_show_yet)}
                </Text>
              </View>
              <Text style={[styles.textStyle, textStyles.styleSmallRegular, { marginTop: 45, maxWidth: 288 }]}>{t(LocaleKeys.screens.EOBs.page_header_subtitle_text)}</Text>
            </EmptyList>
          )}
          maxToRenderPerBatch={Math.ceil(eobsData.length / 2)}
          windowSize={eobsData.length > 0 ? Math.ceil(eobsData.length / 2) : 1}
          refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} />}
          data={eobsData}
          keyExtractor={item => `${item.uuid}`}
          contentContainerStyle={{ flexGrow: 1 }}
          removeClippedSubviews={
            // Subview clipping causes issues with sticky headers on Android and
            // would be hard to fix properly in a performant way.
            Platform.OS !== 'android'
          }
          ListFooterComponent={() => {
            return (
              <EobsNextPageSkeleton
                nextPageError={apiErrorNextPage}
                loadNextPage={() => {
                  eobsListStore.getNextPage({}, true);
                }}
                itemStyles={itemStyles}
                loadingNextPage={loadingNextPage}
                numberOfItems={1}
              />
            );
          }}
          onEndReached={() => {
            if (!isLoading && !loadingNextPage && !onEndReachedCalledDuringMomentum && !apiErrorNextPage) {
              eobsListStore.getNextPage({ numberOfRetries: 2 }, false);
              setOnEndReachedCalledDuringMomentum(true);
            }
          }}
          ListFooterComponentStyle={{ flex: 1 }}
          onMomentumScrollBegin={() => {
            setOnEndReachedCalledDuringMomentum(false);
          }}
          onEndReachedThreshold={0.5}
          disableIntervalMomentum={true}
          ListHeaderComponent={eobsData.length > 0 && ListHeader}
          ItemSeparatorComponent={({ highlighted, leadingItem }) => <View style={{ marginLeft: 20 }} />}
          stickyHeaderIndices={[1]}
          renderItem={({ item, index }) => renderItem(item, index, isLoading, eobsData && eobsData.length - 1 == index)}
        />
      ) : (
        <InitialSkeleton isLoading={isLoading} brandingStore={brandingStore} itemStyles={itemStyles} numberOfItems={8} />
      )}

      {/*{loadingNextPage && <NextPageSkeleton itemStyles={itemStyles} loadingNextPage={loadingNextPage} />}*/}
    </View>
  );
});

const EobsNextPageSkeleton: React.FC<{
  nextPageError: boolean;
  loadNextPage: () => void;
  itemStyles: {
    unavailableTextStyle: { color: string; fontStyle: 'italic' };
    touchableOpacity: { backgroundColor: string };
    rightSectionContainer: { flexGrow: number; alignItems: 'flex-end'; flexBasis: string; paddingLeft: number };
    userNameTextStyle: { color: string; marginTop: number };
    listItemSectionContainer: { paddingBottom: number; flexDirection: 'row'; paddingRight: number; paddingTop: number; paddingLeft: number };
    listItemContainer: { flexDirection: 'row'; justifyContent: 'space-between' };
    leftSectionContainer: { flexGrow: number; paddingRight: number; flexBasis: string };
    nameTextStyle: { color: string };
    singleRow: ViewStyle;
  };
  loadingNextPage: boolean;
  numberOfItems: number;
}> = ({ itemStyles, loadingNextPage, numberOfItems, loadNextPage, nextPageError }) => {
  return (
    <NextPageSkeletonWrapper loadingNextPage={loadingNextPage} loadNextPage={loadNextPage} nextPageError={nextPageError}>
      {new Array(numberOfItems).fill(1).map((_, index) => {
        return (
          <View key={index.toString()}>
            <View style={{ marginLeft: 20, borderBottomColor: 'grey', borderBottomWidth: 0.5 }} />
            <View style={itemStyles.listItemSectionContainer}>
              <View style={itemStyles.listItemContainer}>
                <View style={itemStyles.singleRow}>
                  <View style={itemStyles.leftSectionContainer}>
                    <Blink visible={true} height={20} width={170} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                  <View style={itemStyles.rightSectionContainer}>
                    <Blink visible={true} height={20} width={73} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                </View>
                <View style={itemStyles.singleRow}>
                  <View style={itemStyles.leftSectionContainer}>
                    <Blink visible={true} height={20} width={170} shimmerStyle={{ borderRadius: 4 }} />
                  </View>
                  <View style={itemStyles.rightSectionContainer}>
                    <Blink visible={true} height={20} width={103} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                </View>
              </View>
            </View>
          </View>
        );
      })}
    </NextPageSkeletonWrapper>
  );
};

const InitialSkeleton: React.FC<{
  isLoading: boolean;
  numberOfItems: number;
  brandingStore: BrandingStoreMobile;
  itemStyles: {
    unavailableTextStyle: { color: string; fontStyle: 'italic' };
    touchableOpacity: { backgroundColor: string };
    rightSectionContainer: { flexGrow: number; alignItems: 'flex-end'; flexBasis: string; paddingLeft: number };
    userNameTextStyle: { color: string; marginTop: number };
    listItemSectionContainer: { paddingBottom: number; flexDirection: 'row'; paddingRight: number; paddingTop: number; paddingLeft: number };
    listItemContainer: { flexDirection: 'row'; justifyContent: 'space-between' };
    leftSectionContainer: { flexGrow: number; paddingRight: number; flexBasis: string };
    nameTextStyle: { color: string };
    singleRow: ViewStyle;
  };
}> = ({ isLoading, brandingStore, itemStyles, numberOfItems }) => {
  return (
    <>
      <Blink
        visible={true}
        height={61}
        width={372}
        style={{
          borderRadius: 4,
          marginBottom: 20,
          alignSelf: 'center',
          marginTop: 16,
          paddingHorizontal: 19,
          paddingVertical: 15
        }}
      />
      <View
        style={[
          {
            paddingLeft: 19,
            paddingRight: 19,
            paddingBottom: 7
          },
          { backgroundColor: brandingStore.currentTheme.backgroundLight }
        ]}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Blink visible={true} height={16} width={75} style={{ borderRadius: 4, marginBottom: 13 }} />

          <Blink visible={true} height={16} width={75} style={{ borderRadius: 4, marginBottom: 13 }} />
        </View>
      </View>
      {new Array(numberOfItems).fill(0).map((_, index) => {
        return (
          <View style={{ backgroundColor: 'white' }} key={index.toString()}>
            <View style={itemStyles.listItemSectionContainer}>
              <View style={itemStyles.listItemContainer}>
                <View style={itemStyles.singleRow}>
                  <View style={itemStyles.leftSectionContainer}>
                    <Blink visible={true} height={20} width={170} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                  <View style={itemStyles.rightSectionContainer}>
                    <Blink visible={true} height={20} width={73} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                </View>
                <View style={itemStyles.singleRow}>
                  <View style={itemStyles.leftSectionContainer}>
                    <Blink visible={true} height={20} width={170} shimmerStyle={{ borderRadius: 4 }} />
                  </View>
                  <View style={itemStyles.rightSectionContainer}>
                    <Blink visible={true} height={20} width={103} shimmerStyle={{ borderRadius: 4, marginBottom: 7 }} />
                  </View>
                </View>
              </View>
            </View>
            {index != numberOfItems - 1 ? <View style={{ marginLeft: 20, borderBottomColor: 'grey', borderBottomWidth: 0.5 }} /> : null}
          </View>
        );
      })}
    </>
  );
};
