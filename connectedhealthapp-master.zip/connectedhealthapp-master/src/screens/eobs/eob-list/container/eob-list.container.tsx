import { EOBStoreType, failureSource } from '@healthcareapp/connected-health-common-services';
import { useNavigation } from '@react-navigation/native';
import { observer } from 'mobx-react';
import React, { FC, useEffect, useRef, useState } from 'react';
import { GestureResponderEvent, Image, RefreshControl, Text, View } from 'react-native';
import { useNavigateTo } from '../../../../hooks/useNavigateTo';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentNavigationRoutes, HomeNavigationRoutes } from '../../../../routes';
import { EobList } from '../components/eob-list.component';
import { EmptyList } from '../../../../components/empty-list/empty-list.component';
import { styles as styleCreator } from './eob-list.container.styles';
import images from '../../../../assets/images/images';
import { ScrollView } from 'react-native-gesture-handler';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import { EmptyListContainer } from '../../../../components/EmptyListContainer/empty-list-container';
import { event } from 'react-native-reanimated';
import { DelegationPickerContainer, DelegateSelectorContainerInterface } from '../../../../components/DelegationPickerContainer/delegation-picker.container';

interface EobListContainerProps {}

export const EobListContainer: FC<EobListContainerProps> = observer(props => {
  const { navigate } = useNavigateTo(EnrollmentNavigationRoutes.PersonalInfo);
  const navigation = useNavigation();
  const { brandingStore, eobsListStore, generalStore, errorStore, delegateStore } = useStores();
  const styles = styleCreator(brandingStore);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const containerRef = useRef<DelegateSelectorContainerInterface>(null);
  //const [startedLoad, setStartedLoad] = useState<boolean>(false);
  //const { Container, onMainViewScroll } = useDelegateSelector();

  const { t } = useTranslation('translation');
  // const { loading, eobs, getEOBs, eobsListStore, isError, errorCode } = useGetExplanationsOfBenefits();

  useEffect(() => {
    errorStore.clearError(failureSource.EOB_Get);
    eobsListStore.fetchData({});
    return () => {
      errorStore.clearError(failureSource.EOB_Get);
    };
  }, [delegateStore.selectedDelegateId]);

  /*useEffect(() => {
    if (eobsListStore.loading || eobsListStore.loading || (eobsListStore.eobs && eobsListStore.eobs.length > 0)) {
      setStartedLoad(true);
    }
  }, [eobsListStore.loading, eobsListStore.apiError, eobsListStore.eobs]);*/

  const onRefresh = async () => {
    try {
      setIsRefreshing(true);
      await eobsListStore.fetchData({});
    } finally {
      setIsRefreshing(false);
    }
  };

  const onEobSelected = (event: GestureResponderEvent, eob: EOBStoreType) => {
    eobsListStore.setSelectedEOB(eob);
    navigation.navigate(HomeNavigationRoutes.EobDEtails);
  };

  return (
    <DelegationPickerContainer ref={containerRef}>
      {eobsListStore.initialReqStatus != ReqStatus.ERROR ? (
        <EobList
          onScroll={event => {
            //console.log('this offset', this.offset);
            containerRef.current.onMainViewScroll(event.nativeEvent.contentOffset.y);
          }}
          loadingNextPage={eobsListStore.nextPageStatus == ReqStatus.LOADING}
          apiErrorNextPage={eobsListStore.nextPageStatus == ReqStatus.ERROR}
          onSelected={onEobSelected}
          isLoading={eobsListStore.initialReqStatus == ReqStatus.LOADING || eobsListStore.initialReqStatus == ReqStatus.IDE}
          navigate={navigate}
          eobs={eobsListStore.eobs}
          isRefreshing={isRefreshing}
          onRefresh={onRefresh}
        />
      ) : (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={eobsListStore.initialReqStatus == ReqStatus.LOADING} onRefresh={onRefresh} />}>
          <EmptyListContainer
            containerStyle={styles.logoAndTitleContainer}
            apis={[failureSource.EOB_Get]}
            text={t(LocaleKeys.errors.something_went_wrong) + '.\n' + t(LocaleKeys.errors.please_try_again)}
            image={images.warning_thin}
            imageStyle={{ width: 44, height: 42 }}
            textStyle={styles.textStyle}
            resizeMode="contain"
          />
        </ScrollView>
      )}
    </DelegationPickerContainer>
  );
});
