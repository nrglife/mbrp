import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    titleTextStyle: {
      color: store.currentTheme.blackSecondary
    },
    serviceCharges: {
      color: store.currentTheme.label,
      marginTop: 7
    },
    practitionerTextStyle: {
      color: store.currentTheme.blackMain,
      marginTop: 0
    },
    addressTextStyle: {
      marginTop: 0,
      color: store.currentTheme.blackMain
    },
    contactLinkTextStyle: {
      marginTop: 9
    }
  });
};
