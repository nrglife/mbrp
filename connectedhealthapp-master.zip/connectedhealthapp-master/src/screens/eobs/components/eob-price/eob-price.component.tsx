import React, { FC } from 'react';
import { View, Text, TextStyle } from 'react-native';
import { CurrencyCodes, Money } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { isEmptyString, isValidAmount } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { setNumberPreview } from '../../../../utilities/Money';
import { styles as styleCreator } from './eob-price.styles';
import { useStores } from '../../../../hooks/useStores';

interface IEOBPrice {
  amount: Money | null | undefined;
  isComplete?: boolean;
  withMinus?: boolean;
  currencyStyle?: TextStyle;
  textStyle?: TextStyle;
  isContainUnknownCurrency?: boolean;
  isForeignCurrencyExist?: boolean;

}

export const EOBPrice: FC<IEOBPrice> = ({ amount, isComplete = true, withMinus = false, textStyle, currencyStyle, isContainUnknownCurrency = false, isForeignCurrencyExist = undefined }) => {
  const { brandingStore, eobsListStore } = useStores();
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;

  if (isForeignCurrencyExist === undefined)
    isForeignCurrencyExist = eobsListStore?.selected?.isForeignCurrencyExist;

  if (!isValidAmount(amount, isComplete, isContainUnknownCurrency, isForeignCurrencyExist))
    return <Text style={[styles.amountStyle, textStyles.styleLargeSemiBold, textStyle ? { ...textStyle } : undefined]}>
      {`$ —`}
    </Text>;

  let minusAddition = withMinus === true ? `-` : ``;
  let amountValue = setNumberPreview(amount?.value);

  const amountWithCurrency = amount?.currency?.toUpperCase() === CurrencyCodes.USD ?
    `${minusAddition}$${amountValue}` :
    `${minusAddition}${amountValue} ${amount?.currency?.toUpperCase()}`;

  if (amountWithCurrency.length >= 13) {
    amountValue = amountValue.split('.').join('\n.');
  }
  
  if (amount?.currency?.toUpperCase() === CurrencyCodes.USD ||
  (isEmptyString(amount?.currency) && !!isForeignCurrencyExist === false)) {
    return <Text style={[{ textAlign: 'right' }, styles.amountStyle, textStyles.styleLargeSemiBold, textStyle ? { ...textStyle } : undefined]}>
      {`${minusAddition}$${amountValue}`}
    </Text>;
  }

  return (<View style={{ flexDirection: 'row', alignItems: 'flex-end'}}>
    <Text style={[{ textAlign: 'right' ,padding: 1}, styles.amountStyle, textStyles.styleLargeSemiBold, textStyle ? { ...textStyle } : undefined]}>
      {`${minusAddition}${amountValue}`}
      <Text style={currencyStyle ? currencyStyle : textStyles.styleSmallRegular}>
        {` ${amount?.currency?.toUpperCase()}`}
      </Text>
    </Text>
  </View>
  );
};
