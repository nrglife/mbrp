import React, { FC } from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { getAddressAs2Lines, getTelecom } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { ContactPointSystem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { useStores } from '../../../hooks/useStores';

import { styles as styleCreator } from './questions.styles';
import { callNumber, openEmail } from '../../../utilities/linking';
import { observer } from 'mobx-react';
import { Blink } from '../../../components/AppSkeletonText';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

interface QuestionsProps {}

export const Questions: FC<QuestionsProps> = observer(props => {
  const { eobsListStore, brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;
  const billingAddressIn2Lines = getAddressAs2Lines(eobsListStore.selected?.providerAddress);
  const billingPhoneNumber = eobsListStore.selected?.provider?.telecom ? getTelecom(eobsListStore.selected?.provider?.telecom, ContactPointSystem.Phone) : null;
  const billingEmail = eobsListStore.selected?.provider?.telecom ? getTelecom(eobsListStore.selected?.provider?.telecom, ContactPointSystem.Email) : null;

  const showQuestions =
    ((eobsListStore.selected?.providerFullName && eobsListStore.selected?.providerFullName.trim() !== '') ||
      (!!billingAddressIn2Lines.line1 && billingAddressIn2Lines.line1.trim() !== '') ||
      (!!billingAddressIn2Lines.line2 && billingAddressIn2Lines.line2.trim() !== '') ||
      (!!billingPhoneNumber && billingPhoneNumber.value != null && billingPhoneNumber.value !== '') ||
      (!!billingEmail && billingEmail.value != null && billingEmail.value !== '')) === true;

  const onPhoneNumberPressHandler = (phoneNumber: string) => {
    //console.log('Open DIAL with: ', phoneNumber);
    callNumber(phoneNumber);
  };

  const onEmailPressHandler = (email: string) => {
    //console.log('Open email client with email: ', email);
    openEmail(email);
  };

  if (!showQuestions) return null;

  return (
    <>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={16} width={102} shimmerStyle={{ borderRadius: 4, marginBottom: 10 }}>
        <Text style={[styles.titleTextStyle, textStyles.styleLargeSemiBold]}>Questions?</Text>
      </Blink>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={16} width={156} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        <Text style={[styles.serviceCharges, textStyles.styleSmallRegular]}>Service Charges</Text>
      </Blink>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={21} width={220} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        {!!eobsListStore.selected?.providerFullName && eobsListStore.selected?.providerFullName.trim() !== '' && (
          <Text style={[styles.practitionerTextStyle, textStyles.styleLargeSemiBold]}>{eobsListStore.selected?.providerFullName}</Text>
        )}
      </Blink>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={16} width={95} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        {!!billingAddressIn2Lines.line1 && billingAddressIn2Lines.line1.trim() !== '' && <Text style={[styles.addressTextStyle, textStyles.styleSmallRegular]}>{billingAddressIn2Lines.line1}</Text>}
      </Blink>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={16} width={114} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        {!!billingAddressIn2Lines.line2 && billingAddressIn2Lines.line2.trim() !== '' && <Text style={[styles.addressTextStyle, textStyles.styleSmallRegular]}>{billingAddressIn2Lines.line2}</Text>}
      </Blink>
      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={12} width={114} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        {!!billingPhoneNumber && billingPhoneNumber.value != null && billingPhoneNumber.value !== '' && (
          <TouchableOpacity onPress={() => onPhoneNumberPressHandler(billingPhoneNumber.value)}>
            <Text style={[styles.contactLinkTextStyle, textStyles.styleSmallSemiBoldLink, { color: brandingStore.currentTheme.actionMedium }]}>{billingPhoneNumber.value}</Text>
          </TouchableOpacity>
        )}
      </Blink>

      <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={12} width={114} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
        {!!billingEmail && billingEmail.value != null && billingEmail.value !== '' && (
          <TouchableOpacity onPress={() => onEmailPressHandler(billingEmail.value)}>
            <Text style={[styles.contactLinkTextStyle, textStyles.styleSmallSemiBoldLink, { color: brandingStore.currentTheme.actionMedium }]}>{billingEmail.value}</Text>
          </TouchableOpacity>
        )}
      </Blink>
    </>
  );
});
