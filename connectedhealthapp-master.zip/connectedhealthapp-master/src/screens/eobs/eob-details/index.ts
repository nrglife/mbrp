export { EobDetailsContainer } from './container/eob-details.container';
