import React, { FC, useMemo } from 'react';
import { View, Text } from 'react-native';
import { formatDate, INVALID_DATE, isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import { EOB } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
import { IdentifierCodeType } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { observer } from 'mobx-react';
import { useStores } from '../../../../../hooks/useStores';

import { styles as styleCreator } from './reference.styles';
//Reference#: should be mapped to the EOB.identifier under the following conditions:
//if there are only two items in the array,
//take the value of EOB.identifier where type is different from "HDC_RECORD_UUID"
const getReferenceNum = (eob: EOB | undefined) => {
  try {
    const referenceNum: string | null | undefined = eob?.identifier?.length === 1 && eob?.identifier[0] ? eob.identifier[0]?.value : null;
    return referenceNum;
  } catch (error) {
    return null;
  }
};

export const Reference: FC = observer(props => {
  const { eobsListStore, brandingStore } = useStores();
  const styles = styleCreator(brandingStore);

  const referenceNum = getReferenceNum(eobsListStore.selected?.eob);
  const eobCreationDate = useMemo(() => (isValidDate(eobsListStore.selected?.eob?.created) ? formatDate(eobsListStore.selected?.eob?.created) : null), [eobsListStore.selected]);

  const eobReferenceLabel = referenceNum != null && referenceNum !== '' ? `Reference: ${referenceNum}` : '';
  const eobCreationDateLabel = eobCreationDate != null && eobCreationDate !== INVALID_DATE && eobCreationDate !== '' ? eobCreationDate : '';

  const eobReferenceLabelAndDate = eobReferenceLabel ? (eobCreationDateLabel ? `${eobReferenceLabel}, ${eobCreationDate}` : eobReferenceLabel) : eobCreationDateLabel;
  return (
    <View>
      {eobReferenceLabelAndDate && eobReferenceLabelAndDate.trim() !== '' && (
        <Text style={[styles.referenceTextStyle, brandingStore.textStyles.styleSmallRegular]}>{eobReferenceLabelAndDate.trim()}</Text>
      )}
    </View>
  );
});
