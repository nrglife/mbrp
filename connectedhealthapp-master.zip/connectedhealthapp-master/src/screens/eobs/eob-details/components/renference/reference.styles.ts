import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';




export const styles =  (store: BrandingStoreMobile)=>{

  
  return StyleSheet.create({
    referenceTextStyle: {
      marginTop: 0,
      color: store.currentTheme.blackSecondary
    }
  
  })
}




