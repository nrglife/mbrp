import React, { FC, useRef, useState } from 'react';
import { Text, View } from 'react-native';

import { EOBStoreType } from '@healthcareapp/connected-health-common-services';
import { NavigationProp } from '../../../../models/navigation';
import { BrandingTheme } from '../../../../stores/BrandingStoreMobile';
import { EobDate } from '../../eob-list/components/eob-date/eob-date.component';

import { styles as styleCreator } from './eob-details.styles';
import { getAddressAs2Lines } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { Total } from './total/total.component';
import { ScrollView } from 'react-native-gesture-handler';
import { WarningsContent } from './warning/warning.component';
import { Reference } from './renference/reference.component';
import { Questions } from '../../components/questions.component';
import { useStores } from '../../../../hooks/useStores';
import { ExpandingComponent } from '../../../../components/ExpandingComponent/expanding.component';
import { Transition, Transitioning, TransitioningView } from 'react-native-reanimated';
import { Item } from './item/Item.component';
import { ItemTitle } from './item/Item.title.component';

interface EobDetailsProps extends NavigationProp {
  theme: BrandingTheme;
  eob: EOBStoreType;
  isLoading: boolean;
}

export const EobDetails: FC<EobDetailsProps> = ({ theme, eob }) => {
  const billingAddressIn2Lines = eob && eob.facility && eob.facility.address && getAddressAs2Lines(eob.facility.address);
  const { brandingStore, eobsListStore } = useStores();
  const facilityName = eob && eob.facility?.name;
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;
  const ref = useRef<TransitioningView>();
  const [expanded, setExpanded] = useState<boolean[]>([]);

  const transition = (
    <Transition.Together>
      <Transition.In type="fade" durationMs={100} />
      <Transition.Change />
      <Transition.Out type="fade" durationMs={100} />
    </Transition.Together>
  );

  const showPractiotionerContent = eob?.performingPractitionerFullName != null && eob?.performingPractitionerFullName !== '';
  return (
    <ScrollView style={{ flex: 1, backgroundColor: brandingStore.currentTheme.white }}>
      <Transitioning.View
        ref={x => {
          ref.current = x;
        }}
        transition={transition}
        style={{ width: '100%', flexDirection: 'column', flex: 1 }}>
        <View style={{ paddingTop: 10, paddingHorizontal: 16, alignItems: 'flex-start' }}>
          <Text style={[styles.notABillTextStyle, textStyles.styleXSmallRegularCaps]}>This is not a bill</Text>
          <WarningsContent />
          <Text style={[styles.patientNameTextStyle, textStyles.styleXLarge]}>{`Services for ${eob.patientName}`}</Text>
          <EobDate type="details" date={eob.EOBDate} seperator={' - '} />
          <Reference />
          <Text style={[styles.practitionerLableTextStyle, textStyles.styleSmallRegular]}>Practitioner</Text>

          {!!showPractiotionerContent ? (
            <>
              <Text style={[styles.practitionerTextStyle, textStyles.styleLargeSemiBold]}>{eob.performingPractitionerFullName}</Text>
              <Text style={[styles.practitionerTextStyle, textStyles.styleSmallRegular]}>{eob.practitionerRole}</Text>
            </>
          ) : (
            <Text style={[styles.unavailableTextStyle, textStyles.styleLargeRegular]}>{`Practitioner unavailable`}</Text>
          )}

          <Text style={[styles.facilityLabelTextStyle, textStyles.styleSmallRegular]}>Facility</Text>
          {facilityName && facilityName.trim() !== '' ? (
            <Text style={[styles.facilityTextStyle, textStyles.styleLargeSemiBold]}>{facilityName.trim()}</Text>
          ) : (
            <Text style={[styles.unavailableTextStyle, textStyles.styleLargeRegular]}>{`Facility unavailable`}</Text>
          )}
          {billingAddressIn2Lines && billingAddressIn2Lines.line1 && billingAddressIn2Lines.line1.trim() !== '' ? (
            <Text style={[styles.addressTextStyle, textStyles.styleSmallRegular]}>{billingAddressIn2Lines.line1}</Text>
          ) : null}
          {billingAddressIn2Lines && billingAddressIn2Lines.line2 && billingAddressIn2Lines.line2.trim() !== '' ? (
            <Text style={[styles.addressTextStyle, textStyles.styleSmallRegular]}>{billingAddressIn2Lines.line2}</Text>
          ) : null}
        </View>

        <View style={{ marginTop: 17 }}>
          <Total 
            leftTitle={'Total price'} 
            backgroundColor={brandingStore.currentTheme.hint} 
            price={eob.totalPrice?.amount} 
            isComplete={eob.totalPrice?.isComplete}
            isContainUnknownCurrency={eob.totalPrice?.isContainUnknownCurrency} 
            isForeignCurrencyExist={eob.isForeignCurrencyExist}/>
          <Total 
            leftTitle={'Your balance'} 
            backgroundColor={brandingStore.currentTheme.actionLight} 
            opacity={0.5} 
            price={eob.estimatedBalance?.amount} 
            isComplete={eob.estimatedBalance?.isComplete}
            isContainUnknownCurrency={eob.estimatedBalance?.isContainUnknownCurrency} 
            isForeignCurrencyExist={eob.isForeignCurrencyExist}/>
        </View>

        {eobsListStore.selected.servicesLevelData && eobsListStore.selected.servicesLevelData.length != 0 ? (
          <View style={{ justifyContent: 'space-between', flexDirection: 'row', backgroundColor: '#F9F4EE', paddingBottom: 7, paddingTop: 20, paddingHorizontal: 20 }}>
            <Text style={[{ color: brandingStore.currentTheme.tooltip }, textStyles.styleXSmallRegularCaps]}>service</Text>
            <Text style={[{ color: brandingStore.currentTheme.tooltip }, textStyles.styleXSmallRegularCaps]}>your balance</Text>
          </View>
        ) : null}

        {eobsListStore.selected.servicesLevelData.map((data, index) => {
          

          return (
            <>
              <ExpandingComponent
                key={index.toString()}
                data={data}
                onExpendedCallback={val => {
                  const tmp = [...expanded];
                  tmp[index] = val;
                  setExpanded(tmp);
                }}
                transitioningViewRef={ref}
                titleComponent={<ItemTitle expanded={expanded[index]} title={data.name} date={data.date} amount={data.estimatedBalance} />}
                bodyComponent={<Item data={data} />}
              />
              <View style={{ backgroundColor: brandingStore.currentTheme.separatorOpaque, width: '100%', height: 1, marginLeft: 20 }}></View>
            </>
          );
        })}

        <View style={styles.questionsContainerStyle}>
          <Questions />
        </View>
      </Transitioning.View>
    </ScrollView>
  );
};
