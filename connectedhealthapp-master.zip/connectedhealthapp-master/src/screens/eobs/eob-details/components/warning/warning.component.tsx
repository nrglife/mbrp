import { isValidAmount } from '@healthcareapp/connected-health-common-services/src/utilities/fhir/helper';
import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { Text, View } from 'react-native';
import { InlineWarning } from '../../../../../components/CHInlineWarningItem/ch-inline-warning-item.component';
import { useStores } from '../../../../../hooks/useStores';

export const WarningsContent = observer(() => {
  const { eobsListStore } = useStores();
  const showTotals =
    isValidAmount(
      eobsListStore.selected?.totalPrice?.amount,
      eobsListStore.selected?.totalPrice?.isComplete,
      eobsListStore.selected?.totalPrice?.isContainUnknownCurrency,
      eobsListStore.selected?.isForeignCurrencyExist
    ) ||
    isValidAmount(
      eobsListStore.selected?.estimatedBalance?.amount,
      eobsListStore.selected?.estimatedBalance?.isComplete,
      eobsListStore.selected?.estimatedBalance?.isContainUnknownCurrency,
      eobsListStore.selected?.isForeignCurrencyExist
    );

  return (
    <View style={{ marginTop: !showTotals || !!eobsListStore?.selected?.showMissingDataWarning || !!eobsListStore?.selected?.showForeignCurrencyDataWarningPerEOB ? 12 : 0 }}>
      {!showTotals ? <InlineWarning text="There was a problem processing the amounts for this EOB." /> : null}
      {!!eobsListStore?.selected?.showMissingDataWarning ? <InlineWarning text="Some details of this EOB are not viewable at this time." /> : null}
      {!!eobsListStore?.selected?.showForeignCurrencyDataWarningPerEOB ? <InlineWarning text="This EOB contains mixed currencies." /> : null}
      {!!eobsListStore?.selected?.showUnknownCurrencyDataWarningPerEOB ? <InlineWarning text="This EOB contains unknown currency." /> : null}
    </View>
  );
});
