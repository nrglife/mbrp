import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    main: {
      flexDirection: 'row-reverse',
      justifyContent: 'flex-start',
      marginLeft: 20,
      paddingVertical: 20,
      paddingStart: 0,
      paddingEnd: 20,
      width: '100%',
      display: 'flex'
    },
    date: {
      color: store.currentTheme.tooltip
    },
    title: { paddingBottom: 4, paddingRight: 20, flexWrap: 'wrap',color:'black' },
    value: { paddingBottom: 4, textAlign: 'right' },
    titleAndDateContainer: { flexDirection: 'column' }
  });
};
