import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    itemRow: {
      flexDirection: 'row-reverse',
      justifyContent: 'space-between',
      backgroundColor: 'rgba(238, 238, 238, 0.5)'
    },
    itemRowTitleText: {
      paddingTop: 18,
      paddingLeft: 31,
      textAlign: 'left',
      justifyContent: 'flex-start',
      flexDirection: 'row',
      flex: 1,
      color: store.currentTheme.tooltip
    },
    itemRowValueText: { padding: 16 },
    itemRowLast: { backgroundColor: 'rgba(238, 238, 238, 0.5)' },
    itemRowLastTitle: {
      flexDirection: 'row-reverse',
      justifyContent: 'space-between'
    },
    itemRowLastTitleText: {
      paddingVertical: 18,
      paddingLeft: 31,
      flex: 1,
      color: store.currentTheme.tooltip
    },
    itemRowLastValueBackground: { position: 'absolute', backgroundColor: store.currentTheme.actionLight, opacity: 0.5, width: '100%', height: '100%' },
    itemRowLastValueText: {
      color: store.currentTheme.blackMain,
      paddingVertical: 17,
      paddingLeft: 16,
      paddingRight: 16,
      textAlign: 'right'
    },
    itemRowLastValueContainer: {},
    border: { height: 1, width: '100%', backgroundColor: store.currentTheme.separatorOpaque, marginLeft: 20 }
  });
};
