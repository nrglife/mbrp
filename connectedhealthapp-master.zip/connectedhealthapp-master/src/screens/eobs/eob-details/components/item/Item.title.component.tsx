import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { View, Text, Image } from 'react-native';
import { useStores } from '../../../../../hooks/useStores';
import { styles as styleCreator } from './item.title.component.styles';
import { Money } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { EOBPrice } from '../../../components/eob-price/eob-price.component';
import { Blink } from '../../../../../components/AppSkeletonText';
import images from '../../../../../assets/images/images';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

interface ItemTitleProps {
  title: string;
  date: string;
  amount: Money;
  expanded?: boolean;
}

export const ItemTitle: FC<ItemTitleProps> = observer(props => {
  const { brandingStore, eobsListStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { date, title, amount } = props;
  const textStyles = brandingStore.textStyles;

  // const amountSum = amount ? (amount?.currency.toUpperCase() == CurrencyCodes.USD ? '$' + amount.value : amount.value + ' ' + amount.currency.toUpperCase()) : ' - '

  return (
    <View style={styles.main}>
      <View>
        <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={20} width={73} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
          <View style={{ flexDirection: 'row' }}>
            <EOBPrice amount={amount} textStyle={{ ...styles.value, ...textStyles.styleLargeSemiBold }} currencyStyle={textStyles.styleSmallRegular} />
            <Image source={props.expanded ? images.eobsChevronUp : images.eobsChevronDown} style={{ resizeMode: 'contain', width: 12, marginLeft: 13, marginRight: 13 }}></Image>
          </View>
        </Blink>
      </View>

      <View style={[styles.titleAndDateContainer, { flex: 1 }]}>
        <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={20} width={176} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
          <Text style={[styles.title, textStyles.styleLargeSemiBold]}>{title}</Text>
        </Blink>
        <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={20} width={176} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
          <Text style={[styles.date, textStyles.styleSmallSemiBold]}>{date}</Text>
        </Blink>
      </View>
    </View>
  );
});
