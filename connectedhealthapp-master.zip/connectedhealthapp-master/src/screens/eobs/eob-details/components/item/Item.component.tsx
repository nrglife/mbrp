import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { View, Text } from 'react-native';
import { useStores } from '../../../../../hooks/useStores';
import { styles as styleCreator } from './item.component.styles';
import { ServicesItem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
import { EOBPrice } from '../../../components/eob-price/eob-price.component';

interface ItemProps {
  data: ServicesItem;
}

export const Item: FC<ItemProps> = observer(({ data: { memberPrice, insurancePaid, estimatedBalance } }) => {
  const { brandingStore } = useStores();

  const textStyles = brandingStore.textStyles;

  const styles = styleCreator(brandingStore);

  return (
    <View>
      <View style={styles.itemRow}>
        <EOBPrice amount={memberPrice} textStyle={{ ...styles.itemRowValueText, ...textStyles.styleLargeSemiBold }} currencyStyle={textStyles.styleSmallRegular} />

        <Text style={[styles.itemRowTitleText, textStyles.styleSmallSemiBold]}>Total price</Text>
      </View>
      <View style={styles.itemRow}>
        <EOBPrice amount={insurancePaid} textStyle={{ ...styles.itemRowValueText, ...textStyles.styleLargeSemiBold }} withMinus={true} currencyStyle={textStyles.styleSmallRegular} />

        <Text style={[styles.itemRowTitleText, textStyles.styleSmallSemiBold]}>Insurance paid</Text>
      </View>
      <View style={styles.itemRowLast}>
        <View style={styles.border}></View>
        <View style={styles.itemRowLastTitle}>
          <View style={styles.itemRowLastValueContainer}>
            <View style={styles.itemRowLastValueBackground} />
            <EOBPrice amount={estimatedBalance} textStyle={{ ...styles.itemRowLastValueText, ...textStyles.styleLargeSemiBold }} currencyStyle={textStyles.styleSmallRegular} />
          </View>

          <Text style={[styles.itemRowLastTitleText, textStyles.styleSmallSemiBold]}>Your balance</Text>
        </View>
      </View>
    </View>
  );
});
