import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    addressTextStyle: {
      color: store.currentTheme.blackMain
    },
    notABillTextStyle: {
      textAlign: 'center',
      color: store.currentTheme.label
    },
    patientNameTextStyle: {
      marginTop: 5,
      color: store.currentTheme.blackMain
    },

    practitionerLableTextStyle: {
      marginTop: 10,
      color: store.currentTheme.label
    },
    practitionerTextStyle: {
      color: store.currentTheme.blackMain
    },
    facilityLabelTextStyle: {
      marginTop: 20,
      color: store.currentTheme.label
    },
    facilityTextStyle: {
      color: store.currentTheme.blackMain
    },
    unavailableTextStyle: {
      fontStyle: 'italic',
      color: store.currentTheme.label
    },
    questionsContainerStyle: { paddingLeft: 19, paddingBottom: 42, paddingTop: 43 }
  });
};
