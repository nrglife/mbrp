import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  /*paddingLeft: 20, paddingTop: 23, paddingBottom: 24, paddingRight: 18, */
  return StyleSheet.create({
    container: { flexDirection: 'row', justifyContent: 'space-between' },
    innerContainer: { flexDirection: 'row', justifyContent: 'space-between', paddingLeft: 20, paddingTop: 23, paddingBottom: 24, paddingRight: 16, flex: 1 },
    background: { flexDirection: 'row', justifyContent: 'space-between', position: 'absolute', width: '100%', height: '100%' },
    textStyle: {
      flex: 1,
      color: store.currentTheme.blackMain
    },
    amountValue: { color: store.currentTheme.blackMain }
  });
};
