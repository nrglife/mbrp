import React, { FC } from 'react';
import { View, Text } from 'react-native';
import { Money } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { observer } from 'mobx-react';
import { useStores } from '../../../../../hooks/useStores';
import { EOBPrice } from '../../../components/eob-price/eob-price.component';

import { styles as styleCreator } from './total.styles';
import { Blink } from '../../../../../components/AppSkeletonText';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

interface TotalProps {
  leftTitle: string;
  backgroundColor: string;
  textColor?: string;
  opacity?: number;
  price: Money | null;
  isComplete?: boolean;
  isContainUnknownCurrency?: boolean;
  isForeignCurrencyExist?: boolean;
}
export const Total: FC<TotalProps> = observer(({ leftTitle, backgroundColor, opacity, price, isComplete = true, textColor, isContainUnknownCurrency = false, isForeignCurrencyExist = undefined }) => {
  const { brandingStore, eobsListStore } = useStores();
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;

  return (
    <View style={[styles.container, {}]}>
      <View style={[styles.background, { backgroundColor, opacity }]} />
      <View style={styles.innerContainer}>
        <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={22} width={leftTitle === 'Your balance' ? 159 : 119} shimmerStyle={{ borderRadius: 4 }}>
          <Text style={[styles.textStyle, textStyles.styleXLarge, textColor ? { color: textColor } : null]}>{leftTitle}</Text>
        </Blink>
        <Blink visible={eobsListStore.initialReqStatus == ReqStatus.LOADING} height={22} width={leftTitle === 'Your balance' ? 76 : 119} shimmerStyle={{ borderRadius: 4 }}>
          <EOBPrice
            amount={price}
            isComplete={isComplete}
            textStyle={{ ...styles.amountValue, ...textStyles.styleXLarge, ...(textColor ? { color: textColor } : null) }}
            isContainUnknownCurrency={isContainUnknownCurrency}
            isForeignCurrencyExist={isForeignCurrencyExist}
          />
        </Blink>
      </View>
    </View>
  );
});
