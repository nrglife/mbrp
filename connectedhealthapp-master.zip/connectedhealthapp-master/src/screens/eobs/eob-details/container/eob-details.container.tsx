import React, { FC, useLayoutEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { observer } from 'mobx-react';
import { useStores } from '../../../../hooks/useStores';
import { EobDetails } from '../components/eob-details.component';
import { Platform } from 'react-native';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

interface EobDetailsContainerProps {}

export const EobDetailsContainer: FC<EobDetailsContainerProps> = observer(props => {
  const navigation = useNavigation();
  const { brandingStore, eobsListStore } = useStores();
  useLayoutEffect(() => {
    navigation.setOptions({
      headerTintColor: Platform.OS == 'android' ? brandingStore.currentTheme.white : brandingStore.currentTheme.actionMedium, // YAY! Proper format!
      headerTitleStyle: { color: Platform.OS == 'android' ? brandingStore.currentTheme.white : 'black', ...brandingStore.textStyles.styleLargeSemiBold },
      headerBackTitleStyle: {
        color: Platform.OS == 'android' ? 'white' : brandingStore.currentTheme.actionMedium,
        width: '32%'
      },
      headerTitle: 'Explanation of Benefits',

      headerTruncatedBackTitle: 'Benefits Summary'
    });
  }, [navigation, brandingStore.currentTheme]);

  const navigate = () => {};
  if (!eobsListStore || !eobsListStore.selected) {
    return null;
  }
  return eobsListStore ? <EobDetails isLoading={eobsListStore.initialReqStatus == ReqStatus.LOADING} eob={eobsListStore.selected} theme={brandingStore.currentTheme} navigate={navigate} /> : null;
});
