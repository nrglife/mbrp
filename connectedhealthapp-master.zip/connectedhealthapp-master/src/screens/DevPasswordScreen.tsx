import { Alert, View } from 'react-native';
import React, { useState } from 'react';
import { CHActionButton, CHTextInput } from '../components';
import { createAccessibilityForAutomation } from '../utilities/accessibility';
import { EnrollmentNavigationRoutes } from '../routes';
import { useStores } from '../hooks/useStores';

const DevPasswordScreen = ({ navigation }) => {
  const [password, setPassword] = useState('');
  const { appConfigStore, brandingStore } = useStores();
  const textStyles = brandingStore.textStyles;

  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
      }}>
      <CHTextInput
        {...createAccessibilityForAutomation('devPassword')}
        labelStyle={textStyles.styleLargeRegular}
        secureTextEntry={true}
        onChangeText={e => {
          setPassword(e);
        }}
        passwordInput={true}
        labelWidth={55}
        disableTooltip={true}
        label={'Password'}
      />

      <CHActionButton
        {...createAccessibilityForAutomation('next button')}
        style={{ marginTop: 50, width: '50%' }}
        onPress={() => {
          if (password !== appConfigStore.appConfig.ENABLE_DEV_SCREEN_PROTECTING_DEV_SCREEN_PASSWORD) {
            Alert.alert('Wrong Password', 'Try again...', [{ text: 'OK' }]);
            return;
          }
          navigation.replace(EnrollmentNavigationRoutes.DevScreen);
        }}
        label={'next'}
        noBottomMargin={true}
      />
    </View>
  );
};

export default DevPasswordScreen;
