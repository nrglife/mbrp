import React, { FC, useState } from 'react';
import { Text, Button, SafeAreaView, View, TextInput, Platform, ScrollView, TouchableOpacity, ActivityIndicator, FlatList } from 'react-native';
import DateTimePicker, { AndroidNativeProps, IOSNativeProps } from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';

import { NavigationProp } from '../../../models/navigation';

import { styles } from './appointments.styles';
import { useIsIOS } from '../../../hooks/useIsIOS';
import { Switch } from 'react-native-gesture-handler';

interface AppointmentsProps extends NavigationProp {}
export const Appointments: FC<AppointmentsProps> = ({ navigate }) => {
  return (
    <View style={{ flex: 1 }}>
      <Text>Appointments</Text>
    </View>
  );
};
