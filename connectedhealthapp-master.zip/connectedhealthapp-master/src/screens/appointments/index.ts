export { AppointmentsContainer } from './container/appointments.container';
