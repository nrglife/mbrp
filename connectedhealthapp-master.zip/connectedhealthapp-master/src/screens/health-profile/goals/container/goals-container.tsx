import React, { FC, useEffect, useState } from 'react';
import { NavigationProp } from '../../../../models/navigation';
import { useStores } from '../../../../hooks/useStores';
import MedicationsSkeleton from '../../medications/components/skeleton/medications-skeleton';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { observer } from 'mobx-react';
import { styles as stylesCreator } from './goals-container.styles';
import { useTranslation } from 'react-i18next';
import HealthProfileBaseGroupedList from '../../components/health-profile-base-list/health-profile-base-component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../../assets/images/images';

interface HealthProfileProps extends NavigationProp {}

const GoalsContainer: FC<HealthProfileProps> = () => {
  useNavigationHeaderStyle('Goals', 'Health Profile', '32%');

  const { goalsStore, brandingStore } = useStores();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const onRefresh = async () => {
    try {
      setIsRefreshing(true);
      await goalsStore.fetchData({});
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    goalsStore.fetchData({});
    return () => {
      goalsStore.resetStore();
    };
  }, [goalsStore]);

  const styles = stylesCreator(brandingStore);
  const { t } = useTranslation('translation');

  const goalsData = goalsStore.getUIData();

  return (
    <HealthProfileBaseGroupedList
      SkeletonComponent={() => <MedicationsSkeleton />}
      sections={goalsData?.items}
      extraData={goalsData?.items}
      data={goalsData?.items}
      isLoading={goalsStore.initialReqStatus == ReqStatus.IDE || goalsStore.initialReqStatus == ReqStatus.LOADING}
      isNextPageLoading={goalsStore.nextPageStatus === ReqStatus.LOADING}
      apiErrorNextPage={goalsStore.nextPageStatus === ReqStatus.ERROR}
      isRefreshing={isRefreshing}
      onRefresh={onRefresh}
      getNextPage={() => goalsStore.getNextPage({ numberOfRetries: 1 }, true)}
      noRecordsWarning={goalsData?.recordsRemovedWarning}
      noContentToDisplay={goalsData?.noContentToDisplay}
      iconSource={images.goalItem}
    />
  );
};

export default observer(GoalsContainer);
