import React, { FC, useEffect, useState } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';

import { NavigationProp } from '../../../models/navigation';
import useNavigationHeaderStyle from '../../../hooks/useNavigationHeaderStyle';
import { useStores } from '../../../hooks/useStores';
import HealthProfileBaseGroupedList from '../components/health-profile-base-list/health-profile-base-component';
import MedicationsSkeleton from '../medications/components/skeleton/medications-skeleton';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../assets/images/images';
import { observer } from 'mobx-react';
import { toJS } from 'mobx';

interface HealthProfileProps extends NavigationProp {}

const labObservationsContainer: FC<HealthProfileProps> = ({ navigate }) => {
  useNavigationHeaderStyle('Lab Observations', 'Health Profile', '32%');

  const { labObservationStore } = useStores();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const onRefresh = async () => {
    try {
      setIsRefreshing(true);
      await labObservationStore.fetchData({});
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    labObservationStore.fetchData({});
    return () => {
      labObservationStore.resetStore();
    };
  }, [labObservationStore]);

  const proceduresData = labObservationStore.getUIData();

  return (
    <HealthProfileBaseGroupedList
      SkeletonComponent={() => <MedicationsSkeleton />}
      sections={proceduresData?.items}
      extraData={proceduresData?.items}
      data={proceduresData?.items}
      isLoading={labObservationStore.initialReqStatus === ReqStatus.IDE || labObservationStore.initialReqStatus === ReqStatus.LOADING}
      isNextPageLoading={labObservationStore.nextPageStatus === ReqStatus.LOADING}
      apiErrorNextPage={labObservationStore.nextPageStatus === ReqStatus.ERROR}
      isRefreshing={isRefreshing}
      onRefresh={onRefresh}
      getNextPage={() => labObservationStore.getNextPage({ numberOfRetries: 1 }, true)}
      noRecordsWarning={proceduresData?.recordsRemovedWarning}
      noContentToDisplay={proceduresData?.noContentToDisplay}
      iconSource={images.procedureItem}
    />
  );
};

export default observer(labObservationsContainer);
