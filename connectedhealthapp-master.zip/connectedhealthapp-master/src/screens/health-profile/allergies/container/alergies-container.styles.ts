import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: 'white'
    },
    name: { ...store.textStyles.styleXLarge },
    arrowTicket: { width: 20, height: 20, alignSelf: 'center' },
    section: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      backgroundColor: 'white',
      paddingHorizontal: 15,
      paddingBottom: 10,
      borderBottomWidth: 0.5,
      borderBottomColor: store.currentTheme.separatorOpaque,
      paddingTop: 30
    },
    sectionDate: { ...store.textStyles.styleXSmallSemiBold },
    sectionFacility: { ...store.textStyles.styleXSmallRegular }
  });
};
