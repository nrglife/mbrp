import React, { FC, useEffect, useState } from 'react';
import { NavigationProp } from '../../../../models/navigation';
import { useStores } from '../../../../hooks/useStores';
import MedicationsSkeleton from '../../medications/components/skeleton/medications-skeleton';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { observer } from 'mobx-react';
import { styles as stylesCreator } from './alergies-container.styles';
import { useTranslation } from 'react-i18next';
import HealthProfileBaseGroupedList from '../../components/health-profile-base-list/health-profile-base-component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../../assets/images/images';

interface HealthProfileProps extends NavigationProp {}

const AllergiesContainer: FC<HealthProfileProps> = () => {
  useNavigationHeaderStyle('Allergies & Intolerances', 'Health Profile', '32%');

  const { allergiesStore, brandingStore } = useStores();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const onRefresh = async () => {
    try {
      setIsRefreshing(true);
      await allergiesStore.fetchData({});
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    allergiesStore.fetchData({});
    return () => {
      allergiesStore.resetStore();
    };
  }, [allergiesStore]);

  const styles = stylesCreator(brandingStore);
  const { t } = useTranslation('translation');

  const allergiesData = allergiesStore.getUIData();

  return (
    <HealthProfileBaseGroupedList
      SkeletonComponent={() => <MedicationsSkeleton />}
      sections={allergiesData?.items}
      extraData={allergiesData?.items}
      data={allergiesData?.items}
      isLoading={allergiesStore.initialReqStatus == ReqStatus.IDE || allergiesStore.initialReqStatus == ReqStatus.LOADING}
      isNextPageLoading={allergiesStore.nextPageStatus === ReqStatus.LOADING}
      apiErrorNextPage={allergiesStore.nextPageStatus === ReqStatus.ERROR}
      isRefreshing={isRefreshing}
      onRefresh={onRefresh}
      getNextPage={() => allergiesStore.getNextPage({ numberOfRetries: 1 }, true)}
      noRecordsWarning={allergiesData?.recordsRemovedWarning}
      noContentToDisplay={allergiesData?.noContentToDisplay}
      iconSource={images.allergyItem}
    />
  );
};

export default observer(AllergiesContainer);
