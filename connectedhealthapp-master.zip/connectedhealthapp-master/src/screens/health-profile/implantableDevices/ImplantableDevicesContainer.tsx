import React, { FC } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';

import { NavigationProp } from '../../../models/navigation';

interface HealthProfileProps extends NavigationProp {}

 const ImplantableContainer: FC<HealthProfileProps> = ({ navigate }) => {
    return (
        <TouchableOpacity style={{ flex: 1 }}>
            <Text>Jane Flores</Text>
            <Text>Born November 15, 1977</Text>
        </TouchableOpacity>
    );
};


export default ImplantableContainer
