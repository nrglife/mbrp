import { StyleSheet } from 'react-native';

export const styles = () => {
  return StyleSheet.create({
    container: {
      padding: 20,
      flex: 1,
      backgroundColor: 'white',
      justifyContent: 'space-between'
    },
    section: {
      flexDirection: 'row',
      justifyContent: 'space-between'
    }
  });
};
