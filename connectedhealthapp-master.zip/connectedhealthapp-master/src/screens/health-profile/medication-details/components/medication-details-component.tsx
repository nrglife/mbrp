import React, { FC } from 'react';
import { useStores } from '../../../../hooks/useStores';
import { styles as stylesCreator } from './medication-details-component.styles';
import { Text, View } from 'react-native';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import ProfileItem from '../../components/ProfileItem';

export interface MedicationDetailsProps {
  requestedBy: string;
  dosage: string;
  header: string;
  date: string;
  cardStatus: string;
}

const MedicationsDetails: FC<MedicationDetailsProps> = ({ requestedBy, dosage, date, header, cardStatus }) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator();
  useNavigationHeaderStyle('Medication');

  return (
    <View style={styles.container}>
      <View>
        <Text style={{ ...brandingStore.textStyles.styleXLarge }}>{header}</Text>
        <View style={styles.section}>
          <ProfileItem title={'Prescribed'} content={date} />
          {requestedBy && <ProfileItem title={'Requested by'} content={requestedBy} />}
        </View>
        <View style={styles.section}>
          <ProfileItem title={'Status'} content={cardStatus} />
          <ProfileItem title={'Dose Instructions'} content={dosage} />
        </View>
      </View>

      <Text style={{ ...brandingStore.textStyles.styleXLarge, marginRight: 102, marginLeft: 20 }}>Uses & Side Effects</Text>
      <Text style={{ ...brandingStore.textStyles.styleXLarge, marginRight: 102, marginLeft: 20 }}>Related Events</Text>
    </View>
  );
};

export default MedicationsDetails;
