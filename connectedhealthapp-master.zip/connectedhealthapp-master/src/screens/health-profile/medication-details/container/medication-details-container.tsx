import React, { FC } from 'react';
import { View } from 'react-native';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import MedicationsDetails from '../components/medication-details-component';

const MedicationsDetailsContainer: FC = props => {
  const { params } = props.route;
  const requestedBy = findValue(params.itemsArray, 'Requested by');
  const dosage = findValue(params.itemsArray, 'Dosage');
  useNavigationHeaderStyle('Medication');

  return (
    <View style={{ flex: 1, width: '100%' }}>
      <MedicationsDetails requestedBy={requestedBy} dosage={dosage} date={params.date} header={params.header} cardStatus={params.cardStatus} />
    </View>
  );
};

function findValue(arr, name) {
  return arr.filter(el => el.header === name).length ? arr.filter(el => el.header === name)[0].body : null;
}

export default MedicationsDetailsContainer;
