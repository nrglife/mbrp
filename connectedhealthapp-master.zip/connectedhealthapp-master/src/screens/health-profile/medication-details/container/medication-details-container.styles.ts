import { StyleSheet } from 'react-native';

export const styles = () => {
  return StyleSheet.create({});
};
