import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    headerContainer: {
      marginVertical: 7.5,
      marginHorizontal: 15,
      borderRadius: 12,
      shadowColor: '#000',
      shadowRadius: 5,
      shadowOffset: {
        width: 0.5,
        height: 0.5
      },
      shadowOpacity: 0.1,
      ...Platform.select({
        android: {
          borderRadius: 15,
          overflow: 'hidden',
          elevation: 3,
          backgroundColor: 'grey'
        },
        ios: {}
      })
    },
    container: { padding: 16, backgroundColor: 'white', borderRadius: 12, overflow: 'hidden' },
    shimmerStyle: {
      borderRadius: 0,
      borderBottomLeftRadius: 5,
      borderBottomEndRadius: 5,
      paddingHorizontal: 10
    },
    headerSectionContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingBottom: 5,
      borderBottomWidth: 0.5,
      borderBottomColor: store.currentTheme.separatorOpaque,
      marginBottom: 7.5,
      paddingHorizontal: 15,
      marginTop: 30
    },
    sectionContainer: { flexDirection: 'row', justifyContent: 'space-between' }
  });
};
