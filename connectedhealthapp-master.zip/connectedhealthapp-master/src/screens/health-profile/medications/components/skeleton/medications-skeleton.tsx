import { SectionList, View } from 'react-native';
import { Blink } from '../../../../../components/AppSkeletonText';
import React, { FC } from 'react';
import { styles as stylesCreator } from './medications-skeleton.styles';
import { useStores } from '../../../../../hooks/useStores';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

const renderSectionHeader = (brandingStore: BrandingStoreMobile) => {
  const styles = stylesCreator(brandingStore);

  return (
    <View style={styles.headerSectionContainer}>
      <Blink height={16} width={135} />
      <Blink height={16} width={135} />
    </View>
  );
};

const MedicationsSkeleton: FC = () => {
  const { brandingStore } = useStores();
  return (
    <View style={{ backgroundColor: 'white', flex: 1 }}>
      <SectionList
        stickySectionHeadersEnabled={false}
        sections={DATA}
        renderSectionHeader={() => {
          return renderSectionHeader(brandingStore);
        }}
        keyExtractor={(_, index) => index.toString()}
        data={Array(4).fill(0)}
        renderItem={({ item, index }) => <HealthCardSkeleton key={index} />}
      />
    </View>
  );
};

export default MedicationsSkeleton;

export const HealthCardSkeleton = () => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);
  return (
    <View style={styles.headerContainer}>
      <View style={styles.container}>
        <Blink
          style={{
            position: 'absolute',
            right: 12
          }}
          shimmerStyle={styles.shimmerStyle}
          height={22}
          width={51}
        />
        <View style={styles.sectionContainer}>
          <Blink height={16} width={135} />
        </View>
        <Blink style={{ marginTop: 8 }} height={24} width={295} />
        <View style={styles.sectionContainer}>
          <View>
            <Blink style={{ marginTop: 12 }} height={16} width={95} />
            <Blink style={{ marginTop: 5 }} height={16} width={143} />
          </View>
          <View>
            <Blink style={{ marginTop: 12 }} height={16} width={95} />
            <Blink style={{ marginTop: 5 }} height={16} width={143} />
          </View>
        </View>
      </View>
    </View>
  );
};
const DATA = [
  {
    title: { date: 'May 6, 2021', facilityName: 'West Hills Medical Center' },
    data: [
      {
        cardStatus: 'ACTIVE',
        title: 'Vaccination',
        date: 'May 24, 2021',
        header: 'Amlodipine Besylate 10 MG PO Tabs',
        itemsArray: [
          { body: 'Gilbert Harbor MD', header: 'Prescribed by' },
          {
            body: 'Take one tablet by mouth daily',
            header: 'Dosage'
          }
        ]
      },
      {
        cardStatus: 'COMPLETED',
        title: 'Vaccination',
        date: 'May 24, 2021',
        header: 'Amlodipine Besylate 10 MG PO Tabs',
        itemsArray: [
          { body: 'Gilbert Harbor MD', header: 'Prescribed by' },
          {
            body: 'Take one tablet by mouth daily',
            header: 'Dosage'
          }
        ]
      }
    ]
  },
  {
    title: { date: 'May 6, 2021', facilityName: 'West Hills Medical Center' },
    data: [
      {
        cardStatus: 'ACTIVE',
        title: 'Vaccination',
        date: 'May 24, 2021',
        header: 'Amlodipine Besylate 10 MG PO Tabs',
        itemsArray: [
          { body: 'Gilbert Harbor MD', header: 'Prescribed by' },
          {
            body: 'Take one tablet by mouth daily',
            header: 'Dosage'
          }
        ]
      },
      {
        cardStatus: 'COMPLETED',
        title: 'Vaccination',
        date: 'May 24, 2021',
        header: 'Amlodipine Besylate 10 MG PO Tabs',
        itemsArray: [
          { body: 'Gilbert Harbor MD', header: 'Prescribed by' },
          {
            body: 'Take one tablet by mouth daily',
            header: 'Dosage'
          }
        ]
      }
    ]
  }
];
