import React, { FC } from 'react';
import { HealthProfile } from '../components/health-profile.component';
import { View } from 'react-native';
import { DELEGATE_SELECTOR_HEIGHT, DelegationPickerContainer } from '../../../components/DelegationPickerContainer/delegation-picker.container';
import { useStores } from '../../../hooks/useStores';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';

export const HealthProfileContainer: FC = props => {
  const { delegateStore } = useStores();
  return (
    <DelegationPickerContainer>
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          marginTop: (delegateStore.state == DelegateStoreState.Running || delegateStore.state == DelegateStoreState.RunningShowError) && delegateStore.delegateMenu ? DELEGATE_SELECTOR_HEIGHT : 0
        }}>
        <HealthProfile />
      </View>
    </DelegationPickerContainer>
  );
};
