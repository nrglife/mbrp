import React, { FC, useEffect, useState } from 'react';
import { NavigationProp } from '../../../../models/navigation';
import { useStores } from '../../../../hooks/useStores';
import MedicationsSkeleton from '../../medications/components/skeleton/medications-skeleton';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { observer } from 'mobx-react';
import HealthProfileBaseGroupedList from '../../components/health-profile-base-list/health-profile-base-component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../../assets/images/images';
import { Text, View } from 'react-native';
import ClinicalsOverviewComponent from '../components/clinicals-overview-component';
import { DelegationPickerContainer, PickerType, VisiblityMode } from '../../../../components/DelegationPickerContainer/delegation-picker.container';
import { HealthProfileOverviewData } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';

interface ClinicalsOverviewContainerProps extends NavigationProp {}

const ClinicalsOverviewContainer: FC<ClinicalsOverviewContainerProps> = () => {
  const { clinicalsOverviewStore, brandingStore } = useStores();

  const onRefresh = async () => {
    try {
      clinicalsOverviewStore.resetStore();
      await clinicalsOverviewStore.getOverviewBaseData();
    } finally {
    }
  };

  useEffect(() => {
    clinicalsOverviewStore.getOverviewBaseData();
    return () => {
      clinicalsOverviewStore.resetStore();
    };
  }, [clinicalsOverviewStore]);

  useNavigationHeaderStyle(clinicalsOverviewStore.displayableOverviewData?.pageTitle, 'Health Profile', '32%');

  return (
    <DelegationPickerContainer wrapInScrollView={true} pickerType={PickerType.ReadOnly} visiblityMode={VisiblityMode.MoreThanOne}>
      <ClinicalsOverviewComponent overviewData={clinicalsOverviewStore.displayableOverviewData} isLoading={clinicalsOverviewStore.isLoading} onRefresh={onRefresh} />
    </DelegationPickerContainer>
  );
};

export default observer(ClinicalsOverviewContainer);
