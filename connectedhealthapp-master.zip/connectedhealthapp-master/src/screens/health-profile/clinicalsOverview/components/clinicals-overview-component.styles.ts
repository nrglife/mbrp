import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: { flex: 1, alignItems: 'flex-start', paddingHorizontal: 22, paddingTop: 15, backgroundColor: 'white' },
    noDataContainer: { marginTop: 101, justifyContent: 'center', alignItems: 'center' },
    skeletonSectionContainer: { flexDirection: 'row', justifyContent: 'space-between' }
  });
};
