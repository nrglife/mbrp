import { SectionList, View } from 'react-native';
import { Blink } from '../../../../components/AppSkeletonText';
import React, { FC } from 'react';
import { styles as stylesCreator } from './clinicals-overview-component.styles';
import { useStores } from '../../../../hooks/useStores';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const ClinicalsOverviewSkeleton = () => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);
  return (
    <View style={styles.container}>
      <View style={{ height: 85, marginBottom: 8 }}>
        <Blink style={{ marginTop: 15, marginBottom: 8 }} height={30} width={260} />
        <Blink height={18} width={220} />
      </View>

      <View style={styles.skeletonSectionContainer}>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
      </View>

      <View style={styles.skeletonSectionContainer}>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
      </View>
      <View style={styles.skeletonSectionContainer}>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
        <View style={{ marginBottom: 22 }}>
          <Blink style={{ marginTop: 12 }} height={18} width={95} />
          <Blink style={{ marginTop: 5, paddingRight: 60 }} height={22} width={143} />
        </View>
      </View>
    </View>
  );
};
