import React, { FC, useEffect, useState } from 'react';
import { NavigationProp } from '../../../../models/navigation';
import { useStores } from '../../../../hooks/useStores';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { observer } from 'mobx-react';
import HealthProfileBaseGroupedList, { getNoContentImage } from '../../components/health-profile-base-list/health-profile-base-component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../../assets/images/images';
import { View, Text, RefreshControl } from 'react-native';
import { styles as stylesCreator } from './clinicals-overview-component.styles';
import { HealthTicketFieldsContainer } from '../../components/HealthTicketNew/health-ticket-fields-container';
import { HealthProfileOverviewData } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';

import { ScrollView } from 'react-native-gesture-handler';

import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { EmptyListContainer } from '../../../../components/EmptyListContainer/empty-list-container';
import { ClinicalsOverviewSkeleton } from './clinicals-overview-skeleton';

interface ClinicalsOverviewComponentProps {
  overviewData: HealthProfileOverviewData;
  isLoading: boolean;
  onRefresh: () => {};
}

const ClinicalsOverviewComponent: FC<ClinicalsOverviewComponentProps> = params => {
  const stores = useStores();
  const { brandingStore } = useStores();
  const { overviewData, isLoading, onRefresh } = params;
  const { t } = useTranslation('translation');

  const styles = stylesCreator(stores.brandingStore);

  const getFieldByLabel = fieldLabel => {
    return (
      overviewData?.info &&
      overviewData?.info.length > 0 &&
      overviewData?.info[0]?.items &&
      overviewData?.info[0]?.items.length > 0 &&
      overviewData?.info[0]?.items[0]?.find(f => f?.label == fieldLabel)
    );
  };

  const nameField = getFieldByLabel(t(LocaleKeys.screens.Clinical.Overview.name));
  const birthdayField = getFieldByLabel(t(LocaleKeys.screens.Clinical.Overview.born));

  return isLoading ? (
    <ClinicalsOverviewSkeleton />
  ) : (
    <ScrollView style={{ flex: 1, backgroundColor: 'white' }} contentContainerStyle={{ flexGrow: 1 }} refreshControl={<RefreshControl refreshing={isLoading} onRefresh={onRefresh} />}>
      {overviewData.noContentToDisplay ? (
        <EmptyListContainer
          containerStyle={styles.noDataContainer}
          apis={overviewData.noContentToDisplay?.errorSource ? [overviewData.noContentToDisplay?.errorSource] : null}
          text={overviewData.noContentToDisplay?.errorText}
          image={getNoContentImage(overviewData.noContentToDisplay?.type)}
          resizeMode="contain"
        />
      ) : (
        <View style={styles.container}>
          <View>
            <View>
              {!!nameField && !!nameField?.data && <Text style={[{ color: brandingStore.currentTheme.blackMain }, { ...brandingStore.textStyles.styleLargeBold }]}>{nameField?.data}</Text>}
              {!!birthdayField && !!birthdayField?.data && (
                <Text style={[{ color: brandingStore.currentTheme.blackMain, paddingTop: 2 }, { ...brandingStore.textStyles.styleXSmallRegular }]}>
                  {t(LocaleKeys.screens.Clinical.Overview.born) + ' ' + birthdayField.data}
                </Text>
              )}
            </View>
            <HealthTicketFieldsContainer
              info={overviewData.info}
              isExtendedView={true}
              dismissFieldsByLabelName={[t(LocaleKeys.screens.Clinical.Overview.name), t(LocaleKeys.screens.Clinical.Overview.born)]}></HealthTicketFieldsContainer>
          </View>
        </View>
      )}
    </ScrollView>
  );
};

export default observer(ClinicalsOverviewComponent);
