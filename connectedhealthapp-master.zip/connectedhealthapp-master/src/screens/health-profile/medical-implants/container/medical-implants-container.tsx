import React, { FC, useEffect, useState } from 'react';
import { NavigationProp } from '../../../../models/navigation';
import { useStores } from '../../../../hooks/useStores';
import MedicationsSkeleton from '../../medications/components/skeleton/medications-skeleton';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { observer } from 'mobx-react';
import HealthProfileBaseGroupedList from '../../components/health-profile-base-list/health-profile-base-component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import images from '../../../../assets/images/images';

interface MedicalImplantsContainerProps extends NavigationProp {}

const MedicalImplantsContainer: FC<MedicalImplantsContainerProps> = () => {
  const { implantableDeviceStore, brandingStore } = useStores();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const onRefresh = async () => {
    try {
      setIsRefreshing(true);
      await implantableDeviceStore.fetchData({});
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    implantableDeviceStore.fetchData({});
    return () => {
      implantableDeviceStore.resetStore();
    };
  }, [implantableDeviceStore]);

  const proceduresData = implantableDeviceStore.getUIData();

  useNavigationHeaderStyle(proceduresData.pageTitle, 'Health Profile', '32%');

  return (
    <HealthProfileBaseGroupedList
      SkeletonComponent={() => <MedicationsSkeleton />}
      sections={proceduresData?.items}
      extraData={proceduresData?.items}
      data={proceduresData?.items}
      isLoading={implantableDeviceStore.initialReqStatus === ReqStatus.IDE || implantableDeviceStore.initialReqStatus === ReqStatus.LOADING}
      isNextPageLoading={implantableDeviceStore.nextPageStatus === ReqStatus.LOADING}
      apiErrorNextPage={implantableDeviceStore.nextPageStatus === ReqStatus.ERROR}
      isRefreshing={isRefreshing}
      onRefresh={onRefresh}
      getNextPage={() => implantableDeviceStore.getNextPage({ numberOfRetries: 1 }, true)}
      noRecordsWarning={proceduresData?.recordsRemovedWarning}
      noContentToDisplay={proceduresData?.noContentToDisplay}
      iconSource={images.procedureItem}
    />
  );
};

export default observer(MedicalImplantsContainer);
