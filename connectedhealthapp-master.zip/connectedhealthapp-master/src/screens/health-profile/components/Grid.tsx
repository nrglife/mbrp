import {FlatList, View} from "react-native";
import React, {FC} from "react";
import GridItem from "./ProfileItem";


interface GridProps {
    data: any

}

const Grid: FC<GridProps> = ({data}) => {
    return (
        <FlatList
            bounces={false}
            style={{ marginBottom: 25}}
            data={data}
            renderItem={({item, index}) =>
                <GridItem
                    content={item.content}
                    title={item.title}
                    key={index.toString()}/>}
            numColumns={2}
            keyExtractor={(item, index) => index.toString()}
        />
    )
}
export default Grid
