import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    header: { color: '#9D9D9D', ...store.textStyles.styleSmallRegular },
    content: { color: '#262626', ...store.textStyles.styleSmallRegular },
    container: {
      flex: 1,
      paddingVertical:20
    }
  });
};
