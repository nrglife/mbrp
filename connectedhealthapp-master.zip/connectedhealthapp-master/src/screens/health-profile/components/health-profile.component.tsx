import React, { FC, useRef, useState } from 'react';
import { Alert, FlatList, Image, Text, View } from 'react-native';
import images from '../../../assets/images/images';
import { useStores } from '../../../hooks/useStores';
import { styles as styleCreator } from './health-profile.styles';
import ProfileItem from './ProfileItem';
import { ExpandingComponent } from '../../../components/ExpandingComponent/expanding.component';
import { Transition, Transitioning, TransitioningView } from 'react-native-reanimated';
import ListItem from '../../../components/MenuListItem/ListItem';
import { HomeNavigationRoutes } from '../../../routes';
import AppConfigStore from '../../../stores/AppConfigStore';
import { IocTypesMobile, IocContainer } from '../../../iocTypes';

interface HealthProfileProps {}

export const HealthProfile: FC<HealthProfileProps> = ({}) => {
  const [isExpended, setIsExpended] = useState<boolean>(false);
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const ref = useRef<TransitioningView>();
  const transition = (
    <Transition.Together>
      <Transition.In type="fade" durationMs={100} />
      <Transition.Change />
      <Transition.Out type="fade" durationMs={100} />
    </Transition.Together>
  );

  return (
    <>
      {/*<Transitioning.View*/}
      {/*    ref={x => {*/}
      {/*        ref.current = x;*/}
      {/*    }}*/}
      {/*    transition={transition}*/}
      {/*    style={{width: '100%', flexDirection: 'column'}}>*/}
      {/*    <ExpandingComponent*/}
      {/*        onExpendedCallback={setIsExpended}*/}
      {/*        transitioningViewRef={ref}*/}
      {/*        titleComponent={*/}
      {/*            <View style={styles.container}>*/}
      {/*                <View>*/}
      {/*                    <Text style={styles.name}>Jane Flores</Text>*/}
      {/*                    <Text>Born November 15, 1977</Text>*/}
      {/*                </View>*/}
      {/*                <Image source={isExpended ? images.arrowUp : images.arrowDown} resizeMode={'contain'}*/}
      {/*                       style={styles.arrowTicket}/>*/}
      {/*            </View>*/}
      {/*        }*/}
      {/*        bodyComponent={*/}
      {/*            <FlatList*/}
      {/*                bounces={false}*/}
      {/*                style={{paddingHorizontal: 22, marginBottom: 25}}*/}
      {/*                data={MockArr}*/}
      {/*                renderItem={({item, index}) => <ProfileItem content={item.content} title={item.title}*/}
      {/*                                                            key={index.toString()}/>}*/}
      {/*                numColumns={2}*/}
      {/*                keyExtractor={(item, index) => index.toString()}*/}
      {/*            />*/}
      {/*        }*/}
      {/*    />*/}
      {/*</Transitioning.View>*/}
      <FlatList
        bounces={false}
        // ListHeaderComponent={<View style={{ borderWidth: 0.5, borderColor: brandingStore.currentTheme.separatorOpaque }} />}
        style={{ marginLeft: 0 }}
        data={screensMockArray}
        renderItem={({ item, index }) => <ListItem textColor={brandingStore.currentTheme.actionDark} key={index} item={item} index={index} />}
      />
    </>
  );
};

const MockArr = [
  { title: 'Gender', content: 'Female' },
  { title: 'Race', content: 'White' },
  {
    title: 'Smoking status',
    content: 'Never smoked'
  },
  { title: 'Ethnicity', content: 'Non-hispanic' },
  { title: 'Preferred Language', content: 'English' }
];

let screensMockArray = [
  {
    route: HomeNavigationRoutes.ClinicalsOverviewContainer,
    title: 'Overview'
  },
  {
    route: HomeNavigationRoutes.AllergiesContainer,
    title: 'Allergies & Intolerances'
  },
  {
    route: HomeNavigationRoutes.GoalsContainer,
    title: 'Goals'
  },
  {
    route: HomeNavigationRoutes.labObservationsContainer,
    title: 'Lab Observations'
  },

  {
    route: HomeNavigationRoutes.MedicalImplantsContainer,
    title: 'Medical Implants'
  },
  {
    route: HomeNavigationRoutes.Medications,
    title: HomeNavigationRoutes.Medications
  },
  {
    route: HomeNavigationRoutes.ProblemsAndConditionsContainer,
    title: 'Problems & Conditions'
  },
  {
    route: HomeNavigationRoutes.ProceduresContainer,
    title: 'Procedures'
  },
  {
    route: HomeNavigationRoutes.VaccinationsContainer,
    title: 'Vaccinations'
  },

  {
    route: HomeNavigationRoutes.VisitsContainer,
    title: 'Visit Details'
  }
];
