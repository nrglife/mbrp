import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
  container:{ flexDirection: 'row', justifyContent: 'space-between',marginTop: 30,marginHorizontal:20 ,marginBottom:20},
  name:{ ...store.textStyles.styleXLarge },
    arrowTicket:{ width: 20, height: 20, alignSelf: 'center' }
  });
};
