import React, { FC } from 'react';
import { Image, ScrollView, Text, View } from 'react-native';
import { useStores } from '../../../../hooks/useStores';
import useNavigationHeaderStyle from '../../../../hooks/useNavigationHeaderStyle';
import { RouteProp, useRoute } from '@react-navigation/native';
import { RootStackParamList } from '../../../../routes/navigators/health-profile/health-profile-navigator';
import { observer } from 'mobx-react';
import { styles as styleCreator } from './health-ticket-details-container.styles';
import StatusLabel, { StatusLabelMode } from '../../components/HealthTicketNew/health-ticket-clinical-status-label.component';
import TicketItem from '../../components/HealthTicketNew/health-ticket-item.component';
import Separator from '../../../../components/Separator';
import { HomeNavigationRoutes } from '../../../../routes';
import { useTranslation } from 'react-i18next';
type ProfileScreenRouteProp = RouteProp<RootStackParamList, HomeNavigationRoutes.HealthTicketDetailsContainer>;

const HealthTicketDetailsContainer: FC = observer(({ ...props }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  let route = useRoute<ProfileScreenRouteProp>();
  const {
    item: { titles, status, extendedInfo, typeName, iconSource }
  } = route.params;
  useNavigationHeaderStyle(typeName, 'Health Profile', '32%');
  const { t } = useTranslation();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={{ paddingBottom: 20 }}>
        {/* Header Container Section */}
        <View style={styles.headerContainer}>
          <View style={styles.iconContainer}>{iconSource && <Image source={iconSource} style={styles.itemIcon} />}</View>
          <View style={styles.headerLabelsContainer}>
            {status && <StatusLabel backgroundColor={status.bkgdColor} useDarkTextColor={status.useDarkTextColor} cardStatus={status.name} mode={StatusLabelMode.Full} />}
            {titles[0]?.description && (
              <View>
                <Text style={[styles.description]}>{titles[0].description}</Text>
              </View>
            )}
            {titles[0]?.code && <Text style={styles.code}>({titles[0].code})</Text>}
          </View>
        </View>

        {/* Extended Info Section */}
        {extendedInfo?.map((extendedInfoItem, index0) => {
          return (
            <>
              <View style={styles.extendedInfoContainer}>
                {/* TODO: check why 'extendedInfoItem?.title &&' not working */}
                {extendedInfoItem?.title?.length > 0 && <Text style={styles.title}>{extendedInfoItem.title}</Text>}
                {extendedInfoItem?.items?.map((fieldDataArr, index1) => {
                  return (
                    <View style={styles.extendedInfoItemsList}>
                      {fieldDataArr.map(({ label, data, code, isHighlighted }, index2) => {
                        let body = (data ? `${data} ` : '') + (code ? `(${code})` : '');
                        return (
                          body && (
                            <TicketItem
                              key={index2.toString() + data + label}
                              header={label}
                              body={body}
                              isDescriptionUnavailable={!!!data}
                              isExtendedView={true}
                              isBold={isHighlighted}
                              t={t}
                              unavailableTextStyle={styles.unavailableTextStyle}
                            />
                          )
                        );
                      })}
                      {index1 < extendedInfoItem?.items?.length - 1 && <Separator style={{ marginTop: 22 }} />}
                    </View>
                  );
                })}
              </View>
              {index0 < extendedInfo?.length - 1 && <Separator style={{ marginTop: 22 }} />}
            </>
          );
        })}
      </View>
    </ScrollView>
  );
});

export default HealthTicketDetailsContainer;
