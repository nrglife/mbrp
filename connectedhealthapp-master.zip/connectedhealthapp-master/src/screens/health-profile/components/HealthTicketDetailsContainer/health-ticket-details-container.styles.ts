import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    // Header Container Section
    headerContainer: { flexDirection: 'row' },
    iconContainer: { flexDirection: 'column', marginTop: 10, marginLeft: 10 },
    itemIcon: { width: 100, height: 100 },
    headerLabelsContainer: { flexDirection: 'column', marginTop: 28, marginLeft: 10, flex: 1 },
    description: { ...store.textStyles.styleXLarge, color: store.currentTheme.blackMain },
    code: { color: store.currentTheme.tooltip, ...store.textStyles.styleXSmallRegular },

    // Extended Info Section
    extendedInfoContainer: { marginLeft: 23, marginRight: 23 },
    title: { ...store.textStyles.styleXLarge, marginTop: 22, color: store.currentTheme.blackMain },
    extendedInfoItemsList: { flexDirection: 'row', flexWrap: 'wrap' },
    unavailableTextStyle: {
      fontStyle: 'italic',
      color: store.currentTheme.label
    }
  });
};
