import {View, Text} from 'react-native';
import React, {FC} from 'react';
import {styles as styleCreator} from './health-ticket-header.styles';
import BrandingStoreMobile from "../../../../stores/BrandingStoreMobile";


interface HealthTicketHeaderProps {
    groupedByTitle: string
    brandingStore: BrandingStoreMobile
}

const HealthTicketHeader: FC<HealthTicketHeaderProps> = ({
                                                             groupedByTitle,
                                                             brandingStore
                                                         }) => {

    const styles = styleCreator(brandingStore);
    return (
        <View style={styles.mainContainer}>
            <Text style={[brandingStore.textStyles.styleXSmallBoldCaps, { color: brandingStore.currentTheme.blackMain }]}>{groupedByTitle}</Text>
        </View>
    );
};

export default HealthTicketHeader;
