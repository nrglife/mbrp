import {StyleSheet} from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
    return StyleSheet.create({
        mainContainer: {
            paddingBottom: 7,
            borderBottomWidth: 1,
            borderColor: store.currentTheme.separatorOpaque,
            marginTop: 30,
            paddingLeft: 19
        }

    });
};



