import React, { FC } from 'react';
import { useStores } from '../../../hooks/useStores';
import { Text, View } from 'react-native';
import { styles as styleCreator } from './profile-item.styles';

interface ProfileItemProps {
  title: string;
  content: string;
}

const GridItem: FC<ProfileItemProps> = ({ title, content }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <View style={styles.container}>
      <Text style={styles.header}>{title}</Text>
      <Text style={styles.content}>{content}</Text>
    </View>
  );
};

export default GridItem;
