import { View, Text, TouchableOpacity, TouchableOpacityProps, ImageSourcePropType, Image, StyleProp } from 'react-native';
import React, { FC } from 'react';
import { useStores } from '../../../../hooks/useStores';
import { styles as styleCreator } from './health-ticket.styles';
import { useNavigation } from '@react-navigation/native';
import { HomeNavigationRoutes } from '../../../../routes';
import TicketItem from './health-ticket-item.component';
import StatusLabel from './health-ticket-clinical-status-label.component';
import { DisplayableHealthProfileItem, ItemTitle } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import images from '../../../../assets/images/images';
import { TFunction, useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';
import { HealthTicketFieldsContainer } from './health-ticket-fields-container';

interface HealthTicketProps extends TouchableOpacityProps {
  item: DisplayableHealthProfileItem;
  routeToNavigate?: HomeNavigationRoutes;
  iconSource?: ImageSourcePropType;
}

const HealthTicketNew: FC<HealthTicketProps> = ({ disabled, item, routeToNavigate, iconSource }) => {
  const { titles, secondaryTitle, status, extendedInfo, type, typeName } = item;
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const navigation = useNavigation();
  const { t } = useTranslation();
  const handleTicketPress = () => {
    if (routeToNavigate) {
      navigation.navigate(routeToNavigate, { item: { ...item, iconSource } });
    }
  };

  return (
    <TouchableOpacity disabled={disabled} onPress={handleTicketPress} style={styles.mainContainer}>
      <View style={styles.cardContainer}>
        {status && <StatusLabel backgroundColor={status.bkgdColor} cardStatus={status.name} useDarkTextColor={status.useDarkTextColor} />}
        <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-between' }}>
          <View>
            <View style={{ flexDirection: 'row' }}>
              <Text style={styles.ticketTitle}>{`${typeName} ${secondaryTitle?.data ?? ''}`} </Text>
            </View>
            {titles.map((title, index) => (
              <View style={index + 1 < titles.length && styles.titleFooter}>
                <Title title={title} brandingStore={brandingStore} t={t} key={index.toString()} />
              </View>
            ))}
          </View>
          {!disabled && (
            <View style={{ alignSelf: 'center' }}>
              <Image source={images.arrowRight} style={{ width: 8, height: 12 }} />
            </View>
          )}
        </View>
        <HealthTicketFieldsContainer info={extendedInfo}></HealthTicketFieldsContainer>
      </View>
    </TouchableOpacity>
  );
};

export default HealthTicketNew;

declare interface TitleProps {
  title: ItemTitle;
  t: TFunction<'translation', undefined>;
  brandingStore: BrandingStoreMobile;
}

export const Title: FC<TitleProps> = ({ title: { code, description }, t, brandingStore }) => {
  const { header, smallText, unavailableTextStyle, secondaryTitle } = styleCreator(brandingStore);
  const {
    errors: { description_unavailable, code_unavailable }
  } = LocaleKeys;
  return (
    <>
      <Text style={description ? header : [smallText, unavailableTextStyle]}>{description ?? t(description_unavailable)} </Text>
      <Text style={code ? secondaryTitle : [secondaryTitle, unavailableTextStyle]}>{!!code ? `(${code})` : `(${t(code_unavailable)})`}</Text>
    </>
  );
};
