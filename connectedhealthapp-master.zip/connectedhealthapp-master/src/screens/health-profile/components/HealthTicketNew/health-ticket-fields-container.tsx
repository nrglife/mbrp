import React, { FC } from 'react';
import { useStores } from '../../../../hooks/useStores';
import { View, Text } from 'react-native';

import { styles as styleCreator } from './health-ticket.styles';
import TicketItem from './health-ticket-item.component';
import { ExtendedInfo } from '@healthcareapp/connected-health-common-services/src/stores/clinicals/types';

import { TFunction, useTranslation } from 'react-i18next';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface IHealthTicketFieldsContainerProps {
  info: ExtendedInfo[];
  isExtendedView?: boolean;
  dismissFieldsByLabelName?: string[];
}

export const HealthTicketFieldsContainer: FC<IHealthTicketFieldsContainerProps> = ({ info, isExtendedView = false, dismissFieldsByLabelName = null }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation();

  return (
    <View>
      {info
        .filter(item => !item.detailedViewOnly)
        .map((info, groupindex) => {
          return (
            <>
              {!!info?.title && <Text style={{ fontWeight: 'bold', paddingTop: 18 }}>{info.title}</Text>}
              <View key={'groupindex_' + groupindex} style={styles.itemsList}>
                {info.items.map(itemsList => {
                  return itemsList
                    .filter(field => !field.detailedViewOnly && !dismissFieldsByLabelName?.find(item => item === field.label))
                    .map(({ label, data, isHighlighted, type }, index) => {
                      return (
                        !!data && (
                          <TicketItem
                            fieldType={type}
                            unavailableTextStyle={styles.unavailableTextStyle}
                            t={t}
                            isBold={isHighlighted}
                            key={'fieldindex_' + groupindex + '_' + index.toString() + '_' + label}
                            header={label}
                            body={data}
                            isExtendedView={isExtendedView}
                          />
                        )
                      );
                    });
                })}
              </View>
            </>
          );
        })}
    </View>
  );
};
