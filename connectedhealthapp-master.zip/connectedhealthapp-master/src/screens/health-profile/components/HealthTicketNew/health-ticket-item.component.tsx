import React, { FC } from 'react';
import { useStores } from '../../../../hooks/useStores';
import { Text, View } from 'react-native';
import { TFunction } from 'i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';
import { FieldType } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';

interface TicketItemProps {
  header: string;
  body: string | string[];
  isDescriptionUnavailable?: boolean;
  isBold?: boolean;
  isExtendedView?: boolean;
  t: TFunction;
  unavailableTextStyle: { fontStyle: 'italic'; color: string };
  fieldType?: FieldType;
}

const TicketItem: FC<TicketItemProps> = ({ header, unavailableTextStyle, body, t, fieldType, isDescriptionUnavailable = false, isBold = false, isExtendedView = false }) => {
  const { brandingStore } = useStores();
  return (
    <View style={{ minWidth: '50%', marginTop: isExtendedView ? 22 : 9 }}>
      <Text style={[{ color: brandingStore.currentTheme.tooltip }, isExtendedView ? { ...brandingStore.textStyles.styleXSmallRegular } : { ...brandingStore.textStyles.styleXXSmallRegular }]}>
        {header}
      </Text>
      {fieldType === FieldType.collection && Array.isArray(body) && body.length > 0
        ? body.map((item, index) => {
          const endOfTheList = body!.length - 1 === index ? '' : ',';
          return <FieldDataTitle unavailableTextStyle={unavailableTextStyle} brandingStore={brandingStore} isExtendedView={isExtendedView} isBold={isBold} body={`${item}${endOfTheList}`} t={t} />;
        })
        : body && <FieldDataTitle isDescriptionUnavailable={isDescriptionUnavailable} unavailableTextStyle={unavailableTextStyle} brandingStore={brandingStore} isExtendedView={isExtendedView} isBold={isBold} body={body} t={t} />}
    </View>
  );
};
/** */
export default TicketItem;

interface FieldDataTitleProps {
  body?: string | string[];
  isDescriptionUnavailable?: boolean;
  isBold?: boolean;
  isExtendedView?: boolean;
  t: TFunction;
  unavailableTextStyle: { fontStyle: 'italic'; color: string };
  brandingStore: BrandingStoreMobile;
}

const { errors: { description_unavailable } } = LocaleKeys;
const FieldDataTitle: FC<FieldDataTitleProps> = ({ body, t, brandingStore, isDescriptionUnavailable, isBold, isExtendedView, unavailableTextStyle }) => (
  <>
    <View style={{ flexDirection: 'row' }}>
      {isDescriptionUnavailable &&
        <Text
          style={[unavailableTextStyle,
            isExtendedView ? { ...brandingStore.textStyles.styleSmallRegular } : { ...brandingStore.textStyles.styleXSmallRegular }
          ]}>
          {t(description_unavailable) + ' '}
        </Text>}
      <Text
        style={[
          isExtendedView ? { ...brandingStore.textStyles.styleSmallRegular } : { ...brandingStore.textStyles.styleXSmallRegular },
          { color: brandingStore.currentTheme.blackMain },
          isBold && { fontWeight: 'bold' },
          t(LocaleKeys.screens.Clinical.LabObservation.resultNotViewableThisTime) === body && unavailableTextStyle
        ]}>
        {body}
      </Text>
    </View>
  </>
);
