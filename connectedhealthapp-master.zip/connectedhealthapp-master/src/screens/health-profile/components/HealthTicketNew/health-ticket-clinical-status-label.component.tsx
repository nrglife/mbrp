import React, { FC } from 'react';
import { useStores } from '../../../../hooks/useStores';
import { Text, View } from 'react-native';

interface StatusLabelProps {
  cardStatus: string;
  backgroundColor: string;
  mode?: StatusLabelMode;
  useDarkTextColor?: boolean;
}

export enum StatusLabelMode {
  Full,
  OnTop
}

const StatusLabel: FC<StatusLabelProps> = ({ cardStatus, backgroundColor, mode = StatusLabelMode.OnTop, useDarkTextColor = false }) => {
  const { brandingStore } = useStores();

  return (
    <View
      style={[
        {
          backgroundColor,
          borderBottomLeftRadius: 5,
          borderBottomEndRadius: 5,
          position: 'absolute',
          right: 12,
          paddingHorizontal: 10,
          paddingVertical: 2
        },
        mode === StatusLabelMode.Full && {
          position: 'relative',
          right: 0,
          borderRadius: 5,
          alignSelf: 'flex-start',
          justifyContent: 'center',
          height: 29
        }
      ]}>
      <Text
        testID={'textLabel'}
        style={{
          textTransform: 'uppercase',
          color: useDarkTextColor === true ? '#0F0F59' : 'white',
          ...brandingStore.textStyles.styleXXSmallRegular
        }}>
        {cardStatus}
      </Text>
    </View>
  );
};

export default StatusLabel;
