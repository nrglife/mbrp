import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    mainContainer: {
      borderRadius: 12,
      marginTop: 20,
      marginLeft: 15,
      marginRight: 15,
      shadowColor: '#000',
      shadowRadius: 5,
      shadowOffset: {
        width: 0.5,
        height: 0.5
      },
      shadowOpacity: 0.1,
      ...Platform.select({
        android: {
          borderRadius: 15,
          overflow: 'hidden',
          elevation: 3,
          backgroundColor: 'grey'
        },
        ios: {}
      })
    },
    container: { flex: 1, alignItems: 'center' },
    formFieldStyle: { marginVertical: 5, width: '100%' },
    listItemStyle: { borderTopWidth: 1, borderColor: 'grey', padding: 20, backgroundColor: '#FFFFFF' },
    cardContainer: { padding: 20, backgroundColor: 'white', borderRadius: 12, overflow: 'hidden' },
    ticketTitle: { color: store.currentTheme.tooltip, ...store.textStyles.styleXXSmallRegular },
    secondaryTitle: { marginTop: 3.5, color: store.currentTheme.tooltip, ...store.textStyles.styleXXSmallRegular },
    header: { marginTop: 2, ...store.textStyles.styleSmallSemiBold, color: store.currentTheme.blackMain },
    problemCode: { ...store.textStyles.styleXSmallRegular, color: store.currentTheme.blackMain },
    body: { ...store.textStyles.styleXSmallRegular },
    itemsList: { flexDirection: 'row', marginTop: 7, flexWrap: 'wrap' },
    largeText: { ...store.textStyles.styleLargeRegular },
    smallText: { ...store.textStyles.styleSmallRegular },
    unavailableTextStyle: {
      fontStyle: 'italic',
      color: store.currentTheme.label
    },
    titleFooter: { paddingBottom: 15 }
  });
};
