import React, { FC } from 'react';
import { View, Text, RefreshControl, Platform, SectionList, SectionListProps, Image, ImageSourcePropType } from 'react-native';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import { useStores } from '../../../../hooks/useStores';
import { styles as stylesCreator } from './health-profile-base-component.styles';
import HealthTicketHeader from '../HealthTicketHeader/health-ticket-header';
import { EmptyList } from '../../../../components/empty-list/empty-list.component';
import { DisplayableHealthProfileItem, EmptyDataSource, GroupedDisplayableHealthProfileItem, NoDataType } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import HealthTicketNew from '../HealthTicketNew/health-ticket';
import images from '../../../../assets/images/images';
import { DelegationPickerContainer, PickerType, VisiblityMode } from '../../../../components/DelegationPickerContainer/delegation-picker.container';
import { NextPageSkeletonWrapper } from '../../../../components';
import { HealthCardSkeleton } from '../../medications/components/skeleton/medications-skeleton';
import { InlineWarning } from '../../../../components/CHInlineWarningItem/ch-inline-warning-item.component';
import { HomeNavigationRoutes } from '../../../../routes';
import { HealthProfileDisplayableType } from '@healthcareapp/connected-health-common-services/src/stores/clinicals/types';
import { EmptyListContainer } from '../../../../components/EmptyListContainer/empty-list-container';

export const getNoContentImage = (type: NoDataType) => {
  switch (type) {
    case NoDataType.error:
      return images.warning_thin;
    case NoDataType.not_completed:
      return images.clock;
    case NoDataType.empty:
      return images.no_content;
    default:
      return null;
  }
};
interface Header {
  groupedByTitle?: string;
}

interface HealthProfileBaseGroupedListProps extends SectionListProps<DisplayableHealthProfileItem, Header> {
  data: GroupedDisplayableHealthProfileItem[];
  isLoading: boolean;
  isNextPageLoading: boolean;
  apiErrorNextPage: any;
  isRefreshing: boolean;
  onRefresh: () => void;
  getNextPage: ({ numberOfRetries: number }) => void;
  // nextPageErrorMessage: string;
  // nextPageErrorActionText: string;
  SkeletonComponent: () => JSX.Element;
  noRecordsWarning: string;
  noContentToDisplay: EmptyDataSource;
  iconSource?: ImageSourcePropType;
}

const HealthProfileBaseGroupedList: FC<HealthProfileBaseGroupedListProps> = ({
  SkeletonComponent,
  isLoading,
  isNextPageLoading,
  apiErrorNextPage,
  isRefreshing,
  onRefresh,
  getNextPage,
  // nextPageErrorMessage,
  // nextPageErrorActionText,
  noRecordsWarning,
  noContentToDisplay,
  iconSource,
  data,
  ...props
}) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);

  return (
    <DelegationPickerContainer wrapInScrollView={true} pickerType={PickerType.ReadOnly} visiblityMode={VisiblityMode.MoreThanOne}>
      <>
        {!isLoading ? (
          <SectionList
            {...props}
            style={{ flex: 1 }}
            contentContainerStyle={[styles.sectionListStyle, data.length > 0 && { paddingBottom: 20 }]}
            renderSectionHeader={({ section: { groupedByTitle } }) => (groupedByTitle ? <HealthTicketHeader brandingStore={brandingStore} groupedByTitle={groupedByTitle} /> : <View />)}
            stickySectionHeadersEnabled={false}
            renderItem={({ item }) => {
              let iconSource: ImageSourcePropType = images.logo; //TODO: change it;

              switch (item.type) {
                case HealthProfileDisplayableType.medication:
                  iconSource = images.arrowDown; //TODO: change it;
                  break;

                case HealthProfileDisplayableType.condition_problem:
                  iconSource = images.arrowRight; //TODO: change it;
                  break;

                case HealthProfileDisplayableType.allergy:
                  iconSource = images.allergyItem;
                  break;

                case HealthProfileDisplayableType.procedure:
                  iconSource = images.procedureItem;
                  break;

                case HealthProfileDisplayableType.implantable_device:
                  iconSource = images.procedureItem;
                  break;
              }
              return <HealthTicketNew disabled={!item.isDetailedViewRequired()} item={item} iconSource={iconSource} routeToNavigate={HomeNavigationRoutes.HealthTicketDetailsContainer} />;
            }}
            keyExtractor={({ id }) => id}
            ListHeaderComponent={() => {
              return data?.length > 0 && noRecordsWarning ? <View style={styles.listHealderComponentStyles}>{noRecordsWarning && <InlineWarning text={noRecordsWarning} />}</View> : <></>;
            }}
            ListFooterComponent={() => {
              return (
                <NextPageSkeletonWrapper
                  loadingNextPage={isNextPageLoading}
                  nextPageError={apiErrorNextPage}
                  loadNextPage={() => {
                    getNextPage({ numberOfRetries: 2 });
                  }}>
                  <HealthCardSkeleton />
                </NextPageSkeletonWrapper>
              );
            }}
            ListEmptyComponent={() => {
              return (
                <EmptyListContainer
                  containerStyle={styles.logoAndTitleContainer}
                  apis={noContentToDisplay?.errorSource ? [noContentToDisplay?.errorSource] : null}
                  text={noContentToDisplay?.errorText}
                  image={getNoContentImage(noContentToDisplay?.type)}
                  imageStyle={styles.errorImageStyle}
                  textStyle={styles.textStyle}
                  resizeMode="contain"
                />
              );
            }}
            // ListFooterComponentStyle={styles.listFooterComponentStyles}
            refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} />}
            maxToRenderPerBatch={10}
            windowSize={5}
            removeClippedSubviews={
              // Subview clipping causes issues with sticky headers on Android and
              // would be hard to fix properly in a performant way.
              Platform.OS !== 'android'
            }
            onEndReachedThreshold={0.5}
            onEndReached={() => {
              if (!isLoading && !isNextPageLoading && !apiErrorNextPage) {
                getNextPage({ numberOfRetries: 2 });
              }
            }}
            disableIntervalMomentum={true}
          />
        ) : (
          <SkeletonComponent />
        )}
      </>
    </DelegationPickerContainer>
  );
};

export default HealthProfileBaseGroupedList;
