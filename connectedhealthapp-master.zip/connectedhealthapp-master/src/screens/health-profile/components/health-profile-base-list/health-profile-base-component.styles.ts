import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: 'white'
    },
    name: { ...store.textStyles.styleXLarge },
    arrowTicket: { width: 20, height: 20, alignSelf: 'center' },
    section: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      backgroundColor: 'white',
      paddingHorizontal: 15,
      paddingBottom: 10,
      borderBottomWidth: 0.5,
      borderBottomColor: store.currentTheme.separatorOpaque,
      paddingTop: 30
    },
    sectionDate: { ...store.textStyles.styleXSmallSemiBold },
    sectionFacility: { ...store.textStyles.styleXSmallRegular },
    textStyle: { textAlign: 'center', color: store.currentTheme.tooltip, marginTop: 16 },
    logoAndTitleContainer: { marginTop: 101, justifyContent: 'center', alignItems: 'center' },
    flexGrow: { flexGrow: 1 },
    flex: { flex: 1 },
    listFooterComponentStyles: { marginTop: 18, marginBottom: 36 },
    listHealderComponentStyles: { marginTop: 14, marginLeft: 27 },
    sectionListStyle: { flexGrow: 1, backgroundColor: 'white', paddingBottom:20 },
    errorImageStyle: { width: 44, height: 42 }
  });
};
