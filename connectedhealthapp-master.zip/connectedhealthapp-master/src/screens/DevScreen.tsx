import { StyleSheet, Text, View } from 'react-native';
import React, { FC, useMemo, useState } from 'react';
import RNPickerSelect, { Item } from 'react-native-picker-select';
import { useStores } from '../hooks/useStores';
import RNRestart from 'react-native-restart';
import { CHActionButton } from '../components';
import { LOG_LEVELS } from '../utilities/logger/LOG_LEVELS';
//import LogHelper from '../utilities/logger/LogHelper';
import EnrollmentAPI from '../services/http/enrollment/enrollment-api';

declare interface IProps {}

const DevScreen: FC<IProps> = props => {
  const { appConfigStore, brandingStore } = useStores();
  const [selectedEnvID, setSelectedEnvID] = useState<number>(appConfigStore.envId);
  const [logLevel, setLogLevel] = useState<number>(appConfigStore.logLevel);
  const textStyles = brandingStore.textStyles;

  const debugOptions: Item[] = useMemo(() => {
    return Object.entries(LOG_LEVELS).map(item => ({ value: item[1].type, label: item[1].label }));
  }, []);

  const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
      ...textStyles.styleXLarge,
      paddingVertical: 12,
      paddingHorizontal: 10,
      borderWidth: 1,
      borderColor: 'gray',
      borderRadius: 4,
      color: 'black',
      paddingRight: 30
    },
    inputAndroid: {
      ...textStyles.styleXLarge,
      paddingHorizontal: 10,
      paddingVertical: 8,
      borderWidth: 0.5,
      borderColor: 'purple',
      borderRadius: 8,
      color: 'black',
      paddingRight: 30 // to ensure the text is never behind the icon
    }
  });

  return (
    appConfigStore.envNames.length > 0 &&
    debugOptions.length > 0 && (
      <View style={{ flex: 1, justifyContent: 'space-around', alignContent: 'center' }}>
        <View>
          <View>
            <Text>Env Name</Text>
            <RNPickerSelect
              style={pickerSelectStyles}
              onValueChange={(value, urlId) => {
                if (value != null) {
                  setSelectedEnvID(urlId);
                }
              }}
              placeholder={{
                label: `Env Name - ${appConfigStore.envNames[selectedEnvID - 1] && appConfigStore.envNames[selectedEnvID - 1].label}`,
                value: null,
                color: 'red'
              }}
              items={appConfigStore.envNames}
            />
          </View>
          <View style={{ marginTop: 30 }}>
            <Text>Log Level</Text>
            <RNPickerSelect
              style={pickerSelectStyles}
              onValueChange={(value, id) => {
                if (value != null) {
                  setLogLevel(value);
                }
              }}
              items={debugOptions}
              placeholder={{
                label: `Log Level - ${debugOptions[logLevel].label}`,
                value: null,
                color: 'red'
              }}
            />
          </View>
        </View>
        <View>
          <CHActionButton
            style={{ marginTop: 30 }}
            onPress={() => {
              appConfigStore.saveDevId(selectedEnvID);
              appConfigStore.setLogLevel(logLevel);
              appConfigStore.loadDeveloperSettings().then(() => {
                RNRestart.Restart();
              });
            }}
            label={'save'}
          />
          <CHActionButton
            style={{ marginTop: 30 }}
            onPress={() => {
              //LogHelper.sendFeedback(() => {});
            }}
            label={'Send Log'}
          />
          <CHActionButton
            style={{ marginTop: 30 }}
            onPress={() => {
              //LogHelper.deleteAllLogFiles();
            }}
            label={'Clear Logs'}
          />
        </View>
      </View>
    )
  );
};

export default DevScreen;
