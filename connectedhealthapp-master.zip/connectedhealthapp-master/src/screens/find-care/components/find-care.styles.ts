import { ImageStyle, StyleSheet, TextStyle, ViewStyle } from 'react-native';
import { globals } from '../../../../globals';

export const styles = StyleSheet.create({
  mainContainer: { flex: 1 },
  container: { flex: 1, alignItems: 'center', padding: 30 },
  formFieldStyle: { marginVertical: 5, width: '100%' },
  listItemStyle : { borderTopWidth: 1, borderColor: 'grey', padding: 20 , backgroundColor:'#FFFFFF'}
});
