import React, { FC, useState } from 'react';
import { Text, Button, SafeAreaView, View, TextInput, Platform, ScrollView, TouchableOpacity, ActivityIndicator, FlatList } from 'react-native';
import DateTimePicker, { AndroidNativeProps, IOSNativeProps } from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';

import { NavigationProp } from '../../../models/navigation';

import { styles } from './find-care.styles';
import { useIsIOS } from '../../../hooks/useIsIOS';
import { Switch } from 'react-native-gesture-handler';

interface FindCareProps extends NavigationProp {}
export const FindCare: FC<FindCareProps> = ({ navigate }) => {
  return (
    <View style={{ flex: 1 }}>
      <Text>Find care</Text>
    </View>
  );
};
