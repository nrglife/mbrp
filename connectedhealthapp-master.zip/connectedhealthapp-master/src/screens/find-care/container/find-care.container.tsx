import { useNavigation } from '@react-navigation/native';
import React, { FC, useEffect } from 'react';
import { useNavigateTo } from '../../../hooks/useNavigateTo';
import { EnrollmentNavigationRoutes } from '../../../routes';
import { FindCare } from '../components/find-care.component';

export const FindCareContainer: FC = props => {
  const { navigate } = useNavigateTo(EnrollmentNavigationRoutes.PersonalInfo);
  const navigation = useNavigation()
  return (
      <FindCare navigate = {navigate} />
  )
  
};
