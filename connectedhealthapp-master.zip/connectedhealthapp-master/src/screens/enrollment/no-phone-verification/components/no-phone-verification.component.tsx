import React, { FC, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, GestureResponderEvent, Platform, Text, TouchableOpacity, View } from 'react-native';
import { CHCheckItem, CHTextInput } from '../../../../components';
import { globals } from '../../../../globals';
import { useStores } from '../../../../hooks/useStores';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { PhoneVerificationAction } from '../containers/no-phone-verification.container';
import { CheckedCircle } from './checked-circle/checked-circle.component';

import { styles as styleCreator } from './no-phone-verification.styles';
import { callNumber } from '../../../../utilities/linking';

interface SendCodeComponentProps {
  state: string;
  textColor: string;
  sendAttempts: number;
  disabledTextColor?: string;
  onPress: (event: GestureResponderEvent) => void;
}

export enum SendCodeButtonStates {
  Send_Code = 'Send Code',
  Resend_Code = 'Resend Code',
  Code_Sent = 'Code Sent',
  Send_Requested = 'Send Requested'
}

interface PhoneNumbersProps {
  phoneNumbers: string[];
  checkedIndex: number;
  onChecked: (index: number, phoneNumber: string) => void;
}

const PhoneNumbers: FC<PhoneNumbersProps> = ({ phoneNumbers, checkedIndex, onChecked }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <View style={styles.phoneNumbersContainer}>
      {phoneNumbers.map((phoneNumber: string, index: number) => (
        <View style={{ marginLeft: Platform.OS == 'android' ? 25 : 0 }} key={index}>
          <CHCheckItem
            {...createAccessibilityForAutomation(`phone number ending with ${phoneNumber} digits`)}
            style={styles.phoneNumber}
            checked={checkedIndex === index}
            onPress={() => onChecked(index, phoneNumber)}>
            <Text style={brandingStore.textStyles.styleLargeSemiBold}>{`(***) ***-${phoneNumber}`}</Text>
          </CHCheckItem>
          {/*Platform.OS === 'ios' && <View style={{ marginLeft: 24, borderBottomColor: brandingStore.currentTheme.separatorOpaque, borderBottomWidth: 1 }} />*/}
        </View>
      ))}
    </View>
  );
};

interface PhoneVerificationProps {
  phoneNumbers: string[];
  onSendCodeHandler: (event: GestureResponderEvent) => void;
  isVerificationCodeVisible: boolean;
  // dispatch: React.Dispatch<PhoneVerificationAction>;
  verificationCode: string;
  onTextChange: (string) => void;
  onCodeSetFocus: () => void;
  onCodeClearFocus: () => void;
  codeError: string | null;
  sendAttempts: number;
  sendCodeButtonState: SendCodeButtonStates;
  chcSupportPhoneNumber: string;
}

const SendCodeComponent: FC<SendCodeComponentProps> = ({ state, textColor, disabledTextColor = '#979797', onPress, sendAttempts }) => {
  const isButtonDisabled: boolean = useMemo(() => SendCodeButtonStates.Code_Sent === state, [state]);
  const isSendRequested: boolean = useMemo(() => SendCodeButtonStates.Send_Requested === state, [state]);
  const { brandingStore } = useStores();
  const textStyles = brandingStore.textStyles;
  const styles = styleCreator(brandingStore);

  const topPadding = state == SendCodeButtonStates.Code_Sent || state == SendCodeButtonStates.Send_Requested;
  return (
    <View style={{ flexDirection: 'column', marginTop: topPadding ? 5 : 0, marginBottom: topPadding ? 0 : 5 }}>
      <TouchableOpacity style={{}} onPress={onPress} disabled={isButtonDisabled || isSendRequested} {...createAccessibilityForAutomation(`${state} button`)}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          {isButtonDisabled ? (
            <View style={{ marginRight: 12 }}>
              <CheckedCircle width={20} height={20} color="#2ECC71" />
            </View>
          ) : null}
          {isSendRequested ? (
            <View style={{ marginRight: 12 }}>
              <ActivityIndicator size="small" color={Platform.OS == 'android' ? 'grey' : null} />
            </View>
          ) : null}
          <Text>
            <Text
              style={[
                {
                  ...(state === SendCodeButtonStates.Code_Sent ? brandingStore.textStyles.styleLargeSemiBold : brandingStore.textStyles.styleLargeSemiBoldLink),
                  color: brandingStore.currentTheme.actionMedium
                },
                {
                  color: isButtonDisabled ? disabledTextColor : textColor,
                  opacity: isSendRequested ? 0.3 : 1
                },
                textStyles.styleLargeSemiBold
              ]}>
              {state == SendCodeButtonStates.Code_Sent ? state : 'request a code'}
            </Text>
            {state == SendCodeButtonStates.Code_Sent ? null : <Text style={{ ...brandingStore.textStyles.styleLargeRegular, color: brandingStore.currentTheme.blackMain }}>.</Text>}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export const PhoneVerification: FC<PhoneVerificationProps> = ({
  phoneNumbers = [],
  sendCodeButtonState,
  onSendCodeHandler,
  isVerificationCodeVisible,
  verificationCode,
  onTextChange,
  onCodeClearFocus,
  onCodeSetFocus,
  sendAttempts,
  codeError,
  chcSupportPhoneNumber
}) => {
  const [checkedIndex, setCheckedIndex] = useState<number>(0);
  const [selectedPhoneNumber, setSelectedPhoneNumber] = useState<string>(phoneNumbers[0]);
  const { brandingStore, generalStore } = useStores();
  const styles = styleCreator(brandingStore);

  // console.log('PhoneVerification visible', isVerificationCodeVisible);

  useEffect(() => {
    setSelectedPhoneNumber(phoneNumbers[0]);
  }, [phoneNumbers]);

  const onChecked = (index: number, phoneNumber: string) => {
    setCheckedIndex(index);
    setSelectedPhoneNumber(phoneNumber);
  };

  const onChangeText = (code: string) => {
    onTextChange(code);
    //dispatch({ type: 'SET_VERIFICATION_CODE', payload: code });
  };

  const onSendCodePressHandler = (event: GestureResponderEvent) => {
    onSendCodeHandler(event);
  };

  return (
    <View style={styles.mainContainer}>
      {phoneNumbers.length > 0 && <PhoneNumbers phoneNumbers={phoneNumbers} checkedIndex={checkedIndex} onChecked={onChecked} />}
      <View style={{ marginTop: 5, marginLeft: 25, marginRight: 50, flexDirection: 'row' }}>
        <Text style={{ ...brandingStore.textStyles.styleLargeRegular, color: brandingStore.currentTheme.blackMain }}>1. </Text>
        <View style={{ flexDirection: 'column' }}>
          <Text>
            <Text style={{ ...brandingStore.textStyles.styleLargeRegular, color: brandingStore.currentTheme.blackMain }}>Call customer support at </Text>
            <Text
              onPress={() => {
                callNumber(chcSupportPhoneNumber);
              }}
              style={{
                ...brandingStore.textStyles.styleLargeSemiBoldLink,
                color: brandingStore.currentTheme.actionMedium
              }}>
              {chcSupportPhoneNumber}
            </Text>
            <Text
              style={{
                ...brandingStore.textStyles.styleSmallRegular,
                color: brandingStore.currentTheme.blackMain
              }}>
              .
            </Text>
          </Text>
        </View>
      </View>
      <View style={{ marginLeft: 25, marginRight: 50, marginTop: 36, flexDirection: 'row' }}>
        <Text style={{ ...brandingStore.textStyles.styleLargeRegular, color: brandingStore.currentTheme.blackMain }}>2. </Text>
        <View style={{ flexDirection: 'column' }}>
          <Text style={{ ...brandingStore.textStyles.styleLargeRegular, color: brandingStore.currentTheme.blackMain }}>When prompted by the agent you’ll be asked to </Text>
          <SendCodeComponent
            sendAttempts={sendAttempts}
            onPress={onSendCodePressHandler}
            textColor={brandingStore.currentTheme.actionMedium}
            disabledTextColor={'#979797'}
            state={sendCodeButtonState}
          />
        </View>
      </View>

      {isVerificationCodeVisible && (
        <Text
          style={{
            ...brandingStore.textStyles.styleLargeRegular,
            color: brandingStore.currentTheme.blackMain,
            marginLeft: 25,
            marginRight: 50,
            marginTop: 36
          }}>
          3. Enter the code below:
        </Text>
      )}

      {isVerificationCodeVisible ? (
        <View style={{ marginTop: 13 }}>
          <CHTextInput
            error={codeError}
            underlineColorAndroid="grey"
            placeholder={'6 Digits'}
            maxLength={6}
            onFocus={onCodeSetFocus}
            onEndEditing={onCodeClearFocus}
            onChangeText={onChangeText}
            keyboardType="numeric"
            value={verificationCode}
            labelStyle={{ color: brandingStore.currentTheme.label }}
            {...createAccessibilityForAutomation('Verification code')}
            label={'Verification Code'}
            toolTip="Code expires in 10 minutes."
          />
        </View>
      ) : null}
    </View>
  );
};
