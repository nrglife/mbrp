import NoPhoneVerificationContainer from './containers/no-phone-verification.container';

export { NoPhoneVerificationContainer };
