
import React , {FC} from 'react'
import {Button, Text, View} from 'react-native'

import {StepIndicatorProps} from './step-indicator-props'

export const StepIndicatorIOS: FC<StepIndicatorProps> = (props) => {
    return (
        <View style = {{alignItems: 'center'}}>
            <Text>Step {props.currentStep} of {props.totalSteps}</Text>        
        </View>
      );
        }