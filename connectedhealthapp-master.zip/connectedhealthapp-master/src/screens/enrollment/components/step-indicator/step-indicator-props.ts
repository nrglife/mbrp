import React, { ReactNode } from "react";
import { TextPropTypes } from "react-native";



export interface StepIndicatorProps{
    currentStep: number,
    totalSteps: number
}
