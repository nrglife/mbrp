
import React , {FC} from 'react'
import {Button, Text, View} from 'react-native'

import {StepIndicatorProps} from './step-indicator-props'

export const StepIndicatorAndroid: FC<StepIndicatorProps> = (props) => {
    return (
        <View style = {{alignItems: 'center'}}>
            <Text>Step {props.currentStep} of {props.totalSteps}</Text>   
  
            <View style = {{flexDirection: 'row', width: 200, height: 10}} >
                <View style = {{backgroundColor : '#2D958F', flex: props.currentStep}}></View>
                <View style = {{backgroundColor : '#D3D3D3', flex: props.currentStep + props.totalSteps}}></View>
            </View>
        </View>
      );

        }