import { Platform } from 'react-native'
import { StepIndicatorAndroid} from './step-indicator/step-indicator-android'
import { StepIndicatorIOS} from './step-indicator/step-indicator-ios'
import { StepIndicatorProps} from './step-indicator/step-indicator-props'

const StepIndicator = Platform.OS === 'android'? StepIndicatorAndroid : StepIndicatorIOS

export {StepIndicator}  