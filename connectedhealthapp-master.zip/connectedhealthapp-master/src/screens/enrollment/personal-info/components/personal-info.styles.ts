import { StyleSheet } from 'react-native';
import { globals } from '../../../../globals';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    description: { width: '100%', paddingLeft: 25, paddingRight: 25, alignItems: 'flex-start', color: 'store.currentTheme.blackMain' },
    descriptionText: { marginBottom: 10, color: store.currentTheme.blackMain, ...store.textStyles.styleLargeBold },
    mainContainer: { flex: 1, width: '100%', flexDirection: 'column', height: '100%' },
    container: { flex: 1, alignItems: 'center' },
    formFieldStyle: { marginVertical: 5, width: '100%' }
  });
};
