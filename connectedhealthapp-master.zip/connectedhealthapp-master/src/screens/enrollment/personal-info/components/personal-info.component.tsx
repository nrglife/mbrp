import React, { Dispatch, FC, LegacyRef, MutableRefObject, Ref, RefCallback, RefObject, useEffect, useRef, useState } from 'react';
import { MaskedViewBase, Text, TextInput, TextInputProps, View } from 'react-native';
import { NavigationProp } from '../../../../models/navigation';
import { styles as styleCreator } from './personal-info.styles';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { CHTextInput } from '../../../../components';
import { Action } from '../container/personal-info.container';
import { PersonalSecretIdentifier } from '@healthcareapp/connected-health-common-services/dist/stores/EnrollmentStore';
import { UserSecretMetadata } from '@healthcareapp/connected-health-common-services/src/stores/EnrollmentStore';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { useStores } from '../../../../hooks/useStores';
import moment from 'moment';
import { TextInputMask, TextInputMaskProps, TextMask } from 'react-native-masked-text';

interface PersonalInfoProps2 extends NavigationProp {
  dispatch: Dispatch<Action>;
  dateOfBirth: string;
  zipError: string;
  birthDateError: string;
  ssnError: string;
  userSecretMetadata: UserSecretMetadata;
  identityValue?: string;
  isError?: boolean;
  secretLength: number;
  zipCode?: string;
}

const DateInput = React.forwardRef<TextInput, TextInputProps>((props, ref: MutableRefObject<TextInput> | RefCallback<TextInput>) => {
  return (
    <TextInputMask
      refInput={r => {
        if ({}.toString.call(ref) == '[object Function]') {
          (ref as RefCallback<TextInput>)(r);
        } else {
          (ref as MutableRefObject<TextInput>).current = r;
        }
      }}
      {...props}
      type={'datetime'}
      options={{
        format: 'MM/DD/YYYY'
      }}
    />
  );
});

export const PersonalInfo: FC<PersonalInfoProps2> = ({ isError, navigate, dispatch, dateOfBirth, ssnError, zipError, userSecretMetadata, secretLength, identityValue, zipCode, birthDateError }) => {
  //const [isDatePickerVisible, setShowDatePicker] = useState<boolean>(false);
  const isSSN = !userSecretMetadata || userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.ssn;
  const { enrollmentStore, brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;
  const { t } = useTranslation('translation');
  const { PersonalInfo: PersonalInfoLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <>
      <View style={styles.description}>
        <Text style={[textStyles.styleLargeRegular,{marginTop:11,marginBottom:20, color:brandingStore.currentTheme.blackMain}]}>
          <Text style={textStyles.styleLargeRegular}>
            {
              t(PersonalInfoLocalKeys.DescriptionUnifiedDelegate1) // "If you are enrolling as a delegate,"
            }
          </Text>
          {
            t(PersonalInfoLocalKeys.DescriptionUnifiedDelegate2) // "please enter the info for the delegator below."
          }
        </Text>
      </View>
      <View style={styles.mainContainer}>
        <CHTextInput
          {...createAccessibilityForAutomation(isSSN ? 'Social Security #' : 'Secret Question')}
          isError={isError}
          maxLength={isSSN ? 4 : secretLength}
          error={ssnError}
          onChangeText={ssn =>
            dispatch({
              type: 'SET_IDENTITY',
              payload: { ssn, personalIdentifier: userSecretMetadata?.personalIdentifier, secretLength }
            })
          }
          style={{ marginTop: 0 }}
          // placeholder={isSSN ? 'last 4 digits' : 'secret'}
          label={
            isSSN
              ? t(PersonalInfoLocalKeys.SsnLabelSocialSecurityNumberUnified) // 'Social Security #'
              : t(PersonalInfoLocalKeys.SecretQuestionLabelUnified) // 'Secret Question'

          }
          keyboardType={isSSN ? 'number-pad' : 'default'}
          toolTip={
            isSSN
              ? t(PersonalInfoLocalKeys.SsnLabelUnified) // "LAST 4 DIGITS OF SSN"
              : userSecretMetadata?.secretDisplayName
          }
          // onEndEditing={() =>
          //   dispatch({
          //     type: 'VALIDATE_SSN',
          //     payload: { identityValue, secretLength, personalIdentifier: userSecretMetadata?.personalIdentifier }
          //   })
          // }
          onFocus={() => {
            // dispatch({ type: 'SET_VALIDATE_SSN' });
            dispatch({ type: 'CANCEL_SERVER_ERROR' });
            // dispatch({type: 'SET_SERVER_ERROR', payload: {isError: false}})
          }}
        />

        <CHTextInput
          enableClear={dateOfBirth && dateOfBirth.length != 0}
          onClear={() => {
            dispatch({ type: 'SET_BIRTHDAY_DATE', payload: '' });
          }}
          value={dateOfBirth}
          //keyboardType="number-pad"
          isError={isError}
          error={birthDateError}
          InputComponent={DateInput}
          onChangeText={text => {
            dispatch({ type: 'SET_BIRTHDAY_DATE', payload: text });
          }}
          onEndEditing={() => dispatch({ type: 'VALIDATE_BIRTHDAY_DATE', payload: dateOfBirth })}
          onFocus={() => {
            dispatch({ type: 'SET_VALIDATE_BIRTHDAY_DATE', payload: dateOfBirth });
            dispatch({ type: 'CANCEL_SERVER_ERROR' });
            // dispatch({type: 'SET_SERVER_ERROR', payload: {isError: false}})
          }}
          style={{ marginTop: 25 }}
          placeholder="mm/dd/yyyy"
          {...createAccessibilityForAutomation('Your Birthday')}
          label={t(PersonalInfoLocalKeys.BirthdayUnified)} // Birthday
          // toolTip={'Last four digits of your Social Security Number.'}
        />
        <CHTextInput
          isError={isError}
          maxLength={5}
          error={zipError}
          onChangeText={zipCode => dispatch({ type: 'SET_ZIP_CODE', payload: zipCode })}
          style={{ marginTop: 25 }}
          {...createAccessibilityForAutomation('Your ZIP code')}
          label={t(PersonalInfoLocalKeys.ZipCodeUnified)} // ZIP Code
          keyboardType="number-pad"
          onEndEditing={() => dispatch({ type: 'VALIDATE_ZIP_CODE', payload: zipCode })}
          onFocus={() => {
            dispatch({ type: 'SET_VALIDATE_ZIP_CODE', payload: zipCode });
            dispatch({ type: 'CANCEL_SERVER_ERROR' });
            // dispatch({type: 'SET_SERVER_ERROR', payload: {isError: false}})
          }}
        />
      </View>
    </>
  );
};
