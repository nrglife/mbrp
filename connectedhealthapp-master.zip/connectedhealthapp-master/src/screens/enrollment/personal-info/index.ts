export { PersonalInfoContainer } from './container/personal-info.container';
