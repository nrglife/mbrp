import { EnrollmentApi, EnrollmentSteps, failureSource } from '@healthcareapp/connected-health-common-services';
import { PersonalSecretIdentifier } from '@healthcareapp/connected-health-common-services/dist/stores/EnrollmentStore';
import { StackActions, useNavigation } from '@react-navigation/native';
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';

import moment from 'moment';
import React, { FC, useMemo, useCallback, useEffect, useReducer } from 'react';
import { useNavigateTo } from '../../../../hooks/useNavigateTo';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentNavigationRoutes } from '../../../../routes';
import { Text } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';
import stores from '../../../../stores';
import { StepContainer } from '../../containers';
import { PersonalInfo } from '../components/personal-info.component';
import { AxiosResponse } from 'axios';
import { observer } from 'mobx-react';
import Config from 'react-native-config';
import { IocContainer, IocTypesMobile } from '../../../../iocTypes';
import { AppSafeConsoleLogger } from '../../../../utilities/logger/console-log';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

interface State {
  postalcode: string;
  dateOfBirth?: string;
  identityValue: string;
  zipErrorErrorText: string;
  identityValueStringError: string;
  birthDateErrorText: string;
  serverError: Element;
  tryingPostData: boolean;
  isError: boolean;
}

const initialState: State = {
  postalcode: '',
  dateOfBirth: '',
  identityValue: '',
  zipErrorErrorText: '',
  birthDateErrorText: '',
  identityValueStringError: '',
  serverError: '',
  tryingPostData: false,
  isError: false
};

declare interface DataResponse {
  firstname: string;
  phone: string[];
}

declare interface PersonalInfoResponse {
  data: {
    success: boolean;
    message: string;
    data: DataResponse;
  };
}

type ActionTypes =
  | 'CANCEL_SERVER_ERROR'
  | 'SET_ZIP_CODE'
  | 'SET_BIRTHDAY_DATE'
  | 'SET_IDENTITY'
  | 'SET_ERROR'
  | 'SET_INVALID_DATE_ERROR'
  | 'VALIDATE_ZIP_CODE'
  | 'SET_VALIDATE_ZIP_CODE'
  | 'VALIDATE_BIRTHDAY_DATE'
  | 'SET_VALIDATE_BIRTHDAY_DATE'
  | 'SET_SERVER_ERROR'
  | 'SET_SUCCESS_POST_DATA'
  | 'TRYING_POST_DATA'
  | 'VALIDATE_SSN'
  | 'SET_VALIDATE_SSN';
export type Action = { type: ActionTypes; payload?: any };

function isNumeric(string: string): boolean {
  return /^-?\d+$/.test(string);
}

const isDatePast = date => {
  const now = new Date();
  return moment(date).diff(now) < 0;
};

const isBiggerThanMinDate = date => {
  const minDate = new Date();
  minDate.setFullYear(minDate.getFullYear() - 120);
  return moment(date).diff(minDate) > 0;
};

const isDateFormatValid = date => {
  return moment(date, 'MM/DD/YYYY', true).isValid();
};

const isDteValid = date => {
  return isDateFormatValid(date) && isDatePast(date) && isBiggerThanMinDate(date);
};

const reducerCreator =
  t =>
  (state: State = initialState, action: Action): State => {
    const { type, payload } = action;
    switch (type) {
      case 'SET_ZIP_CODE':
        return {
          ...state,
          postalcode: payload,
          isError: payload.isError
        };

      case 'VALIDATE_ZIP_CODE':
        const isZipCodeValid = isNumeric(payload) && payload.length === 5;
        return {
          ...state,
          zipErrorErrorText: isZipCodeValid ? '' : t(LocaleKeys.errors.please_enter_valid_zip_code)
        };

      case 'SET_VALIDATE_ZIP_CODE':
        return {
          ...state,
          postalcode: payload,
          zipErrorErrorText: ''
        };

      case 'VALIDATE_BIRTHDAY_DATE':
        let bdError = '';
        if (!isDateFormatValid(state.dateOfBirth)) {
          bdError = t(LocaleKeys.errors.please_enter_valid_date);
        } else if (!isDatePast(state.dateOfBirth)) {
          bdError = t(LocaleKeys.errors.please_enter_valid_birthday);
        } else if (!isBiggerThanMinDate(state.dateOfBirth)) {
          bdError = t(LocaleKeys.errors.please_enter_valid_birthday);
        }
        return {
          ...state,
          birthDateErrorText: bdError
        };

      case 'SET_VALIDATE_BIRTHDAY_DATE':
        return {
          ...state,
          dateOfBirth: payload,
          birthDateErrorText: ''
        };

      case 'SET_SERVER_ERROR':
        return {
          ...state,
          tryingPostData: false,
          serverError: payload.badReqError,
          isError: payload.isError
        };
      case 'CANCEL_SERVER_ERROR':
        return {
          ...state,
          isError: false
        };
      case 'SET_BIRTHDAY_DATE':
        //return state;
        return {
          ...state,
          dateOfBirth: payload
        };
      case 'SET_IDENTITY':
        // const isIdentityValueValid = payload.personalIdentifier === PersonalSecretIdentifier.ssn ? (payload.ssn.length === 4 && isNumeric(payload.ssn)) : payload.ssn.length === payload.secretLength
        return {
          ...state,
          identityValue: payload.ssn
          // identityValueStringError: isIdentityValueValid ? '' : 'identityValueStringError'
        };
      case 'SET_SUCCESS_POST_DATA':
        return {
          ...state,
          serverError: '',
          tryingPostData: false,
          isError: false
        };
      case 'TRYING_POST_DATA':
        return {
          ...state,
          tryingPostData: true
        };
      default:
        return { ...state };
    }
  };

export const PersonalInfoContainer: FC = observer(props => {
  const navigateToRoute = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.replace(route));
  };
  const { enrollmentStore, generalStore, brandingStore, appConfigStore } = useStores();
  // @ts-ignore
  const secretLength = enrollmentStore?.userSecretMetadata?.secretLength || 40;
  const { navigate } = useNavigateTo(EnrollmentNavigationRoutes.PersonalInfo);
  const navigation = useNavigation();

  const navigateTo = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.replace(route));
    //navigation.dispatch(StackActions.replace(route));
  };

  useEffect(() => {
    const timeoutId = enrollmentStore.registerEnrollmentTimeout(() => {
      // console.log('TIMEOUT from personal info screen: ', timeoutId);
      enrollmentStore.clearAllRegisteredTimeouts();
      navigateToRoute(EnrollmentNavigationRoutes.Timeout);
    }, minutesToMilliseconds(appConfigStore.appConfig.REACT_APP_ENROLLMENT_GLOBAL_TIME_OUT_IN_MINUTES));
  }, [enrollmentStore]);

  const { t } = useTranslation('translation');
  const { PersonalInfo: PersonalInfoLocalKeys } = LocaleKeys.components.Enrollment;

  const reducer = reducerCreator(t);

  const [{ postalcode, dateOfBirth, identityValue, zipErrorErrorText, identityValueStringError, serverError, tryingPostData, isError, birthDateErrorText }, dispatch] = useReducer(
    reducer,
    initialState
  );

  const isFormValid = useCallback(() => {
    let isValid = true;

    const isDateValid = isDteValid(dateOfBirth);
    const isZipCodeValid = isNumeric(postalcode) && postalcode.length === 5;
    const isIdentityValueValid = identityValue !== '';

    if (!isIdentityValueValid || !isZipCodeValid || !isDateValid) {
      isValid = false;
    }
    return isValid;
  }, [identityValue, dateOfBirth, postalcode]);

  const onNextHandler = async () => {
    if (!isFormValid()) return;

    const dataToSend = {
      ssn: enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.ssn ? identityValue : '',
      secret: enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.secret ? identityValue : '',
      dateOfBirth: moment(dateOfBirth).format('YYYY-MM-DD'),
      postalcode
    };
    try {
      dispatch({ type: 'TRYING_POST_DATA' });

      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postPersonalInfo({ code: enrollmentStore.invitationCode, errorHandlerParam: navigateTo, data: dataToSend });
      let errorString: string = null;
      AppSafeConsoleLogger.Info('response ', response);
      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS:
          dispatch({ type: 'SET_SUCCESS_POST_DATA' });
          const {
            data: { data }
          }: PersonalInfoResponse = response;

          if (generalStore.appSupportPhoneNumbers.length <= 0 || !generalStore.appSupportPhoneNumbers) {
            enrollmentStore.setStep(EnrollmentSteps.GeneralError);
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
            return;
          }

          if (!data.phone || (data.phone && Array.isArray(data.phone) && data.phone.length === 0)) {
            enrollmentStore.setUserCredentials({ ...data });
            enrollmentStore.setStep(EnrollmentSteps.NoUserPhone);
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.NoUserPhoneNumber));
            return;
          }

          enrollmentStore.setUserCredentials({ ...data });
          enrollmentStore.setStep(EnrollmentSteps.ConfirmPhoneNumber);
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.ConfirmPhoneNumber));
          return;

        case HTTP_STATUS_CODES.TIME_OUT:
          let errorString = t(LocaleKeys.errors.enrollment_process_timed_out);

          dispatch({ type: 'SET_SERVER_ERROR', payload: { badReqError: errorString, isError: false } });
          break;

        case HTTP_STATUS_CODES.NOT_FOUND:
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
          break;

        case HTTP_STATUS_CODES.BAD_REQUEST:
          let badReqError;
          let attempts = null;
          if (response.data.data && response.data.data.attemptMax && response.data.data.attemptCount) {
            const remainintAttempts = parseInt(response.data.data.attemptMax) - parseInt(response.data.data.attemptCount);
            if (remainintAttempts <= 0) {
              navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.Locked));
              return;
            }

            // dispatch({ type: 'SET_ATTEMPT_COUNT', payload: response.data.data.attemptMax });
            // dispatch({ type: 'SET_MAX_ATTEMPTS', payload: response.data.data.attemptCount });
            attempts = (
              <Text style={remainintAttempts <= 2 ? brandingStore.textStyles.styleLargeBold : null}>
                {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainintAttempts, s: remainintAttempts > 1 ? 's' : '' })}
              </Text>
            );
          }

          badReqError = (
            <>
              {t(LocaleKeys.errors.information_not_match_records)} {attempts ? attempts : ''}
            </>
          );
          dispatch({ type: 'SET_SERVER_ERROR', payload: { badReqError, isError: true } });
          break;
      }
    } catch (err) {
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        // dispatch({ type: 'SET_SERVER_ERROR', payload: { badReqError: t(LocaleKeys.errors.something_went_wrong), isError: true } });
        navigateTo(EnrollmentNavigationRoutes.GeneralError);
        return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
      } else {
        dispatch({ type: 'SET_SUCCESS_POST_DATA' });
      }
    }
  };
  return (
    <StepContainer
      title={t(PersonalInfoLocalKeys.DescriptionUnified)} // In order to protect personal information we need to ask you a few security questions.
      titleStyle={{ marginBottom: 0 }}
      logo={true}
      activityIndicator={tryingPostData}
      currentStep={enrollmentStore.stepNumber}
      totalSteps={enrollmentStore.totalSteps}
      error={serverError}
      next={{
        label: 'next',
        func: onNextHandler,
        enabled: isFormValid() && !isError
      }}>
      {enrollmentStore.userSecretMetadata && (
        <PersonalInfo
          secretLength={secretLength}
          isError={isError}
          zipCode={postalcode}
          userSecretMetadata={enrollmentStore.userSecretMetadata}
          zipError={zipErrorErrorText}
          birthDateError={birthDateErrorText}
          ssnError={identityValueStringError}
          navigate={navigate}
          dispatch={dispatch}
          dateOfBirth={dateOfBirth}
          identityValue={identityValue}
        />
      )}
    </StepContainer>
  );
});
