import React, { FC, useCallback, useEffect, useLayoutEffect, useMemo, useReducer, useRef, useState } from 'react';
import { observer } from 'mobx-react';
import Welcome from '../components/welcome.component';
import { StackActions, useFocusEffect, useNavigation } from '@react-navigation/native';
import { StepContainer } from '../../containers';
import { useNavigateTo } from '../../../../hooks/useNavigateTo';
import { EnrollmentNavigationRoutes, LoginNavigationRoutes } from '../../../../routes';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentApi, EnrollmentSteps, IocTypes, failureSource } from '@healthcareapp/connected-health-common-services';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import { AxiosResponse } from 'axios';

// import useAppCheckVersion from '../../../../hooks/useAppCheckVersion';
import Loader from '../../../../components/Loader';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Alert, AppState, Linking, View } from 'react-native';
import Config from 'react-native-config';
import { AppSafeConsoleLogger } from '../../../../utilities/logger/console-log';
//import Recaptcha, { RecaptchaHandles } from '../../../../utilities/recptcha/Recaptcha';
import { onReactionError } from 'mobx';
import { IocContainer } from '../../../../iocTypes';
import { useTranslation } from 'react-i18next';
import { i18nReloadTranslations } from '../../../../../i18n';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

interface WelcomeState {
  code: string;
  error: string;
  codeFieldError: string;
  activityIndicator: boolean;
}

const initialState: WelcomeState = {
  code: '',
  error: '',
  codeFieldError: null,
  activityIndicator: false
};

type WelcomeActionTypes = 'SET_CODE' | 'SET_ERROR' | 'SET_CODE_FIELD_ERROR' | 'SET_ACTIVITY_INDICATOR';
export type WelcomeAction = { type: WelcomeActionTypes; payload?: any };

const reducer = (state: WelcomeState = initialState, action: WelcomeAction): WelcomeState => {
  const { type, payload } = action;

  switch (type) {
    case 'SET_CODE':
      var reg = /^[0-9,A-Z, a-z]*$/g;
      if (!reg.test(payload) && payload.length != 0) {
        return { ...state, code: state.code + '' };
      }
      return { ...state, code: payload };
    case 'SET_ERROR':
      return { ...state, error: payload };

    case 'SET_CODE_FIELD_ERROR':
      return { ...state, codeFieldError: payload };
    case 'SET_ACTIVITY_INDICATOR':
      return { ...state, activityIndicator: payload };
  }
};

interface WelcomeContainerProps {}

const WelcomeContainer: FC<WelcomeContainerProps> = props => {
  const navigation = useNavigation();

  const { brandingStore, enrollmentStore, generalStore, payerStore, imageStore, appConfigStore, errorStore } = useStores();
  const { t } = useTranslation('translation');
  const [{ code, error, codeFieldError, activityIndicator }, dispatch] = useReducer(reducer, initialState);
  const ERROR_CODE_406_422 = t(LocaleKeys.errors.code_already_been_claimed);

  React.useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
      brandingStore.resetStore();
      brandingStore.setIsDefaultTheme(true);
      payerStore.setPayer(null);

      dispatch({ type: 'SET_CODE', payload: '' });
      dispatch({ type: 'SET_ERROR', payload: null });
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
      errorStore.clearAllErrors();
    });

    return unsubscribe;
  }, [navigation]);
  const navigate = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.push(route));
    //navigation.dispatch(StackActions.replace(route));
  };

  const onNextHandler = useCallback(async () => {
    dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: true });
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypes.EnrollmentApi).getInvitationCode({ code: code, errorHandlerParam: navigate });

      let errorString: string = null;
      AppSafeConsoleLogger.Info('response ', response);
      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS:
          const { data } = response;
          await payerStore.loadPayerFullData(data.data.customerId, {
            loadConfig: true,
            waitForAllLoadingTasks: true,
            loadTheme: true,
            loadImageLogos: true,
            loadDocuments: false,
            useStorageCache: false
          });
          await i18nReloadTranslations();
          enrollmentStore.setInvitationCode(code);
          enrollmentStore.setUserSecretMetadata({ ...data.data });
          enrollmentStore.setStep(EnrollmentSteps.PersonalInfo);
          dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
          // brandingStore.setCurrentTheme(brandingStore.aldenTheme);
          navigation.dispatch(StackActions.push(EnrollmentNavigationRoutes.ENrollmentSteps));
          return;
        case HTTP_STATUS_CODES.BAD_REQUEST:
        case HTTP_STATUS_CODES.NOT_FOUND:
          errorString = t(LocaleKeys.errors.invitation_screen_not_valid_code);
          dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: t(LocaleKeys.errors.this_is_not_valid_code) });
          break;
        case HTTP_STATUS_CODES.TIME_OUT:
          errorString = t(LocaleKeys.errors.enrollment_timed_out_try_again);
          break;

        //case HTTP_STATUS_CODES.ALREADY_IN_USE:
        default:
        //errorString = t(LocaleKeys.errors.could_not_activate_invitation_code);
      }
      dispatch({ type: 'SET_ERROR', payload: errorString });
    } catch (err) {
      console.log('err internal', err);
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        navigate(EnrollmentNavigationRoutes.GeneralError);
        dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });

        //dispatch({ type: 'SET_ERROR', payload: t(LocaleKeys.errors.something_went_wrong) });
      }
    } finally {
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
    }
  }, [navigation, code]);

  const onSignHandler = useCallback(() => {
    generalStore.setEnrollmentComplete(true);
  }, []);

  const verifyCode = (code: string) => {
    if (code.length == 6) {
      return true;
    }
    return false;
  };

  const codeErrorMessage = t(LocaleKeys.errors.must_match_6_character);

  const codeChangeHandler = useCallback((text: string) => {
    dispatch({ type: 'SET_CODE', payload: text });
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
    dispatch({ type: 'SET_ERROR', payload: null });
    errorStore.clearAllErrors();
  }, []);

  const onCodeClearFocus = () => {
    if (code.length != 0 && code.length != 6) {
      dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: codeErrorMessage });
    }
  };

  const onCodeSetFocus = () => {
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
  };

  const onContactHandler = useCallback(() => {
    generalStore.contactUsSheetRef.current.open();
  }, []);

  const onPrivacyPolicyHandler = useCallback(() => {
    Linking.openURL(appConfigStore.appConfig['PRIVACY_POLICY_LINK']);
  }, []);

  //const captchaForm = useRef<RecaptchaHandles>();

  /*const onNextHandler = () => {
          console.log('send!');
          captchaForm.current.open();
        };*/

  /*const onVerify = (token: string) => {
          console.log('success!', token);
          onCaptchaComplete(token);
        };

        const onRecaptchaError = error => {
          // console.log('error!!!!', error);
          Alert.alert(
            'Something went wrong',
            'Please make sure you are connected to the internet.',
            [
              {
                text: 'Ok',
                onPress: () => {}
              }
            ],
            { cancelable: false }
          );
        };*/

  /*const onExpire = () => {
          console.warn('expired!');
        };

        const onLoadRecaptcha = () => {};*/

  return (
    <>
      {/*<Loader size={8} isLoading={isLoading} />*/}
      <Welcome
        onCodeSetFocus={onCodeSetFocus}
        onCodeClearFocus={onCodeClearFocus}
        onNext={onNextHandler}
        onSignIn={onSignHandler}
        onPrivacyPolicy={onPrivacyPolicyHandler}
        onContactUs={onContactHandler}
        onCodeChanged={codeChangeHandler}
        nextEnabled={verifyCode(code) && !codeFieldError}
        code={code}
        codeError={codeFieldError}
        error={error}
        activityIndicator={activityIndicator}
      />
      {/*  <Recaptcha
        siteKey={appConfigStore.appConfig.RECAPTCHA_SITE_KEY}
        ref={captchaForm}
        baseUrl={'https://localhost'}
        onVerify={onVerify}
        onExpire={onExpire}
        size="invisible"
        onLoad={onLoadRecaptcha}
        onError={onRecaptchaError}
    />*/}
    </>
  );
};

export default observer(WelcomeContainer);
