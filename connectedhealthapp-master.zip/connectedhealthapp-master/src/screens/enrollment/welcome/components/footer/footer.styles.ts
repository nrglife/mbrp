import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    poweredBy: {
      color: store.currentTheme.label,
      width: '100%',
      marginTop: 10,
      textAlign: 'center'
    },
    main: {
      width: '100%',
      alignItems: 'center'
    },
    logoSmall: {
      width: 60,
      height: 18,
      marginTop: 6
    },
    nextButton: {
      marginTop: 17
    },
    questions: {
      color: store.currentTheme.tooltip
    },
    contactUsLink: {
      color: store.currentTheme.actionMedium
    },
    alreadyEnrolled: {
      color: store.currentTheme.blackMain
    },
    signInContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      marginTop: Platform.OS == 'android' ? 20 : 20
    },
    contactUsContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      marginTop: 20
    },
    privacyPolicyContainer: {
      flexDirection: 'column',
      justifyContent: 'center',
      marginTop: 15,
      marginBottom: insents.bottom == 0 ? 20 : 0
    },

    signInLink: {
      color: store.currentTheme.actionMedium
    },
    errorCode: {
      marginTop: 8
    }
  });
};
