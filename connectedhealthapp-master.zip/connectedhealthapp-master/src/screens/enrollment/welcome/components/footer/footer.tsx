import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { Image, Text, TouchableOpacity, View } from 'react-native';

import { styles as styleCreator } from './footer.styles';
import { CHActionButton, CHButton, CHTextInput, ErrorCode } from '../../../../../components';
import { TextInput } from 'react-native-gesture-handler';
import { useStores } from '../../../../../hooks/useStores';
import { WelcomeProps } from '../welcome-props';
import { createAccessibilityForAutomation } from '../../../../../utilities/accessibility';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useTranslation } from 'react-i18next';

interface FooterProps extends WelcomeProps {
  full: boolean;
}

const Footer: FC<FooterProps> = props => {
  const { brandingStore } = useStores();
  const { t } = useTranslation('translation');

  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;

  return (
    <View style={styles.main}>
      <CHActionButton
        {...createAccessibilityForAutomation('next button')}
        style={styles.nextButton}
        onPress={props.onNext}
        label={'next'}
        noBottomMargin={true}
        disabled={props.nextEnabled === false ? true : false}></CHActionButton>
      {props.full ? (
        <View style={styles.signInContainer}>
          <Text style={[styles.alreadyEnrolled, textStyles.styleLargeSemiBold]}>Already Enrolled? </Text>
          <TouchableOpacity onPress={props.onSignIn} {...createAccessibilityForAutomation('sign in button')}>
            <Text style={[styles.signInLink, textStyles.styleLargeSemiBoldLink]}>Sign In</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {props.full ? <Text style={[styles.poweredBy, textStyles.styleXXSmallRegular]}>Powered by</Text> : null}
      {props.full ? <Image style={styles.logoSmall} source={require('../../../../../assets/images/change_logo2.png')} /> : null}

      {props.full ? (
        <View style={styles.contactUsContainer}>
          <Text style={[styles.questions, textStyles.styleSmallRegular]}>Need help? </Text>
          <TouchableOpacity onPress={props.onContactUs} {...createAccessibilityForAutomation('contact us')}>
            <Text style={[styles.contactUsLink, { textDecorationLine: 'none' }, textStyles.styleSmallSemiBold]}>{t(LocaleKeys.errors.contact_us)}</Text>
          </TouchableOpacity>
        </View>
      ) : null}
      {props.full ? (
        <View style={styles.privacyPolicyContainer}>
          <TouchableOpacity onPress={props.onPrivacyPolicy} {...createAccessibilityForAutomation('privacy policy')}>
            <Text style={[styles.contactUsLink, textStyles.styleSmallSemiBoldLink]}>Privacy Policy</Text>
          </TouchableOpacity>
          <ErrorCode style={styles.errorCode} />
        </View>
      ) : null}
    </View>
  );
};

export default observer(Footer);
