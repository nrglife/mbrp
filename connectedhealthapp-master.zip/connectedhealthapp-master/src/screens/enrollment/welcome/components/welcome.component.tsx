import React, { FC, useCallback, useState } from 'react';
import { observer } from 'mobx-react';
import { Image, KeyboardAvoidingView, ScrollView, Text, TouchableOpacity, View, TextInput, Button, ActivityIndicator, Platform, Alert } from 'react-native';

import { styles as styleCreator } from './welcome.styles';
import { CHTextInput, KeyboardContainer } from '../../../../components';
import { useStores } from '../../../../hooks/useStores';
import { WelcomeProps } from './welcome-props';
import Footer from './footer/footer';
import Header from './header/header';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import withDevScreenLoadSupport from '../../../../HOCs/withDevScreenLoadSupport';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

const Welcome: FC<WelcomeProps> = props => {
  const stores = useStores();
  const { t } = useTranslation('translation');
  const { InvitationCode: InvitationCodeLocalKeys } = LocaleKeys.components.Enrollment;

  const styles = styleCreator(stores.brandingStore, stores.generalStore.insets.top + 20, stores.generalStore.insets.bottom);
  const textChangeHandler = useCallback(event => {
    props.onCodeChanged(event.nativeEvent.text);
  }, []);

  /***
   *
   *
       <View style={styles.main}>
      <View style={styles.mainContent}>
        <Header />
        <CHTextInput value={props.code} style={styles.input} placeholder={'6 characters'} label={'Invitation Code'} keyboardType="number-pad" onChange={useCallback(textChangeHandler, [])} />
      </View>

      <Footer {...props} />
    </View>
   */

  /**
    *
      return (
    <KeyboardAvoidingView style={styles.keyboardAvoidingView} behavior={'height'}>
      <ScrollView alwaysBounceVertical={false} style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.main}>
          <View style={styles.mainContent}>
            <Header />
            <View style={{ height: 250 }}></View>
            <CHTextInput value={props.code} style={styles.input} placeholder={'6 characters'} label={'Invitation Code'} keyboardType="number-pad" onChange={useCallback(textChangeHandler, [])} />
          </View>
        </View>
        <Footer {...props} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
};
    *
    */

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.main}>
        <KeyboardContainer
          {...props}
          mainView={
            <View style={styles.mainContent}>
              <Header onHeaderLogoPress={props.onDeveloperAreaPressHandler} error={props.error} />
              <CHTextInput
                {...createAccessibilityForAutomation('invitation code')}
                error={props.codeError}
                value={props.code}
                style={styles.input}
                onEndEditing={props.onCodeClearFocus}
                onFocus={props.onCodeSetFocus}
                toolTip={t(InvitationCodeLocalKeys.InvitationCodeToolTip, {totalCharacters: '6'})} // {{totalCharacters}} characters
                label={t(InvitationCodeLocalKeys.InvitationCodeLabel)}  // Invitation Code
                //keyboardType="number-pad"
                maxLength={6}
                onChange={textChangeHandler}
              />
            </View>
          }
          footer={<Footer {...props} full={true} />}
          keyboardFooter={<Footer {...props} full={false} />}
        />
      </View>
      {props.activityIndicator ? (
        <View style={{ backgroundColor: 'rgba(74,74,74,0.8)', width: '100%', height: '100%', position: 'absolute', flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size="small" color={Platform.OS == 'android' ? 'white' : 'white'} />
        </View>
      ) : null}
    </View>
  );
};

export default withDevScreenLoadSupport(observer(Welcome));
