import { Platform, StyleSheet } from 'react-native';
import { onScrollEvent } from 'react-native-redash';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile, top, bottom) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    main: {
      alignItems: 'center',
      backgroundColor: store.currentTheme.white,
      flex: 1,
      flexGrow: 1,

      paddingTop: top,
      paddingBottom: bottom
    },
    contentContainer: {
      flexGrow: 1
      // paddingTop: insents.top + 15,
      // paddingBottom: insents.bottom,
      //  flex:1
    },
    mainContent: {
      flex: 1,
      alignItems: 'center',
      flexGrow: 1
    },

    input: {
      marginTop: Platform.OS == 'android' ? 5 : 20
    },
    scrollView: {
      flex: 1,
      backgroundColor: store.currentTheme.white
    },
    keyboardAvoidingView: {
      flex: 1,
      backgroundColor: store.currentTheme.white
    }
  });
};
