import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { Image, Text, TouchableWithoutFeedback, View, ViewProps } from 'react-native';
import { styles as styleCreator } from './header.styles';
import { useStores } from '../../../../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface WelcomeHeaderProps extends ViewProps {
  error?: string;
  onHeaderLogoPress: () => void;
}

const Header: FC<WelcomeHeaderProps> = props => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;
  const { t } = useTranslation('translation');
  const { InvitationCode: InvitationCodeLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <View style={styles.main}>
      <TouchableWithoutFeedback onPress={props.onHeaderLogoPress}>
        <Image style={styles.logo} source={require('../../../../../assets/images/change_logo.png')} />
      </TouchableWithoutFeedback>
      <Text style={[styles.welcomeText, textStyles.styleXLarge]}>
        {
          t(LocaleKeys.components.Enrollment.InvitationCode.TitleUnified) // Welcome to Connected Health
        }
      </Text>
      {props.error ? <Text style={[styles.errorStyle, { color: brandingStore.currentTheme.error }, textStyles.styleLargeSemiBold]}>{props.error}</Text> : null}
      <Text style={[styles.messageBody, textStyles.styleLargeSemiBold]}>
        {
          t(InvitationCodeLocalKeys.DescriptionUnified1) + ' ' + t(InvitationCodeLocalKeys.DescriptionUnified2) // Please enter your invitation code. You should have received this by email or mail.
        }
      </Text>
    </View>
  );
};

export default observer(Header);
