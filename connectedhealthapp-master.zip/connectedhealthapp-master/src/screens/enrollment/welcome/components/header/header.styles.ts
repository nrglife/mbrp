import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    main: {
      alignItems: 'center',
      backgroundColor: store.currentTheme.white,
      paddingHorizontal: 25,
      width: '100%',
    },
    title: {
      marginTop: 50
    },
    messageBody: {
      marginTop: 20,
      color: store.blackMain,
      width: '100%'
    },
    welcomeText: {
      color: store.currentTheme.changeBlue,
      marginTop: 11,
      width: 216,
      textAlign: 'center'
    },
    logo: {
      width: 57,
      height: 62,
      marginTop: 20,
      borderRadius: 18,
      overflow: 'hidden',resizeMode:"contain"
    },
    errorStyle: { alignSelf: 'center', textAlign: 'center', marginTop: 25 }
  });
};
