export interface WelcomeProps {
    onNext: () => void;
    onSignIn: () => void;
    onContactUs: () => void;
    onPrivacyPolicy: () => void;
    onCodeChanged: (text:string) => void;
    code: string;
    nextEnabled: boolean;
    codeError?: string;
    error?:string
    onCodeSetFocus: ()=>void;
    onCodeClearFocus: ()=>void;
    activityIndicator: boolean;
    onDeveloperAreaPressHandler: () => void;
  }
