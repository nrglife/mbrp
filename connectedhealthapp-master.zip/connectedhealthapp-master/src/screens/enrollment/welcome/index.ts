import Welcome from './containers/welcome.container';

export { Welcome };
