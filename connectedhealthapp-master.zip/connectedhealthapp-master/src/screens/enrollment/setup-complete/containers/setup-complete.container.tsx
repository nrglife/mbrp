import React, { FC, useEffect } from 'react';
import { observer } from 'mobx-react';
import SetupComplete from '../components/setup-complete.component';
import { useNavigation } from '@react-navigation/native';
import { StepContainer } from '../../containers';
import { useNavigateTo } from '../../../../hooks/useNavigateTo';
import { EnrollmentNavigationRoutes, LoginNavigationRoutes } from '../../../../routes';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentSteps } from '@healthcareapp/connected-health-common-services';
import { ENROLLED_KEY } from '../../../../utilities/async-storage-keys';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface SetupCompleteContainerProps {}
const SetupCompleteContainer: FC<SetupCompleteContainerProps> = props => {
  const navigation = useNavigation();
  const stores = useStores();
  const { t } = useTranslation('translation');
  const { Enrolled: EnrolledLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <StepContainer
      title={
        t(EnrolledLocalKeys.TitleUnified) // 'Sign in to get started'
      }
      messageBody={
        t(EnrolledLocalKeys.DescriptionLandingPageSetupComplete) + // 'Your account setup is complete.'
        '\n' +
        t(EnrolledLocalKeys.DescriptionLandingPageNextStep) // 'The next step is to sign in with the email you just used for verification:'
      }
      currentStep={null}
      totalSteps={stores.enrollmentStore.totalSteps}
      titleStyle={stores.brandingStore.textStyles.styleXLarge}
      centerAlign={true}
      noHeader={true}
      logoBottom={true}
      HideContactUs={true}
      descriptionMargin={9}
      next={{
        label: t(EnrolledLocalKeys.ButtonSignIn), // 'Sign in'
        func: async () => {
          stores.generalStore.setEnrollmentComplete(true);
          await AsyncStorage.setItem(ENROLLED_KEY, 'true');
        },
        enabled: true
      }}>
      <SetupComplete emailAddress={stores.enrollmentStore.registeredEmail} />
    </StepContainer>
  );
};

export default observer(SetupCompleteContainer);
