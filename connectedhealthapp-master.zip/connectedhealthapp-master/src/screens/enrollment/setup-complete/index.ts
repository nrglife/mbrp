import SetupComplete from './containers/setup-complete.container';

export { SetupComplete };
