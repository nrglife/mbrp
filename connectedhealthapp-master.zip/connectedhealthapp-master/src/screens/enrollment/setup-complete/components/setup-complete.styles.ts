import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  main: {
    marginHorizontal: 15,
    justifyContent: 'center'
  }
});
