import React, { FC, useCallback } from 'react';
import { observer } from 'mobx-react';
import { BackHandler, StatusBar, Text, View } from 'react-native';

import { styles } from './setup-complete.styles';
import { CHTextInput } from '../../../../components';
import { useStores } from '../../../../hooks/useStores';
import { useFocusEffect } from '@react-navigation/native';
import stores from '../../../../stores';

interface SetupCompleteProps {
  emailAddress: string;
}

const onBackPress = () => {
  return true;
};

const SetupComplete: FC<SetupCompleteProps> = props => {
  const { brandingStore } = useStores();
  useFocusEffect(
    useCallback(() => {
     const hardwareBackPress =  BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => hardwareBackPress.remove()
    }, [])
  );
  return (
    <View style={styles.main}>
      <StatusBar backgroundColor={brandingStore.currentTheme.backgroundLight} barStyle={'dark-content'} />
      <Text style={[brandingStore.textStyles.styleLargeSemiBold, { color: brandingStore.currentTheme.blackMain, textAlign: 'center' }]}>{props.emailAddress}</Text>
    </View>
  );
};

export default observer(SetupComplete);
