import React, { FC, useMemo, useReducer, useState } from 'react';
import { observer } from 'mobx-react';
import CreatePasswordScreen from '../components/create-password.component';
import { StackActions, useNavigation } from '@react-navigation/native';
import { StepContainer } from '../../containers';
import { EnrollmentNavigationRoutes } from '../../../../routes';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentApi, EnrollmentSteps, failureSource } from '@healthcareapp/connected-health-common-services';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import { IocContainer, IocTypesMobile } from '../../../../iocTypes';
import { useTranslation } from 'react-i18next';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

interface State {
  password: string;
  confirmPassword: string;
  error: string;
  inputError: string;
  tryingPostData: boolean;
}

const initialState: State = {
  password: '',
  confirmPassword: '',
  error: '',
  inputError: '',
  tryingPostData: false
};
type ActionTypes = 'SET_SUBMIT_PASSWORD_ERROR' | 'SET_CONFIRM_PASSWORD' | 'SET_PASSWORD' | 'SET_PASSWORD_ERROR' | 'SET_ACTIVITY_INDICATOR' | 'CLEAR_ACTIVITY_INDICATOR' | 'SET_ERROR';

export type PasswordAction = { type: ActionTypes; payload?: any };

const reducer = (state: State = initialState, action: PasswordAction): State => {
  const { type, payload } = action;
  switch (type) {
    case 'SET_PASSWORD':
      return { ...state, password: payload };
    case 'SET_PASSWORD_ERROR':
      return { ...state, inputError: payload };
    case 'SET_ERROR':
      return { ...state, error: payload };
    case 'SET_CONFIRM_PASSWORD':
      return { ...state, confirmPassword: payload };
    case 'SET_SUBMIT_PASSWORD_ERROR':
      return { ...state, password: payload, error: payload, tryingPostData: false };
    case 'SET_ACTIVITY_INDICATOR':
      return { ...state, tryingPostData: true };

    case 'CLEAR_ACTIVITY_INDICATOR':
      return { ...state, tryingPostData: false };
    default:
      return state;
  }
};

const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,100}$/;

const CreatePasswordContainer = () => {
  const { enrollmentStore, appConfigStore } = useStores();
  const { t } = useTranslation('translation');
  const { CreatePassword: CreatePasswordLocalKeys } = LocaleKeys.components.Enrollment;
  const navigation = useNavigation();
  const stores = useStores();
  const [{ password, inputError, confirmPassword, error, tryingPostData }, dispatch] = useReducer(reducer, initialState);
  const passwordsAreMatches = password === confirmPassword;
  const isValid = passwordsAreMatches && passwordRegex.test(password);
  const validatePasswords = () => {
    let errorString;
    if (!passwordsAreMatches && password.length > 0 && confirmPassword.length > 0) {
      errorString = t(LocaleKeys.errors.your_passwords_dont_match);
      dispatch({
        type: 'SET_PASSWORD_ERROR',
        payload: errorString
      });
      return;
    } else if ((!passwordRegex.test(password) && password.length > 0) || (!passwordRegex.test(confirmPassword) && confirmPassword.length > 0)) {
      errorString = t(LocaleKeys.errors.doesnt_meet_password_requirements);
      dispatch({
        type: 'SET_PASSWORD_ERROR',
        payload: errorString
      });
      return;
    } else {
      errorString = '';
      dispatch({ type: 'SET_PASSWORD_ERROR', payload: errorString });
      return;
    }
  };

  const navigate = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.replace(route));
  };
  const handleSubmit = async () => {
    dispatch({
      type: 'SET_ERROR',
      payload: null
    });
    // setError(null);
    const { invitationCode = '', userId = '' } = enrollmentStore || {};
    if (!isValid) {
      return;
    } else {
      dispatch({ type: 'SET_ACTIVITY_INDICATOR' });
      try {
        const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postPassword({ code: invitationCode, errorHandlerParam: navigate, password: password, userId: userId });
        // let errorString = '';
        switch (response.status) {
          case HTTP_STATUS_CODES.SUCCESS:
            enrollmentStore.setStep(EnrollmentSteps.Enrolled);
            stores.enrollmentStore.clearAllRegisteredTimeouts();
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.EnrollmentComplete));
            break;
          case HTTP_STATUS_CODES.BAD_REQUEST:
            dispatch({
              type: 'SET_ERROR',
              payload: t(LocaleKeys.errors.something_wrong_try_again)
            });
            dispatch({ type: 'CLEAR_ACTIVITY_INDICATOR' });
            //  stores.enrollmentStore.clearAllRegisteredTimeouts();
            //  navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
            break;
          case HTTP_STATUS_CODES.NOT_FOUND:
            stores.enrollmentStore.clearAllRegisteredTimeouts();
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
            break;
          default:
        }
      } catch (err) {
        if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
          navigate(EnrollmentNavigationRoutes.GeneralError);
        } else {
          dispatch({ type: 'CLEAR_ACTIVITY_INDICATOR' });
        }
      }
    }
  };

  return (
    <StepContainer
      activityIndicator={tryingPostData}
      currentStep={stores.enrollmentStore.stepNumber}
      totalSteps={stores.enrollmentStore.totalSteps}
      error={error}
      title={t(CreatePasswordLocalKeys.Title, 'Email confirmed, let’s create a password')}
      messageBody={
        t(CreatePasswordLocalKeys.DescriptionWhatTo) // 'Create a unique password that will be used for signing into Connected Health.'
      }
      next={{
        label: t(CreatePasswordLocalKeys.NextButton), // 'Next'
        func: async () => {
          handleSubmit();
        },
        enabled: isValid
      }}>
      <CreatePasswordScreen validatePasswords={validatePasswords} inputError={inputError} dispatch={dispatch} />
    </StepContainer>
  );
};

export default observer(CreatePasswordContainer);
