import CreatePasswordContainer from './containers/create-password.container';

export { CreatePasswordContainer };
