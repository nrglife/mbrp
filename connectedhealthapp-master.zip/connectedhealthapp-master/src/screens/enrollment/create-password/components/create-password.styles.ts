import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    hint: {
      color: store.currentTheme.tooltip,
      marginHorizontal: 20
    }
  });
};
