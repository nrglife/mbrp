import React, { Dispatch, FC, SetStateAction, useState } from 'react';
import { observer } from 'mobx-react';
import { Text, View } from 'react-native';

import { styles as styleCreator } from './create-password.styles';
import { CHTextInput } from '../../../../components';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { Action } from '../../personal-info/container/personal-info.container';
import { PasswordAction } from '../containers/create-password.container';
import { useStores } from '../../../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface CreatePasswordProps {
  dispatch: Dispatch<PasswordAction>;
  inputError: string;
  validatePasswords: () => void;
}

const INPUT_MAX_LENGTH = 100;

const CreatePasswordScreen: FC<CreatePasswordProps> = ({ dispatch, inputError, validatePasswords }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation('translation');
  const { CreatePassword: CreatePasswordLocalKeys } = LocaleKeys.components.Enrollment;
  const [isSecureTextEntry, setSecureTextEntry] = useState(true);
  return (
    <View style={{ marginTop: 0 }}>
      <CHTextInput
        {...createAccessibilityForAutomation('New Password')}
        // secureTextEntry={true}
        passwordInput={true}
        isSecureTextEntry={isSecureTextEntry}
        setSecureTextEntry={setSecureTextEntry}
        labelWidth={55}
        disableTooltip={true}
        onChangeText={password => dispatch({ type: 'SET_PASSWORD', payload: password })}
        label={
          t(CreatePasswordLocalKeys.Password) // 'Password'
        }
        onEndEditing={validatePasswords}
        isError={!!inputError}
        maxLength={INPUT_MAX_LENGTH}
        onFocus={() => {
          dispatch({ type: 'SET_PASSWORD_ERROR', payload: '' });
        }}
      />
      <CHTextInput
        {...createAccessibilityForAutomation('Confirm Password')}
        passwordInput={true}
        isSecureTextEntry={isSecureTextEntry}
        setSecureTextEntry={setSecureTextEntry}
        labelWidth={55}
        disableTooltip={!inputError}
        onChangeText={confirmPassword => dispatch({ type: 'SET_CONFIRM_PASSWORD', payload: confirmPassword })}
        label={
          t(CreatePasswordLocalKeys.ConfirmPassword) // 'Confirm Password'
        }
        error={inputError}
        onEndEditing={validatePasswords}
        maxLength={INPUT_MAX_LENGTH}
        onFocus={() => {
          dispatch({ type: 'SET_PASSWORD_ERROR', payload: '' });
        }}
        //placeholder={'8 digits'}
      />
      <Text style={[styles.hint, !inputError ? { marginTop: 8 } : { marginTop: 5 }, brandingStore.textStyles.styleSmallRegular]}>
        {
          t(CreatePasswordLocalKeys.DescriptionRequirements) // 'Minimum 8 characters, both upper and lower case letters, at least one number, and one special character.'
        }
      </Text>
    </View>
  );
};

export default observer(CreatePasswordScreen);
