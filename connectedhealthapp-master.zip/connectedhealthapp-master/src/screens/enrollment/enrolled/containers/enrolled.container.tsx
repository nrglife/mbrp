import React, { FC } from 'react';
import { Enrolled } from '../components/enrolled.component';

interface EnrolledContainerProps {}

export const EnrolledContainer: FC<EnrolledContainerProps> = props => {
  return <Enrolled />;
};
