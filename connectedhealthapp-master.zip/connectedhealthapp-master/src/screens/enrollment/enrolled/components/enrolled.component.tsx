import React, { FC } from 'react';

import { View, Text } from 'react-native';

interface EnrolledProps {}
export const Enrolled: FC<EnrolledProps> = props => {
  return (
    <View>
      <Text>enrolled screen</Text>
    </View>
  );
};
