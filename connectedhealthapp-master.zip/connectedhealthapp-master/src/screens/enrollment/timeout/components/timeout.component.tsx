import React, { FC } from 'react';
import { Text, View } from 'react-native';

import { styles } from './timeout.styles';

export interface TimeoutProps {}

export const MissingInfo: FC<TimeoutProps> = props => {
  return (
    <View>
      <Text>error screen</Text>
    </View>
  );
};
