import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { ErrorContainer } from '../../containers';
import { StackActions, useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export interface TimeoutContainerProps {}

export const TimeoutContainer: FC<TimeoutContainerProps> = observer(({}) => {
  const navigation = useNavigation();
  const { t } = useTranslation('translation');
  return (
    <ErrorContainer
      title={t(LocaleKeys.errors.enrollment_timed_out)}
      messageBody={t(LocaleKeys.errors.enrollment_process_timed_out)}
      ok={{
        label: 'Ok',
        func: () => {
          navigation.dispatch(StackActions.pop());
        }
      }}
    />
  );
});
