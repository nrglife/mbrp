import React, { FC, useEffect } from 'react';
import { StatusBar, Text, View } from 'react-native';
import FastImage from 'react-native-fast-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CHActionButton, ErrorCode } from '../../../../components';
import { useStores } from '../../../../hooks/useStores';
import { ErrorContainerProps } from './error-container-props';

import images from '../../../../assets/images/images';
import { styles as styleCreator } from './error-container.styles';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';

export const ErrorContainerIOS: FC<ErrorContainerProps> = ({ title, messageBody, ok, children, footer, errorApi, errorCode }) => {
  const { brandingStore, enrollmentStore, errorStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { bottom, top } = useSafeAreaInsets();
  const textStyles = brandingStore.textStyles;

  useEffect(() => {
    enrollmentStore.clearAllRegisteredTimeouts();
  }, [enrollmentStore]);
  return (
    <View style={[styles.mainContainerStyle, { paddingBottom: bottom, paddingTop: top }, { flexDirection: 'column', paddingBottom: 34 }]}>
      <StatusBar backgroundColor={brandingStore.currentTheme.actionDark} barStyle={'light-content'} />
      <View style={{ alignItems: 'center', marginTop: 75, flexDirection: 'column', flex: 1 }}>
        <FastImage resizeMode="cover" style={styles.logoStyle} source={images.error} />
        <View style={[styles.titleAndDescriptionContainerStyle, { alignItems: 'center' }]}>
          {title || true ? <Text style={[styles.titleStyle, { color: brandingStore.currentTheme.blackMain }, textStyles.styleXLarge]}>{title}</Text> : null}
          {messageBody || true ? <Text style={[styles.descriptionStyle, textStyles.styleLargeSemiBold]}>{messageBody}</Text> : null}
        </View>
        <View style={{ flex: 1 }}>{children}</View>
      </View>
      <View style={{ flexDirection: 'column', alignItems: 'center' }}>
        {footer ? (
          <Text style={[styles.footerText, { color: brandingStore.currentTheme.tooltip }, textStyles.styleSmallRegular]}>
            {footer.pt1}
            {'\n'}
            <Text
              {...createAccessibilityForAutomation(footer.link)}
              style={[styles.footerLink, { color: brandingStore.currentTheme.actionMedium }, textStyles.styleSmallSemiBold]}
              onPress={footer.onClick}>
              {footer.link}
            </Text>{' '}
            {footer.pt2}
          </Text>
        ) : null}
        <ErrorCode style={styles.errorCodeStyle} />
      </View>
      <View style={styles.buttonContainerStyle}>
        {ok ? (
          <CHActionButton
            {...createAccessibilityForAutomation(ok.label)}
            label={ok.label}
            onPress={() => {
              errorStore.getLastFilteredError() && errorStore.clearError(errorStore.getLastFilteredError().source);
              ok.func();
            }}></CHActionButton>
        ) : null}
      </View>
    </View>
  );
};
