import { Platform, StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    mainContainerStyle: { flex: 1, paddingTop: 0, alignItems: 'center', flexDirection: 'column', backgroundColor: 'white' },
    titleAndDescriptionContainerStyle: { width: '100%', paddingLeft: 35, paddingRight: 35, alignItems: 'flex-start' },
    logoStyle: { width: 58, height: 58, marginTop: 25 },
    titleStyle: { marginTop: 39 },
    descriptionStyle: { textAlign: 'center', marginTop: 20 },
    buttonContainerStyle: { flexDirection: 'column', width: '100%' },
    footerText: { marginRight: 60, marginLeft: 60, textAlign: 'center', marginBottom: 64 },
    errorCodeStyle: { marginBottom: 12, position: 'absolute', bottom: 0 },
    footerLink: {}
  });
};
