import { failureSource } from '@healthcareapp/connected-health-common-services';

export interface ErrorContainerOk {
  label: string;
  func: () => void;
}

export interface ErrorContainerProps {
  ok?: ErrorContainerOk;
  title?: string;
  messageBody?: string | Element;
  footer?: { pt1?: string; link: string; pt2?: string; onClick: () => void };
}
