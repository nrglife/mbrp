import { StepContainerIOS } from './step-container/step-container-ios';
import { StepContainerNext, StepContainerProps } from './step-container/step-container-props';

import { ErrorContainerIOS } from './error-container/error-container-ios';
import { ErrorContainerOk, ErrorContainerProps } from './error-container/error-container-props';

const StepContainer = StepContainerIOS;

const ErrorContainer = ErrorContainerIOS;

export { StepContainer, StepContainerNext, StepContainerProps, ErrorContainer, ErrorContainerOk, ErrorContainerProps };
