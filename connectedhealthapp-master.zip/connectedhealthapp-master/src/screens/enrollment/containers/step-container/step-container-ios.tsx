import React, { FC, useCallback } from 'react';
import { observer } from 'mobx-react';
import { ActivityIndicator, Linking, Modal, Platform, ScrollView, StatusBar, Text, TouchableOpacity, View } from 'react-native';
import FastImage from 'react-native-fast-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CHActionButton, ErrorCode, KeyboardContainer } from '../../../../components';
import { useStores } from '../../../../hooks/useStores';
import { StepContainerProps } from './step-container-props';

import images from '../../../../assets/images/images';
import { styles as styleCreator } from './step-container.styles';
import Footer from './footer/footer';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { callNumber } from '../../../../utilities/linking';
import { useTranslation } from 'react-i18next';
import { ImageState, LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useEffect } from 'react';

export const StepContainerIOS: FC<StepContainerProps> = observer(
  ({ logo, title, messageBody, next, children, error, centerAlign, noHeader, logoBottom, activityIndicator, titleStyle, descriptionMargin, HideContactUs }) => {
    const { brandingStore, imageStore, payerStore, generalStore, errorStore } = useStores();
    const { t } = useTranslation('translation');
    const styles = styleCreator(brandingStore);
    const { bottom, top } = useSafeAreaInsets();
    const textStyles = brandingStore.textStyles;

    useEffect(() => {
      errorStore.clearAllErrors();
    }, [errorStore]);

    const onContactUs = useCallback(() => {
      generalStore.contactUsSheetRef.current.open();
    }, []);
    return (
      <View style={{ flex: 1 }}>
        {activityIndicator ? (
          <Modal transparent={true}>
            <View
              style={{
                backgroundColor: 'rgba(74,74,74,0.8)',
                width: '100%',
                height: '100%',
                position: 'absolute',
                flex: 1,
                alignItems: 'center',
                justifyContent: 'center'
              }}>
              <ActivityIndicator size="small" color={Platform.OS == 'android' ? 'white' : 'white'}></ActivityIndicator>
            </View>
          </Modal>
        ) : null}
        <View
          style={[
            styles.mainContainerStyle,
            {
              paddingBottom: bottom,
              backgroundColor: brandingStore.currentTheme.backgroundLight
            },
            { flexDirection: 'column' }
          ]}>
          <StatusBar backgroundColor={brandingStore.currentTheme.actionDark} barStyle={'light-content'} />

          <KeyboardContainer
            mainView={
              <View style={{ flex: 1, alignItems: 'center', marginTop: noHeader ? 76 + top : 0 }}>
                {logo ? (
                  imageStore.images?.logos?.light?.state === ImageState.Loaded ? (
                    <FastImage resizeMode="contain" style={styles.logoStyle} source={{ uri: imageStore.images.logos.light.data }} />
                  ) : (
                    <Text style={[{ marginVertical: 25 }, textStyles.styleLargeSemiBold]}>{payerStore.payerName}</Text>
                  )
                ) : null}

                <View
                  style={[
                    styles.titleAndDescriptionContainerStyle,
                    centerAlign
                      ? {
                          alignItems: 'center',
                          paddingBottom: 0
                        }
                      : null
                  ]}>
                  {error ? <Text style={[styles.errorStyle, { color: brandingStore.currentTheme.error }, textStyles.styleLargeSemiBold]}>{error}</Text> : null}
                  {title ? <Text style={[styles.titleStyle, !messageBody ? { marginBottom: 20 } : null, textStyles.styleLargeSemiBold, titleStyle]}>{title}</Text> : null}
                  {messageBody ? (
                    <Text style={[styles.descriptionStyle, centerAlign ? { textAlign: 'center' } : null, textStyles.styleLargeRegular, descriptionMargin && { marginBottom: descriptionMargin }]}>
                      {messageBody}
                    </Text>
                  ) : null}
                </View>
                <View style={{ flex: 1, width: '100%' }}>{children}</View>
                {!HideContactUs && (
                  <View style={styles.contactUsContainer}>
                    <Text style={[styles.questions, textStyles.styleSmallRegular]}>Need help? </Text>
                    <TouchableOpacity onPress={onContactUs} {...createAccessibilityForAutomation('contact us')}>
                      <Text style={[styles.contactUsLink, { textDecorationLine: 'none' }, textStyles.styleSmallSemiBold]}>{t(LocaleKeys.errors.contact_us)}</Text>
                    </TouchableOpacity>
                  </View>
                )}
                <ErrorCode style={styles.errorCode} />
              </View>
            }
            footer={
              <View style={styles.buttonContainerStyle}>
                {next ? (
                  <CHActionButton {...createAccessibilityForAutomation(next.label)} disabled={!next.enabled} label={next.label} onPress={next.func}></CHActionButton>
                ) : (
                  <View style={{ opacity: 0 }}>
                    <CHActionButton label={''} onPress={() => {}} />
                  </View>
                )}
                {logoBottom ? <Footer /> : null}
              </View>
            }
            keyboardFooter={
              <View style={styles.buttonContainerStyle}>
                {next ? (
                  <CHActionButton noBottomMargin={true} {...createAccessibilityForAutomation(next.label)} disabled={!next.enabled} label={next.label} onPress={next.func}></CHActionButton>
                ) : null}
              </View>
            }
          />
        </View>
      </View>
    );
  }
);

// export const CallChcSupportBtn = ({phoneNumber, store, centerAlign, textStyles}) => {
//     return (
//         <TouchableOpacity
//             style={{margin: 0}}
//             onPress={() => {
//                 callNumber(phoneNumber);
//             }}>
//             <Text
//
//                 style={[
//                     {...store.textStyles.styleSmallSemiBoldLink, color: store.currentTheme.actionMedium},
//
//                 ]}>
//                 {phoneNumber}
//             </Text>
//         </TouchableOpacity>
//     );
// };
