import { TextStyle, ViewStyle } from 'react-native';

export interface StepContainerNext {
  label: string;
  func: () => void;
  enabled: boolean;
}

export interface StepContainerProps {
  next?: StepContainerNext;
  currentStep: number | null;
  totalSteps: number;
  logo?: boolean;
  logoBottom?: boolean;
  title?: string;
  messageBody?: string;
  error?: string | Element;
  centerAlign?: boolean;
  noHeader?: boolean;
  activityIndicator?: boolean;
  titleStyle?: TextStyle;
  descriptionMargin?: number;
  HideContactUs?:boolean

}
