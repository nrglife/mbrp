import { Platform, StyleSheet } from 'react-native';
import { globals } from '../../../../globals';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    mainContainerStyle: { flex: 1, paddingTop: 25, alignItems: 'center', flexDirection: 'column' },
    titleAndDescriptionContainerStyle: { width: '100%', paddingLeft: 25, paddingRight: 25, alignItems: 'flex-start' },
    logoStyle: { width: 130, height: 39, marginBottom: 25 },
    titleStyle: { marginBottom: 10, color: store.currentTheme.blackMain },
    errorStyle: { width: '100%', marginBottom: 20, textAlign: 'center' },
    descriptionStyle: { textAlign: 'left', marginTop: 0, marginBottom: 20, color: store.currentTheme.blackMain },
    descriptionStyle2: { textAlign: 'left', marginTop: 0, color: store.currentTheme.blackMain },
    callBtnStyle: { ...store.textStyles.styleLargeSemiBoldLink, color: store.currentTheme.actionMedium },
    buttonContainerStyle: { flexDirection: 'column', width: '100%' },

    questions: {
      color: store.currentTheme.tooltip
    },
    contactUsLink: {
      color: store.currentTheme.actionMedium
    },
    alreadyEnrolled: {
      color: store.currentTheme.blackMain
    },
    signInContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      marginTop: Platform.OS == 'android' ? 20 : 20
    },
    contactUsContainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      marginTop: 5,
      marginBottom: 25
    },

    signInLink: {
      color: store.currentTheme.actionMedium
    },
    errorCode: {
      marginBottom: 12
    }
  });
};
