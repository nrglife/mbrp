import { StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles =  (store: BrandingStoreMobile)=>{
    const insents = useSafeAreaInsets();

    
    return StyleSheet.create({
    
        poweredBy: {
            color: store.currentTheme.label,
            width: '100%',
            marginTop: 10,
            textAlign: 'center'
        },
        main :{
            width: '100%',
            alignItems:'center',
            marginBottom: 37
        },
        logoSmall: {
            width: 80,
            height: 24,
            marginTop: 10,
         
          },
        

})

}
