import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { Image, Text, View } from 'react-native';

import { styles as styleCreator } from './footer.styles';
import { useStores } from '../../../../../hooks/useStores';

interface FooterProps {}

const Footer: FC<FooterProps> = props => {
  const stores = useStores();
  const styles = styleCreator(stores.brandingStore);
  const textStyles = stores.brandingStore.textStyles;

  return (
    <View style={styles.main}>
      <Text style={[styles.poweredBy, textStyles.styleXXSmallRegular]}>Powered by</Text>
      <Image style={styles.logoSmall} source={require('../../../../../assets/images/change_logo2.png')} />
    </View>
  );
};

export default observer(Footer);
