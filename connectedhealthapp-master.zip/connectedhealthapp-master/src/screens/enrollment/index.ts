export { EnrollmentContainer } from './container/enrollment.container';

export interface IInvitationCodeResponse {
  personalIdentifier: string;
  secretDisplayName?: string;
  secretLength?: number;
  customerId: string;
}

export interface ISVCResponse {
  data: any;
}
