export enum HTTP_STATUS_CODES {
  SUCCESS = 200,
  SUCCESS_CREATED = 201,
  INVALID_LOCKED = 422, //An invalid invitation code state. Code is expired, locked or user already enrolled.
  BAD_REQUEST = 400, // Bad request.
  UNAUTHORIZED = 401, // Unauthorized,
  SERVER_TIMEOUT = 408, // Server Timeout
  CONFLICT = 409, // Conflict. A request to this endpoint is made prior to the 'validate invitation code' step.
  EXCEEDED_ATTEMPTS = 419, //Exceeded the allowed time to finish the validation steps for enrollment.
  NOT_FOUND = 404,
  MISSING_INFO = 412, // User's record is missing required information to enroll.
  ALREADY_IN_USE = 428, // The selected account is already used by another user.
  SERVER_ERROR = 500,
  TIME_OUT = 503,
  RECAPTCHA_SERVER_ERROR = 530,
  MEMBER_ALREADY_ENROLLED = 406
}

export interface IHTTP_ERROR {
  statusCode: HTTP_STATUS_CODES;
}
