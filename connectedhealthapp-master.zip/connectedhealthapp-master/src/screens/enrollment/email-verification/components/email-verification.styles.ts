import { Platform, StyleSheet } from 'react-native';
import { globals } from '../../../../globals';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    phoneNumber: {
      marginTop: 20,
      textAlign: 'center'
    },
    mainContainer: {
      padding: 0
    },
    emailsContainer: {
      ...Platform.select({
        ios: { flex: 1, marginTop: 0, marginLeft: 0, marginRight: 0, backgroundColor: Platform.select({ ios: store.currentTheme.white, android: 'transparent' }) },
        android: { flex: 1, marginTop: 0, backgroundColor: Platform.select({ ios: store.currentTheme.white, android: 'transparent' }) }
      })
    }
  });
};
