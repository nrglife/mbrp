import React, { FC } from 'react';
import { ImageStyle } from 'react-native';
import { View } from 'react-native';
import FastImage from 'react-native-fast-image';
import images from '../../../../../assets/images/images';

interface CheckedCircleProps {
  width: number;
  height: number;
  color: string;
}

export const CheckedCircle: FC<CheckedCircleProps> = ({ height, width, color }) => (
  <View style={{ backgroundColor: color, width, height, padding: 3, borderRadius: width / 2 }}>
    <FastImage resizeMode="contain" source={images.checked_icon} style={{ width: '100%', height: '100%' }} />
  </View>
);
