import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, GestureResponderEvent, Platform, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { CHCheckItem, CHTextInput } from '../../../../components';
import { globals } from '../../../../globals';
import { useStores } from '../../../../hooks/useStores';
import { PhoneVerificationAction } from '../containers/email-verification.container';
import { CheckedCircle } from './checked-circle/checked-circle.component';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import { styles as styleCreator } from './email-verification.styles';

interface SendCodeComponentProps {
  state: string;
  textColor: string;
  disabledTextColor?: string;
  onPress: (event: GestureResponderEvent) => void;
  isEmailValid: boolean;
  sendAttempts: number;
}
export enum SendCodeButtonStates {
  Send_Code = 'Send Code',
  Resend_Code = 'Resend Code',
  Code_Sent = 'Code Sent',
  Send_Requested = 'Send Requested'
}

const SendCodeComponent: FC<SendCodeComponentProps> = ({ state, textColor, disabledTextColor = '#979797', onPress, isEmailValid, sendAttempts }) => {
  const isButtonDisabled: boolean = useMemo(() => SendCodeButtonStates.Code_Sent === state, [state]);
  const isSendRequested: boolean = useMemo(() => SendCodeButtonStates.Send_Requested === state, [state]);
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation('translation');
  const { EmailVerification: EmailVerificationLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <TouchableOpacity onPress={onPress} disabled={isButtonDisabled || isSendRequested || !isEmailValid}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginLeft: 25 }}>
        {isButtonDisabled ? (
          <View style={{ marginRight: 12 }}>
            <CheckedCircle width={20} height={20} color="#2ECC71" />
          </View>
        ) : null}
        {isSendRequested ? (
          <View style={{ marginRight: 12 }}>
            <ActivityIndicator size="small" color={Platform.OS == 'android' ? 'grey' : null} />
          </View>
        ) : null}
        <Text style={[{ color: isButtonDisabled ? disabledTextColor : textColor, opacity: isSendRequested ? 0.3 : 1 }, brandingStore.textStyles.styleLargeSemiBold]}>
          {isSendRequested
            ? sendAttempts == 0
              ? t(EmailVerificationLocalKeys.SendCode) // Send Code
              : t(EmailVerificationLocalKeys.ResendCode) // Resend Code
            : state}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

interface EmailsProps {
  emails: string[];
  onEmailSetFocus: () => void;
  onEmailClearFocus: () => void;
  onEnteredEmailChange: (string) => void;
  onSelectedEmailIndex: (number) => void;
  selectedEmailIndex: number;
  enteredEmailValue: string;
  emailError: string;
}
const Emails: FC<EmailsProps> = ({ emails, selectedEmailIndex, onSelectedEmailIndex, onEnteredEmailChange, onEmailClearFocus, onEmailSetFocus, enteredEmailValue, emailError }) => {
  const inputRef = useRef<TextInput>();
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation('translation');
  const { EmailVerification: EmailVerificationLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <View style={styles.emailsContainer}>
      {[...emails, ''].map((email: string, index: number) => (
        <View style={{ marginLeft: Platform.OS == 'android' ? 25 : 0 }} key={index}>
          <CHCheckItem
            error={index != emails.length ? null : emailError}
            style={styles.phoneNumber}
            checked={selectedEmailIndex === index}
            onPress={() => {
              onSelectedEmailIndex(index);
              if (index == emails.length) {
                inputRef.current.focus();
              }
            }}>
            {index != emails.length ? (
              <Text style={[brandingStore.textStyles.styleLargeSemiBold,{color:brandingStore.currentTheme.blackMain}]}>{email}</Text>
            ) : (
              <TextInput
                ref={input => {
                  inputRef.current = input;
                }}
                placeholder={
                  t(EmailVerificationLocalKeys.EnterNewEmail) // 'Enter a new email'
                }
                style={[{ padding: 0 }, brandingStore.textStyles.styleLargeSemiBold]}
                onFocus={onEmailSetFocus}
                onEndEditing={onEmailClearFocus}
                value={enteredEmailValue}
                onChangeText={onEnteredEmailChange}/>
            )}
          </CHCheckItem>
          {/*Platform.OS === 'ios' && <View style={{ marginLeft: 24, borderBottomColor: brandingStore.currentTheme.separatorOpaque, borderBottomWidth: 1 }} />*/}
        </View>
      ))}
    </View>
  );
};

interface EmailVerificationProps {
  emails: string[];
  onSendCodeHandler: () => void;
  isVerificationCodeVisible: boolean;
  verificationCode: string;
  onTextChange: (string) => void;
  onCodeSetFocus: () => void;
  onCodeClearFocus: () => void;
  onEmailSetFocus: () => void;
  onEmailClearFocus: () => void;
  onEnteredEmailChange: (string) => void;
  onSelectedEmailIndex: (number) => void;
  selectedEmailIndex: number;
  codeError: string | null;
  sendCodeButtonState: SendCodeButtonStates;
  emailError: string;
  enteredEmailValue: string;
  isEmailValid: boolean;
  sendAttempts: number;
}

export const EmailVerification: FC<EmailVerificationProps> = ({
  emails = [],
  sendCodeButtonState,
  onSendCodeHandler,
  isVerificationCodeVisible,
  verificationCode,
  onTextChange,
  onCodeClearFocus,
  onCodeSetFocus,
  onEmailClearFocus,
  onEmailSetFocus,
  codeError,
  onEnteredEmailChange,
  emailError,
  enteredEmailValue,
  selectedEmailIndex,
  onSelectedEmailIndex,
  sendAttempts,
  isEmailValid
}) => {
  const { brandingStore } = useStores();
  const onChangeText = (code: string) => {
    onTextChange(code);
  };
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation('translation');
  const { EmailVerification: EmailVerificationLocalKeys } = LocaleKeys.components.Enrollment;

  return (
    <View style={styles.mainContainer}>
      <Emails
        enteredEmailValue={enteredEmailValue}
        onEmailSetFocus={onEmailSetFocus}
        onEmailClearFocus={onEmailClearFocus}
        onEnteredEmailChange={onEnteredEmailChange}
        emails={emails}
        selectedEmailIndex={selectedEmailIndex}
        onSelectedEmailIndex={onSelectedEmailIndex}
        emailError={emailError}
      />

      <View style={{ marginTop: 13 }}>
        <SendCodeComponent
          sendAttempts={sendAttempts}
          isEmailValid={isEmailValid}
          onPress={onSendCodeHandler}
          textColor={brandingStore.currentTheme.actionMedium}
          disabledTextColor={'#979797'}
          state={sendCodeButtonState}
        />
      </View>
      {isVerificationCodeVisible ? (
        <View style={{ marginHorizontal: 0, marginTop: 75 }}>
          <CHTextInput
            error={codeError}
            underlineColorAndroid="grey"
            placeholder={'6 Digits'}
            maxLength={6}
            onFocus={onCodeSetFocus}
            onEndEditing={onCodeClearFocus}
            onChangeText={onChangeText}
            keyboardType="numeric"
            value={verificationCode}
            labelStyle={{ color: brandingStore.currentTheme.label }}
            label={t(EmailVerificationLocalKeys.VerificationCode)} // 'Verification Code'
            toolTip={
              t(EmailVerificationLocalKeys.EnterVerificationCode) + // 'Enter the verification code sent to email.'
              ' ' +
              t(EmailVerificationLocalKeys.CodeExpires, { minutes: 60 }) // 'Code expires in {{minutes}} minutes.'
            }
          />
        </View>
      ) : null}
    </View>
  );
};
