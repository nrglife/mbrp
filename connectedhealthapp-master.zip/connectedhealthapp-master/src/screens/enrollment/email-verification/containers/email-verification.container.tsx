import React, { FC, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { Alert, GestureResponderEvent, ScrollView, Text, View } from 'react-native';
import { observer } from 'mobx-react';
import { EmailVerification, SendCodeButtonStates } from '../components/email-verification.component';
import { StackActions, useNavigation } from '@react-navigation/native';
import { EnrollmentNavigationRoutes } from '../../../../routes';
import { StepContainer } from '../../containers';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentApi, EnrollmentSteps, failureSource } from '@healthcareapp/connected-health-common-services';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import { AxiosResponse } from 'axios';
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';
import Config from 'react-native-config';
import { IocContainer, IocTypesMobile } from '../../../../iocTypes';
import { callNumber } from '../../../../utilities/linking';
import { useTranslation } from 'react-i18next';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

interface EmailVerificationActionState {
  isVerificationCodeVisible: boolean;
  OTPCode: string;
  error: string | Text;
  sendButtonState: SendCodeButtonStates;
  sendAttempts: number;
  codeFieldError: string;
  attemptCount: number;
  maxAttempts: number;
  activityIndicator: boolean;
  emailError: string;
  enteredEmailValue: string;
  selectedEmailIndex: number;
  emailFocused: boolean;
}

const initialState: EmailVerificationActionState = {
  isVerificationCodeVisible: false,
  OTPCode: '',
  error: '',
  enteredEmailValue: '',
  emailError: null,
  sendButtonState: SendCodeButtonStates.Send_Code,
  sendAttempts: 0,
  codeFieldError: null,
  attemptCount: 0,
  maxAttempts: 5,
  activityIndicator: false,
  selectedEmailIndex: 0,
  emailFocused: false
};

type EmailVerificationActionTypes =
  | 'SET_EMAIL_FOCUSED'
  | 'SET_SELECTED_EMAIL_INDEX'
  | 'SET_ENTERED_EMAIL_VALUE'
  | 'SET_FIRSTNAME'
  | 'SET_SEND_CODE_BUTTON_STATE'
  | 'SET_VIRIFICATION_CODE_VISIBILITY'
  | 'SET_VERIFICATION_CODE'
  | 'SET_ERROR'
  | 'SET_CODE_FIELD_ERROR'
  | 'INC_SEND_ATTEMPTS'
  | 'SET_ATTEMPT_COUNT'
  | 'SET_MAX_ATTEMPTS'
  | 'SET_ACTIVITY_INDICATOR';

export type PhoneVerificationAction = { type: EmailVerificationActionTypes; payload?: any };

const reducer = (state: EmailVerificationActionState = initialState, action: PhoneVerificationAction): EmailVerificationActionState => {
  const { type, payload } = action;
  switch (type) {
    case 'SET_EMAIL_FOCUSED':
      return { ...state, emailFocused: payload };
    case 'SET_SEND_CODE_BUTTON_STATE':
      return { ...state, sendButtonState: payload };
    case 'SET_SELECTED_EMAIL_INDEX':
      return { ...state, selectedEmailIndex: payload };
    case 'SET_VIRIFICATION_CODE_VISIBILITY':
      return { ...state, isVerificationCodeVisible: payload };
    case 'SET_VERIFICATION_CODE':
      var reg = /^[0-9]*$/g;
      if (!reg.test(payload) && payload.length != 0) {
        return { ...state, OTPCode: state.OTPCode + '0' };
      }
      return { ...state, OTPCode: payload };
    case 'SET_ERROR':
      return { ...state, error: payload };

    case 'SET_CODE_FIELD_ERROR':
      return { ...state, codeFieldError: payload };
    case 'INC_SEND_ATTEMPTS':
      return { ...state, sendAttempts: state.sendAttempts + 1 };

    case 'SET_ATTEMPT_COUNT':
      return { ...state, attemptCount: payload };
    case 'SET_MAX_ATTEMPTS':
      return { ...state, sendAttempts: payload };
    case 'SET_ACTIVITY_INDICATOR':
      return { ...state, activityIndicator: payload };
    case 'SET_ENTERED_EMAIL_VALUE':
      return { ...state, enteredEmailValue: payload };
    default:
      return { ...state };
  }
};

const firstResendTimeout: number = 10 * 1000;
const secondResendTimeout: number = 20 * 1000;
const thirdResendTimeout: number = 30 * 1000;

interface EmailVerificationContainerProps {}

const PhoneVerificationContainer: FC<EmailVerificationContainerProps> = props => {
  const navigate = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.replace(route));
  };

  const navigation = useNavigation();
  const { enrollmentStore, appConfigStore, brandingStore, generalStore, payerStore } = useStores();
  const { t } = useTranslation('translation');
  const { EmailVerification: EmailVerificationLocalKeys } = LocaleKeys.components.Enrollment;

  const timerIdRef = useRef<NodeJS.Timeout>(null);
  const timeoutsRef = useRef({});

  useEffect(() => {
    resetEmailVerificationTimeOut();

    return () => {
      //clear previous time out

      Object.keys(timeoutsRef.current).forEach(timeout => {
        clearTimeout(timeoutsRef.current[timeout]);
      });
    };
  }, []);

  const resetEmailVerificationTimeOut = (timeOutInMinutes: string | null = null) => {
    //clear previous time out
    enrollmentStore.clearAllRegisteredTimeouts();

    //set new time out
    timerIdRef.current = enrollmentStore.registerEnrollmentTimeout(() => {
      console.log('TIMEOUT from Email Verification screen: ', timerIdRef.current);
      enrollmentStore.clearTimeout(timerIdRef.current);
      navigate(EnrollmentNavigationRoutes.Timeout);
    }, minutesToMilliseconds(timeOutInMinutes ? timeOutInMinutes : appConfigStore.appConfig.REACT_APP_ENROLLMENT_EMAIL_CODE_TIME_OUT_IN_MINUTES));

    return timerIdRef.current;
  };

  const [
    { emailFocused, selectedEmailIndex, isVerificationCodeVisible, OTPCode, sendButtonState, error, sendAttempts, codeFieldError, activityIndicator, emailError, enteredEmailValue },
    dispatch
  ] = useReducer(reducer, initialState);

  const handleCodeSent = () => {
    dispatch({ type: 'SET_VIRIFICATION_CODE_VISIBILITY', payload: true });
    dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Code_Sent });
    let timeout: number;
    switch (sendAttempts) {
      case 0:
        timeout = firstResendTimeout;
        break;
      case 1:
        timeout = secondResendTimeout;
        break;
      default:
        timeout = thirdResendTimeout;
        break;
    }
    timeoutsRef.current['codeSent'] = setTimeout(() => {
      dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Resend_Code });
    }, timeout);
    dispatch({ type: 'INC_SEND_ATTEMPTS' });
  };

  const nextButtonHandler = async () => {
    dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });

    const federatedId = payerStore.payer?.federatedId || '';
    const isFederated = federatedId !== '';
    const idp = isFederated ? '' : 'CIAM';

    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postOtpEmailPassCode({
        code: enrollmentStore.invitationCode,
        errorHandlerParam: navigate,
        passCode: OTPCode,
        idp: idp,
        ciamFederationId: federatedId,
        token: ''
      });
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
      let errorString: string | Element = null;

      const { data, success } = response.data;

      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS_CREATED:
          enrollmentStore.clearAllRegisteredTimeouts();
          //set back to previous global time out
          resetEmailVerificationTimeOut(appConfigStore.appConfig.REACT_APP_ENROLLMENT_GLOBAL_TIME_OUT_IN_MINUTES);

          const { userId = '' } = data || '';

          // success 201 - Successful user creation
          // User is federated, no need for CIAM password creation.
          if (isFederated) {
            //
            enrollmentStore.setStep(EnrollmentSteps.Enrolled);
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.EnrollmentComplete, {}));
          }
          // success 201 - Successful user creation, user isnt federated, need to set CIAM password for the new user.
          else if (success && userId.length > 0) {
            // if (response.status === HTTP_STATUS_CODES.CREATED && userId.length > 0) {
            enrollmentStore.setUserId(data.userId);
            enrollmentStore.setStep(EnrollmentSteps.CreatePassword);
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.CreatePassword, {}));
          } else {
            errorString = t(LocaleKeys.errors.unable_find_user_verification_code);
          }

          break;
        case HTTP_STATUS_CODES.SUCCESS:
          // success 200 - User was already exist in CIAM but not in member portal (IHDP),
          // No password needed, and user was linked to enrollment accout.
          enrollmentStore.clearAllRegisteredTimeouts();
          //set back to previous global time out
          resetEmailVerificationTimeOut(appConfigStore.appConfig.REACT_APP_ENROLLMENT_GLOBAL_TIME_OUT_IN_MINUTES);
          if (success) {
            //else if (response.status === HTTP_STATUS_CODES.SUCCESS) {
            enrollmentStore.setStep(EnrollmentSteps.Enrolled);
            navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.EnrollmentComplete, {}));
          }
          break;
        case HTTP_STATUS_CODES.ALREADY_IN_USE:
          const resetSendButton = () => {
            clearTimeout(timeoutsRef.current['codeSent']);
            dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Resend_Code });
            dispatch({ type: 'SET_VIRIFICATION_CODE_VISIBILITY', payload: false });
            dispatch({ type: 'SET_VERIFICATION_CODE', payload: '' });
          };
          if (data) {
            if (data.code === 1901) {
              resetSendButton();
              errorString = (
                <Text>
                  <Text
                    style={[
                      {
                        width: '100%',
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {t(LocaleKeys.errors.email_is_already_registered, { currentEmail: getCurrentEmail() })}
                  </Text>
                  <Text
                    onPress={() => {
                      generalStore.setEnrollmentComplete(true);
                    }}
                    style={[
                      {
                        textDecorationLine: 'underline',
                        width: '100%',
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {t(LocaleKeys.errors.signing_in)}
                  </Text>
                  <Text
                    style={[
                      {
                        width: '100%',
                        marginBottom: 20,
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {' ' + t(LocaleKeys.errors.select_another_email)}
                  </Text>
                </Text>
              );
            } else if (data.code === 1902) {
              resetSendButton();
              errorString = (
                <Text>
                  <Text
                    style={[
                      {
                        width: '100%',
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {t(LocaleKeys.errors.email_is_already_in_use, { currentEmail: getCurrentEmail() })}
                  </Text>

                  <Text
                    onPress={() => {
                      generalStore.contactUsSheetRef.current.open();
                    }}
                    style={[
                      {
                        textDecorationLine: 'underline',
                        width: '100%',
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {t(LocaleKeys.errors.contact_us_lowercase)}
                  </Text>
                  <Text
                    style={[
                      {
                        width: '100%',
                        marginBottom: 20,
                        textAlign: 'center',
                        color: brandingStore.currentTheme.error
                      },
                      brandingStore.textStyles.styleLargeSemiBold
                    ]}>
                    {' ' + t(LocaleKeys.errors.for_help_lowercase)}
                  </Text>
                </Text>
              );
            }
          }

          break;
        case HTTP_STATUS_CODES.TIME_OUT:
          errorString = t(LocaleKeys.errors.enrollment_process_timed_out);
          break;
        case HTTP_STATUS_CODES.NOT_FOUND:
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
          break;

        case HTTP_STATUS_CODES.BAD_REQUEST:
          if (data && data.attemptMax && data.attemptCount) {
            const remainintAttempts = +data.attemptMax - +data.attemptCount;
            // console.log('data', data);
            if (remainintAttempts <= 0) {
              navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.Locked));
              return;
            }

            dispatch({ type: 'SET_ATTEMPT_COUNT', payload: data.attemptCount });
            dispatch({ type: 'SET_MAX_ATTEMPTS', payload: data.attemptMax });
            // errorString = '';
            errorString = (
              <Text>
                {t(LocaleKeys.errors.something_wrong_try_again)}
                <Text style={remainintAttempts <= 2 ? brandingStore.textStyles.styleLargeBold : null}>
                  {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainintAttempts, s: remainintAttempts > 1 ? 's' : '' })}
                </Text>
              </Text>
            );

            dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: t(LocaleKeys.errors.wrong_verification_code) });
          } else {
            errorString = t(LocaleKeys.errors.something_wrong_try_again);
          }

          break;
      }
      dispatch({ type: 'SET_ERROR', payload: errorString });
    } catch (err) {
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        //dispatch({ type: 'SET_ERROR', payload: t(LocaleKeys.errors.something_went_wrong) });

        //console.log('nav4');
        navigate(EnrollmentNavigationRoutes.GeneralError);
      }
    }
  };

  const codeErrorMessage = t(LocaleKeys.errors.code_too_short);

  const onChangeText = (code: string) => {
    dispatch({ type: 'SET_VERIFICATION_CODE', payload: code });
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
  };

  const onCodeClearFocus = () => {
    if (OTPCode.length != 0 && OTPCode.length != 6) {
      dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: codeErrorMessage });
    }
  };

  const onCodeSetFocus = () => {};

  const onEmailClearFocus = () => {
    dispatch({ type: 'SET_EMAIL_FOCUSED', payload: false });
  };

  const onEmailSetFocus = () => {
    dispatch({ type: 'SET_EMAIL_FOCUSED', payload: true });
    dispatch({
      type: 'SET_SELECTED_EMAIL_INDEX',
      payload: Array.isArray(enrollmentStore.emails) ? enrollmentStore.emails.length : 1
    });
  };

  const onSendCodeHandler = async () => {
    const sendStatus = sendButtonState;

    enrollmentStore.setRegisteredEmail(getCurrentEmail());
    dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Send_Requested });
    dispatch({ type: 'SET_ERROR', payload: null });

    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postRequestOtpEmailCode({
        code: enrollmentStore.invitationCode,
        email: getCurrentEmail(),
        errorHandlerParam: navigate
      });
      const { data } = response.data;
      let errorString: string | Element = null;
      dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: sendStatus });
      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS:
          resetEmailVerificationTimeOut();
          handleCodeSent();
          return;
        case HTTP_STATUS_CODES.TIME_OUT:
          errorString = t(LocaleKeys.errors.enrollment_process_timed_out);
          break;
        case HTTP_STATUS_CODES.NOT_FOUND:
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
          break;
        case HTTP_STATUS_CODES.BAD_REQUEST:
          if (data && data.attemptMax && data.attemptCount) {
            const remainintAttempts = +data.attemptMax - +data.attemptCount;
            if (remainintAttempts <= 0) {
              navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.Locked));
              return;
            }
            // console.log('data', data);

            dispatch({ type: 'SET_ATTEMPT_COUNT', payload: data.attemptCount });
            dispatch({ type: 'SET_MAX_ATTEMPTS', payload: data.attemptMax });
            errorString = (
              <Text>
                {t(LocaleKeys.errors.something_wrong_try_again)}
                <Text style={remainintAttempts <= 2 ? brandingStore.textStyles.styleLargeBold : null}>
                  {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainintAttempts, s: remainintAttempts > 1 ? 's' : '' })}
                </Text>
              </Text>
            );
          } else {
            errorString = t(LocaleKeys.errors.something_wrong_try_again);
          }

          break;
      }
      dispatch({ type: 'SET_ERROR', payload: errorString });
    } catch (err) {
      //dispatch({ type: 'SET_ERROR', payload: t(LocaleKeys.errors.something_wrong_try_again) });
      //dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: sendStatus });
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        navigate(EnrollmentNavigationRoutes.GeneralError);
      } else {
        dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Send_Code });
      }
    }
  };

  const emailErrorString = t(LocaleKeys.errors.not_valid_email);
  const verifyEmail = (email: string) => {
    //  const regex = /^[a-zA-Z0-9]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/;
    //const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regex.test(email)) {
      return true;
    }
    return false;
  };

  const isSendEnabled = () => {
    if (selectedEmailIndex < enrollmentStore.emails.length || verifyEmail(enteredEmailValue)) {
      return true;
    } else {
      return false;
    }
  };

  const getEmailError = () => {
    if (selectedEmailIndex < enrollmentStore.emails.length || verifyEmail(enteredEmailValue) || enteredEmailValue.length == 0 || emailFocused) {
      return null;
    } else {
      return emailErrorString;
    }
  };

  const onEnteredEmailChange = (email: string) => {
    dispatch({ type: 'SET_ENTERED_EMAIL_VALUE', payload: email });
  };

  const onSelectedEmailIndex = (index: number) => {
    dispatch({ type: 'SET_SELECTED_EMAIL_INDEX', payload: index });
  };

  const getCurrentEmail = () => {
    if (selectedEmailIndex == enrollmentStore.emails.length) {
      return enteredEmailValue;
    }
    return enrollmentStore.emails[selectedEmailIndex];
  };

  return (
    enrollmentStore.userCredentials && (
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flex: 1 }} keyboardShouldPersistTaps="always">
        <StepContainer
          title={
            t(EmailVerificationLocalKeys.Title, { userName: enrollmentStore.userCredentials.firstname ? ' ' + enrollmentStore.userCredentials.firstname : '' }) // "Title": "Hi{{userName}}, we’ve confirmed your identity"
          }
          messageBody={
            t(EmailVerificationLocalKeys.DescriptionWhatToDoUnified) +
            ' ' + // To sign you in securely, we need to confirm your email. This will also be your username for signing into Connected Health.
            t(EmailVerificationLocalKeys.DescriptionRequirements1email) // We’ll send a unique code to this address:'
          }
          currentStep={enrollmentStore.stepNumber}
          totalSteps={enrollmentStore.totalSteps}
          error={error}
          // errorElement={errorElement}
          activityIndicator={activityIndicator}
          next={
            isVerificationCodeVisible && !emailFocused
              ? {
                  label: t(EmailVerificationLocalKeys.ButtonNext), //  'Next'
                  func: nextButtonHandler,
                  enabled: OTPCode.length === 6
                }
              : null
          }>
          <EmailVerification
            sendAttempts={sendAttempts}
            selectedEmailIndex={selectedEmailIndex}
            emailError={getEmailError()}
            isEmailValid={isSendEnabled()}
            enteredEmailValue={enteredEmailValue}
            //  emailInput={addedEmail === null}
            onEnteredEmailChange={onEnteredEmailChange}
            onCodeSetFocus={onCodeSetFocus}
            onCodeClearFocus={onCodeClearFocus}
            onEmailSetFocus={onEmailSetFocus}
            onEmailClearFocus={onEmailClearFocus}
            sendCodeButtonState={sendButtonState}
            onSelectedEmailIndex={onSelectedEmailIndex}
            isVerificationCodeVisible={isVerificationCodeVisible}
            verificationCode={OTPCode}
            onTextChange={onChangeText}
            codeError={codeFieldError}
            emails={Array.isArray(enrollmentStore.emails) ? enrollmentStore.emails : [enrollmentStore.emails]}
            onSendCodeHandler={onSendCodeHandler}
          />
        </StepContainer>
      </ScrollView>
    )
  );
};

export default observer(PhoneVerificationContainer);
