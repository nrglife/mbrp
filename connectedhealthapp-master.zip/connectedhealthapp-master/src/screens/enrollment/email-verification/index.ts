import EmailVerificationContainer from './containers/email-verification.container';

export { EmailVerificationContainer };
