import React, { FC, useCallback } from 'react';
import { observer } from 'mobx-react';
import { ErrorContainer } from '../../containers';
import { RouteProp, StackActions, useNavigation } from '@react-navigation/native';
import { useStores } from '../../../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export interface GeneralErrorContainerProps {}

export const GeneralErrorContainer: FC<GeneralErrorContainerProps> = observer((props: GeneralErrorContainerProps) => {
  const navigation = useNavigation();
  const { generalStore } = useStores();
  const { t } = useTranslation('translation');

  const contactUsHandler = () => {
    generalStore.contactUsSheetRef.current.open();
  };
  return (
    <ErrorContainer
      title={t(LocaleKeys.errors.something_went_wrong)}
      messageBody={t(LocaleKeys.errors.enrollment_process_failed_try_again)}
      footer={{
        pt1: t(LocaleKeys.errors.if_problem_persists),
        onClick: useCallback(contactUsHandler, [generalStore.contactUsSheetRef]),
        link: t(LocaleKeys.errors.contact_us)
      }}
      ok={{
        label: 'Ok',
        func: () => {
          navigation.dispatch(StackActions.pop());
        }
      }}
    />
  );
});
