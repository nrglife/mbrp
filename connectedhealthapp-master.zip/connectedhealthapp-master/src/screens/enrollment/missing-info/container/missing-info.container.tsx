import React, { FC, useCallback } from 'react';
import { observer } from 'mobx-react';
import { ErrorContainer } from '../../containers';
import { RouteProp, StackActions, useNavigation } from '@react-navigation/native';
import { useStores } from '../../../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export interface MissingInfoContainerProps {}

export const MissingInfoContainer: FC<MissingInfoContainerProps> = observer((props: MissingInfoContainerProps) => {
  const navigation = useNavigation();
  const { generalStore } = useStores();
  const { t } = useTranslation('translation');
  const contactUsHandler = () => {
    generalStore.contactUsSheetRef.current.open();
  };
  return (
    <ErrorContainer
      title={t(LocaleKeys.errors.something_went_wrong)}
      messageBody={t(LocaleKeys.errors.enrollment_contact_payer)}
      footer={{
        onClick: useCallback(contactUsHandler, [generalStore.contactUsSheetRef]),
        link: t(LocaleKeys.errors.contact_us),
        pt2: t(LocaleKeys.errors.to_complete_missing_details)
      }}
      ok={{
        label: 'Ok',
        func: () => {
          navigation.dispatch(StackActions.pop());
        }
      }}
    />
  );
});
