import React, { FC, useCallback } from 'react';
import { observer } from 'mobx-react';
import { ErrorContainer } from '../../containers';
import { StackActions, useNavigation } from '@react-navigation/native';
import { useStores } from '../../../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface LockedContainerProps {}

const LockedContainer: FC<LockedContainerProps> = (props: LockedContainerProps) => {
  const navigation = useNavigation();
  const { generalStore } = useStores();
  const { t } = useTranslation('translation');
  const contactUsHandler = () => {
    generalStore.contactUsSheetRef.current.open();
  };
  return (
    <ErrorContainer
      title={t(LocaleKeys.errors.something_went_wrong)}
      messageBody={t(LocaleKeys.errors.enrollment_invitation_code_locked)}
      footer={{
        pt1: t(LocaleKeys.errors.for_help),
        onClick: useCallback(contactUsHandler, [generalStore.contactUsSheetRef]),
        link: t(LocaleKeys.errors.contact_us)
      }}
      ok={{
        label: 'Ok',
        func: () => {
          navigation.dispatch(StackActions.pop());
        }
      }}
    />
  );
};

export default observer(LockedContainer);
