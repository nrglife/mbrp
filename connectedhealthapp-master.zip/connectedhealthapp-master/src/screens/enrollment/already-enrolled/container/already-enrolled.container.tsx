import React, { ReactElement, useCallback } from 'react';
import { observer } from 'mobx-react';
import { ErrorContainer } from '../../containers';
import { StackActions, useNavigation } from '@react-navigation/native';
import { RouteProp } from '@react-navigation/native';
import { useStores } from '../../../../hooks/useStores';
import { Trans, useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { Text } from 'react-native';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { IReactComponent } from 'mobx-react/dist/types/IReactComponent';

export interface AlreadyEnrolledContainerProps {}

export const AlreadyEnrolledContainer: IReactComponent<AlreadyEnrolledContainerProps> = observer<IReactComponent<AlreadyEnrolledContainerProps>>(
  (props: AlreadyEnrolledContainerProps): ReactElement<any, any> => {
    const navigation = useNavigation();
    const { generalStore } = useStores();
    const { t } = useTranslation('translation');
    const { brandingStore } = useStores();

    const contactUsHandler = () => {
      generalStore.contactUsSheetRef.current.open();
    };
    return (
      <ErrorContainer
        title={t(LocaleKeys.errors.something_went_wrong)}
        messageBody={
          <Text>
            {t(LocaleKeys.errors.account_already_enrolled) + ' '}
            <Trans
              t={t}
              i18nKey={LocaleKeys.errors.try_to_sign_in}
              components={[
                <Text
                  {...createAccessibilityForAutomation('Contact us')}
                  onPress={useCallback(contactUsHandler, [generalStore.contactUsSheetRef])}
                  style={{ color: brandingStore.currentTheme.actionMedium }}
                />
              ]}
            />
          </Text>
        }
        footer={null}
        ok={{
          label: 'Ok',
          func: () => {
            navigation.dispatch(StackActions.pop());
          }
        }}
      />
    );
  }
);
