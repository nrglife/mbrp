import PhoneVerificationContainer from './containers/phone-verification.container';

export { PhoneVerificationContainer };
