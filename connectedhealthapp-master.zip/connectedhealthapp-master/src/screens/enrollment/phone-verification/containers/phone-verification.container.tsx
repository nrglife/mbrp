import React, { FC, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { GestureResponderEvent, ScrollView, Text } from 'react-native';
import { observer } from 'mobx-react';
import { PhoneVerification, SendCodeButtonStates } from '../components/phone-verification.component';
import { StackActions, useNavigation } from '@react-navigation/native';
import { EnrollmentNavigationRoutes } from '../../../../routes';
import { StepContainer } from '../../containers';
import { useStores } from '../../../../hooks/useStores';
import { EnrollmentApi, EnrollmentSteps, failureSource } from '@healthcareapp/connected-health-common-services';

import { AxiosResponse } from 'axios';
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';
import Config from 'react-native-config';
import { AppSafeConsoleLogger } from '../../../../utilities/logger/console-log';
import { IocContainer, IocTypesMobile } from '../../../../iocTypes';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';
import { SendCodeMethod } from '@healthcareapp/connected-health-common-services/dist/stores/EnrollmentStore';

interface PhoneVerificationActionState {
  isVerificationCodeVisible: boolean;
  OTPCode: string;
  error: string;
  sendButtonState: SendCodeButtonStates;
  sendAttempts: number;
  codeFieldError: string;
  attemptCount: number;
  maxAttempts: number;
  activityIndicator: boolean;
}

const initialState: PhoneVerificationActionState = {
  isVerificationCodeVisible: false,
  OTPCode: '',
  error: '',
  sendButtonState: SendCodeButtonStates.Send_Code,
  sendAttempts: 0,
  codeFieldError: null,
  attemptCount: 0,
  maxAttempts: 5,
  activityIndicator: false
};

type PhoneVerificationActionTypes =
  | 'SET_FIRSTNAME'
  | 'SET_SEND_CODE_BUTTON_STATE'
  | 'SET_VIRIFICATION_CODE_VISIBILITY'
  | 'SET_VERIFICATION_CODE'
  | 'SET_ERROR'
  | 'SET_CODE_FIELD_ERROR'
  | 'INC_SEND_ATTEMPTS'
  | 'SET_ATTEMPT_COUNT'
  | 'SET_MAX_ATTEMPTS'
  | 'SET_ACTIVITY_INDICATOR';
export type PhoneVerificationAction = { type: PhoneVerificationActionTypes; payload?: any };

const reducer = (state: PhoneVerificationActionState = initialState, action: PhoneVerificationAction): PhoneVerificationActionState => {
  const { type, payload } = action;

  switch (type) {
    case 'SET_SEND_CODE_BUTTON_STATE':
      return { ...state, sendButtonState: payload };
    case 'SET_VIRIFICATION_CODE_VISIBILITY':
      return { ...state, isVerificationCodeVisible: payload };
    case 'SET_VERIFICATION_CODE':
      var reg = /^[0-9]*$/g;
      if (!reg.test(payload) && payload.length != 0) {
        return { ...state, OTPCode: state.OTPCode + '0' };
      }
      return { ...state, OTPCode: payload };
    case 'SET_ERROR':
      return { ...state, error: payload };
    case 'SET_CODE_FIELD_ERROR':
      return { ...state, codeFieldError: payload };
    case 'INC_SEND_ATTEMPTS':
      return { ...state, sendAttempts: state.sendAttempts + 1 };

    case 'SET_ATTEMPT_COUNT':
      return { ...state, attemptCount: payload };
    case 'SET_MAX_ATTEMPTS':
      return { ...state, sendAttempts: payload };
    case 'SET_ACTIVITY_INDICATOR':
      return { ...state, activityIndicator: payload };
    default:
      return { ...state };
  }
};

const firstResendTimeout: number = 10 * 1000;
const secondResendTimeout: number = 20 * 1000;
const thirdResendTimeout: number = 30 * 1000;

interface PhoneVerificationContainerProps {}

const PhoneVerificationContainer: FC<PhoneVerificationContainerProps> = props => {
  const navigate = (route: EnrollmentNavigationRoutes) => {
    navigation.dispatch(StackActions.replace(route));
  };
  const navigation = useNavigation();
  const { enrollmentStore, appConfigStore, brandingStore, generalStore } = useStores();
  const { t } = useTranslation('translation');
  const { ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys } = LocaleKeys.components.Enrollment;
  // const enrollmentApi = new EnrollmentAPI(appConfigStore.appConfig.API_BASE_URL)

  const timerIdRef = useRef<NodeJS.Timeout>();

  const timeoutsRef = useRef({});
  //console.log('timeouts during render', timeoutsRef.current);

  useEffect(() => {
    // resetConfirmSMSTimeOut();
    return () => {
      //console.log('timeouts object', timeoutsRef.current);
      Object.keys(timeoutsRef.current).forEach(timeout => {
        //  console.log('clearing timeout', timeoutsRef.current[timeout]);
        clearTimeout(timeoutsRef.current[timeout]);
      });
    };
  }, []);

  const resetConfirmSMSTimeOut = () => {
    //clear previous time out
    enrollmentStore.clearAllRegisteredTimeouts();
    //set new time out
    timerIdRef.current = enrollmentStore.registerEnrollmentTimeout(() => {
      // console.log('TIMEOUT from confirm SMS screen: ', timerIdRef.current);
      enrollmentStore.clearTimeout(timerIdRef.current);
      navigate(EnrollmentNavigationRoutes.Timeout);
    }, minutesToMilliseconds(appConfigStore.appConfig.REACT_APP_ENROLLMENT_SMS_CODE_TIME_OUT_IN_MINUTES));
    return timerIdRef.current;
  };

  const [{ isVerificationCodeVisible, OTPCode, sendButtonState, error, sendAttempts, codeFieldError, activityIndicator }, dispatch] = useReducer(reducer, initialState);
  // console.log('error gen', error);
  const handleCodeSent = () => {
    resetConfirmSMSTimeOut();
    dispatch({ type: 'SET_VIRIFICATION_CODE_VISIBILITY', payload: true });
    dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Code_Sent });
    let timeout: number;
    switch (sendAttempts) {
      case 0:
        timeout = firstResendTimeout;
        break;
      case 1:
        timeout = secondResendTimeout;
        break;
      default:
        timeout = thirdResendTimeout;
        break;
    }

    // console.log('timeouts before update', timeoutsRef.current);
    timeoutsRef.current['codeSent'] = setTimeout(() => {
      dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Resend_Code });
    }, timeout);

    // console.log('timeouts updated', timeoutsRef.current);
    dispatch({ type: 'INC_SEND_ATTEMPTS' });
  };

  const nextButtonHandler = async () => {
    dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });
    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postOtpPassCode({ code: enrollmentStore.invitationCode, errorHandlerParam: navigate, passCode: OTPCode });
      dispatch({ type: 'SET_ERROR', payload: null });
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
      // console.log('response data', response.data);
      // console.log('response ', response);
      let errorString: string | Element = null;

      const { data } = response.data;
      AppSafeConsoleLogger.Info('response ', response);
      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS:
          // console.log('emails', response.data);
          if (timerIdRef.current) {
            enrollmentStore.clearTimeout(timerIdRef.current);
          }
          enrollmentStore.setEmails(data);
          enrollmentStore.setStep(EnrollmentSteps.EmailVerification);
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.EmailVerification, { emails: response.data.data }));
          break;
        case HTTP_STATUS_CODES.TIME_OUT:
          errorString = t(LocaleKeys.errors.enrollment_process_timed_out);
          break;
        case HTTP_STATUS_CODES.NOT_FOUND:
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
          break;
        case HTTP_STATUS_CODES.BAD_REQUEST:
          if (data && data.attemptMax && data.attemptCount) {
            const remainintAttempts = +data.attemptMax - +data.attemptCount;
            if (remainintAttempts <= 0) {
              navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.Locked));
              return;
            }

            dispatch({ type: 'SET_ATTEMPT_COUNT', payload: data.attemptCount });
            dispatch({ type: 'SET_MAX_ATTEMPTS', payload: data.attemptMax });
            errorString = (
              <Text>
                {t(LocaleKeys.errors.something_wrong_try_again)}
                <Text style={remainintAttempts <= 2 ? brandingStore.textStyles.styleLargeBold : null}>
                  {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainintAttempts, s: remainintAttempts > 1 ? 's' : '' })}
                </Text>
              </Text>
            );
            dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: t(LocaleKeys.errors.wrong_verification_code) });
          } else {
            errorString = t(LocaleKeys.errors.something_wrong_try_again);
          }

          break;
      }
      dispatch({ type: 'SET_ERROR', payload: errorString });
    } catch (err) {
      dispatch({ type: 'SET_ACTIVITY_INDICATOR', payload: false });
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        // dispatch({ type: 'SET_ERROR', payload: t(LocaleKeys.errors.something_went_wrong) });
        //dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: sendStatus });

        navigate(EnrollmentNavigationRoutes.GeneralError);

        return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
      }
    }
  };

  const codeErrorMessage = t(LocaleKeys.errors.code_too_short);

  const onChangeText = (code: string) => {
    dispatch({ type: 'SET_VERIFICATION_CODE', payload: code });
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
  };

  const onCodeClearFocus = () => {
    if (OTPCode.length != 0 && OTPCode.length != 6) {
      dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: codeErrorMessage });
    }
  };

  const onCodeSetFocus = () => {
    dispatch({ type: 'SET_CODE_FIELD_ERROR', payload: null });
  };

  const onSendCodeHandler = async (event: GestureResponderEvent, phoneNumber: string, sendCodeMethod: SendCodeMethod) => {
    const sendStatus = sendButtonState;
    dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Send_Requested });
    dispatch({ type: 'SET_ERROR', payload: null });

    try {
      const response = await IocContainer.get<EnrollmentApi>(IocTypesMobile.EnrollmentApi).postRequestOtpCode({
        code: enrollmentStore.invitationCode,
        errorHandlerParam: navigate,
        phoneNumber: phoneNumber,
        channel: sendCodeMethod
      });
      const { data } = response.data;
      let errorString: string | Element = null;
      dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: sendStatus });
      switch (response.status) {
        case HTTP_STATUS_CODES.SUCCESS:
          handleCodeSent();
          return;
        case HTTP_STATUS_CODES.TIME_OUT:
          errorString = t(LocaleKeys.errors.enrollment_process_timed_out);
          break;
        case HTTP_STATUS_CODES.NOT_FOUND:
          navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.GeneralError));
          break;
        case HTTP_STATUS_CODES.BAD_REQUEST:
          if (data && data.attemptMax && data.attemptCount) {
            // console.log('data', data);

            const remainintAttempts = +data.attemptMax - +data.attemptCount;
            if (remainintAttempts <= 0) {
              navigation.dispatch(StackActions.replace(EnrollmentNavigationRoutes.Locked));
              return;
            }

            dispatch({ type: 'SET_ATTEMPT_COUNT', payload: data.attemptCount });
            dispatch({ type: 'SET_MAX_ATTEMPTS', payload: data.attemptMax });
            errorString = (
              <Text>
                {t(LocaleKeys.errors.something_wrong_try_again) + ' '}
                <Text style={remainintAttempts <= 2 ? brandingStore.textStyles.styleLargeBold : null}>
                  {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainintAttempts, s: remainintAttempts > 1 ? 's' : '' })}
                </Text>
              </Text>
            );
          } else {
            errorString = t(LocaleKeys.errors.something_wrong_try_again);
          }

          break;
      }
      dispatch({ type: 'SET_ERROR', payload: errorString });
    } catch (err) {
      if (err.statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        //dispatch({ type: 'SET_ERROR', payload: t(LocaleKeys.errors.something_wrong_try_again) });
        // dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: sendStatus });

        return navigate(EnrollmentNavigationRoutes.GeneralError);
      } else {
        dispatch({ type: 'SET_SEND_CODE_BUTTON_STATE', payload: SendCodeButtonStates.Send_Code });
      }
    }
  };
  return (
    enrollmentStore.userCredentials && (
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flex: 1 }} keyboardShouldPersistTaps="always">
        <StepContainer
          title={t(ConfirmPhoneNumberLocalKeys.TitleUnified)} // Let's confirm your identity"
          messageBody={t(ConfirmPhoneNumberLocalKeys.ConfirmIdentityCode)} // To confirm your identity, we’ll send a unique code to your mobile number. This code expires in 10 minutes.
          currentStep={enrollmentStore.stepNumber}
          totalSteps={enrollmentStore.totalSteps}
          error={error}
          activityIndicator={activityIndicator}
          next={
            isVerificationCodeVisible
              ? {
                  label: t(ConfirmPhoneNumberLocalKeys.ButtonNext), // 'Next'
                  func: nextButtonHandler,
                  enabled: OTPCode.length === 6
                }
              : null
          }>
          <PhoneVerification
            chcSupportPhoneNumber={
              generalStore.appSupportPhoneNumbers && generalStore.appSupportPhoneNumbers.length > 0 && generalStore.appSupportPhoneNumbers.filter(number => number && number !== '')[0]
            }
            sendAttempts={sendAttempts}
            onCodeSetFocus={onCodeSetFocus}
            onCodeClearFocus={onCodeClearFocus}
            sendCodeButtonState={sendButtonState}
            isVerificationCodeVisible={isVerificationCodeVisible}
            verificationCode={OTPCode}
            onTextChange={onChangeText}
            codeError={codeFieldError}
            phoneNumbers={
              enrollmentStore.userCredentials.phone.length > 0
                ? Array.isArray(enrollmentStore.userCredentials.phone)
                  ? enrollmentStore.userCredentials.phone
                  : [enrollmentStore.userCredentials.phone]
                : []
            }
            onSendCodeHandler={onSendCodeHandler}
          />
        </StepContainer>
      </ScrollView>
    )
  );
};

export default observer(PhoneVerificationContainer);
