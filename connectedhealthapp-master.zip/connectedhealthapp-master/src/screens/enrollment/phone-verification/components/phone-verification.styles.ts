import { Platform, StyleSheet } from 'react-native';
import { globals } from '../../../../globals';
import stores from '../../../../stores';
import BrandingStoreMobile from '../../../../stores/BrandingStoreMobile';



export const styles =  (brandingStore: BrandingStoreMobile) => {

  
  return StyleSheet.create({
    messageBody: {
      marginTop: 20
    },
    phoneNumber: {
      backgroundColor:'red',
      marginTop: 20,
      textAlign: 'center'
    },
    mainContainer: {
      padding: 0
    },
    checkItemsTitle: {
      color: brandingStore.currentTheme.blackMain,
      marginLeft: 25, //TODO: check with android
      marginBottom: 8.5
    },
    phoneNumbersContainer: {
      ...Platform.select({
        ios: { flex: 1, marginTop: 0,  backgroundColor: Platform.select({ ios: 'white', android: 'transparent' }) },
        android: { flex: 1, marginTop: 0, backgroundColor: Platform.select({ ios: 'white', android: 'transparent' }) }
      })
    },
    sendCodeButtonStyle: { }
})

}

