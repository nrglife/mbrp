import React, { FC, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, GestureResponderEvent, Platform, Text, TouchableOpacity, View } from 'react-native';
import { CHCheckItem, CHTextInput } from '../../../../components';
import { globals } from '../../../../globals';
import { useStores } from '../../../../hooks/useStores';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { PhoneVerificationAction } from '../containers/phone-verification.container';
import { CheckedCircle } from './checked-circle/checked-circle.component';
import { styles as styleCreator } from './phone-verification.styles';
import { callNumber } from '../../../../utilities/linking';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { SendCodeMethod } from '@healthcareapp/connected-health-common-services/dist/stores/EnrollmentStore';

interface SendCodeComponentProps {
  state: string;
  textColor: string;
  sendAttempts: number;
  disabledTextColor?: string;
  onPress: (event: GestureResponderEvent) => void;
  selectedSendCodeMethod: SendCodeMethod;
}

export enum SendCodeButtonStates {
  Send_Code = 'Send Code',
  Resend_Code = 'Resend Code',
  Code_Sent = 'Code Sent',
  Send_Requested = 'Send Requested'
}

const SendCodeComponent: FC<SendCodeComponentProps> = ({ state, textColor, disabledTextColor = '#979797', onPress, sendAttempts, selectedSendCodeMethod }) => {
  const isButtonDisabled: boolean = useMemo(() => SendCodeButtonStates.Code_Sent === state, [state]);
  const isSendRequested: boolean = useMemo(() => SendCodeButtonStates.Send_Requested === state, [state]);
  const { brandingStore } = useStores();
  

  const { t } = useTranslation('translation');
  const { ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys } = LocaleKeys.components.Enrollment;
  const textStyles = brandingStore.textStyles;
  const styles = styleCreator(brandingStore);
  let sendCodeStateLabel = state;
  if (state == SendCodeButtonStates.Code_Sent && selectedSendCodeMethod === SendCodeMethod.Voice) 
    sendCodeStateLabel = t(ConfirmPhoneNumberLocalKeys.CallComing);// "Call is coming, stand by"
  if (isSendRequested)
    sendCodeStateLabel = sendAttempts == 0 ?
      t(ConfirmPhoneNumberLocalKeys.SendCode) :// "Send Code"
      t(ConfirmPhoneNumberLocalKeys.ResendCode)
  return (
    <View style={{ flexDirection: 'column' }}>
      <TouchableOpacity style={{}} onPress={onPress} disabled={isButtonDisabled || isSendRequested} {...createAccessibilityForAutomation(`${state} button`)}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          {isButtonDisabled ? (
            <View style={{ marginRight: 12 }}>
              <CheckedCircle width={20} height={20} color="#2ECC71" />
            </View>
          ) : null}
          {isSendRequested ? (
            <View style={{ marginRight: 12 }}>
              <ActivityIndicator size="small" color={Platform.OS == 'android' ? 'grey' : null} />
            </View>
          ) : null}

          <Text
            style={[
              styles.sendCodeButtonStyle,
              {
                color: isButtonDisabled ? disabledTextColor : textColor,
                opacity: isSendRequested ? 0.3 : 1
              },
              textStyles.styleLargeSemiBold
            ]}>
              {sendCodeStateLabel}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

interface PhoneNumbersProps {
  phoneNumbers: string[];
  checkedIndex: number;
  onChecked: (index: number, phoneNumber: string) => void;
  disabled?: boolean;
}
const PhoneNumbers: FC<PhoneNumbersProps> = ({ phoneNumbers, checkedIndex, onChecked, disabled = false }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <View style={{ marginBottom: 20 }}>
      <Text style={[brandingStore.textStyles.styleSmallSemiBold, styles.checkItemsTitle]}>{`Send Code To: `}</Text>
      <View style={styles.phoneNumbersContainer}>
        {phoneNumbers.map((phoneNumber: string, index: number) => (
          <View style={{ marginLeft: Platform.OS == 'android' ? 25 : 0 }} key={index}>
            <CHCheckItem
              {...createAccessibilityForAutomation(`phone number ending with ${phoneNumber} digits`)}
              style={styles.phoneNumber}
              checked={checkedIndex === index}
              onPress={() => onChecked(index, phoneNumber)}
              disabled={disabled}>
              <Text style={[brandingStore.textStyles.styleLargeSemiBold, { color: disabled ? brandingStore.currentTheme.greyEmptyState : brandingStore.currentTheme.blackMain }]}>{`(***) ***-${phoneNumber}`}</Text>
            </CHCheckItem>
            {/*Platform.OS === 'ios' && <View style={{ marginLeft: 24, borderBottomColor: brandingStore.currentTheme.separatorOpaque, borderBottomWidth: 1 }} />*/}
          </View>
        ))}
      </View>
    </View>
  );
};

interface SendCodeMethodComponentProps {
  selectedSendCodeMethod: SendCodeMethod;
  setSelectedSendCodeMethod: (selectedSendCodeMethod: SendCodeMethod) => void;
  disabled?: boolean;
}
const SendCodeMethodComponent: FC<SendCodeMethodComponentProps> = ({ selectedSendCodeMethod, setSelectedSendCodeMethod, disabled = false }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { t } = useTranslation('translation');
  const { ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys } = LocaleKeys.components.Enrollment;

  

  return (
    <View>
      <Text style={[brandingStore.textStyles.styleSmallSemiBold, styles.checkItemsTitle]}>{t(ConfirmPhoneNumberLocalKeys.SendCodeVia)}</Text>{/* Send Code Via: */}
      <View style={styles.phoneNumbersContainer}>
        <View style={{ marginLeft: Platform.OS == 'android' ? 25 : 0 }} key={SendCodeMethod.SMS}>
          <CHCheckItem
            style={styles.phoneNumber}
            checked={selectedSendCodeMethod === SendCodeMethod.SMS}
            onPress={() => setSelectedSendCodeMethod(SendCodeMethod.SMS)}
            disabled={disabled}>
            <Text style={[brandingStore.textStyles.styleLargeSemiBold, { color: disabled ? brandingStore.currentTheme.greyEmptyState : brandingStore.currentTheme.blackMain }]}>{t(ConfirmPhoneNumberLocalKeys.TextMessage)}</Text>{/* Text Message */}
          </CHCheckItem>
        </View>
        <View style={{ marginLeft: Platform.OS == 'android' ? 25 : 0 }} key={SendCodeMethod.Voice}>
          <CHCheckItem
            style={styles.phoneNumber}
            checked={selectedSendCodeMethod === SendCodeMethod.Voice}
            onPress={() => setSelectedSendCodeMethod(SendCodeMethod.Voice)}
            disabled={disabled}>
            <Text style={[brandingStore.textStyles.styleLargeSemiBold, { color: disabled ? brandingStore.currentTheme.greyEmptyState : brandingStore.currentTheme.blackMain }]}>{t(ConfirmPhoneNumberLocalKeys.VoiceCall)}</Text>{/* Voice Call */}
          </CHCheckItem>
        </View>
      </View>
    </View>
  );
};

interface PhoneVerificationProps {
  phoneNumbers: string[];
  onSendCodeHandler: (event: GestureResponderEvent, phoneNumber: string, sendMethod: SendCodeMethod) => void;
  isVerificationCodeVisible: boolean;
  // dispatch: React.Dispatch<PhoneVerificationAction>;
  verificationCode: string;
  onTextChange: (string) => void;
  onCodeSetFocus: () => void;
  onCodeClearFocus: () => void;
  codeError: string | null;
  sendAttempts: number;
  sendCodeButtonState: SendCodeButtonStates;
  chcSupportPhoneNumber: string;
}

export const PhoneVerification: FC<PhoneVerificationProps> = ({
  phoneNumbers = [],
  sendCodeButtonState,
  onSendCodeHandler,
  isVerificationCodeVisible,
  verificationCode,
  onTextChange,
  onCodeClearFocus,
  onCodeSetFocus,
  sendAttempts,
  codeError,
  chcSupportPhoneNumber
}) => {
  const [checkedIndex, setCheckedIndex] = useState<number>(0);
  const [selectedPhoneNumber, setSelectedPhoneNumber] = useState<string>(phoneNumbers[0]);
  const [selectedSendCodeMethod, setSelectedSendCodeMethod] = useState<SendCodeMethod>(SendCodeMethod.SMS);
  const { brandingStore, generalStore } = useStores();
  const { t } = useTranslation('translation');
  const { ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys } = LocaleKeys.components.Enrollment;
  const styles = styleCreator(brandingStore);

  // console.log('PhoneVerification visible', isVerificationCodeVisible);

  useEffect(() => {
    setSelectedPhoneNumber(phoneNumbers[0]);
  }, [phoneNumbers]);

  const onChecked = (index: number, phoneNumber: string) => {
    setCheckedIndex(index);
    setSelectedPhoneNumber(phoneNumber);
  };

  const onChangeText = (code: string) => {
    onTextChange(code);
    //dispatch({ type: 'SET_VERIFICATION_CODE', payload: code });
  };

  const onSendCodePressHandler = (event: GestureResponderEvent) => {
    onSendCodeHandler(event, selectedPhoneNumber, selectedSendCodeMethod);
  };

  
  return (
    <View style={styles.mainContainer}>
      {phoneNumbers.length > 0 && <PhoneNumbers phoneNumbers={phoneNumbers} checkedIndex={checkedIndex} onChecked={onChecked}  disabled={sendCodeButtonState === SendCodeButtonStates.Code_Sent}/>}

      <SendCodeMethodComponent selectedSendCodeMethod={selectedSendCodeMethod} setSelectedSendCodeMethod={setSelectedSendCodeMethod}  disabled={sendCodeButtonState === SendCodeButtonStates.Code_Sent}/>
      {selectedSendCodeMethod === SendCodeMethod.SMS && <>
        <Text style={[{ marginTop: 8, marginLeft: 25, marginRight: 40, color: brandingStore.currentTheme.tooltip }, brandingStore.textStyles.styleSmallRegular]}>
          {
            t(ConfirmPhoneNumberLocalKeys.DataRatesMayApply) // "Messaging & data rates may apply"
          }
        </Text>
        <Text style={{ marginTop: 20, marginLeft: 25, marginRight: 40 }}>
          <Text style={{ ...brandingStore.textStyles.styleSmallRegular, color: brandingStore.currentTheme.tooltip }}>
            {
              t(ConfirmPhoneNumberLocalKeys.NoSmsPleaseCall) + ' ' // If you cannot receive SMS at this number please call
            }
          </Text>
          <Text
            onPress={() => {
              callNumber(chcSupportPhoneNumber);
            }}
            style={{
              ...brandingStore.textStyles.styleSmallSemiBoldLink,
              color: brandingStore.currentTheme.actionMedium
            }}>
            {chcSupportPhoneNumber}
          </Text>
        </Text>
      </>}
      {selectedSendCodeMethod === SendCodeMethod.Voice &&
        <Text style={[{ marginTop: 8, marginLeft: 25, marginRight: 40, color: brandingStore.currentTheme.tooltip }, brandingStore.textStyles.styleSmallRegular]}>
          {
            //Receive an automated phone call with your confirmation code. Be prepared to write the code down.
            t(ConfirmPhoneNumberLocalKeys.ReceiveAnAutomated)
          }
        </Text>
      }
      <View style={{ marginLeft: 25, marginTop: 20 }}>
        <SendCodeComponent sendAttempts={sendAttempts} onPress={onSendCodePressHandler} textColor={brandingStore.currentTheme.actionMedium} disabledTextColor={'#979797'} state={sendCodeButtonState} selectedSendCodeMethod={selectedSendCodeMethod} />
      </View>
      {isVerificationCodeVisible ? (
        <View style={{ marginTop: 20, marginBottom: 20 }}>
          <CHTextInput
            error={codeError}
            underlineColorAndroid="grey"
            placeholder={'6 Digits'}
            maxLength={6}
            onFocus={onCodeSetFocus}
            onEndEditing={onCodeClearFocus}
            onChangeText={onChangeText}
            keyboardType="numeric"
            value={verificationCode}
            labelStyle={{ color: brandingStore.currentTheme.label }}
            {...createAccessibilityForAutomation('Verification code')}
            label={
              t(ConfirmPhoneNumberLocalKeys.VerificationCode) // 'Verification Code'
            }
            toolTip={selectedSendCodeMethod === SendCodeMethod.SMS ? 
            "Enter the verification code sent to your mobile phone. Code expires in 10 minutes." : 
            "Please enter the code from the automated phone call to proceed. Code expires in 10 minutes."}
          />
        </View>
      ) : null}
    </View>
  );
};
