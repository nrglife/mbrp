export interface NavigationProp {
  navigate: () => void;
}
