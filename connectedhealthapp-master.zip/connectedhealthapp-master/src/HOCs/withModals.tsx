import React, { ForwardRefExoticComponent, PropsWithoutRef, RefAttributes, useImperativeHandle, useState } from 'react';

import { View, ViewProps } from 'react-native';

interface WithModalProps extends ViewProps {}

type NodeFunc = () => React.ReactNode;

type NodeFuncs = NodeFunc[];

export interface WithModalInterface {
  addModal: (NodeFunc) => string;
  clearModal: (string) => void;
}

export declare type WithModalsComponent = ForwardRefExoticComponent<PropsWithoutRef<ViewProps> & RefAttributes<WithModalInterface>>;

export declare type IReactComponent<P = any> = React.ClassicComponentClass<P> | React.ComponentClass<P> | React.FunctionComponent<P> | React.ForwardRefExoticComponent<P>;

//export declare type IReactComponent<P = any> = React.FC<P>;

//export declare type WithModalsHoc<T extends IReactComponent> = (WrappedComponent: T) => WithModalsComponent;

export interface DiffResult<T> {
  additions: T[];
  updates: T[];
  deletes: T[];
}

export const withModals = <T extends ViewProps>(WrappedComponent: IReactComponent<T>) => {
  return React.forwardRef<WithModalInterface, T>((props, ref) => {
    const [funcs, setFuncs] = useState({});
    useImperativeHandle(ref, () => ({
      addModal: func => {
        let index = undefined;
        let i = 0;
        while (index == undefined) {
          const key = 'modal_' + i;
          if (!funcs[key]) {
            index = key;
          }
          i++;
        }
        funcs[index] = func;

        setFuncs({ ...funcs });
        return index;
      },
      clearModal: (key: string) => {
        delete funcs[key];
        setFuncs({ ...funcs });
      }
    }));

    //console.log('funcs', funcs);

    return (
      <View style={{ width: '100%', height: '100%' }}>
        <WrappedComponent {...props} />
        <View pointerEvents={'box-none'} style={{ position: 'absolute', width: '100%', height: '100%', zIndex: 1000 }}>
          {Object.keys(funcs).map(key => {
            return (
              <View key={key} pointerEvents={'box-none'} style={{ position: 'absolute', width: '100%', height: '100%' }}>
                {funcs[key]()}
              </View>
            );
          })}
        </View>
      </View>
    );
  });
};

export default withModals;
