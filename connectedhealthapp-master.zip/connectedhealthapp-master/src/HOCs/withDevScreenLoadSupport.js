import React from 'react';
import Config from 'react-native-config';
import toBoolean from 'underscore.string/toBoolean';
import Toast from 'react-native-root-toast';
import { EnrollmentNavigationRoutes } from '../routes';
import * as navigationRef from '../services/NavigationService';
import AppConfigStore from '../stores/AppConfigStore';
import { IocTypesMobile, IocContainer } from '../iocTypes';

const withDevScreenLoadSupport = WrappedComponent => {
  class HOC extends React.Component {
    constructor(props) {
      super(props);
      this.devPressed = 10; // need to decide where to place it
      this.timeout = null;
      this.toast = null;
      this.configStore = IocContainer.get(IocTypesMobile.AppConfigStore);

      this.state = {
        isDialogVisible: false
      };
    }
    componentWillUnmount() {
      this.toast && this.toast.destroy();
      clearTimeout(this.timeout);
    }

    _showToast = message => {
      this.toast && this.toast.destroy();
      this.toast = Toast.show(message, {
        duration: Toast.durations.SHORT,
        position: Toast.positions.BOTTOM,
        shadow: false,
        animation: true,
        hideOnPress: true,
        onPress: () => {},
        onHidden: () => {
          this.toast && this.toast.destroy();
          this.toast = null;
        }
      });
    };

    _onDeveloperAreaPressHandler = () => {
      const isDevEnabled = Config['ENABLE_DEV_SCREEN'] ? Config['ENABLE_DEV_SCREEN'] : '';
      if (!toBoolean(isDevEnabled)) {
        return;
      }
      this.timeout = setTimeout(() => {
        this.devPressed = 10;
      }, 7500);
      if (this.devPressed >= 0 && this.devPressed <= 8) {
        if (toBoolean(Config.ENABLE_DEV_SCREEN_ENTERING_DEV_IN_TOAST)) {
          this._showToast(`Entering dev in... ${this.devPressed.toString()}`, Toast.durations.SHORT, Toast.positions.BOTTOM);
        }
        if (this.devPressed === 0) {
          this.toast && this.toast.destroy();
          this.devPressed = 10;

          if (toBoolean(Config.ENABLE_DEV_SCREEN_PROTECTING_DEV_SCREEN_WITH_PASSWORD)) {
            this.navigateToDevPasswordScreen();
          } else {
            this.navigateToDevScreen();
          }
          return;
        }
      }
      this.devPressed--;
    };

    navigateToDevPasswordScreen = () => {
      // LogHelper.PrintInfoLog('user navigates to DEV password screen');=
      navigationRef.navigate(EnrollmentNavigationRoutes.DevPasswordScreen);
    };
    navigateToDevScreen = () => {
      navigationRef.navigate(EnrollmentNavigationRoutes.DevScreen);
    };
    render() {
      return <WrappedComponent {...this.props} onDeveloperAreaPressHandler={this._onDeveloperAreaPressHandler} />;
    }
  }

  return HOC;
};

export default withDevScreenLoadSupport;
