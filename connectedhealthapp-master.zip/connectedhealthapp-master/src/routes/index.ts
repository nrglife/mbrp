export enum MainNavigationRoutes {
  LandingPage = 'LandingPage',
  EnrollmentPage = 'EnrollmentPage'
}

export enum HomeNavigationRoutes {
  Home = 'Home',
  Settings = 'Settings',
  LinkedServices = 'Linked Services',
  LinkedServicesFind = 'Linked Services Find',
  LinkedServicesDetails = 'Linked Services Details',
  LinkedServicesManage = 'Linked Services Manage',
  linkedServicesRequests = 'Request & Send',
  RequestContainer = 'RequestContainer',
  RecordContainer = 'RecordContainer',
  PayerLoginContainer = 'PayerLoginContainer',
  Eobs = 'Benefits Summary',
  EobDEtails = 'Eob Details',
  FindCare = 'FindCare',
  Visits = 'Visits',
  Appointments = 'Appointments',
  HealthProfile = 'HealthProfile',
  Medications = 'Medications',
  MedicationsDetails = 'MedicationsDetails',
  ProblemsAndConditionsContainer = 'ProblemsAndConditionsContainer',
  AllergiesContainer = 'AllergiesContainer',
  GoalsContainer = 'GoalsContainer',
  VisitsContainer = 'VisitsContainer',
  labObservationsContainer = 'labObservationsContainer',
  ProceduresContainer = 'ProceduresContainer',
  MedicalImplantsContainer = 'MedicalImplantsContainer',
  VaccinationsContainer = 'VaccinationsContainer',
  HealthTicketDetailsContainer = 'HealthTicketDetailsContainer',
  LinkedServicesRequests = 'LinkedServicesRequests',
  More = 'More',
  Help = 'Help',
  ContactUs = 'Contact us',
  ClinicalsOverviewContainer = 'ClinicalsOverviewContainer'
}

export enum HomeNavigationRoutesMain {
  Eobs = 'EOBsmain',
  More = 'MoreMain',
  Settings = 'SettingsMain',
  HealthProfile = 'HealthProfile',
  LinkedServices = 'LinkedServicesMain',
  Help = 'HelpMain',
  LinkedServicesFind = 'LinkedServicesFind',
  LinkedServicesRequests = 'LinkedServicesRequests'
}

export enum LinkedServicesRoute {
  LinkedServicesFind = 'LinkedServicesFind',
  LinkedServicesRequests = 'LinkedServicesRequests'
}

export enum LoginNavigationRoutes {
  Login = 'Login',
  TermsAndConditions = 'TermsAndConditions'
}

export enum EnrollmentNavigationRoutes {
  InvitationCode = 'InvitationCode',
  ENrollmentSteps = 'ENrollmentSteps',
  PersonalInfo = 'PersonalInfo',
  Welcome = 'Welcome',
  ConfirmPhoneNumber = 'ConfirmPhoneNumber',
  ConfirmSms = 'ConfirmSms',
  EmailVerification = 'EmailVerification',
  ConfirmEmail = 'ConfirmEmail',
  CreatePassword = 'CreatePassword',
  Locked = 'Locked',
  Enrolled = 'Enrolled',
  MissingInfo = 'MissingInfo',
  AlreadyEnrolled = 'AlreadyEnrolled',
  GeneralError = 'GeneralError',
  Timeout = 'Timeout',
  EnrollmentComplete = 'EnrollmentComplete',
  DevScreen = 'DevScreen',
  DevPasswordScreen = 'DevPasswordScreen',
  NoUserPhoneNumber = 'NoUserPhoneNumber'
}
