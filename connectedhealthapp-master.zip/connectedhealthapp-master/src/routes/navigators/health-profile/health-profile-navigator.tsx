import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import { ImageSourcePropType } from 'react-native';

interface HealthTicketDetailsContainerParams extends DisplayableHealthProfileItem{
  iconSource?: ImageSourcePropType
}

export type RootStackParamList = {
  HealthTicketDetailsContainer: { item: HealthTicketDetailsContainerParams }
}
