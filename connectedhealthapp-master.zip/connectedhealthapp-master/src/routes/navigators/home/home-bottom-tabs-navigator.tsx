import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { FlatList, Image, Platform, StatusBar, View } from 'react-native';
import React, { FC, useEffect, useMemo, useState } from 'react';
import { styles as stylesCreator } from './home-bottom-tabs-navigator.styles';
import { useStores } from '../../../hooks/useStores';
import { createStackNavigator } from '@react-navigation/stack';
import { observer } from 'mobx-react';
import { TabBarComponent } from './components/tab-bar-component';
import withModals, { WithModalsComponent } from '../../../HOCs/withModals';
import { ScreenList, ScreenType, TabScreen, useModularNavigation } from '../../../hooks/useModularNavigation';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

interface InternalStackProps {
  screens: ScreenList;
}

/*
const DelegateSelectorContainer: FC<DelegateSelectorContainerProps> = ({ screen, ...props }) => {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ marginTop: screen.showDelegationPicker ? 50 : 0, flex: 1 }}>
        <screen.component {...props} />
      </View>
      {screen.showDelegationPicker && (
        <View style={{ position: 'absolute', flex: 1, width: '100%' }}>
          <DelegationPicker />
        </View>
      )}
    </View>
  );
};*/

const InternalStack: FC<InternalStackProps> = observer(props => {
  const { brandingStore, generalStore } = useStores();

  return (
    <View style={{ flex: 1 }}>
      <StatusBar
        backgroundColor={Platform.OS == 'android' ? brandingStore.currentTheme.actionDark : brandingStore.currentTheme.white}
        barStyle={Platform.OS == 'android' ? 'light-content' : 'dark-content'}
      />
      <Stack.Navigator
        screenOptions={{
          safeAreaInsets: generalStore.insets,
          headerStyle: {
            backgroundColor: Platform.OS == 'android' ? brandingStore.currentTheme.actionDark : brandingStore.currentTheme.white
          },
          headerTitleStyle: brandingStore.textStyles.styleLargeSemiBold,
          headerTintColor: Platform.OS == 'android' ? brandingStore.currentTheme.white : '#000'
        }}>
        {props.screens.map((screen: ScreenType, index: number) => {
          return (
            <Stack.Screen key={index} name={screen.route} component={screen.component} {...(screen.title ? { options: { title: screen.title } } : null)} initialParams={{ ...props.route.params }} />
          );
        })}
      </Stack.Navigator>
    </View>
  );
});

const createInternalStack: (screens: ScreenList) => FC = screens => {
  const comp = props => {
    return <InternalStack {...props} screens={screens} />;
  };
  return comp;
};

export const HomeTabsNavigatorBottom: WithModalsComponent = withModals(
  observer(() => {
    const { brandingStore, payerStore, generalStore, appConfigStore, delegateStore } = useStores();
    const { getPayerRoutes, getTabRouteDictionary } = useModularNavigation(payerStore, generalStore, appConfigStore, delegateStore);
    const styles = stylesCreator(brandingStore);
    // const [appBottomTabs, setAppBottomTabs] = useState<TabScreen[]>([]);

    const payerRoutes = getPayerRoutes();
    const tabRouteDictionary = getTabRouteDictionary();
    const appBottomTabs: TabScreen[] = useMemo(() => {
      return payerRoutes.homeRoutes.map(item => {
        return {
          ...tabRouteDictionary[item],
          component: createInternalStack(tabRouteDictionary[item].screens),
          route: item
        };
      });
    }, [payerRoutes.homeRoutes, tabRouteDictionary]);

    if (appBottomTabs.length == 0) {
      return null;
    }

    return (
      <Tab.Navigator
        screenOptions={{ headerShown: false }}
        tabBar={props => <TabBarComponent {...props} />}
        options={{
          labelStyle: brandingStore.textStyles.styleXXSmallSemiBold,
          activeTintColor: brandingStore.currentTheme.actionDark,
          inactiveTintColor: brandingStore.currentTheme.label,
          iconStyle: { height: 10, backgroundColor: 'blue' },

          style: {
            justifyContent: 'center',
            backgroundColor: Platform.OS == 'android' ? brandingStore.currentTheme.bottomBar : brandingStore.currentTheme.bottomBar,
            ...(Platform.OS == 'android' && false
              ? {
                  height: 72
                }
              : null)
          }
        }}
        initialRouteName={appBottomTabs[0].route}>
        {appBottomTabs.map(({ route, component, inactiveTabIcon, activeTabIcon, title }, index) => {
          return (
            <Tab.Screen
              key={index}
              component={component}
              name={route}
              options={{
                tabBarIcon: ({ focused, color, size }) => {
                  return <Image style={[styles.tabImage, { tintColor: color, width: size, height: size }]} source={focused ? activeTabIcon : inactiveTabIcon} />;
                },
                title: title,
                tabBarVisible: true
              }}
            />
          );
        })}
      </Tab.Navigator>
    );
  })
);
