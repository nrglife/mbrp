import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { Platform } from 'react-native';
import { EnrollmentNavigationRoutes, HomeNavigationRoutes } from '../..';
import { EobListContainer } from '../../../screens/eobs/eob-list';
import { VisitsContainer } from '../../../screens/visits';
import { FindCareContainer } from '../../../screens/find-care';
import React from 'react';
import { useStores } from '../../../hooks/useStores';

const Tab = createMaterialTopTabNavigator();

export const HomeTabsNavigator = () => {
  /**, color: Platform.OS == 'android'? 'white':'grey'  */

  const { brandingStore } = useStores();
  const textStyles = brandingStore.textStyles;

  return (
    <Tab.Navigator
      options={{
        labelStyle: textStyles.styleXXSmallRegular,
        activeTintColor: Platform.OS == 'android' ? 'white' : 'grey',
        inactiveTintColor: Platform.OS == 'android' ? 'rgba(255, 255, 255, 0.38)' : 'grey',
        indicatorStyle: { backgroundColor: '#F8CA7B' },

        style: {
          justifyContent: 'flex-end',
          backgroundColor: Platform.OS == 'android' ? '#0D0555' : '#FFFFFF',
          ...(Platform.OS == 'android'
            ? {
                height: 72
              }
            : null)
        }
      }}
      style={{}}
      initialRouteName={EnrollmentNavigationRoutes.InvitationCode}>
      <Tab.Screen name={HomeNavigationRoutes.Eobs} component={EobListContainer} />
      <Tab.Screen name={HomeNavigationRoutes.FindCare} component={FindCareContainer} />
      <Tab.Screen name={HomeNavigationRoutes.Visits} component={VisitsContainer} />
    </Tab.Navigator>
  );
};
