import { createDrawerNavigator } from '@react-navigation/drawer';
import { HomeTabsNavigator } from './home-tabs-navigator';
import { DrawerComponent } from './components/drawer-component';
import React from 'react';
import { Platform, Text, View } from 'react-native';
import { MenuButton } from './components/menu-button';
import { HomeNavigationRoutes } from '../..';

const Drawer = createDrawerNavigator();
export const HomeDrawerNavigator = props => {
  return (
    <Drawer.Navigator drawerContent={() => <DrawerComponent {...props} />}>
      <Drawer.Screen
        name={HomeNavigationRoutes.Home}
        component={HomeTabsNavigator}
        options={{
          headerShown: true,
          headerStyle: {
            backgroundColor: Platform.OS == 'android' ? '#0D0555' : 'white'
          },
          headerTintColor: Platform.OS == 'android' ? 'white' : 'black',
          headerLeft: () => <MenuButton />
        }}
      />
    </Drawer.Navigator>
  );
};
