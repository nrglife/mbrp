import { globals } from '../../../globals';

import { StyleSheet, Platform, TextStyle, ViewStyle, ImageStyle } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  interface Style {
    mainContainer: ViewStyle;
    container: ViewStyle;
    formFieldStyle: ViewStyle;
    tabImage: ImageStyle;
    listItemStyle: ViewStyle;
  }

  return StyleSheet.create<Style>({
    mainContainer: { flex: 1 },
    container: { flex: 1, alignItems: 'center', padding: 30 },
    formFieldStyle: { marginVertical: 5, width: '100%' },
    tabImage: {  resizeMode: 'contain' },
    listItemStyle: { borderTopWidth: 1, borderColor: 'grey', padding: 20, backgroundColor: '#FFFFFF' }
  });
};
