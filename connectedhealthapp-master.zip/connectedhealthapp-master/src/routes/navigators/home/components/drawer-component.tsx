import AsyncStorage from '@react-native-async-storage/async-storage';
import React from 'react';
import { Button, Text, View } from 'react-native';
import { HomeNavigationRoutes } from '../../..';
import { useStores } from '../../../../hooks/useStores';
import { ENROLLED_KEY } from '../../../../utilities/async-storage-keys';

export const DrawerComponent = ({ navigation }) => {
  const stores = useStores();
  return (
    <View>
      <Text>drawer</Text>
      <Button
        title={'settings'}
        onPress={() => {
          navigation.navigate(HomeNavigationRoutes.Settings);
        }}></Button>

      <Button
        title={'un-enrol'}
        onPress={async () => {
          await AsyncStorage.setItem(ENROLLED_KEY, 'false');
          stores.generalStore.setEnrollmentComplete(false);
        }}></Button>
    </View>
  );
};
