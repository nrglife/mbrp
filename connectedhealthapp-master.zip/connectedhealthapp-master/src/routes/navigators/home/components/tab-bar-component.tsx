import AsyncStorage from '@react-native-async-storage/async-storage';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import React, { FC } from 'react';
import { Button, Text, View, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { HomeNavigationRoutes } from '../../..';
import { useStores } from '../../../../hooks/useStores';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';
import { ENROLLED_KEY } from '../../../../utilities/async-storage-keys';

export const TabBarComponent: FC<BottomTabBarProps> = ({ state, descriptors, navigation }) => {
  const { brandingStore } = useStores();
  const { bottom } = useSafeAreaInsets();
  const focusedOptions = descriptors[state.routes[state.index].key].options;

  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  return (
    <View style={{ flexDirection: 'row', height: 'auto', width: '100%', backgroundColor: 'white', borderTopColor: brandingStore.currentTheme.label, borderTopWidth: 0.5, paddingBottom: bottom }}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        descriptors[route.key].options.tabBarVisible;
        const label = options.tabBarLabel !== undefined ? options.tabBarLabel : options.title !== undefined ? options.title : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key
          });
        };

        return (
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            {...createAccessibilityForAutomation(route.name)}
            disabled={options.tabBarVisible ? false : true}
            onPress={onPress}
            key={'tab_' + index}
            onLongPress={onLongPress}
            style={{ display: 'flex', flex: 1, flexGrow: 1, height: 'auto', flexBasis: 0, flexDirection: 'column', alignItems: 'center' }}>
            <View style={{ flexDirection: 'column', alignItems: 'center', opacity: options.tabBarVisible ? 1 : 0.4 }}>
              <View style={{ paddingVertical: 7 }}>
                {options.tabBarIcon ? options.tabBarIcon({ focused: isFocused, color: isFocused ? brandingStore.currentTheme.actionDark : brandingStore.currentTheme.label, size: 24 }) : null}
              </View>
              <Text
                numberOfLines={1}
                style={[
                  {
                    color: isFocused ? brandingStore.currentTheme.actionDark : brandingStore.currentTheme.label,
                    marginBottom: 7
                  },
                  brandingStore.textStyles.bottomBar
                ]}>
                {label}
              </Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};
