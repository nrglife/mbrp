import { Platform, View } from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import { DrawerActions, useNavigation } from '@react-navigation/native';

export const MenuButton = props => {
  const navigation = useNavigation();
  // console.log('navigation3: ', navigation);
  return (
    <View style={{ marginLeft: 20, width: 30, height: 20 }}>
      <Icon
        color={Platform.OS === 'ios' ? 'black' : 'white'}
        size={20}
        name={Platform.OS === 'ios' ? 'ios-menu-outline' : 'md-menu'}
        onPress={() => {
          navigation.dispatch(DrawerActions.toggleDrawer());
        }}
      />
    </View>
  );
};
