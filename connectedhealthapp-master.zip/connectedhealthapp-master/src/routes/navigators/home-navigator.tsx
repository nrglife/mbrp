import React, { useCallback, useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';

// pages
import { SettingsContainer } from '../../screens/settings';

// routes
import { HomeNavigationRoutes } from '..';
import { HomeTabsNavigatorBottom } from './home/home-bottom-tabs-navigator';
import { useStores } from '../../hooks/useStores';
import LinkedServicesManageContainer from '../../screens/linked-services-manage/container/linked-services-manage.container';
import Loader from '../../components/Loader';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/src/stores/DelegateStore';
import { observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import PayerLoginContainer from "../../screens/p2p/payer-login/container/payer-login.container";
import {HelpContactUsContainer} from "../../screens/help-contact-us/container/help-contact-us.container";
export { uppercaseFirstLetter, titleCase } from '@healthcareapp/connected-health-common-services/dist/utilities/string';

const Stack = createStackNavigator();

export const HomeStackNavigator = observer(() => {
  const { generalStore, delegateStore, errorStore } = useStores();
  const { t } = useTranslation('translation');

  const Tabs = useCallback(props => <HomeTabsNavigatorBottom {...props} ref={generalStore.screenRef} />, []);

  return (
    <>
      <Loader isLoading={delegateStore.state != DelegateStoreState.Running && delegateStore.state != DelegateStoreState.RunningShowError} />
      {delegateStore.state !== DelegateStoreState.PreInit && (
        <Stack.Navigator
          key={'key_' + delegateStore.selectedDelegateId}
          initialRouteName={HomeNavigationRoutes.Home}
        >
          <Stack.Screen name={HomeNavigationRoutes.Home} component={Tabs} options={{ headerShown: false }} />
          <Stack.Screen name={HomeNavigationRoutes.Settings} component={SettingsContainer} />
          <Stack.Screen name={HomeNavigationRoutes.LinkedServicesManage} component={LinkedServicesManageContainer} />
          <Stack.Screen name={HomeNavigationRoutes.PayerLoginContainer} component={PayerLoginContainer} />
          <Stack.Screen  name={HomeNavigationRoutes.ContactUs} component={HelpContactUsContainer} />
        </Stack.Navigator>
      )}
    </>
  );
});
