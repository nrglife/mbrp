import React, { FC, RefObject, useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import { EnrollmentNavigationRoutes, HomeNavigationRoutes, LoginNavigationRoutes } from '../..';
import { useStores } from '../../../hooks/useStores';
import { observer } from 'mobx-react';

import { LinkedServicesFindContainer } from '../../../screens/linked-services-find';
import { LinkedServicesDetailsContainer } from '../../../screens/linked-services-details';
import { LinkedServiceStoreType } from '@healthcareapp/connected-health-common-services/dist/inversify.config';
import { LinkedService } from '@healthcareapp/connected-health-common-services/dist/stores/LinkedServiceStore';

const Stack = createStackNavigator();
const StackInternal = createStackNavigator();

export type RootStackParamList = {
  LinkedServicesDetailsContainer: { appData: LinkedServiceStoreType };
};

export const LinkedServicesFindNavigator: FC<RootStackParamList> = observer(props => {
  const { generalStore, brandingStore } = useStores();

  return (
    <Stack.Navigator>
      <Stack.Screen name={HomeNavigationRoutes.LinkedServicesFind} component={LinkedServicesFindContainer} options={{ headerShown: false, title: 'Terms & Conditions' }} />
      <Stack.Screen name={HomeNavigationRoutes.LinkedServicesDetails} component={LinkedServicesDetailsContainer} options={{ headerShown: false, title: 'Terms & Conditions' }} />
    </Stack.Navigator>
  );
});
