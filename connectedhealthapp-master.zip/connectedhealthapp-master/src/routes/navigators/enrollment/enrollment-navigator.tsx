import React, { useCallback, useEffect, useState } from 'react';
import { Platform, TouchableOpacity, View, Text, Alert, BackHandler, Dimensions } from 'react-native';
import { createStackNavigator, TransitionPresets } from '@react-navigation/stack';
import FastImage from 'react-native-fast-image';

import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

// routes
import { EnrollmentNavigationRoutes } from '../..';

// pages
import { PersonalInfoContainer } from '../../../screens/enrollment/personal-info';
import { EmailVerificationContainer } from '../../../screens/enrollment/email-verification';
import { PhoneVerificationContainer } from '../../../screens/enrollment/phone-verification';
import { SetupComplete } from '../../../screens/enrollment/setup-complete';
import { CreatePasswordContainer } from '../../../screens/enrollment/create-password';
import { Welcome } from '../../../screens/enrollment/welcome';
import { useStores } from '../../../hooks/useStores';
import { HeaderLeft } from './components/header-left.component';
import { LockedContainer } from '../../../screens/enrollment/locked';
import { MissingInfoContainer } from '../../../screens/enrollment/missing-info';
import { GeneralErrorContainer } from '../../../screens/enrollment/general-error';
import { TimeoutContainer } from '../../../screens/enrollment/timeout';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EnrollmentStatuses } from '../../../screens/ciam-login/container/ciam-login.container';
import DevScreen from '../../../screens/DevScreen';
import DevPasswordScreen from '../../../screens/DevPasswordScreen';
import { CHBottomSheet, ContactModal } from '../../../components';
import NoPhoneVerificationContainer from '../../../screens/enrollment/no-phone-verification/containers/no-phone-verification.container';
import { AlreadyEnrolledContainer } from '../../../screens/enrollment/already-enrolled/container/already-enrolled.container';

export type RootStackParams = {
  PersonalInfo: undefined;
  ConfirmPhoneNumber: undefined;
  EmailVerification: { emails: string[] };
  CreatePassword: undefined;
  EnrollmentComplete: undefined;
  Welcome: undefined;
  Locked: undefined;
  MissingInfo: undefined;
  GeneralError: undefined;
  ENrollmentSteps: undefined;
  AlreadyEnrolled: undefined;
  Timeout: undefined;
  DevScreen: undefined;
  DevPasswordScreen: undefined;
  NoUserPhoneNumber: undefined;
};

const RootStack = createStackNavigator<RootStackParams>();
const EnrollmentStack = createStackNavigator();

const EnrollmentNavigator = () => {
  const { brandingStore, generalStore } = useStores();
  const { width } = Dimensions.get('window');
  const { top, bottom } = useSafeAreaInsets();
  const [insets, setInsets] = useState({ top: top, bottom: bottom });
  const { t } = useTranslation('translation');
  const {
    PersonalInfo: PersonalInfoLocalKeys,
    ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys,
    EmailVerification: EmailVerificationLocalKeys,
    CreatePassword: CreatePasswordLocalKeys
  } = LocaleKeys.components.Enrollment;

  return (
    <EnrollmentStack.Navigator
      // initialRouteName={EnrollmentNavigationRoutes.ConfirmPhoneNumber}
      screenOptions={({ navigation, route }) => {
        return {
          safeAreaInsets: generalStore.insets,
          headerStyle: {
            backgroundColor: brandingStore.currentTheme.actionDark
          },
          headerTitleStyle: brandingStore.textStyles.styleLargeSemiBold,
          headerTintColor: '#fff',
          headerLeft: () => <HeaderLeft navigation={navigation} />
        };
      }}>
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.PersonalInfo}
        options={{
          title: t(PersonalInfoLocalKeys.TitleLandingUnified) // 'Confirm personal information'
          //headerTitleStyle: {
          // width: width * 0.666
          // }
        }}
        component={PersonalInfoContainer}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.ConfirmPhoneNumber}
        options={{
          title: t(ConfirmPhoneNumberLocalKeys.HeaderUnified) // 'Verify your phone'
        }}
        component={PhoneVerificationContainer}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.NoUserPhoneNumber}
        options={{
          title: t(ConfirmPhoneNumberLocalKeys.HeaderUnified) // 'Verify your phone'
        }}
        component={NoPhoneVerificationContainer}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.EmailVerification}
        options={{
          title: t(EmailVerificationLocalKeys.Header) // 'Verify your email'
        }}
        component={EmailVerificationContainer}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.CreatePassword}
        options={{
          title: t(CreatePasswordLocalKeys.Header) // 'Create password'
        }}
        component={CreatePasswordContainer}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.Locked}
        component={LockedContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.MissingInfo}
        component={MissingInfoContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.AlreadyEnrolled}
        component={AlreadyEnrolledContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.Timeout}
        component={TimeoutContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.GeneralError}
        component={GeneralErrorContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.EnrollmentComplete}
        component={SetupComplete}
        options={{
          headerShown: false
        }}
      />
    </EnrollmentStack.Navigator>
  );
};

export const EnrollmentStackNavigator = observer(() => {
  const { enrollmentStore } = useStores();

  return (
    <View style={{ width: '100%', height: '100%' }}>
      <RootStack.Navigator
        screenOptions={{ headerShown: false, gestureEnabled: true, presentation: "card" }} // initialRouteName={EnrollmentNavigationRoutes.ENrollmentSteps}
      >
        <RootStack.Screen name={EnrollmentNavigationRoutes.Welcome} component={Welcome} />
        {/*<RootStack.Screen*/}
        {/*  name={EnrollmentNavigationRoutes.DevScreen}*/}
        {/*  component={DevScreen}*/}
        {/*  options={{*/}
        {/*    headerShown: true*/}
        {/*  }}*/}
        {/*/>*/}
        {/*<RootStack.Screen*/}
        {/*  name={EnrollmentNavigationRoutes.DevPasswordScreen}*/}
        {/*  component={DevPasswordScreen}*/}
        {/*  options={{*/}
        {/*    headerShown: true*/}
        {/*  }}*/}
        {/*/>*/}
        <RootStack.Screen
          name={EnrollmentNavigationRoutes.ENrollmentSteps}
          component={enrollmentStore.userSecretMetadata ? EnrollmentNavigator : Welcome}
          options={({ navigation, route }) => ({
            gestureEnabled: false
            // ...TransitionPresets.ModalSlideFromBottomIOS
          })}
        />

        <RootStack.Screen
          name={EnrollmentNavigationRoutes.Locked}
          component={LockedContainer}
          options={{
            headerShown: false
          }}
        />
        <RootStack.Screen
          name={EnrollmentNavigationRoutes.MissingInfo}
          component={MissingInfoContainer}
          options={{
            headerShown: false
          }}
        />

        <RootStack.Screen
          name={EnrollmentNavigationRoutes.AlreadyEnrolled}
          component={AlreadyEnrolledContainer}
          options={{
            headerShown: false
          }}
        />
        <RootStack.Screen
          name={EnrollmentNavigationRoutes.GeneralError}
          component={GeneralErrorContainer}
          options={{
            headerShown: false
          }}
        />
      </RootStack.Navigator>
    </View>
  );
});

/*export const EnrollmentStackNavigator = () => {
  const { brandingStore } = useStores();
  const route = useRoute();
  return (
    <RootStack.Navigator
      mode={!route ? 'modal' : route.name == EnrollmentNavigationRoutes.Welcome ? 'modal' : 'card'}
      screenOptions={({ navigation, route }) => {
        return {
          headerStyle: {
            backgroundColor: brandingStore.currentTheme.actionDark
          },

          headerTitleStyle: {  },
          headerTintColor: '#fff',
          headerLeft: () => <HeaderLeft navigation={navigation} />
        };
      }}>
      <RootStack.Screen
        options={{
          headerShown: false
        }}
        name={EnrollmentNavigationRoutes.Welcome}
        component={Welcome}
      />
      <RootStack.Screen name={EnrollmentNavigationRoutes.PersonalInfo} component={PersonalInfoContainer2} />
      <RootStack.Screen name={EnrollmentNavigationRoutes.ConfirmPhoneNumber} options={{ title: 'Verify your phone' }} component={PhoneVerificationContainer} />
      <RootStack.Screen name={EnrollmentNavigationRoutes.EmailVerification} component={EmailVerificationContainer2} />
      <RootStack.Screen name={EnrollmentNavigationRoutes.CreatePassword} component={CreatePasswordContainer2} />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.Locked}
        component={LockedContainer}
        options={{
          headerShown: false
        }}
      />
      <RootStack.Screen
        name={EnrollmentNavigationRoutes.EnrollmentComplete}
        component={SetupComplete}
        options={{
          headerShown: false
        }}
      />
    </RootStack.Navigator>
  );
};*/
