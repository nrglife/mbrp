import { StackActions, useFocusEffect } from '@react-navigation/native';
import React, { useCallback } from 'react';
import { Alert, BackHandler, Platform, StyleSheet, TouchableOpacity } from 'react-native';
import FastImage from 'react-native-fast-image';
import { EnrollmentNavigationRoutes } from '../../..';
import images from '../../../../assets/images/images';
import { useStores } from '../../../../hooks/useStores';
import GeneralStore from '../../../../stores/GeneralStore';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';

const ALERT_DATA = {
  title: 'Exit enrollment?',
  text: 'You will need to restart the process.'
};

export const HeaderLeft = ({ navigation }) => {
  const { enrollmentStore, generalStore } = useStores();
  useFocusEffect(
    useCallback(() => {
      const subHardwareBackPress = BackHandler.addEventListener('hardwareBackPress', onCloseEnrollmentProcess);
      return () => subHardwareBackPress.remove();
    }, [])
  );

  const onCloseEnrollmentProcess = () => {
    Alert.alert(ALERT_DATA.title, ALERT_DATA.text, [
      { text: 'Don’t exit', style: 'cancel', onPress: () => {} },
      {
        text: 'Exit',
        style: 'destructive',
        onPress: () => {
          generalStore.clearAllStores();
          navigation.dispatch(StackActions.pop());
        }
      }
    ]);

    return true;
  };

  return (
    <TouchableOpacity onPress={onCloseEnrollmentProcess} {...createAccessibilityForAutomation('Close Button')}>
      <FastImage resizeMode={FastImage.resizeMode.stretch} tintColor="#fff" source={images.closeXIcon} style={styles.closeIconStyle} />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  closeIconStyle: { flexDirection: 'row', justifyContent: 'flex-start', width: 13, height: 13, marginLeft: Platform.select({ ios: 25, android: 25 }) }
});
