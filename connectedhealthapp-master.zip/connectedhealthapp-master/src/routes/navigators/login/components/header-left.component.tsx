import { StackActions, useFocusEffect } from '@react-navigation/native';
import React, { useCallback } from 'react';
import { Alert, BackHandler, Platform, StyleSheet, TouchableOpacity } from 'react-native';
import FastImage from 'react-native-fast-image';
import { LoginNavigationRoutes } from '../../..';
import images from '../../../../assets/images/images';
import { useStores } from '../../../../hooks/useStores';
import { createAccessibilityForAutomation } from '../../../../utilities/accessibility';

const ALERT_DATA = {
  title: 'Are you sure you want to quit?',
  text: 'In order to access your account, you must agree to the Terms & Conditions.'
};

export const HeaderLeft = ({ navigation }) => {
  const { enrollmentStore, brandingStore, generalStore } = useStores();
  useFocusEffect(
    useCallback(() => {
      const hardwareBackPress =  BackHandler.addEventListener('hardwareBackPress', onClose);
      return () => hardwareBackPress.remove()
    }, [])
  );

  const onClose = () => {
    Alert.alert(ALERT_DATA.title, ALERT_DATA.text, [
      { text: 'Stay', style: 'cancel', onPress: () => {} },
      {
        text: 'Quit',
        style: 'destructive',
        onPress: () => {
          generalStore.logout();
          navigation.dispatch(StackActions.replace(LoginNavigationRoutes.Login));
        }
      }
    ]);

    return true;
  };

  return (
    <TouchableOpacity onPress={onClose} {...createAccessibilityForAutomation('Close Button')}>
      <FastImage resizeMode={FastImage.resizeMode.stretch} tintColor="#fff" source={images.closeXIcon} style={styles.closeIconStyle} />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  closeIconStyle: { flexDirection: 'row', justifyContent: 'flex-start', width: 13, height: 13, marginLeft: Platform.select({ ios: 25, android: 25 }) }
});
