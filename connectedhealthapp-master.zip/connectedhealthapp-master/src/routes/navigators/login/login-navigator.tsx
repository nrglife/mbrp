import React, { useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import { HomeTabsNavigator } from '../home/home-tabs-navigator';
// pages
import { HomeContainer } from '../../../screens/home';
import { SettingsContainer } from '../../../screens/settings';

import { HeaderLeft } from './components/header-left.component';

// routes
import { EnrollmentNavigationRoutes, HomeNavigationRoutes, LoginNavigationRoutes } from '../..';
import { HomeDrawerNavigator } from '../home/home-drawer-navigator';
import { Alert, Platform } from 'react-native';
import { MenuButton } from '../home/components/menu-button';
import CIAMLoginContainer from '../../../screens/ciam-login/container/ciam-login.container';
import { TermsAndConditionsContainer } from '../../../screens/terms-and-comditions';
import { HomeStackNavigator } from '../home-navigator';
import { useStores } from '../../../hooks/useStores';
import { observer } from 'mobx-react';
import DevScreen from '../../../screens/DevScreen';
import DevPasswordScreen from '../../../screens/DevPasswordScreen';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import { ENROLLED_KEY } from '../../../utilities/async-storage-keys';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { titleCase } from '@healthcareapp/connected-health-common-services/src/utilities/string';

const TermsStack = props => {
  const { generalStore, brandingStore } = useStores();
  return (
    <Stack.Navigator
      screenOptions={({ navigation, route }) => {
        return {
          safeAreaInsets: generalStore.insets,
          headerStyle: {
            backgroundColor: brandingStore.currentTheme.actionDark
          },
          headerTitleStyle: brandingStore.textStyles.styleLargeSemiBold,
          headerTintColor: '#fff',
          headerLeft: () => <HeaderLeft navigation={navigation} />
        };
      }}>
      <Stack.Screen
        name={LoginNavigationRoutes.TermsAndConditions}
        component={TermsAndConditionsContainer}
        // initialParams={{ token: props.route.params.token }}
        options={{ headerShown: true, title: 'Terms & Conditions' }}
      />
    </Stack.Navigator>
  );
};

const Stack = createStackNavigator();
const StackInternal = createStackNavigator();

export const LoginStackNavigator = observer(props => {
  const { generalStore, brandingStore, delegateStore, errorStore } = useStores();
  const { t } = useTranslation('translation');

  return (
    <Stack.Navigator>
      {generalStore.isAuthenticated ? (
        <Stack.Screen name={HomeNavigationRoutes.Home} component={HomeStackNavigator} options={{ headerShown: false }} />
      ) : (
        <>
          <Stack.Screen name={LoginNavigationRoutes.Login} component={CIAMLoginContainer} />
          <Stack.Screen name={LoginNavigationRoutes.TermsAndConditions} component={TermsStack} options={{ headerShown: false, title: 'Terms & Conditions' }} />
          {/*<Stack.Screen*/}
          {/*  name={EnrollmentNavigationRoutes.DevScreen}*/}
          {/*  component={DevScreen}*/}
          {/*  options={{*/}
          {/*    headerShown: true*/}
          {/*  }}*/}
          {/*/>*/}
          {/*<Stack.Screen*/}
          {/*  name={EnrollmentNavigationRoutes.DevPasswordScreen}*/}
          {/*  component={DevPasswordScreen}*/}
          {/*  options={{*/}
          {/*    headerShown: true*/}
          {/*  }}*/}
          {/*/>*/}
        </>
      )}
    </Stack.Navigator>
  );
});
