import { useEffect } from 'react';
import { AppConfigurationApi, IocContainer, IocTypes } from '@healthcareapp/connected-health-common-services';
import { HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';

export function useGetAppConfiguration(/*enable: boolean,*/ responseHandler, stores, onError, onFinally) {
  useEffect(() => {
    //  if (!enable) {
    //    return;
    //  }
    (async () => {
      if (!stores.appConfigStore.isLoadingEnvFile) {
        try {
          const response = await IocContainer.get<AppConfigurationApi>(IocTypes.AppConfigurationApi).getAppConfiguration({});
          if (!response) throw Error('');
          response && responseHandler(response);
        } catch (e) {
          onError();
        } finally {
          onFinally();
        }
      }
    })();
  }, [stores.appConfigStore.isLoadEnv /*, enable*/]);
}
