import { useSafeAreaInsets } from 'react-native-safe-area-context';

export const useSafeAreaInsents = () => {
  const { top, bottom, right, left } = useSafeAreaInsets();
  return { top, bottom, right, left };
};
