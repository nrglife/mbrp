// import {Dispatch, SetStateAction, useEffect, useLayoutEffect, useRef, useState} from "react";
// import appConfigurationAPI from "../services/http/appConfiguration/appConfiguration-api";
// import {getAppVersion, getVersionInfo} from "../utilities/AppVersion";
// import {Alert, Linking, Platform} from "react-native";
// import Config from "react-native-config";
// import {AppState} from 'react-native'
// import {useNavigation} from "@react-navigation/native";
// import AppToast from "../utilities/app-toast";
// import {navigationRef} from "../services/NavigationService";
//
//
// declare interface AppVersionDetails {
//     [version: string]: string
// }
//
// declare interface AppConfigurationHTTPResponse {
//     data: {
//         data: {
//             appVersions: {
//                 latestVersion: AppVersionDetails;
//                 AppVersionDetails
//             }
//         }
//     }
//
// }
//
//
// enum VERSION_STATUS {
//     DEPRECATED = 'deprecated',
//     ALLOWED = 'allowed'
// }
//
//
// function useAppCheckVersion(): { isLoading: boolean } {
//     const [isLoading, setIsLoading] = useState<boolean>(true)
//     const [isSkipped, setIsSkipped] = useState<boolean>(false)
//     //TODO
//     // const appStateRef = useRef<{ appState: "active" | "background" | "inactive" | "unknown" | "extension", setAppState: Dispatch<SetStateAction<"active" | "background" | "inactive" | "unknown" | "extension">> }>();
//
//     const [appState, setAppState] = useState<"active" | "background" | "inactive" | "unknown" | "extension">(AppState.currentState)
//     const skippedRef = useRef<{ isSkipped: boolean, setIsSkipped: (isSkipped: boolean) => void }>();
//     skippedRef.current = {isSkipped, setIsSkipped}
//     // appStateRef.current = {appState, setAppState}
//
//     async function onChangeAppStatusHandler(nextState: "active" | "background" | "inactive" | "unknown" | "extension", isFromApp?: RegExp) {
//
//         // const screenIndex = navigationRef.current && navigationRef.current.getRootState().index
//         // console.log(navigationRef.current && navigationRef.current.getRootState().routeNames[screenIndex])
//         // const isInitialScreen = screenIndex === null || screenIndex === 0
//
//         try {
//             if (appState.match(Platform.OS === "ios" ? isFromApp ? isFromApp : /unknown|active/ : /active/) && nextState === 'active' && !skippedRef.current.isSkipped) {
//                 const response: AppConfigurationHTTPResponse = await appConfigurationAPI.AppConfigurationHTTP.get('/appConfiguration')
//
//                 const appVersion = getAppVersion();
//                 const {appVersions} = response.data.data;
//                 const versionInfo = getVersionInfo(appVersion, appVersions);
//                 const latestInfo = getVersionInfo(appVersion, appVersions.latestVersion);
//                 // console.log(appVersion)
//                 // console.log(latestInfo)
//                 if (latestInfo || skippedRef.current.isSkipped) {
//                     setIsLoading(false)
//                     return
//                 }
//
//                 if (!versionInfo || versionInfo.status === VERSION_STATUS.ALLOWED) {
//                     Alert.alert(
//                         'Update available',
//                         'A newer version of Connected Health is available.',
//                         [
//                             {
//                                 text: 'Skip',
//                                 style: 'cancel',
//                                 onPress: () => {
//                                     setIsLoading(false)
//                                     skippedRef.current.setIsSkipped(true)
//                                 }
//                             },
//                             {
//                                 text: 'Update',
//                                 onPress: () => {
//                                     Linking.openURL(Config[`APP_UPDATE_LINK_${Platform.OS.toUpperCase()}`])
//                                     setIsLoading(false)
//                                 }
//                             }
//                         ],
//                         {cancelable: false}
//                     );
//                 } else if (versionInfo.status === VERSION_STATUS.DEPRECATED) {
//                     Alert.alert(
//                         'Update required',
//                         'A newer version of Connected Health is available.',
//                         [
//                             {
//                                 text: 'Update',
//                                 onPress: () => {
//                                     setIsLoading(false)
//                                     const updateLink = Config[`APP_UPDATE_LINK_${Platform.OS.toUpperCase()}`];
//                                     Linking.openURL(updateLink)
//                                 }
//                             }
//                         ],
//                         {cancelable: false}
//                     );
//                 }
//
//             }
//             setAppState(nextState)
//         } catch (e) {
//             // setTimeout(()=>{
//             //     AppToast.ShowToast(e.toString(), { onShow: () =>  setIsLoading(false) });
//             // },3000)
//             Alert.alert(
//                 'No internet',
//                 'Check your connection and try again.',
//                 [
//                     {
//                         text: 'Cancel',
//                         onPress: () => {
//                             setIsLoading(false)
//                         }
//                     },
//                     {
//                         text: 'Retry',
//                         onPress: () => {
//
//                         }
//                     }
//                 ],
//                 {cancelable: false}
//             );
//
//
//         }
//
//     }
//
//
//     useLayoutEffect(() => {
//
//         onChangeAppStatusHandler('active', /active/)
//
//         AppState.addEventListener('change', (state) => onChangeAppStatusHandler(state));
//         return () => {
//             AppState.removeEventListener('change', (state) => onChangeAppStatusHandler(state));
//         }
//     }, [])
//
//
//     return {isLoading}
// }
//
//
// export default useAppCheckVersion
