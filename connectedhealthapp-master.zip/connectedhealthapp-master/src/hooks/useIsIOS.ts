import { Platform } from 'react-native';

export const useIsIOS = () => Platform.OS === 'ios';
