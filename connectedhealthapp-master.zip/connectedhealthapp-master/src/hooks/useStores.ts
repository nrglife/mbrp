import { useContext } from 'react';
import { StoresContext, Stores } from '../stores';

export const useStores = () => useContext<Stores>(StoresContext);
