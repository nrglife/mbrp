import { EnrollmentNavigationRoutes, HomeNavigationRoutes, HomeNavigationRoutesMain, LinkedServicesRoute, MainNavigationRoutes } from '../routes';
import { ImageSourcePropType, Linking } from 'react-native';
import React, { ComponentType, useMemo } from 'react';
import images from '../assets/images/images';
import { EobListContainer } from '../screens/eobs/eob-list';
import { EobDetailsContainer } from '../screens/eobs/eob-details';
import { SettingsContainer } from '../screens/settings';
import { LinkedServicesMenuWrapper } from '../screens/linked-services/components/menuWrapper/linked-services.menuWrapper';
import { LinkedServicesContainer } from '../screens/linked-services';
import { LinkedServicesDetailsContainer } from '../screens/linked-services-details';
import { MoreContainer } from '../screens/more';
import { HelpContainer } from '../screens/help';
import { HelpContactUsContainer } from '../screens/help-contact-us/container/help-contact-us.container';
import { StackActions } from '@react-navigation/native';
import { CHMenuItemProps } from '../components';
import { navigationRef } from '../services/NavigationService';
import { HealthProfileContainer } from '../screens/health-profile';
import MedicationsContainer from '../screens/health-profile/medications/container/medications-container';
import MedicationsDetails from '../screens/health-profile/medication-details/container/medication-details-container';
import ProblemsAndConditionsContainer from '../screens/health-profile/problems-and-conditions/container/problems-and-conditions-container';
import AllergiesContainer from '../screens/health-profile/allergies/container/alergies-container';
import GoalsContainer from '../screens/health-profile/goals/container/goals-container';
import VisitsContainer from '../screens/health-profile/visits/container/visits-container';
import ProceduresContainer from '../screens/health-profile/procedures/container/procedures-container';
import MedicalImplantsContainer from '../screens/health-profile/medical-implants/container/medical-implants-container';
import { DelegateStore, DelegateStoreType, PayerStore } from '@healthcareapp/connected-health-common-services';
import { FeaturesMap, PayerStoreFeatures } from '@healthcareapp/connected-health-common-services/dist/stores/PayerStore';
import GeneralStore from '../stores/GeneralStore';
import AppConfigStore from '../stores/AppConfigStore';
import HealthTicketDetailsContainer from '../screens/health-profile/components/HealthTicketDetailsContainer/health-ticket-details-container';
import { LinkedService } from '@healthcareapp/connected-health-common-services/dist/stores/LinkedServiceStore';
import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import { P2pContainer } from '../screens/p2p/main';
import RequestContainer from '../screens/p2p/request/container/request.container';
import RecordContainer from '../screens/p2p/recored/container/record.container';
import PayerLoginContainer from '../screens/p2p/payer-login/container/payer-login.container';
import labObservationsContainer from '../screens/health-profile/labObservations/labObservationsContainer';
import { Request_Record } from '@healthcareapp/connected-health-common-services/dist/services/apis/payer-to-payer/payer-to-payer-api';
import VaccinationsContainer from '../screens/health-profile/vaccinations/vaccinations-container';
import ClinicalsOverviewContainer from '../screens/health-profile/clinicalsOverview/container/clinicals-overview-container';

export type ScreenType = {
  route: string;
  component: ComponentType;
  title: string;
};

export interface FeatureStackInterface {
  title: string;
  activeTabIcon: ImageSourcePropType;
  inactiveTabIcon: ImageSourcePropType;
  moreIcon: ImageSourcePropType;
  moreTitle: string;
  screens: ScreenList;
}

export interface TabScreen extends FeatureStackInterface {
  component: React.ComponentType;
  route: HomeNavigationRoutesMain;
}

declare interface PayerRoutesType {
  homeRoutes: HomeNavigationRoutesMain[];
  moreRoutes: HomeNavigationRoutesMain[];
  linkedServicesRoutes: HomeNavigationRoutesMain[];
}

type RouteToFeatureMap = {
  [key in HomeNavigationRoutesMain]: PayerStoreFeatures;
};

const routeToFeatureMap: RouteToFeatureMap = {
  [HomeNavigationRoutesMain.Eobs]: PayerStoreFeatures.EOBs,
  [HomeNavigationRoutesMain.LinkedServices]: PayerStoreFeatures.LinkedServices,
  [HomeNavigationRoutesMain.More]: PayerStoreFeatures.Other,
  [HomeNavigationRoutesMain.Settings]: PayerStoreFeatures.Profile,
  [HomeNavigationRoutesMain.Help]: PayerStoreFeatures.Help,
  [HomeNavigationRoutesMain.HealthProfile]: PayerStoreFeatures.HealthProfile,
  [HomeNavigationRoutesMain.LinkedServicesFind]: PayerStoreFeatures.LinkedServicesFind,
  [HomeNavigationRoutesMain.LinkedServicesRequests]: PayerStoreFeatures.LinkedServicesRequests
};

interface MoreLinkData {
  title: string;
  icon: ImageSourcePropType;
}

export type ScreenList = ScreenType[];

type RouteDictionary = {
  [key in HomeNavigationRoutesMain]: FeatureStackInterface;
};

interface MoreItemProps extends CHMenuItemProps {
  bottomDisplacement?: number;
}

export interface HealthTicketDetailsContainerParams extends DisplayableHealthProfileItem {
  iconSource?: ImageSourcePropType;
}

export interface InsuranceData {
  name: string;
  payerId: string;
  types: string;
  icon: string;
}

export interface RootStackParamList {
  [MainNavigationRoutes.EnrollmentPage]: undefined;
  [MainNavigationRoutes.LandingPage]: undefined;
  [HomeNavigationRoutesMain.HealthProfile]: undefined;
  [HomeNavigationRoutesMain.Settings]: undefined;
  [HomeNavigationRoutesMain.More]: undefined;
  [HomeNavigationRoutesMain.LinkedServices]: undefined;
  [HomeNavigationRoutesMain.Help]: undefined;
  [HomeNavigationRoutesMain.Eobs]: undefined;
  [HomeNavigationRoutes.Home]: undefined;
  [HomeNavigationRoutes.Settings]: undefined;
  [HomeNavigationRoutes.LinkedServices]: undefined;
  [HomeNavigationRoutes.LinkedServicesFind]: undefined;
  [HomeNavigationRoutes.LinkedServicesDetails]: { appData: LinkedService };
  [HomeNavigationRoutes.LinkedServicesManage]: undefined;
  [HomeNavigationRoutes.Eobs]: undefined;
  [HomeNavigationRoutes.EobDEtails]: undefined;
  [HomeNavigationRoutes.FindCare]: undefined;
  [HomeNavigationRoutes.Visits]: undefined;
  [HomeNavigationRoutes.Appointments]: undefined;
  [HomeNavigationRoutes.HealthProfile]: undefined;
  [HomeNavigationRoutes.Medications]: undefined;
  [HomeNavigationRoutes.MedicationsDetails]: undefined;
  [HomeNavigationRoutes.ProblemsAndConditionsContainer]: undefined;
  [HomeNavigationRoutes.AllergiesContainer]: undefined;
  [HomeNavigationRoutes.GoalsContainer]: undefined;
  [HomeNavigationRoutes.VisitsContainer]: undefined;
  [HomeNavigationRoutes.ProceduresContainer]: undefined;
  [HomeNavigationRoutes.MedicalImplantsContainer]: undefined;
  [HomeNavigationRoutes.PayerLoginContainer]: { authorize_uri: string; insuranceData: InsuranceData };
  [HomeNavigationRoutes.HealthTicketDetailsContainer]: { item: HealthTicketDetailsContainerParams };
  [HomeNavigationRoutes.More]: undefined;
  [HomeNavigationRoutes.Help]: undefined;
  [HomeNavigationRoutes.ContactUs]: undefined;
  [HomeNavigationRoutes.RecordContainer]: { recordData: Request_Record };
  // [HomeNavigationRoutes.RequestContainer]: { insuranceData: PayerLoginContainerInsuranceData };
  [HomeNavigationRoutes.RequestContainer]: { insuranceData: InsuranceData };
  [EnrollmentNavigationRoutes.InvitationCode]: undefined;
  [EnrollmentNavigationRoutes.ENrollmentSteps]: undefined;
  [EnrollmentNavigationRoutes.PersonalInfo]: undefined;
  [EnrollmentNavigationRoutes.Welcome]: undefined;
  [EnrollmentNavigationRoutes.ConfirmPhoneNumber]: undefined;
  [EnrollmentNavigationRoutes.ConfirmSms]: undefined;
  [EnrollmentNavigationRoutes.EmailVerification]: undefined;
  [EnrollmentNavigationRoutes.ConfirmEmail]: undefined;
  [EnrollmentNavigationRoutes.CreatePassword]: undefined;
  [EnrollmentNavigationRoutes.Locked]: undefined;
  [EnrollmentNavigationRoutes.Enrolled]: undefined;
  [EnrollmentNavigationRoutes.MissingInfo]: undefined;
  [EnrollmentNavigationRoutes.AlreadyEnrolled]: undefined;
  [EnrollmentNavigationRoutes.GeneralError]: undefined;
  [EnrollmentNavigationRoutes.Timeout]: undefined;
  [EnrollmentNavigationRoutes.EnrollmentComplete]: undefined;
  [EnrollmentNavigationRoutes.DevScreen]: undefined;
  [EnrollmentNavigationRoutes.DevPasswordScreen]: undefined;
  [EnrollmentNavigationRoutes.NoUserPhoneNumber]: undefined;
}

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}

const payerAppRoutes: PayerRoutesType = {
  homeRoutes: [HomeNavigationRoutesMain.Eobs, HomeNavigationRoutesMain.HealthProfile, HomeNavigationRoutesMain.Settings, HomeNavigationRoutesMain.More],
  moreRoutes: [HomeNavigationRoutesMain.LinkedServices, HomeNavigationRoutesMain.Help],
  linkedServicesRoutes: [HomeNavigationRoutesMain.LinkedServicesFind, HomeNavigationRoutesMain.LinkedServicesRequests]
};

const filter = (featuresMap: FeaturesMap, delegateStore: DelegateStore) => (route: HomeNavigationRoutesMain) => {
  if (!delegateStore.selectedDelegateIsMember && route == HomeNavigationRoutesMain.LinkedServices) {
    return false;
  }
  return featuresMap[routeToFeatureMap[route]];
};

export const useModularNavigation = (payerStore: PayerStore, generalStore: GeneralStore, appConfigStore: AppConfigStore, delegateStore: DelegateStoreType) => {
  const tabRouteDictionary: RouteDictionary = useMemo<RouteDictionary>(() => {
    const ret: RouteDictionary = {
      [HomeNavigationRoutesMain.Eobs]: {
        title: 'Benefits Summary',
        activeTabIcon: images.tab_bar_filled_find_eobs,
        inactiveTabIcon: images.tab_bar_outlined_find_eobs,
        moreIcon: images.tab_bar_outlined_find_eobs,
        moreTitle: 'Benefits Summary',
        screens: [
          { route: HomeNavigationRoutes.Eobs, component: EobListContainer, title: 'Benefits Summary' },
          {
            route: HomeNavigationRoutes.EobDEtails,
            component: EobDetailsContainer,
            title: 'Explanation of Benefits'
          }
        ]
      },
      [HomeNavigationRoutesMain.Settings]: {
        title: 'Profile & Settings',
        activeTabIcon: images.tab_bar_filled_profile,
        inactiveTabIcon: images.tab_bar_outlined_profile,
        moreIcon: images.settings,
        moreTitle: 'Profile & Settings',
        screens: [
          {
            route: HomeNavigationRoutes.Settings,
            component: SettingsContainer,
            title: 'Profile & Settings'
          }
        ]
      },
      [HomeNavigationRoutesMain.LinkedServicesFind]: {
        title: 'Find Connected Apps',
        activeTabIcon: images.tab_bar_filled_profile,
        inactiveTabIcon: images.tab_bar_outlined_profile,
        moreIcon: images.settings,
        moreTitle: 'Find Connected Apps',
        screens: [
          {
            route: HomeNavigationRoutes.LinkedServicesFind,
            component: LinkedServicesContainer,
            title: 'Connected Apps'
          }
        ]
      },

      [HomeNavigationRoutesMain.LinkedServicesRequests]: {
        title: 'Request & Send Health Records',
        activeTabIcon: images.tab_bar_filled_profile,
        inactiveTabIcon: images.tab_bar_outlined_profile,
        moreIcon: images.settings,
        moreTitle: 'Request & Send Health Records',
        screens: [
          {
            route: HomeNavigationRoutes.LinkedServicesRequests,
            component: P2pContainer,
            title: 'LinkedServicesRequests'
          }
        ]
      },

      [HomeNavigationRoutesMain.HealthProfile]: {
        title: 'Health Profile',
        activeTabIcon: images.health_profile_tab_icon_black,
        inactiveTabIcon: images.health_profile_tab_icon_white,
        moreIcon: images.health_profile_tab_icon_white,
        moreTitle: 'Health Profile',
        screens: [
          {
            route: HomeNavigationRoutes.HealthProfile,
            component: HealthProfileContainer,
            title: 'Health Profile'
          },
          {
            route: HomeNavigationRoutes.Medications,
            component: MedicationsContainer,
            title: 'Medications'
          },
          {
            route: HomeNavigationRoutes.MedicationsDetails,
            component: MedicationsDetails,
            title: 'MedicationsDetails'
          },
          {
            route: HomeNavigationRoutes.ProblemsAndConditionsContainer,
            component: ProblemsAndConditionsContainer,
            title: 'ProblemsAndConditionsContainer'
          },
          {
            route: HomeNavigationRoutes.AllergiesContainer,
            component: AllergiesContainer,
            title: 'AllergiesContainer'
          },
          {
            route: HomeNavigationRoutes.GoalsContainer,
            component: GoalsContainer,
            title: 'GoalsContainer'
          },
          {
            route: HomeNavigationRoutes.VisitsContainer,
            component: VisitsContainer,
            title: 'VisitsContainer'
          },
          {
            route: HomeNavigationRoutes.ProceduresContainer,
            component: ProceduresContainer,
            title: 'ProceduresContainer'
          },
          {
            route: HomeNavigationRoutes.labObservationsContainer,
            component: labObservationsContainer,
            title: 'labObservationsContainer'
          },
          {
            route: HomeNavigationRoutes.MedicalImplantsContainer,
            component: MedicalImplantsContainer,
            title: 'MedicalImplantsContainer'
          },
          {
            route: HomeNavigationRoutes.HealthTicketDetailsContainer,
            component: HealthTicketDetailsContainer,
            title: 'HealthTicketDetailsContainer'
          },
          {
            route: HomeNavigationRoutes.VaccinationsContainer,
            component: VaccinationsContainer,
            title: 'VaccinationsContainer'
          },
          {
            route: HomeNavigationRoutes.ClinicalsOverviewContainer,
            component: ClinicalsOverviewContainer,
            title: 'Overview'
          }
        ]
      },
      [HomeNavigationRoutesMain.LinkedServices]: {
        title: 'Linked Services',
        activeTabIcon: images.linkedServices,
        inactiveTabIcon: images.link,
        moreIcon: images.linkedServices,
        moreTitle: 'Linked Services',
        screens: [
          {
            route: HomeNavigationRoutes.LinkedServices,
            component: LinkedServicesMenuWrapper,
            title: 'Linked Services'
          },

          {
            route: HomeNavigationRoutes.LinkedServicesDetails,
            component: LinkedServicesDetailsContainer,
            title: 'Service Details'
          },

          {
            route: HomeNavigationRoutes.RequestContainer,
            component: RequestContainer,
            title: 'RequestContainer'
          },
          {
            route: HomeNavigationRoutes.RecordContainer,
            component: RecordContainer,
            title: 'RecordContainer'
          }
          // {
          //   route: HomeNavigationRoutes.PayerLoginContainer,
          //   component: PayerLoginContainer,
          //   title: 'PayerLoginContainer'
          // }
        ]
      },
      [HomeNavigationRoutesMain.More]: {
        title: 'More',
        activeTabIcon: images.tab_bar_filled_more,
        inactiveTabIcon: images.tab_bar_outlined_more,
        moreIcon: images.tab_bar_outlined_find_eobs,
        moreTitle: 'rrrrrr',
        screens: [{ route: HomeNavigationRoutes.More, component: MoreContainer, title: 'More' }]
      },
      [HomeNavigationRoutesMain.Help]: {
        title: 'Help',
        activeTabIcon: images.tab_bar_filled_more,
        inactiveTabIcon: images.tab_bar_outlined_more,
        moreIcon: images.help,
        moreTitle: 'Help',
        screens: [
          { route: HomeNavigationRoutes.Help, component: HelpContainer, title: 'Help' },
          { route: HomeNavigationRoutes.ContactUs, component: HelpContactUsContainer, title: 'Contact Us' }
        ]
      }
    };

    Object.values(HomeNavigationRoutesMain).forEach(route => {
      if (route != HomeNavigationRoutesMain.More) {
        ret[HomeNavigationRoutesMain.More].screens = [...ret[HomeNavigationRoutesMain.More].screens, ...ret[route].screens];
      }
    });
    return ret;
  }, []);

  const payerRoutes = useMemo<PayerRoutesType>(() => {
    return {
      homeRoutes: payerAppRoutes.homeRoutes.filter(filter(payerStore.featuresMap, delegateStore)),
      moreRoutes: payerAppRoutes.moreRoutes.filter(filter(payerStore.featuresMap, delegateStore)),
      linkedServicesRoutes: payerAppRoutes.linkedServicesRoutes.filter(filter(payerStore.featuresMap, delegateStore))
    };
  }, [payerStore.featuresMap, delegateStore]);

  const moreRoutes = useMemo(() => {
    const moreDefaultLinks: MoreItemProps[] = [
      {
        label: 'Privacy Policy',
        onPress: () => {
          Linking.openURL(appConfigStore.appConfig.PRIVACY_POLICY_LINK);
        },
        logo: images.privacy_policy,
        chevron: true,
        bottomDisplacement: 1
      },

      {
        label: 'Sign out',
        onPress: () => {
          generalStore.logout();
        },
        logo: images.sign_out,
        chevron: false
      }
    ];
    const moreRoute = payerRoutes.moreRoutes.map(route => {
      return {
        label: tabRouteDictionary[route].moreTitle,
        onPress: () => {
          navigationRef.current.dispatch(StackActions.push(tabRouteDictionary[route].screens[0].route));
        },
        logo: tabRouteDictionary[route].moreIcon,
        chevron: true
      };
    });

    moreDefaultLinks.forEach(link => {
      if (link.bottomDisplacement) {
        moreRoute.splice(moreRoute.length - link.bottomDisplacement, 0, link);
      } else {
        moreRoute.push(link);
      }
    });

    return moreRoute;
  }, [appConfigStore, generalStore, payerRoutes, tabRouteDictionary]);

  const linkedServices = useMemo(() => {
    return payerRoutes.linkedServicesRoutes.map(route => {
      return {
        label: tabRouteDictionary[route].moreTitle,
        onPress: () => {
          navigationRef.current.dispatch(StackActions.push(tabRouteDictionary[route].screens[0].route));
        },
        logo: tabRouteDictionary[route].moreIcon,
        chevron: true
      };
    });
  }, [appConfigStore, generalStore, payerRoutes, tabRouteDictionary]);

  const getPayerRoutes = () => {
    return payerRoutes;
  };

  const getMoreRoutes = () => {
    return moreRoutes;
  };

  const getLinkedServicesRoutes = () => {
    return linkedServices;
  };

  const getTabRouteDictionary = () => {
    return tabRouteDictionary;
  };

  return { getPayerRoutes, getMoreRoutes, getTabRouteDictionary, getLinkedServicesRoutes };
};
