/*import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Alert } from 'react-native';

export enum ConnectionState {
  PENDING = 'pending',
  UP = 'up',
  DOWN = 'down'
}

export const useNetworkReachability = () => {
  const { t } = useTranslation('translation');
  const timeoutRef = useRef<NodeJS.Timeout>(null);
  const [connected, setConnected] = useState<ConnectionState>(ConnectionState.PENDING);

  const checkConnection = async () => {
    const fetchWithTimeout = (url, options) =>
      new Promise((resolve, reject) => {
        const timeoutId = setTimeout(reject, 3000);
        fetch(url, options)
          .then(res => {
            resolve(res);
          })
          .catch(err => {
            reject(err);
          })
          .finally(() => {
            clearTimeout(timeoutId);
          });
      });

    try {
      const res = await fetchWithTimeout('https://clients3.google.com/generate_204', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json'
        },
        timeout: 1000
      });
      // console.log('ressssss', res);
      if (res.status === 204) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      // console.log('fetch errrr', err);
      return false;
    }
  };

  const startListening = async () => {
    const newState = await checkConnection();
    // console.log('new state', newState);
    setConnected(newState ? ConnectionState.UP : ConnectionState.DOWN);
    timeoutRef.current = setTimeout(startListening, 3000);
  };

  const stopListening = () => {
    clearTimeout(timeoutRef.current);
  };

  useEffect(() => {
    //console.log('state11111', connected);
    if (connected === ConnectionState.UP) {
    } else if (connected === ConnectionState.DOWN) {
      stopListening();

      Alert.alert(t(LocaleKeys.errors.no_internet), t(LocaleKeys.errors.check_your_connection_and_try_again), [
        {
          text: 'Retry',
          style: 'cancel',
          onPress: () => {
            setConnected(ConnectionState.PENDING);

            startListening();
          }
        }
      ]);
    }
  }, [connected]);

  useEffect(() => {
    startListening();
    return () => {
      stopListening();
    };
  }, []);
  return connected;
};
*/
