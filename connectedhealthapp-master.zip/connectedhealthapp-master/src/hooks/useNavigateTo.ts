import { useNavigation } from '@react-navigation/native';
import { EnrollmentNavigationRoutes, HomeNavigationRoutes, MainNavigationRoutes } from '../routes';

export const useNavigateTo = (navigateTo: HomeNavigationRoutes | EnrollmentNavigationRoutes | MainNavigationRoutes, params?: any) => {
  const navigation = useNavigation();

  const navigate = () => navigation.navigate(navigateTo, params);

  return { navigate };
};
