import { useStores } from './useStores';
import { useNavigation } from '@react-navigation/native';
import { useLayoutEffect } from 'react';
import { Platform } from 'react-native';

export interface HeaderStyle {
  headerTintColor: { android: string; ios: string };
  titleColor: { android: string; ios: string };
  backColor: { android: string; ios: string };
}

const useNavigationHeaderStyle = (headerTitle: string, headerTruncatedBackTitle, width, style?: HeaderStyle, headerRight?: Element, dependency?: any[], headerBackTitle?: string) => {
  const { brandingStore } = useStores();
  const navigation = useNavigation();
  useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: headerBackTitle ?? '',
      headerTintColor: Platform.OS == 'android' ? brandingStore.currentTheme.white : brandingStore.currentTheme.actionMedium, // YAY! Proper format!
      headerTitleStyle: { color: Platform.OS == 'android' ? brandingStore.currentTheme.white : 'black', ...brandingStore.textStyles.styleLargeSemiBold },
      headerBackTitleStyle: {
        color: Platform.OS == 'android' ? 'white' : brandingStore.currentTheme.actionMedium,
        width
      },
      headerTitle,
      headerRight: () => headerRight,

      headerTruncatedBackTitle
    });
  }, [navigation, brandingStore.currentTheme, brandingStore.textStyles, ...(dependency ?? [])]);
};

export default useNavigationHeaderStyle;
