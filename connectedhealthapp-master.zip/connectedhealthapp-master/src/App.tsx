/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * Generated with the TypeScript template
 * https://github.com/react-native-community/react-native-template-typescript
 *
 * ccc
 *
 * @format
 */

import 'react-native-get-random-values';
import '../src/utilities/helpers/FixTimerBug';
import './utilities/helpers/fixFonts';
import React, { useCallback, useEffect, useLayoutEffect, useState } from 'react';
import { Alert, AppState, Dimensions, KeyboardAvoidingView, LogBox, NativeModules, Platform, StatusBar, View } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { RootSiblingParent } from 'react-native-root-siblings';

import createStores, { StoresContext } from './stores';

const stores = createStores();
// navigators
import { EnrollmentStackNavigator } from './routes/navigators';
import { EdgeInsets, SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LoginStackNavigator } from './routes/navigators/login/login-navigator';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { observer } from 'mobx-react';
import SplashScreen from 'react-native-splash-screen';
import { navigationRef } from './services/NavigationService';
import UserInactivity from 'react-native-user-inactivity';
import { useGetAppConfiguration } from './hooks/useAppChangeState';
import { KeyboardHandlingMode } from './utilities/constants';
import { ENROLLED_KEY } from './utilities/async-storage-keys';
import Config from 'react-native-config';
import { CHBottomSheet, ContactModal } from './components';
import { ScrollView } from 'react-native-gesture-handler';
import { HTTP_STATUS_CODES } from './screens/enrollment/utils';
import { IocContainer, WhoAmIApi } from '@healthcareapp/connected-health-common-services';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { IocTypesMobile } from './iocTypes';
import AppModal from './components/AppModal';
import { _handleAppStateChange, checkAppVersion, launchEntryMessage, showEntryMessage } from './utilities/appConfiguration';
//TODO: oreng: check if it's necessary
import '../i18n';
import Loader from './components/Loader';
import { getAppVersion } from './utilities/AppVersion';
import { useTranslation } from 'react-i18next';
import { useRef } from 'react';
import { toJS } from 'mobx';
//import { useNetworkReachability, ConnectionState } from './hooks/useNetworkReachability';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { titleCase } from '@healthcareapp/connected-health-common-services/src/utilities/string';

declare const global: { HermesInternal: null | {} };

if (Config.DISABLE_LOG_BOX === 'true') {
  LogBox.ignoreAllLogs(); //Ignore all log notifications
  // @ts-ignore
  console.reportErrorsAsExceptions = false; // wont display console.error() as red screen
}

const MainComp = observer(({ setIsModalIsVisible, isModalIsVisible }) => {
  // const stores = useStores();
  const { t } = useTranslation('translation');
  // const [networkAvailableFirst, setNetworkAvailableFirst] = useState<boolean>(false);
  //const [networkAvailable, setNetworkAvailable] = useState<boolean>(true);

  useLayoutEffect(() => {
    SplashScreen.hide();
  }, []);

  useEffect(() => {
    if (
      (!stores.generalStore.connectivityAlert && stores.delegateStore.state == DelegateStoreState.RunningShowError) ||
      stores.delegateStore.state == DelegateStoreState.Error ||
      stores.delegateStore.state == DelegateStoreState.InitError
    ) {
      Alert.alert(
        t(LocaleKeys.errors.something_went_wrong),
        t(LocaleKeys.errors.unable_to_get_account_information) +
          (stores.errorStore.getLastFilteredError()
            ? '\n(Code: ' + stores.errorStore.getLastFilteredError().source.toLocaleLowerCase() + '-' + stores.errorStore.getLastFilteredError().code + ')'
            : ''),
        [
          {
            text: 'Cancel',

            onPress: async () => {
              stores.delegateStore.clearError();
              if (stores.delegateStore.state == DelegateStoreState.Error || stores.delegateStore.state == DelegateStoreState.InitError) {
                const enrolled: boolean = (await AsyncStorage.getItem(ENROLLED_KEY)) === 'true';
                stores.generalStore.setEnrollmentComplete(enrolled);
                stores.generalStore.logout();
              }
            }
          },
          {
            text: titleCase(t(LocaleKeys.errors.try_again_button)),
            style: 'cancel',
            onPress: () => {
              if (stores.delegateStore.state == DelegateStoreState.InitError) {
                stores.delegateStore.init();
              } else {
                stores.delegateStore.retrySelectMember();
              }
            }
          }
        ]
      );
    }
  }, [stores.delegateStore.state]);
  //hide the native splash

  //const connectionStatus = useNetworkReachability();

  /*useEffect(() => {
    if (connectionStatus === ConnectionState.UP) {
      setNetworkAvailableFirst(true);
    }
  }, [connectionStatus]);*/

  useGetAppConfiguration(
    // networkAvailableFirst,
    response => {
      const appVersion = getAppVersion();
      stores.generalStore.setAppVersion(appVersion);
      stores.generalStore.setDisableDisplayErrorCodes(response.data.data.disableDisplayErrorCodes);
      stores.generalStore.setAppConfigResponse(response);
      stores.generalStore.setAppSupportDetails(stores.generalStore.appConfigResponse.appSupportDetails);
      stores.generalStore.setSmileCDRRevokeURL(stores.generalStore.appConfigResponse.smileCDRRevokeURL);
      //TODO REMOVE AND TAKE PHONES FROM generalStore.setAppConfigResponse
      stores.generalStore.setPayerPhoneNumbers(response.data.data.appSupportDetails.appSupportPhoneNumbers);
      stores.generalStore.setAppSupportVisible(response.data.data.appSupportVisible);
      stores.generalStore.setInsuranceSupportVisible(response.data.data.insuranceSupportVisible);
      if (showEntryMessage(response)) {
        launchEntryMessage(setIsModalIsVisible);
      } else {
        checkAppVersion(stores);
      }
    },
    stores,
    () => {},
    () => {
      setIsSplash(true);
      setIsStatusBarHidden(false);
    }
  );

  const [sheetHeight, setSheetHeight] = useState<number>(100);
  const [isStatusBarHidden, setIsStatusBarHidden] = useState<boolean>(true);

  const [isSplash, setIsSplash] = useState(false);
  const insets = useSafeAreaInsets();
  const insetsRef = useRef<EdgeInsets>(insets);
  insetsRef.current = insets;

  useEffect(() => {
    if (!stores.generalStore.insets || insetsRef.current.bottom || insetsRef.current.top) {
      stores.generalStore.insets = insetsRef.current;
    }
  }, [insetsRef.current.top, insetsRef.current.bottom]);
  //const { bottom, top } = useSafeAreaInsets();
  const onMeasureHeight = useCallback((h: number) => {
    setSheetHeight(h + insetsRef.current.bottom);
  }, []);

  const screenHeight = Dimensions.get('window').height - (insetsRef.current.top ? insetsRef.current.top : StatusBar.currentHeight);

  return isSplash ? (
    <View style={{ width: '100%', height: '100%' }}>
      {/*connectionStatus == ConnectionState.PENDING && <Loader isLoading={true} />*/}
      <NavigationContainer ref={navigationRef}>{stores.generalStore.isEnrollmentComplete ? <LoginStackNavigator /> : <EnrollmentStackNavigator />}</NavigationContainer>
      <StatusBar hidden={isStatusBarHidden} barStyle="dark-content" backgroundColor="white" />

      {stores.generalStore.appConfigResponse && stores.generalStore.appConfigResponse.appMessage && (
        <AppModal
          onCancel={() => {
            checkAppVersion(stores);
            setIsModalIsVisible(false);
          }}
          isVisible={isModalIsVisible}
          coverScreen={true}
        />
      )}

      <CHBottomSheet
        key={'modal_sheet'}
        onMeasureHeight={onMeasureHeight}
        backgroundInteractions={false}
        snapPoints={[sheetHeight > screenHeight ? screenHeight : sheetHeight, 0]}
        label={t(LocaleKeys.errors.contact_us)}
        ref={stores.generalStore?.contactUsSheetRef}>
        <ScrollView>
          <ContactModal />
        </ScrollView>
      </CHBottomSheet>
    </View>
  ) : (
    <Loader isLoading={true} />
  );
});

export const App = observer(() => {
  const [isModalIsVisible, setIsModalIsVisible] = useState<boolean>(false);

  const _onAction = (isActive: boolean) => {
    if (!isActive) {
      stores.generalStore.logout();
    } else if (isActive) {
    }
  };

  useEffect(() => {
    const subscription = AppState.addEventListener('change', handleStateChange);
    (async () => {
      const enrolled: boolean = (await AsyncStorage.getItem(ENROLLED_KEY)) === 'true';
      stores.generalStore.setEnrollmentComplete(enrolled);
      stores.generalStore.logout();
      stores.appConfigStore.loadDeveloperSettings().then(() => {});
    })();

    return () => {
      subscription.remove();
    };
  }, []);

  useEffect(() => {
    (async () => {
      if (stores.generalStore.isAuthenticated) {
        try {
          await stores.whoAmIStore.loadBasicInfo();
        } catch (error) {
          if (error.response) {
          }
        }

        try {
          await stores.whoAmIStore.loadPayerInfo();
        } catch (error) {
          if (error.response) {
          }
        }

        stores.delegateStore.clearStoredDelegateIndex();
        await stores.delegateStore.init();
      }
    })();
  }, [stores.generalStore.isAuthenticated]);

  if (KeyboardHandlingMode) {
    return (
      <UserInactivity
        onAction={_onAction}
        timeForInactivity={stores.appConfigStore.appConfig.APP_USER_INACTIVITY_GENERAL_TIMEOUT ? parseInt(stores.appConfigStore.appConfig.APP_USER_INACTIVITY_GENERAL_TIMEOUT) : 1000}>
        <RootSiblingParent>
          {Platform.OS == 'ios' ? (
            <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
              <StoresContext.Provider value={stores}>
                <SafeAreaProvider>
                  <MainComp setIsModalIsVisible={setIsModalIsVisible} isModalIsVisible={isModalIsVisible} />
                </SafeAreaProvider>
              </StoresContext.Provider>
            </KeyboardAvoidingView>
          ) : (
            <StoresContext.Provider value={stores}>
              <SafeAreaProvider>
                <MainComp setIsModalIsVisible={setIsModalIsVisible} isModalIsVisible={isModalIsVisible} />
              </SafeAreaProvider>
            </StoresContext.Provider>
          )}
        </RootSiblingParent>
      </UserInactivity>
    );
  } else {
    return (
      <UserInactivity onAction={_onAction} timeForInactivity={Config.APP_USER_INACTIVITY_GENERAL_TIMEOUT ? parseInt(Config.APP_USER_INACTIVITY_GENERAL_TIMEOUT) : 1000}>
        <RootSiblingParent>
          {/*<StatusBar hidden={isStatusBarHidden} barStyle="dark-content" backgroundColor="white" />*/}
          <SafeAreaProvider>
            <MainComp setIsModalIsVisible={setIsModalIsVisible} isModalIsVisible={isModalIsVisible} />
          </SafeAreaProvider>
        </RootSiblingParent>
      </UserInactivity>
    );
  }
});

const handleStateChange = state => {
  _handleAppStateChange(state, stores);
};
