import 'reflect-metadata';
import { StorageServiceType } from './services';
import {
  //  IHttpService,
  IocTypes,
  IStorageService,
  ITimeoutService,
  EnrollmentStore as EnrollmentStoreType,
  TimeoutServiceType,
  EOBListStoreType,
  MedicationRequestStoreType,
  ConditionsStoreType,
  AllergiesStoreType,
  GoalsStoreType,
  EncountersStoreType,
  ImplantableDeviceStoreType,
  PayerDocumentsStoreType,
  ImageStoreType,
  PayerStoreType,
  DelegateStoreType,
  ProceduresStoreType,
  ImmunizationsStoreType,
  ClinicalsOverviewStoreType
} from '@healthcareapp/connected-health-common-services';
import BrandingStoreMobile from './stores/BrandingStoreMobile';
import EnrollmentStoreMobile from './stores/EnrollmentStoreMobile';
import AppConfigStore from './stores/AppConfigStore';
import GeneralStore, { GeneralStoreType } from './stores/GeneralStore';
import { IocTypesMobile, IocContainer } from './iocTypes';
import { ApiConfigsProvider, AuthProvider, ConsentDateProvider, ErrorStoreConfigProvider } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-config';
import { ApiError, BaseResponse, HTTP_STATUS_CODES } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-api';
import { EnrollmentNavigationRoutes } from './routes';
import { Alert, Platform } from 'react-native';
import i18n from '../i18n';
import { I18nCommonType, LocaleKeys } from '@healthcareapp/connected-health-common-services';

export const fixLocalUrl = (url: string) => {
  return Platform.OS === 'android' ? url.replace('localhost', '10.0.2.2') : url;
};

// Services
IocContainer.bind<IStorageService>(IocTypesMobile.StorageService).to(StorageServiceType);
IocContainer.bind<ITimeoutService>(IocTypesMobile.ITimeoutService).to(TimeoutServiceType);
//IocContainer.bind<DataServicesHCAApi>(IocTypesMobile.DataServicesHCAApi).to(DataServicesHCAApi);
IocContainer.bind<ApiConfigsProvider>(IocTypesMobile.ApiConfigsProvider).toConstantValue(() => {
  return {
    commonHeaders: {},
    connectionCheck: null /* {
      url: 'https://clients3.google.com/generate_204',
      status: 204,
      timeout: 1000,
      retries: 3,
      callback: () => {
        IocContainer.get<GeneralStoreType>(IocTypesMobile.GeneralStore).setConnectivityAlert(true);
        Alert.alert(i18n.t(LocaleKeys.errors.something_went_wrong), i18n.t(LocaleKeys.errors.please_make_sure_you_are_connected), [
          {
            text: 'OK',
            onPress: () => {
              IocContainer.get<GeneralStoreType>(IocTypesMobile.GeneralStore).setConnectivityAlert(false);
            }
          }
        ]);
      }
    }*/,

    eobsApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_explanationOfBenefitApiUrl),
      headers: {},
      maxEobs: Number(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_MAX_EOBS_PER_REQUEST)
    },
    consentApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.API_BASE_URL),
      headers: {},
      REACT_APP_ID_CONSENT: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.APP_ID_CONSENT
    },

    appConfigurationApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.API_BASE_URL),
      headers: {},
      apikey: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.CIAM_CLIENT_ID
    },
    appLocalesApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.API_BASE_URL),
      headers: {},
      apikey: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.CIAM_CLIENT_ID
    },
    whoAmIapi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_whoAmIBaseUrl),
      headers: {}
    },
    linkedServicesApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_linkedServicesBaseUrl),
      headers: {}
    },
    clinicalApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_clinicalsApiUrl),
      headers: {},
      maxItems: Number(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_MAX_CLINICAL_ITEMS_PER_REQUEST)
    },

    payerToPayerApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.API_BASE_URL),
      headers: {},
      maxItems: Number(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_MAX_CLINICAL_ITEMS_PER_REQUEST)
    },
    enrollmentApi: {
      apikey: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.CIAM_CLIENT_ID,
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.API_BASE_URL),
      precallHandler: null,
      successHandler: null,
      headers: {},
      errorHandler: (err: ApiError, errorHandlerParam: any) => {
        console.log('new res status', err);
        const navigate = errorHandlerParam;
        if (err.statusCode === HTTP_STATUS_CODES.TIME_OUT) {
          return { status: err.statusCode, data: err.responseData };
        }

        console.log(err.responseData);
        const { meta = {} } = err.responseData || {};
        const { remoteRequest = {} } = meta || {};
        const { status = HTTP_STATUS_CODES.NOT_FOUND } = remoteRequest || {};
        const { meta: innerMeta = {} } = remoteRequest || {};
        const { attemptCount = 0, attemptMax = 0 } = innerMeta || {};

        const newResponse: BaseResponse = {
          data: { data: innerMeta },
          status: remoteRequest.status
        };

        switch (newResponse.status) {
          // if  INVALID_LOCKED navigate to LOCK screen.
          case HTTP_STATUS_CODES.INVALID_LOCKED:
            navigate(EnrollmentNavigationRoutes.Locked);
            return newResponse;
          // errors handled in UI
          case HTTP_STATUS_CODES.MISSING_INFO:
            navigate(EnrollmentNavigationRoutes.MissingInfo);
            return newResponse;
          case HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED:
            navigate(EnrollmentNavigationRoutes.AlreadyEnrolled);
            return newResponse;

          case HTTP_STATUS_CODES.UNAUTHORIZED:
          case HTTP_STATUS_CODES.CONFLICT:
          case HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS:
          case HTTP_STATUS_CODES.SERVER_ERROR:
            navigate(EnrollmentNavigationRoutes.GeneralError);
            return newResponse;
          default:
            return newResponse;
        }
        throw err;
      }
    },
    dataServicesApi: {
      errorHandler: null,
      precallHandler: null,
      successHandler: null,
      XCHCClientId: IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_dataServicesHCAXChcClientID,
      headers: {},
      baseUrl: fixLocalUrl(IocContainer.get<AppConfigStore>(IocTypesMobile.AppConfigStore).appConfig.REACT_APP_dataServicesHCABaseUrl)
    }
  };
});
IocContainer.bind<AuthProvider>(IocTypesMobile.AuthProvider).toConstantValue(() => {
  return IocContainer.get<GeneralStore>(IocTypesMobile.GeneralStore).tokenDetails?.access_token;
});

IocContainer.bind<ConsentDateProvider>(IocTypesMobile.ConsentDateProvider).toConstantValue(() => {
  return IocContainer.get<GeneralStore>(IocTypesMobile.GeneralStore).consentDate;
});

IocContainer.bind<I18nCommonType>(IocTypes.I18nProvider).toConstantValue(i18n);

IocContainer.bind<ErrorStoreConfigProvider>(IocTypesMobile.ErrorStoreConfigProvider).toConstantValue(() => {
  return {
    disableLogging: IocContainer.get<GeneralStore>(IocTypesMobile.GeneralStore).disableDisplayErrorCodes
  };
});

// Stores
IocContainer.bind<BrandingStoreMobile>(IocTypesMobile.ThemeStore).to(BrandingStoreMobile).inSingletonScope();
IocContainer.bind<EnrollmentStoreMobile>(IocTypesMobile.EnrollmentStore).to(EnrollmentStoreMobile).inSingletonScope();
IocContainer.bind<AppConfigStore>(IocTypesMobile.AppConfigStore).to(AppConfigStore).inSingletonScope();
IocContainer.bind<GeneralStoreType>(IocTypesMobile.GeneralStore).to(GeneralStoreType).inSingletonScope();

export type { IStorageService, ITimeoutService };
export { EnrollmentStoreType };
export { EOBListStoreType };
export { MedicationRequestStoreType };
export { ConditionsStoreType };
export { AllergiesStoreType };
export { GoalsStoreType };
export { EncountersStoreType };
export { ImplantableDeviceStoreType };
export { ImmunizationsStoreType };
export { DelegateStoreType, PayerStoreType, PayerDocumentsStoreType, ImageStoreType, ProceduresStoreType, ClinicalsOverviewStoreType };
export { IocTypesMobile, IocContainer };
