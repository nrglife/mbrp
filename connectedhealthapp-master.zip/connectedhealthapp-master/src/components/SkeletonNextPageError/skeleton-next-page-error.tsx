import React, { FC } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

import { useStores } from '../../hooks/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

const SkeletonNextPageError: React.FC<{
  loadNextPage: () => void;
  loadingNextPage: boolean;
}> = ({ loadNextPage, loadingNextPage }) => {
  const { brandingStore } = useStores();
  const { t } = useTranslation('translation');
  return (
    <View style={{ marginTop: 12, marginBottom: 12, marginLeft: 21, flexDirection: 'row' }}>
      <Text style={[{ color: brandingStore.currentTheme.tooltip, paddingBottom: 0 }, brandingStore.textStyles.styleSmallRegular]}>{t(LocaleKeys.errors.something_went_wrong) + '. '}</Text>
      <TouchableOpacity
        style={{ paddingBottom: 0 }}
        onPress={() => {
          if (!loadingNextPage) {
            loadNextPage();
          }
        }}>
        <Text style={[{ color: brandingStore.currentTheme.actionMedium }, brandingStore.textStyles.styleSmallSemiBold]}>Try again</Text>
      </TouchableOpacity>
    </View>
  );
};

export default SkeletonNextPageError;
