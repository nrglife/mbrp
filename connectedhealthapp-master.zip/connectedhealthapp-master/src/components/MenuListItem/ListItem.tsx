import { HomeNavigationRoutes } from '../../routes';
import React, { FC } from 'react';
import { useNavigation } from '@react-navigation/native';
import { CHMenuItem } from '..';

export interface ListItemRoute {
  route: HomeNavigationRoutes;
  title: string;
}

export interface ListItemProps {
  item: ListItemRoute;
  index: number;
  textColor: string;
}

const ListItem: FC<ListItemProps> = ({ item, index, textColor }) => {
  const navigation = useNavigation();

  return <CHMenuItem textColor={textColor} label={item.title} onPress={() => navigation.navigate(item.route)} logo={null} chevron={true} />;
};

export default ListItem;
