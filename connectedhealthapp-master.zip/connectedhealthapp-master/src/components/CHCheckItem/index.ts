import { Platform } from 'react-native';
import CHCheckItemAndroid from './ch-check-item-android';
import CHCheckItemIOS from './ch-check-item-ios';

const CHCheckItem = Platform.OS === 'android' ? CHCheckItemAndroid : CHCheckItemIOS;

export default CHCheckItem;
