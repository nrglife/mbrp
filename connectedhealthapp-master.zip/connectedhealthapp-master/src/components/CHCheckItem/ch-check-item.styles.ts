import { StyleSheet, Platform, TextStyle, ViewStyle } from 'react-native';

import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const containerStyleAndroid: ViewStyle = {
    flexDirection: 'row',
    paddingTop: 20,
    paddingBottom: 20,
    alignItems: 'center',
    justifyContent: 'flex-start',
    borderBottomColor: 'grey',
    borderBottomWidth: 1,
    marginLeft: 20,
    marginRight: 20
  };

  const containerStyleIOS: ViewStyle = {
    width: '100%',
    borderStyle: 'solid',
    backgroundColor: store.currentTheme.white,
    borderBottomWidth: 0,
    borderColor: store.currentTheme.separatorOpaque,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 9,
    paddingHorizontal: 25
  };

  const errorStyleIOS: TextStyle = {
    marginRight: 0,
    marginLeft: 0,
    marginTop: 0,
    paddingLeft: 18,
    paddingTop: 6,
    paddingBottom: 6,

    opacity: 1,
    height: 'auto',
    color: store.currentTheme.blackMain,
    position: 'relative'
  };
  const errorStyleAndroid: TextStyle = {
    marginRight: 27,

    marginTop: 5,
    paddingTop: 5,
    color: store.currentTheme.error,
    borderTopColor: store.currentTheme.error,
    borderTopWidth: 1
    // backgroundColor:'blue'
  };

  interface Style {
    container: ViewStyle;
    error: TextStyle;
  }

  return StyleSheet.create<Style>({
    container: Platform.OS === 'android' ? containerStyleAndroid : containerStyleIOS,
    error: Platform.OS === 'android' ? errorStyleAndroid : errorStyleIOS
  });
};
