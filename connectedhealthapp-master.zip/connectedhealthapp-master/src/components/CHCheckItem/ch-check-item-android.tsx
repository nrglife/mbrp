import React, { FC } from 'react';
import { View, ViewProps, Text } from 'react-native';
import CHCheckItemProps from './ch-check-item-props';

import { RadioButton } from './radio-button.component';
import { useStores } from '../../hooks/useStores';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { styles as stylesCreator } from './ch-check-item.styles';

const CHCheckItemAndroid: FC<CHCheckItemProps & ViewProps> = ({ checked, children, style, inputStyle, error, onPress, disabled = false, ...props }) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);
  return (
    <TouchableOpacity onPress={onPress} disabled={disabled}>
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-start', marginVertical: 7.5 }}>
        <View style={{ marginRight: 21, marginTop: 5 }}>
          <RadioButton isSelected={checked} radioButtonColor={brandingStore.currentTheme.actionMedium} activeColor={brandingStore.currentTheme.actionMedium} />
        </View>
        <View style={{ flex: 1 }}>
          {children}

          {error ? (
            <View style={{}}>
              <Text style={[styles.error, brandingStore.textStyles.styleSmallRegular]}>{error}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default CHCheckItemAndroid;
