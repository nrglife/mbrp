import { TextInputProps, TextStyle } from 'react-native';

export default interface CHTextInputProps extends TextInputProps {
  checked: boolean;
  inputStyle?: TextStyle;
  onPress: () => void;
  error?: string;
  disabled?: boolean;
}
