import React, { useMemo } from 'react';
import { View, Animated } from 'react-native';

interface RadioButtonProps {
  isSelected: boolean;
  radioButtonColor: string;
  activeColor: string;
}

const OUTER_WIDTH = 18;
const INNER_WIDTH = 8;
export const RadioButton: React.FC<RadioButtonProps> = ({ isSelected, radioButtonColor, activeColor }) => {
  const animatedValue = useMemo(() => {
    return new Animated.Value(isSelected ? 1 : 0);
  }, [isSelected]);

  const opacity = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
    extrapolate: 'clamp'
  });

  return (
    <View
      style={{
        height: OUTER_WIDTH,
        width: OUTER_WIDTH,
        borderRadius: OUTER_WIDTH / 2,
        borderWidth: 2,
        borderColor: isSelected ? activeColor : radioButtonColor, // branding
        alignItems: 'center',
        justifyContent: 'center'
      }}>
      <Animated.View
        style={{
          height: INNER_WIDTH,
          width: INNER_WIDTH,
          borderRadius: INNER_WIDTH / 2,
          backgroundColor: isSelected ? activeColor : radioButtonColor, // branding
          opacity
        }}
      />
    </View>
  );
};
