import { TextInput, TextInputProps, TextStyle, View, Text, Image } from 'react-native';
import React, { FC } from 'react';
import { styles as stylesCreator } from './ch-check-item.styles';
import CHCheckItemProps from './ch-check-item-props';
import Icon from 'react-native-vector-icons/Ionicons';
import { TouchableOpacity } from 'react-native-gesture-handler';
import images from '../../assets/images/images';
import FastImage from 'react-native-fast-image';
import { useStores } from '../../hooks/useStores';

const CHCheckItemIOS: FC<CHCheckItemProps> = ({ checked = false, children, style, onPress, error, disabled = false }) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);
  return (
    <View>
      <TouchableOpacity style={styles.container /*{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 9, paddingHorizontal: 25  }*/} onPress={onPress} disabled={disabled}>
        {children}
        {checked ? <FastImage resizeMode="contain" source={images.enrollmentCheckIcon} style={{ width: 14, height: 14 }} /> : null}
      </TouchableOpacity>
      <View style={{ marginLeft: 25, width: '100%', height: 1, backgroundColor: error ? brandingStore.currentTheme.error : brandingStore.currentTheme.separatorOpaque }}></View>
      {error ? (
        <View style={{ backgroundColor: error ? brandingStore.currentTheme.errorBackground : null }}>
          <Text style={[styles.error, brandingStore.textStyles.styleSmallRegular]}>{error}</Text>
        </View>
      ) : null}
    </View>
  );
};

export default CHCheckItemIOS;
