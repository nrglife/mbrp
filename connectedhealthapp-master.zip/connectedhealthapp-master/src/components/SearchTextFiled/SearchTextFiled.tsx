import React, { FC, LegacyRef, MutableRefObject, useEffect, useRef, useState } from 'react';
import {
  FlatList,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Button,
  Alert,
  Image,
  TextInput,
  ViewStyle,
  TextInputProps,
  ImageSourcePropType,
  NativeSyntheticEvent,
  TextInputFocusEventData
} from 'react-native';
import { useStores } from '../../hooks/useStores';
import { styles as styleCreator } from './SearchTextFiled.style';
import images from '../../assets/images/images';

interface SearchTextFiledProps extends TextInputProps {
  //openResultsSheet?: () => void;
  inputRef?: MutableRefObject<TextInput>;
  customIcon?: ImageSourcePropType;
  onClear: () => void;
  value?: string;
  style?: ViewStyle;
}

const SearchTextFiled: FC<SearchTextFiledProps> = ({ onBlur, onFocus, onClear, customIcon, inputRef, value, style, ...props }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(useStores().brandingStore);
  const textStyles = brandingStore.textStyles;

  return (
    <View style={[styles.searchContainer, style]}>
      <Image style={styles.searchImage} source={images.search} />
      {customIcon ? <Image style={styles.customIcon} source={customIcon} /> : null}
      <TextInput
        multiline={true}
        value={value}
        onFocus={onFocus}
        onBlur={onBlur}
        ref={inputRef && inputRef}
        style={[
          {
            flex: 1,
            paddingTop: 0,
            paddingBottom: 0,

            textAlignVertical:"center",
          },
          textStyles.styleSmallRegular,
          { color: brandingStore.currentTheme.blackSecondary }
        ]}
        {...props}
      />
      {value && value.length != 0 ? (
        <TouchableOpacity onPress={onClear}>
          <Image style={styles.closeIcon} source={images.clearInput} />
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

export default SearchTextFiled;
