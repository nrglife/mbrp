import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    searchContainer: {
      marginHorizontal: 16,
      borderRadius: 10,
      overflow: 'hidden',
      backgroundColor: 'rgba(118, 118, 128, 0.12)',
      marginTop: 11,
      paddingVertical: 3,
      flexDirection: 'row',
      alignItems: 'center',
      marginVertical: 14,
      alignContent: 'center'
    },
    searchImage: { width: 30, height: 30, resizeMode: 'contain' },
    customIcon: { width: 30, height: 15, resizeMode: 'contain', tintColor: store.currentTheme.blackSecondary },
    closeIcon: {
      marginRight: 10,
      width: 20,
      height: 20,
      borderRadius: 10,
      overflow: 'hidden',
      resizeMode: 'contain'
    }
  });
};
