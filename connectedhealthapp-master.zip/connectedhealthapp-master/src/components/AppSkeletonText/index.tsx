import React, {useEffect, useRef} from 'react';
import {StyleProp, StyleSheetProperties, View, ViewProps, ViewStyle} from 'react-native';
import {Animated} from 'react-native';
import {useStores} from '../../hooks/useStores';

declare interface BlinkProps extends ViewProps {
    height: string | number;
    visible?: boolean;
    width: string | number;
    shimmerStyle?: StyleProp<ViewStyle>;
}

export const Blink: React.FC<BlinkProps> = ({children, style, visible = true, height, width, shimmerStyle}) => {
    const fadeAnimation = new Animated.Value(0.3);
    const animationRf = useRef<Animated.Value>(fadeAnimation);
    const {brandingStore} = useStores();

    useEffect(() => {
        Animated.loop(
            Animated.sequence([
                Animated.timing(animationRf.current, {
                    toValue: 0.6,
                    duration: 1000,
                    useNativeDriver: true
                }),
                Animated.timing(animationRf.current, {
                    toValue: 0.3,
                    duration: 1000,
                    useNativeDriver: true
                })
            ]),
            {}
        ).start();
    }, []);

    return (
        <>
            {visible ? (
                <Animated.View style={[{opacity: animationRf.current}, style]}>
                    <View
                        style={[
                            {
                                backgroundColor: brandingStore.currentTheme.hint,
                                height: height,
                                width: width,
                                borderRadius: 4
                            },
                            shimmerStyle
                        ]}
                    />
                </Animated.View>
            ) : (
                <>{children}</>
            )}
        </>
    );
};
