import { Keyboard, Text, TouchableOpacity } from 'react-native';
import React, { FC, useCallback } from 'react';
import { CHActionButtonProps } from './ch-action-button-props';
import { useStores } from '../../hooks/useStores';

const CHActionButtonIOS: FC<CHActionButtonProps> = ({ onPress, label, style, disabled }) => {
  const { brandingStore } = useStores();
  const pressHandler = useCallback(() => {
    Keyboard.dismiss();
    onPress && onPress();
  }, [onPress]);

  return (
    <TouchableOpacity
      disabled={disabled}
      style={[
        style,
        {
          width: '100%',
          height: style ? style.height ?? 52 : 52,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: brandingStore.currentTheme.actionLight,
          opacity: disabled ? 0.5 : 1
        }
      ]}
      onPress={pressHandler}>
      <Text
        style={[
          {
            color: brandingStore.currentTheme.actionDark,
            textTransform: 'capitalize'
          },
          brandingStore.textStyles.styleLargeSemiBold
        ]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
};

export default CHActionButtonIOS;
