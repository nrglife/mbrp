import { Button, ButtonProps, Keyboard, Text, TouchableOpacity, View } from 'react-native';
import React, { FC, useCallback } from 'react';
import { CHActionButtonProps } from './ch-action-button-props';
import Icon from 'react-native-vector-icons/Ionicons';
import { useStores } from '../../hooks/useStores';

const CHNextButtonAndroid: FC<CHActionButtonProps> = ({ onPress, label, style, disabled, noBottomMargin }) => {
  const { brandingStore } = useStores();
  const pressHandler = useCallback(() => {
    Keyboard.dismiss();
    onPress && onPress();
  }, [onPress]);
  return (
    <View
      style={{
        width: '100%',
        flexDirection: 'row',
        borderStartColor: 'green'
      }}>
      <TouchableOpacity
        disabled={disabled}
        style={[
          style,
          {
            height: style ? style.height ?? 56 : 56,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: brandingStore.currentTheme.actionLight,
            borderRadius: 4,
            overflow: 'hidden',
            marginRight: style ? style.marginRight ?? 27 : 27,
            marginLeft: style ? style.marginLeft ?? 27 : 27,
            marginBottom: noBottomMargin ? 0 : 18,
            flex: 1,
            elevation: 3,
            opacity: disabled ? 0.5 : 1
          }
        ]}
        onPress={pressHandler}>
        <Text
          style={[
            {
              color: brandingStore.currentTheme.actionDark,
              textTransform: 'capitalize'
            },
            brandingStore.textStyles.styleLargeSemiBold
          ]}>
          {label}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default CHNextButtonAndroid;
