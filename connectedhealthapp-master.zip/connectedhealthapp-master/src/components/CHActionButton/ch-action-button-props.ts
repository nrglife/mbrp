import { ButtonProps, TouchableOpacityProps, ViewStyle } from 'react-native';

export interface CHActionButtonProps extends TouchableOpacityProps{
  onPress: () => void;
  label: string;
  style?: ViewStyle;
  noBottomMargin? : boolean;
}
