
import { Platform } from 'react-native'
import CHActionButtonAndroid from './ch-action-button-android'
import CHActionButtonIOS from './ch-action-button-ios'
import {CHActionButtonProps} from './ch-action-button-props'


const CHActionButton = Platform.OS === 'android'?CHActionButtonAndroid: CHActionButtonIOS

export {CHActionButton, CHActionButtonProps}