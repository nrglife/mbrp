import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: { flex: 1, alignItems: 'center', paddingHorizontal: 44 },
    errorStyle: { position: 'absolute', bottom: 0, color: store.currentTheme.greyEmptyState, marginBottom: 18 }
  });
};
