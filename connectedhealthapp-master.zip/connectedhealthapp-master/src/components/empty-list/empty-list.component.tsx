import React, { FC } from 'react';
import { View, ViewStyle } from 'react-native';
import { styles as styleCreator } from './empty-list.styles';
import { useStores } from '../../hooks/useStores';
import { ErrorCode } from '..';
import { failureSource } from '@healthcareapp/connected-health-common-services';

interface EmptyListProps {
  apis?: failureSource[];
  mainStyle?: ViewStyle;
}

export const EmptyList: FC<EmptyListProps> = ({ children, apis, mainStyle }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);

  return (
    <View style={[styles.container, { backgroundColor: brandingStore.currentTheme.backgroundLight }, mainStyle]}>
      {children}
      {apis && <ErrorCode apis={apis} ignoreNextPage={true} style={styles.errorStyle} />}
    </View>
  );
};
