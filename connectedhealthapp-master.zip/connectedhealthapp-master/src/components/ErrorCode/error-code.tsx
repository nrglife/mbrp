import React, { FC } from 'react';

import { observer } from 'mobx-react';
import ErrorCodeProps from './error-code-props';
import { Text } from 'react-native';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import { useStores } from '../../hooks/useStores';
import { styles as stylesCreator } from './error-code-styles';

const ErrorCode: FC<ErrorCodeProps> = observer((props: ErrorCodeProps) => {
  const { errorStore, brandingStore } = useStores();
  const filtered = errorStore.getLastFilteredError(props.apis);
  const styles = stylesCreator(brandingStore);

  if (!filtered) {
    return null;
  }

  const codeTxt = filtered.code ? `Code:` + filtered.source.toLocaleLowerCase() + '-' + filtered.code : `Code:` + filtered.source.toLocaleLowerCase();
  return <Text style={[styles.errorStyle, brandingStore.textStyles.styleXSmallRegular, props.style]}>{codeTxt}</Text>;
});

failureSource;

export default ErrorCode;
