import { TextProps } from 'react-native';
import { failureSource } from '@healthcareapp/connected-health-common-services';

export default interface ErrorCodeProps extends TextProps {
  apis?: failureSource[];
  ignoreNextPage?: boolean;
}
