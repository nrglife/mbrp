import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    errorStyle: { color: store.currentTheme.greyEmptyState }
  });
};
