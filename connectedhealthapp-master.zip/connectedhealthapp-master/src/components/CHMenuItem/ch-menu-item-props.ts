import React, {Component} from 'react';
import {ButtonProps, ImageSourcePropType, TouchableOpacityProps, ViewProps, ViewStyle} from 'react-native';

export interface CHMenuItemProps {
    label: string;
    onPress: () => void;
    logo: ImageSourcePropType;
    chevron: boolean;
    textColor?: string;
}
