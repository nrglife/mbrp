import React, { FC, useState } from 'react';
import { Text, Button, SafeAreaView, View, TextInput, Platform, ScrollView, TouchableOpacity, ActivityIndicator, FlatList, Image, ImageSourcePropType, StyleSheet } from 'react-native';
import DateTimePicker, { AndroidNativeProps, IOSNativeProps } from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';

import { NavigationProp } from '../../models/navigation';

import { styles as styleCreator } from './ch-menu-item.styles';
import { useIsIOS } from '../../hooks/useIsIOS';
import { Switch } from 'react-native-gesture-handler';
import { HomeNavigationRoutes } from '../../routes';
import images from '../../assets/images/images';
import { useStores } from '../../hooks/useStores';
import { CHTouchableOpacity } from '../../components';
import { CHMenuItemProps } from './ch-menu-item-props';

const CHMenuItem: FC<CHMenuItemProps> = ({ label, onPress, logo, chevron, textColor, children }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  return (
    <View style={styles.main}>
      <CHTouchableOpacity pressedColor={brandingStore.currentTheme.backgroundMedium} pressedColorOpacity={0.5} style={styles.touchableOpacity} onPress={onPress}>
        {logo && <Image style={styles.logo} source={logo} />}
        <Text style={[styles.text, brandingStore.textStyles.styleSmallRegular, logo ? {} : { marginLeft: 28 }, textColor ? { color: textColor } : {}]}>{label}</Text>
        {children}
        {chevron ? <Image source={images.rightChevron} style={styles.chevron} /> : null}
      </CHTouchableOpacity>
      <View style={styles.border} />
    </View>
  );
};

export { CHMenuItem, CHMenuItemProps };
