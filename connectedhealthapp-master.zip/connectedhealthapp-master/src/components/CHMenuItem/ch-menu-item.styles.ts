import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    main: { height: Platform.OS == 'android' ? 56 : 56, backgroundColor: store.currentTheme.white, justifyContent: 'center' },
    border: { backgroundColor: store.currentTheme.separatorOpaque, height: 0.5, marginLeft: 20 },
    logo: { marginLeft: Platform.OS == 'android' ? 24 : 20, width: 24, height: 24, resizeMode: 'contain', tintColor: /*'rgba(60, 60, 67, 0.33)'*/ store.currentTheme.label },
    text: { flex: 1, marginLeft: 10, color: store.currentTheme.blackMain },
    chevron: { tintColor: store.currentTheme.label, marginRight: 10 },
    touchableOpacity: { flexDirection: 'row', alignItems: 'center', flex: 1 }
  });
};
