import React, { useEffect, useRef } from 'react';
import { Image, Modal, ModalProps, StyleProp, StyleSheet, StyleSheetProperties, View, ViewProps, ViewStyle } from 'react-native';
import { Animated } from 'react-native';
import images from '../assets/images/images';

declare interface LoaderProps extends ModalProps {
  isLoading: boolean;
}

 const Loader: React.FC<LoaderProps> = ({ isLoading }) => {
  const fadeAnimation = new Animated.Value(0);
  const animationRf = useRef<Animated.Value>(fadeAnimation);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(animationRf.current, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true
        }),
        Animated.timing(animationRf.current, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: true
        })
      ])
    ).start();
  }, []);
  const scale = animationRf.current.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.25]
  });

  return (
    <Modal visible={isLoading} transparent={false} onRequestClose={() => {}}>
      <View style={[styles.absoluteStyle, styles.loaderContainerStyle]}>
        <Animated.View style={[{ transform: [{ scale }] }]}>
          <Image source={images.change_logo} resizeMode={'contain'} />
        </Animated.View>
      </View>
    </Modal>
  );
};
 const styles = StyleSheet.create({
  absoluteStyle: { ...StyleSheet.absoluteFillObject },
  loaderContainerStyle: { flex: 1, backgroundColor: '#F0F3F8', justifyContent: 'center', alignItems: 'center' }
});


export default Loader
