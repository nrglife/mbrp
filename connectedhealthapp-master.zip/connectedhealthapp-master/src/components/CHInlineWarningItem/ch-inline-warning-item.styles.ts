import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: { marginVertical: 5, flexDirection: 'row' },
    textStyle: {
      flexBasis: 302,
      color: store.currentTheme.blackMain,
      marginLeft: 8
    }
  });
};
