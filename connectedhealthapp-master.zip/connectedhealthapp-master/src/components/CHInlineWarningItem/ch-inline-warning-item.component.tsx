import React, { FC } from 'react';
import { Image, Text, View, ViewStyle } from 'react-native';
import FastImage from 'react-native-fast-image';
import images from '../../assets/images/images';
import { useStores } from '../../hooks/useStores';
import { styles as stylesCreator } from './ch-inline-warning-item.styles';

interface WarningProps {
  text: string;
  style?: ViewStyle;
}

export const InlineWarning: FC<WarningProps> = ({ text, style }) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);
  return (
    <View style={[styles.container, style]}>
      <Image source={images.warning_fiiled} resizeMode="contain" style={{ width: 17, height: 17, marginTop: 3 }} />
      <Text style={[styles.textStyle, brandingStore.textStyles.styleXSmallRegular]}>{text}</Text>
    </View>
  );
};
