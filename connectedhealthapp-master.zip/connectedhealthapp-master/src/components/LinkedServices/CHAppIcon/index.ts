import { Platform } from 'react-native'
import {CHAppIcon} from './ch-app-icon'
import CHAppIconProps from './ch-app-icon-props'
export default CHAppIcon;

export {CHAppIconProps}