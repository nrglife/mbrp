import { StyleSheet, Platform, TextStyle, ViewStyle } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile, size: number) => {
  return StyleSheet.create({
    logo: {
      width: size,
      height: size,
      ...Platform.select({
        android: {},
        ios: {
          borderRadius: 15
        }
      }),
      overflow: 'hidden',
      backgroundColor: store.currentTheme.white
    },
    logoNoShadow: {
      width: size,
      height: size,

      overflow: 'hidden',
      backgroundColor: store.currentTheme.white,
      borderWidth: 0,
      borderColor: 'transparent',
      ...Platform.select({
        android: {},
        ios: {
          borderRadius: 15
        }
      })
    },
    shadow: {
      shadowColor: '#000',
      shadowRadius: 5,
      shadowOffset: {
        width: 1,
        height: 1
      },
      shadowOpacity: 0.3,
      ...Platform.select({
        android: {
          borderRadius: 15,
          overflow: 'hidden',
          elevation: 3,
          backgroundColor: store.currentTheme.white
        },
        ios: {}
      })
    },
    noShadow: {
      borderRadius: 15,
      overflow: 'hidden',
      backgroundColor: store.currentTheme.white,
      borderWidth: 0.5,
      borderColor: store.currentTheme.hint
    }
  });
};
