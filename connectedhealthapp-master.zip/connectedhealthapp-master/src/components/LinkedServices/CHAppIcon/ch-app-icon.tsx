import { TextInput, View, Text, Button, Dimensions, Image, ActivityIndicator } from 'react-native';
import React, { FC, useRef, useState } from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import CHAppIconProps from './ch-app-icon-props';
import { observer } from 'mobx-react';
import { styles as stylesCreator } from './ch-app-icon-styles';
import { useStores } from '../../../hooks/useStores';
import CHImageWithLoader from '../../CHImageWithLoader';
import images from '../../../assets/images/images';
import Spinner from '../../Spinner';

export const CHAppIcon: React.FC<CHAppIconProps> = props => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore, props.size);

  return (
    <View style={[props.style, styles.noShadow]}>
      <CHImageWithLoader
        defaultImage={images.emptyAppIcon}
        resizeMode="contain"
        style={styles.logo}
        source={props.source}
        onLoad={props.onLoad}
        onLoadEnd={props.onLoadEnd}
      />
    </View>
  );
};
