import React, { Component } from 'react';
import { ImageProps, ImageSourcePropType, ImageStyle, TextInputProps, TextProps, TextStyle, ViewProps} from 'react-native';



export default interface CHAppIconProps extends ImageProps{
    source:ImageSourcePropType;
    size:number;


}
