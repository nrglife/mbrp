import Modal from 'react-native-modal';
import { View, Text } from 'react-native';
import React from 'react';
import { useStores } from '../../hooks/useStores';
import { CHActionButton } from '../index';
import { styles } from './styles';
import { observer } from 'mobx-react';

declare interface AppModalProps {
  onCancel: () => void;
  isVisible: boolean;
  coverScreen: boolean;
}

const AppModal: React.FC<AppModalProps> = ({ onCancel, isVisible, coverScreen }) => {
  const { brandingStore, generalStore } = useStores();
  const { showCloseButton, title, message, closeButtonText } = generalStore.appConfigResponse.appMessage;

  return (
    <Modal isVisible={isVisible} coverScreen={coverScreen}>
      <View style={styles.content}>
        <Text style={[styles.title, brandingStore.textStyles.styleLargeBold]}>{title}</Text>
        <Text style={[brandingStore.textStyles.styleLargeRegular, styles.text]}>{message}</Text>
        {showCloseButton && (
          <View style={styles.buttonContainer}>
            <CHActionButton noBottomMargin={true} style={styles.button} onPress={onCancel} label={closeButtonText} />
          </View>
        )}
      </View>
    </Modal>
  );
};

export default observer(AppModal);
