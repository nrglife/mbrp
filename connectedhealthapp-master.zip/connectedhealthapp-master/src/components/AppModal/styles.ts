import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  content: {
    backgroundColor: 'white',
    paddingHorizontal: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    borderColor: 'rgba(0, 0, 0, 0.1)',
    paddingBottom: 26
  },
  contentTitle: {
    fontSize: 20,
    marginBottom: 12
  },
  button: {
    borderRadius: 5,
    marginRight: 0,
    marginLeft: 0,
    height: 41
  },
  buttonContainer: { width: '100%', marginTop: 20 },
  title: {
    textAlign: 'center',
    marginTop: 23,
    marginBottom: 26,
    color: '#0F0F59'
  },
  text: {
    textAlign: 'center',
    color: '#0F0F59',
    paddingHorizontal: 10
  }
});
