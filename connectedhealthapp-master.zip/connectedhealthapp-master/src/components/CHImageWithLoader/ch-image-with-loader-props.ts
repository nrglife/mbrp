import React, { Component } from 'react';
import { ImageProps, ImageSourcePropType, ImageStyle, TextInputProps, TextProps, TextStyle} from 'react-native';



export default interface CHImageWithLoaderProps extends ImageProps{
    // SpinnerComponent?: React.ComponentType<any>;
    defaultImage?:ImageSourcePropType


}
