import { Platform } from 'react-native'
import {CHImageWithLoader} from './ch-image-with-loader'
import CHImageWithLoaderProps from './ch-image-with-loader-props'
export default CHImageWithLoader;

export {CHImageWithLoaderProps}