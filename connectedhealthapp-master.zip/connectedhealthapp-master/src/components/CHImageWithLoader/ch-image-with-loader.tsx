import {Image} from 'react-native';
import React, {useState} from 'react';
import CHImageWithLoaderProps from './ch-image-with-loader-props';
import {Blink} from "../AppSkeletonText";


export const CHImageWithLoader: React.FC<CHImageWithLoaderProps> = props => {
    const {style, defaultImage} = props;
    const [isImageLoading, setIsImageLoading] = useState<boolean>(true);
    const [loadSuccess, setLoadSuccess] = useState<boolean>(false);


    return (
        <>
            <Image
                {...props}
                style={[props.style, {opacity: isImageLoading ? 0 : 1}]}
                onLoad={e => {
                    setLoadSuccess(true);
                    props.onLoad && props.onLoad(e);
                }}
                onError={e => {
                    setIsImageLoading(false);
                    props.onError && props.onError(e);
                }}
                onLoadEnd={() => {
                    setIsImageLoading(false);
                    props.onLoadEnd && props.onLoadEnd();
                }}
            />
            {isImageLoading && (
                <Blink
                    height={'100%'}
                    width={'100%'}
                    visible={true}
                    style={[
                        style,
                        {
                            top: 0,
                            left: 0,
                            position: 'absolute',
                            width: '100%',
                            height: '100%',

                        }
                    ]}
                />
            )}
            {!loadSuccess && !isImageLoading && <Image {...props} onLoadEnd={null} onLoad={null} source={defaultImage}
                                                       style={[style, {
                                                           top: 0,
                                                           left: 0,
                                                           position: 'absolute',
                                                           width: '100%',
                                                           height: '100%'
                                                       }]}/>}

        </>
    );
};
