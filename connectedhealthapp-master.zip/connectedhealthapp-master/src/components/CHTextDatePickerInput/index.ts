import { Platform } from 'react-native'
import CHTextDatePickerInputAndroid from './CHTextDatePickerInput-android'
import CHTextDatePickerInputIos from './CHTextDatePickerInput-ios'

const  CHDatePicker = Platform.OS === 'android'?CHTextDatePickerInputAndroid:CHTextDatePickerInputIos;

export default CHDatePicker;
