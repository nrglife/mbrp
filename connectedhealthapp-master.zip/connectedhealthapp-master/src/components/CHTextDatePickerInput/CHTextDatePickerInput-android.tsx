import { Alert, Text, TextStyle, TouchableOpacity, TouchableOpacityProps, View } from 'react-native';
import React, { Dispatch, FC, SetStateAction } from 'react';
import { useStores } from '../../hooks/useStores';
import { styles as stylesCreator } from './CHTextDatePickerInput.styles';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import CHTextDatePickerInputProps from './CHTextDatePicker-props';
import { TextInput } from 'react-native-paper';
import moment from 'moment';

const CHTextDatePickerInputAndroid: FC<CHTextDatePickerInputProps> = ({
  error,
  isError,
  style,
  label,
  labelStyle,
  inputStyle,
  toolTip,
  tooltipStyle,
  birthdayValue,
  setShowDatePicker,
  isDatePickerVisible,
  onConfirm,
  children,
  ...props
}) => {
  const stores = useStores();
  const styles = stylesCreator(stores.brandingStore);
  const theme: ReactNativePaper.Theme = {
    mode: 'adaptive',
    colors: {
      primary: stores.brandingStore.currentTheme.actionMedium,
      background: 'transparent',
      //surface: 'yellow',
      //accent: 'green',
      error: stores.brandingStore.currentTheme.error,
      //,
      //onSurface: 'green',
      //onBackground: 'orange',
      disabled: stores.brandingStore.currentTheme.label,
      placeholder: stores.brandingStore.currentTheme.label,
      backdrop: stores.brandingStore.currentTheme.label
      //notification: 'cyan'
    }
  };
  const textStyles = stores.brandingStore.textStyles;
  const oneYearFromNow = new Date();
  oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() - 120);
  return (
    <TouchableOpacity
      style={{ width: '100%' }}
      onPress={() => {
        setShowDatePicker(true);
      }}>
      <DateTimePickerModal
        date={birthdayValue || new Date(`01/01/${new Date().getFullYear()}`)}
        maximumDate={new Date()}
        minimumDate={oneYearFromNow}
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={onConfirm}
        onCancel={() => {
          setShowDatePicker(false);
        }}
      />
      <>
        <View style={[styles.container, style, isError && { borderBottomColor: 'red' }]}>
          <TextInput
            underlineColor={isError && 'red'}
            error={error}
            value={birthdayValue ? moment(new Date(birthdayValue), 'MM/DD/YYYY').format('MM/DD/YYYY').toString() : ''}
            editable={false}
            theme={theme}
            mode={'flat'}
            label={label}
            {...props}
            style={[styles.main, inputStyle, { backgroundColor: stores.brandingStore.currentTheme.white }, textStyles.styleLargeRegular]}>
            {children}
          </TextInput>
        </View>
        <View style={{ height: styles.errorContainer.height }}>
          <View style={[error ? styles.errorContainer : null]} />
          <Text style={[error ? styles.error : styles.tooltip, tooltipStyle, textStyles.styleSmallRegular]}>{error ? error : toolTip}</Text>
        </View>
      </>
    </TouchableOpacity>
  );
};

export default CHTextDatePickerInputAndroid;
