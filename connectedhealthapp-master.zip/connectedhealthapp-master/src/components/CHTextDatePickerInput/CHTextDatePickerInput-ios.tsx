import { Alert, Text, TextInput, TextStyle, TouchableOpacity, TouchableOpacityProps, View } from 'react-native';
import React, { Dispatch, FC, SetStateAction } from 'react';
import { useStores } from '../../hooks/useStores';
import { styles as stylesCreator } from './CHTextDatePickerInput.styles';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import CHTextDatePickerInputProps from './CHTextDatePicker-props';
import DateTimePicker from 'react-native-modal-datetime-picker';
import moment from 'moment';

const CHTextDatePickerInputIos: FC<CHTextDatePickerInputProps> = ({
  error,
  isError,
  style,
  label,
  labelStyle,
  inputStyle,
  toolTip,
  tooltipStyle,
  birthdayValue,
  setShowDatePicker,
  isDatePickerVisible,
  onConfirm,
  children,
  ...props
}) => {
  const stores = useStores();
  const styles = stylesCreator(stores.brandingStore);
  const textStyles = stores.brandingStore.textStyles;
  const oneYearFromNow = new Date();
  oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() - 120);
  return (
    <TouchableOpacity
      style={{ width: '100%' }}
      onPress={() => {
        setShowDatePicker(true);
      }}>
      <DateTimePickerModal
        date={birthdayValue || new Date(`01/01/${new Date().getFullYear()}`)}
        headerTextIOS={'Your Birthday'}
        maximumDate={new Date()}
        minimumDate={oneYearFromNow}
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={onConfirm}
        onCancel={() => {
          setShowDatePicker(false);
        }}
      />
      <>
        <View style={[styles.container, style]}>
          <Text style={[styles.label, textStyles.styleLargeSemiBold, labelStyle]}>{label}</Text>
          <Text
            placeholder={'mm/dd/yyyy'}
            value={birthdayValue !== null ? birthdayValue.toString() : ''}
            editable={false}
            focusable={false}
            {...props}
            style={[styles.main, inputStyle, { color: !birthdayValue || false ? stores.brandingStore.currentTheme.hint : stores.brandingStore.currentTheme.blackMain }, textStyles.styleLargeSemiBold]}
            //colorize input cursor
            // selectionColor={'green'}
            placeholderTextColor={stores.brandingStore.currentTheme.hint}>
            {birthdayValue && moment(new Date(birthdayValue), 'MM/DD/YYYY').format('MM/DD/YYYY').toString()}
          </Text>
        </View>
        <View
          style={{
            marginLeft: 25,
            width: '100%',
            height: 1,
            backgroundColor: isError || error ? stores.brandingStore.currentTheme.error : stores.brandingStore.currentTheme.separatorOpaque
          }}
        />

        <View style={{ backgroundColor: error ? stores.brandingStore.currentTheme.errorBackground : null }}>
          <Text style={[error ? styles.error : styles.tooltip, tooltipStyle, textStyles.styleSmallRegular]}>{error ? error : toolTip}</Text>
        </View>
      </>
    </TouchableOpacity>
  );
};

export default CHTextDatePickerInputIos;
