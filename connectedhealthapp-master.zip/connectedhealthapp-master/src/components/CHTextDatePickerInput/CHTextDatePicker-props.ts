import {TextStyle, TouchableOpacityProps} from "react-native";
import {Dispatch, SetStateAction} from "react";
import {ReactNativeModalDateTimePickerProps} from "react-native-modal-datetime-picker";

export default interface CHTextDatePickerInputProps extends ReactNativeModalDateTimePickerProps {
    label: string;
    labelStyle?: TextStyle;
    inputStyle?: TextStyle;
    toolTip?: string;
    tooltipStyle?: TextStyle;
    isDatePickerVisible: boolean;
    setShowDatePicker: Dispatch<SetStateAction<boolean>>
    birthdayValue?: Date
    onConfirm: (date: Date) => void
    error?: string;
    isError?: boolean
}
