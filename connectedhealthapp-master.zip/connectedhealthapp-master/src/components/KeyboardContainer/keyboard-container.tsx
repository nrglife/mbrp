import React, { FC, memo, useCallback, useEffect, useRef, useState } from 'react';
import { observer } from 'mobx-react';
import { Image, KeyboardAvoidingView, ScrollView, Text, TouchableOpacity, View, TextInput, Button, Keyboard, Platform, Animated } from 'react-native';
import { KeyboardAvoidingScrollView } from 'react-native-keyboard-avoiding-scroll-view';
import { KeyboardHandlingMode } from '../../utilities/constants';
import { Transition, Transitioning, TransitioningView } from 'react-native-reanimated';
import { useMemo } from 'react';
import { Easing } from 'react-native';

interface KeyboardContainerProps {
  mainView: Element;
  keyboardFooter: Element;
  footer: Element;
}

type KeyboardState = 'SHOWN' | 'HIDDEN' | 'SHOWING' | 'HIDING';

const transition = (
  <Transition.Together>
    <Transition.Out type="fade" durationMs={300} />
    <Transition.In type="fade" durationMs={200} />
  </Transition.Together>
);
const KeyboardContainer: FC<KeyboardContainerProps> = props => {
  const [keyboardState, setKeyboardState] = useState<KeyboardState>('HIDDEN');

  const fadeAnim = useRef(new Animated.Value(1)).current;
  const ref = useRef<TransitioningView>();
  const _keyboardDidShow = () => {
    if (Platform.OS === 'android') {
      fadeAnim.setValue(0);
      setKeyboardState('SHOWING');
      setTimeout(() => {
        setKeyboardState('SHOWN');
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 200,
          easing: Easing.cubic,
          useNativeDriver: true
        }).start();
      }, 200);

      /*  Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 0,
        useNativeDriver: true,
        easing: Easing.cubic
      }).start(() => {
        setKeyboardState('SHOWN');
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 500,
          easing: Easing.cubic,
          useNativeDriver: true
        }).start();
      });*/
    } else {
      ref.current.animateNextTransition();
      setKeyboardState('SHOWN');
    }
  };
  const _keyboardWillShow = () => {
    ref.current.animateNextTransition();
    setKeyboardState('SHOWING');
  };

  const _keyboardWillHide = () => {
    ref.current.animateNextTransition();
    setKeyboardState('HIDING');
  };

  const _keyboardDidHide = () => {
    if (Platform.OS == 'android') {
      setKeyboardState('HIDING');
      fadeAnim.setValue(0);
      setTimeout(() => {
        setKeyboardState('HIDDEN');
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
          easing: Easing.cubic
        }).start();
      }, 200);

      /*setKeyboardState('HIDING');
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
        easing: Easing.cubic
      }).start(() => {
        setKeyboardState('HIDDEN');
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
          easing: Easing.cubic
        }).start();
      });*/
    } else {
      ref.current.animateNextTransition();
      setKeyboardState('HIDDEN');
    }
  };

  useEffect(() => {
    if (Platform.OS == 'ios') {
      const keyboardWillShowSub = Keyboard.addListener('keyboardWillShow', _keyboardWillShow);
      const keyboardWillHideSub = Keyboard.addListener('keyboardWillHide', _keyboardWillHide);
      const keyboardDidShowSub = Keyboard.addListener('keyboardDidShow', _keyboardDidShow);
      const keyboardDidHideSub = Keyboard.addListener('keyboardDidHide', _keyboardDidHide);
      return () => {

        keyboardWillHideSub.remove()
        keyboardWillShowSub.remove()
        keyboardDidShowSub.remove()
        keyboardDidHideSub.remove()
      };
    } else {
      const keyboardDidShowSub = Keyboard.addListener('keyboardDidShow', _keyboardDidShow);
      const keyboardDidHideSub = Keyboard.addListener('keyboardDidHide', _keyboardDidHide);
      return () => {
        keyboardDidShowSub.remove()
        keyboardDidHideSub.remove()
      };
    }
  }, []);

  if (KeyboardHandlingMode) {
    return (
      <View style={{ flex: 1, width: '100%' }}>
        <Animated.ScrollView
          keyboardShouldPersistTaps={'handled'}
          alwaysBounceVertical={true}
          style={{ flex: 1, opacity: fadeAnim }}
          contentContainerStyle={{ flexGrow: 1 }}>
          {props.mainView}
        </Animated.ScrollView>
        {Platform.OS == 'android' ? (
          <Animated.View style={{ opacity: fadeAnim }}>
            {keyboardState == 'SHOWN' || (Platform.OS === 'android' && keyboardState == 'HIDING') ? props.keyboardFooter : null}
            {keyboardState == 'HIDDEN' || (Platform.OS === 'android' && keyboardState == 'SHOWING') ? props.footer : null}
          </Animated.View>
        ) : (
          <Transitioning.View
            ref={x => {
              ref.current = x;
            }}
            transition={transition}>
            {keyboardState == 'SHOWN' || keyboardState == 'SHOWING' ? props.keyboardFooter : null}
            {keyboardState == 'HIDDEN' ? props.footer : null}
          </Transitioning.View>
        )}
      </View>
    );
  } else {
    return (
      <View style={{ flex: 1, width: '100%' }}>
        <KeyboardAvoidingScrollView
          keyboardShouldPersistTaps={'always'}
          alwaysBounceVertical={false}
          style={{ flex: 1 }}
          contentContainerStyle={{ flexGrow: 1 }}
          stickyFooter={keyboardState == 'SHOWN' ? props.keyboardFooter : props.footer}>
          {props.mainView}
        </KeyboardAvoidingScrollView>
        {Platform.OS === 'android' && keyboardState == 'SHOWN' ? <View style={{ height: 20 }}></View> : null}
      </View>
    );
  }
};

export default KeyboardContainer;
