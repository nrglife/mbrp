import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    logoAndTitleContainer: { justifyContent: 'center', alignItems: 'center' },
    textStyle: { textAlign: 'center', color: store.currentTheme.tooltip, marginTop: 16 }
  });
};
