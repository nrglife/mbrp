import React, { FC } from 'react';
import { Image, ImageResizeMode, ImageSourcePropType, ImageStyle, Text, TextStyle, View, ViewStyle } from 'react-native';
import { styles as styleCreator } from './empty-list-container.styles';
import { useStores } from '../../hooks/useStores';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import { EmptyList } from '../empty-list/empty-list.component';

interface EmptyListContainerProps {
  apis?: failureSource[];
  mainStyle?: ViewStyle;
  containerStyle?: ViewStyle;
  textStyle?: TextStyle;
  imageStyle?: ImageStyle;
  text: string;
  image: ImageSourcePropType;
  showImage?: boolean;
  resizeMode?: ImageResizeMode;
}

export const EmptyListContainer: FC<EmptyListContainerProps> = ({ children, mainStyle, apis, image, containerStyle, textStyle, imageStyle, text, showImage = true, resizeMode = 'contain' }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);

  return (
    <EmptyList apis={apis} mainStyle={mainStyle}>
      <View style={[styles.logoAndTitleContainer, containerStyle]}>
        {showImage && <Image source={image} resizeMode={resizeMode} style={[imageStyle]} />}
        <Text style={[styles.textStyle, brandingStore.textStyles.styleSmallSemiBold, textStyle]}>{text}</Text>
      </View>
      {children}
    </EmptyList>
  );
};
