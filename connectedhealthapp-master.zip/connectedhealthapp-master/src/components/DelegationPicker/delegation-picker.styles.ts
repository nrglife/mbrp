import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: { width: '100%', flexDirection: 'column' },
    boxWithShadow: {
      shadowColor: 'rgba(0, 0, 0, 0.15)',
      shadowOffset: { width: 0, height: 3 },
      shadowOpacity: 6,
      elevation: 5
    },
    borderBottom: { borderBottomColor: store.currentTheme.separatorOpaque, borderBottomWidth: 0.5 },
    delegateText: { color: store.currentTheme.blackMain },
    bodyContainer: { backgroundColor: store.currentTheme.backgroundMedium },
    textPadding: { paddingLeft: 24, paddingRight: 24, paddingTop: 10, paddingBottom: 10 },
    textStyle: { textAlign: 'center', color: store.currentTheme.tooltip, marginTop: 16 },
    textTitle: { textTransform: 'uppercase', paddingLeft: 24, paddingBottom: 11, color: store.currentTheme.blackSecondary },
    flex: { flex: 1 },
    isActive: { backgroundColor: store.currentTheme.actionLight },
    background: { flex: 1, backgroundColor: store.currentTheme.label, width: '100%', opacity: 0.3 }
  });
};
