import React, { FC, useState, useRef } from 'react';
import { observer } from 'mobx-react';
import { View, Text } from 'react-native';
import { Transition, Transitioning, TransitioningView } from 'react-native-reanimated';

import { ExpandingComponent, ExpandingComponentInterface } from '../../components/ExpandingComponent/expanding.component';
import { Item } from './Components/Item.component';
import { ItemTitle } from './Components/Item.title.component';
import { styles as stylesCreator } from './delegation-picker.styles';
import { useStores } from '../../hooks/useStores';
import { styles as styleCreator } from './delegation-picker.styles';
import { DelegateMenu } from '@healthcareapp/connected-health-common-services/src/stores/DelegateStore';

export enum PickerType {
  Default = 'Default',
  ReadOnly = 'ReadOnly'
}

export enum VisiblityMode {
  Always = 'Always',
  MoreThanOne = 'MoreThanOne'
}

type DelegationPickerProps = {
  pickerType?: PickerType;
};

type BodyComponentProps = {
  menu: DelegateMenu | null;
  expanded: boolean;
  onSelect: () => void;
};

const BodyComponent: FC<BodyComponentProps> = observer(({ menu, onSelect }) => {
  const { brandingStore } = useStores();
  const textStyles = brandingStore.textStyles;
  const styles = styleCreator(brandingStore);

  return (
    <View style={styles.bodyContainer}>
      {menu && (
        <>
          {menu.mainMember && (
            <Text
              style={[styles.delegateText, textStyles.styleXSmallRegular, menu.mainMember.isHighlighted && styles.isActive, styles.textPadding]}
              onPress={() => {
                onSelect();
                menu.mainMember.onClick();
              }}>
              {menu.mainMember.name}
            </Text>
          )}
          <Text style={[styles.textTitle, menu.mainMember ? { marginTop: 22 } : {}]}>Delegate Accounts</Text>
          {menu.otherMembers.length > 0 && (
            <View>
              {menu.otherMembers?.map(item => {
                return <Item key={item.userID} data={item} onSelect={onSelect} />;
              })}
            </View>
          )}
        </>
      )}
    </View>
  );
});

const DelegationPicker: FC<DelegationPickerProps> = ({ pickerType = PickerType.Default }) => {
  const { brandingStore, delegateStore } = useStores();
  const [expanded, setExpanded] = useState<boolean>(false);
  const styles = stylesCreator(brandingStore);
  const ref = useRef<TransitioningView>();
  const expandingRef = useRef<ExpandingComponentInterface>(null);

  const { delegateMenu, selectedDelegateName, membersForDelegate } = delegateStore;

  const transition = (
    <Transition.Together>
      <Transition.In type="fade" durationMs={100} />
      <Transition.Change />
      <Transition.Out type="fade" durationMs={100} />
    </Transition.Together>
  );

  return (
    <View pointerEvents="box-none" style={{ flex: 1, flexDirection: 'column' }}>
      <Transitioning.View
        ref={x => {
          ref.current = x;
        }}
        transition={transition}
        style={[styles.container, expanded ? styles.boxWithShadow : styles.borderBottom]}>
        {membersForDelegate && (
          <>
            {pickerType !== PickerType.ReadOnly && delegateMenu ? (
              <ExpandingComponent
                ref={expandingRef}
                onExpendedCallback={value => {
                  setExpanded(value);
                }}
                transitioningViewRef={ref}
                titleComponent={<ItemTitle expanded={expanded} title={selectedDelegateName} withMenu={!!delegateMenu} />}
                bodyComponent={
                  <BodyComponent
                    menu={delegateMenu}
                    expanded={expanded}
                    onSelect={() => {
                      expandingRef.current.expand();
                    }}
                  />
                }
              />
            ) : (
              <ItemTitle expanded={false} title={selectedDelegateName} withMenu={false} />
            )}
          </>
        )}
      </Transitioning.View>
      {expanded && <View pointerEvents="auto" style={styles.background} />}
    </View>
  );
};

export default observer(DelegationPicker);
