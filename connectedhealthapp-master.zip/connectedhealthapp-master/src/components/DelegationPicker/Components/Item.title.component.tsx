import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { View, Text, Image } from 'react-native';
import { useStores } from '../../../hooks/useStores';
import { styles as styleCreator } from './item.title.component.styles';
import { Blink } from '../../../components/AppSkeletonText';
import images from '../../../assets/images/images';

interface ItemTitleProps {
  title: string;
  expanded?: boolean;
  withMenu: boolean;
}

export const ItemTitle: FC<ItemTitleProps> = observer(props => {
  const { brandingStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { title, expanded, withMenu } = props;
  const textStyles = brandingStore.textStyles;

  return (
    <View style={[styles.main, !withMenu && styles.mainReadOnly]}>
      <View>
        <Blink visible={false} height={20} width={176} shimmerStyle={{ borderRadius: 4, marginBottom: 6 }}>
          <Text style={[expanded ? styles.hidden : styles.visible, withMenu ? textStyles.styleXSmallSemiBold : textStyles.styleXSmallRegular, withMenu ? styles.titleText : styles.titleTextReadOnly]}>{title}</Text>
        </Blink>
      </View>
      {withMenu && (
        <View style={styles.imageWrap}>
          <Image source={images.closeXIconWhite} style={[expanded ? styles.visible : styles.hidden, styles.imageExpand]} />
          <Image source={images.chevronDownWhite} style={[expanded ? styles.hidden : styles.visible, styles.imageCollapse]} />
        </View>
      )}
    </View>
  );
});
