import { observer } from 'mobx-react';
import React, { FC } from 'react';
import { View, Text } from 'react-native';
import { useStores } from '../../../hooks/useStores';
import { styles as styleCreator } from './item.component.styles';
import { DelegateMenuItem } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';

interface ItemProps {
  data: DelegateMenuItem;
  onSelect: () => void;
}

export const Item: FC<ItemProps> = observer(({ data, onSelect }) => {
  const { brandingStore } = useStores();
  const textStyles = brandingStore.textStyles;
  const styles = styleCreator(brandingStore);

  return (
    <View>
      <View style={[styles.itemRow, data.isHighlighted && styles.isActive]}>
        <Text
          style={[styles.itemRowTitleText, textStyles.styleXSmallRegular]}
          onPress={() => {
            onSelect();
            data.onClick();
          }}>
          {data.name}
        </Text>
      </View>
    </View>
  );
});
