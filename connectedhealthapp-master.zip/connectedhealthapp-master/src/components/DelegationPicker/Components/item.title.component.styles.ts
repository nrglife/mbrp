import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';
import { DELEGATE_SELECTOR_HEIGHT, DELEGATE_SELECTOR_READONLY_HEIGHT } from '../../DelegationPickerContainer/delegation-picker.container';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    main: {
      justifyContent: 'center',
      alignItems: 'center',
      width: '100%',
      display: 'flex',
      height: DELEGATE_SELECTOR_HEIGHT,
      position: 'relative',
      flexDirection: 'row',
      backgroundColor: store.currentTheme.backgroundDark,
      
    },
    mainReadOnly: {
      height: DELEGATE_SELECTOR_READONLY_HEIGHT,
      backgroundColor: store.currentTheme.backgroundMedium,
      
    },
    titleText: {
      color: store.currentTheme.white
    },
    titleTextReadOnly: {
      color: store.currentTheme.blackMain
    },
    boxWithShadow: {
      shadowColor: 'rgba(0, 0, 0, 0.15)',
      shadowOffset: { width: 0, height: 3 },
      shadowOpacity: 6,
      elevation: 5
    },
    imageWrap: { position: 'absolute', right: 13, top: 14, height: 12, width: 12, display: 'flex', justifyContent: 'center', alignItems: 'center' },
    imageExpand: { width: 20, height: 20, position: 'absolute' },
    imageCollapse: { width: 12, height: 8, position: 'absolute' },
    hidden: { opacity: 0 },
    visible: { opacity: 1 }
  });
};
