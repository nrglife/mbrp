import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    itemRow: {
      justifyContent: 'flex-start',
      paddingLeft: 24,
      paddingRight: 24,
      paddingVertical: 13
    },
    itemRowTitleText: {
      color: store.currentTheme.blackMain
    },
    isActive: { backgroundColor: store.currentTheme.actionLight }
  });
};
