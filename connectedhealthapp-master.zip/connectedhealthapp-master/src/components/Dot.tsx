import React from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import Animated from 'react-native-reanimated';

export const REM = Dimensions.get('window').width / 375
const DEFAULT_DOT_SIZE = 8;

declare interface DotProps{
    size:number;
    key:string;
    style:any;

}

export const Dot:React.FC<DotProps> = ({ style, size, ...props }) => {
    return <Animated.View style={[styles.dotStyle(size), { ...style }]} {...props} />;
};

const styles = StyleSheet.create({
    dotStyle: (size = DEFAULT_DOT_SIZE) => ({
        width: size * REM,
        height: size * REM,
        backgroundColor: 'white',
        borderRadius: size / 2
    })
});
