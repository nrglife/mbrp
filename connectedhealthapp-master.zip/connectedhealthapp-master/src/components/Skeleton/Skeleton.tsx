import { Animated, Dimensions, Easing, View } from 'react-native';
import React, { FC, useEffect } from 'react';
import LinearGradient from 'react-native-linear-gradient';

const Skeleton: FC = () => {
  const width = 300

  const AnimatedLinea = Animated.createAnimatedComponent(LinearGradient);
  const animatedValue = new Animated.Value(0);
  useEffect(() => {
    Animated.loop(
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 1000,
        easing: Easing.linear,
        useNativeDriver: true
      })
    ).start();
  }, []);

  const translateX = animatedValue.interpolate({
    inputRange: [-1, 1],
    outputRange: [-width, width]
  });
  return (

    <View style={{ backgroundColor: '#a0a0a0', height: 150, width: 300,  }}>
      <AnimatedLinea
        style={{

          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          transform: [{ translateX: translateX }]
        }}
        start={{ x: -1, y: 0.5 }}
        end={{ x: 2, y:0.5 }}
        colors={['#a0a0a0', '#b0b0b0', '#a0a0a0']}
      />
    </View>
  );
};

export default Skeleton;
