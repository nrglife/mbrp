import { ColorValue, StyleProp, View, ViewStyle } from "react-native";
import React, { FC } from "react";
import { useStores } from "../hooks/useStores";


interface SeparatorProps {
    width?: string,
    backgroundColor?: ColorValue,
    height?: number,
    style?: StyleProp<ViewStyle>;
}

const Separator: FC<SeparatorProps> = ({ width = "100%", backgroundColor, height = 1, style }) => {
    const { brandingStore } = useStores();
    if (!backgroundColor)
        backgroundColor = brandingStore.currentTheme.separatorOpaque;

    return (
        < View style={[{ width: '100%', alignItems: 'center' }, style]} >
            <View style={{ backgroundColor: backgroundColor, height: height, width: width }}>
            </View>
        </View >
    )
}
export default Separator
