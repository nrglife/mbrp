import { ColorValue, Image, Text, TextInputProps, TextStyle, TouchableWithoutFeedback, View, TextInput as OrigInput, TouchableOpacity } from 'react-native';
import React, { Component, FC, useEffect, useRef, useState } from 'react';
import { styles as stylesCreator } from './ch-text-input.styles';
import CHTextInputProps from './ch-text-input-props';
import { useStores } from '../../hooks/useStores';
import { TextInput, DefaultTheme } from 'react-native-paper';

import images from '../../assets/images/images';
import { RenderProps } from 'react-native-paper/lib/typescript/components/TextInput/types';

const CHTextInputAndroid: FC<CHTextInputProps> = props => {
  //return <TextInput    {...props} style = {[styles.main, props.style]} >{props.children}</TextInput>

  const stores = useStores();
  const Comp: React.ComponentType<React.ComponentPropsWithRef<typeof OrigInput>> = props.InputComponent ? props.InputComponent : OrigInput;

  const theme: ReactNativePaper.Theme = {
    ...DefaultTheme,
    mode: 'adaptive',
    colors: {
      ...DefaultTheme.colors,
      primary: stores.brandingStore.currentTheme.actionMedium,
      // background: 'white',
      // surface: 'yellow',
      //accent: 'green',
      error: stores.brandingStore.currentTheme.error,
      //,
      // onSurface: 'transparent',
      //  onBackground: 'transparent',
      disabled: stores.brandingStore.currentTheme.label,
      placeholder: stores.brandingStore.currentTheme.label,
      backdrop: stores.brandingStore.currentTheme.label
      //notification: 'cyan'
    }
  };

  const styles = stylesCreator(stores.brandingStore);
  const textStyles = stores.brandingStore.textStyles;
  const inputRef = useRef<OrigInput>();

  return (
    <View style={{ width: '100%' }}>
      <View style={[styles.container, props.style]}>
        <TextInput
          {...props}
          render={props => {
            return <Comp {...props} />;
          }}
          ref={inputRef}
          secureTextEntry={props.isSecureTextEntry}
          error={(props.error ? true : false) || (props.isError ? true : false)}
          underlineColor={props.error || props.isError ? 'red' : 'grey'}
          theme={theme}
          mode={'flat'}
          label="Email"
          {...props}
          style={[styles.main, props.inputStyle, { backgroundColor: stores.brandingStore.currentTheme.white, paddingRight: 35 }, textStyles.styleLargeRegular]}>
          {props.children}
        </TextInput>
        <View style={{ position: 'absolute', right: 19 }}>
          <TouchableWithoutFeedback onPress={() => props.setSecureTextEntry && props.setSecureTextEntry(prevState => !prevState)}>
            {props.passwordInput ? <Image style={{ height: 15, width: 22 }} source={!props.isSecureTextEntry ? images.eye : images.eyeHidden} /> : <View />}
          </TouchableWithoutFeedback>
          {props.enableClear ? (
            <TouchableOpacity
              style={styles.closeIconContainer}
              onPress={() => {
                inputRef.current.focus();
                //inputRef.current.forceFocus();
                props.onClear();
              }}>
              <Image style={styles.closeIcon} source={images.sheetClose} />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
      {props.toolTip && !props.error ? <Text style={[styles.tooltip, props.tooltipStyle, textStyles.styleSmallRegular]}>{props.toolTip}</Text> : null}
      {props.error ? <Text style={[styles.error, props.tooltipStyle, textStyles.styleSmallRegular]}>{props.error}</Text> : null}
    </View>
  );
};

export default CHTextInputAndroid;
