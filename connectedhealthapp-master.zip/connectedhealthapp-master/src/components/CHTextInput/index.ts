import { Platform } from 'react-native'
import CHTextInputAndroid from './ch-text-input-android'
import CHTextInputIOS from './ch-text-input-ios'

const  CHTextInput = Platform.OS === 'android'?CHTextInputAndroid:CHTextInputIOS;

export default CHTextInput;
