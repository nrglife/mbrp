import { StyleSheet, Platform, TextStyle, ViewStyle, ImageStyle } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const styleIOS: TextStyle = {
    flex: 1,
    textAlign: 'left',
    //height:52,
    // backgroundColor:'red',
    color: store.currentTheme.blackMain
  };
  const styleAndroid: TextStyle = {
    flex: 1,
    width: '100%',
    paddingStart: 1,

    color: store.currentTheme.blackMain
  };

  const labelStyleIOS: TextStyle = {
    marginRight: 10,
    flex: 1,

    color: store.currentTheme.label
  };
  const labelStyleAndroid: TextStyle = {};

  const tooltipStyleIOS: TextStyle = {
    marginRight: 25,
    marginLeft: 25,
    marginTop: 9,
    color: store.currentTheme.tooltip
  };
  const tooltipStyleAndroid: TextStyle = {
    marginRight: 27,
    marginLeft: 27,
    marginTop: 9,
    color: store.currentTheme.tooltip
    // backgroundColor:'blue'
  };

  const errorStyleIOS: TextStyle = {
    marginRight: 0,
    marginLeft: 0,
    marginTop: 0,
    paddingLeft: 18,
    paddingTop: 6,
    paddingBottom: 6,

    opacity: 1,
    height: 'auto',
    color: store.currentTheme.blackMain,
    position: 'relative'
  };
  const errorStyleAndroid: TextStyle = {
    marginRight: 27,
    marginLeft: 27,
    marginTop: 10,
    color: store.currentTheme.error
    // backgroundColor:'blue'
  };

  const errorContainerStyleIOS: TextStyle = {
    marginRight: 0,
    marginLeft: 0,
    marginTop: 0,
    paddingLeft: 18,
    paddingTop: 6,
    paddingBottom: 6,
    position: 'absolute',
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: store.currentTheme.error,
    opacity: 0.15
  };
  const errorContainerStyleAndroid: TextStyle = {
    marginRight: 27,
    marginLeft: 27,
    marginTop: 9,
    backgroundColor: store.currentTheme.error,
    color: store.currentTheme.blackMain
    // backgroundColor:'blue'
  };

  const containerStyleAndroid: ViewStyle = {
    flex: 1,
    flexDirection: 'row',
    // paddingTop: 20,
    // paddingBottom: 20,
    alignItems: 'center',
    justifyContent: 'flex-start',

    //borderBottomWidth: 1,
    marginLeft: 27,
    marginRight: 27
  };

  const containerStyleIOS: ViewStyle = {
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-start',
    borderTopWidth: 0,
    borderBottomWidth: 0,
    borderColor: store.currentTheme.separatorOpaque,
    borderStyle: 'solid',
    backgroundColor: store.currentTheme.white,
    height: 52,
    paddingLeft: 25,
    paddingRight: 25
  };

  interface Style {
    main: TextStyle;
    label: TextStyle;
    container: ViewStyle;
    tooltip: TextStyle;
    error: TextStyle;
    errorContainer: ViewStyle;
    closeIcon: ImageStyle;
    closeIconContainer: ViewStyle;
  }

  return StyleSheet.create<Style>({
    main: Platform.OS === 'android' ? styleAndroid : styleIOS,
    label: Platform.OS === 'android' ? labelStyleAndroid : labelStyleIOS,
    container: Platform.OS === 'android' ? containerStyleAndroid : containerStyleIOS,
    tooltip: Platform.OS === 'android' ? tooltipStyleAndroid : tooltipStyleIOS,
    error: Platform.OS === 'android' ? errorStyleAndroid : errorStyleIOS,
    errorContainer: Platform.OS === 'android' ? errorContainerStyleAndroid : errorContainerStyleIOS,
    closeIconContainer: { padding: 5, borderRadius: 10, overflow: 'hidden', backgroundColor: store.currentTheme.separatorOpaque },
    closeIcon: { width: 10, height: 10, resizeMode: 'contain', tintColor: store.currentTheme.blackSecondary }
  });
};
