import { TextInput, View, Text, Dimensions, Image, TouchableWithoutFeedback, TextInputProps, TouchableOpacity } from 'react-native';
import React, { FC, useRef, useState } from 'react';
import { styles as stylesCreator } from './ch-text-input.styles';
import CHTextInputProps from './ch-text-input-props';
import { useStores } from '../../hooks/useStores';
import images from '../../assets/images/images';

const CHTextInputIOS: FC<CHTextInputProps> = ({
  isError,
  passwordInput,
  setSecureTextEntry,
  isSecureTextEntry,
  error,
  style,
  label,
  labelStyle,
  inputStyle,
  toolTip,
  tooltipStyle,
  disableTooltip,
  children,
  ...props
}) => {
  const stores = useStores();
  const styles = stylesCreator(stores.brandingStore);

  const { width } = Dimensions.get('window');
  const textStyles = stores.brandingStore.textStyles;

  const Comp: React.ComponentType<React.ComponentPropsWithRef<typeof TextInput>> = props.InputComponent ? props.InputComponent : TextInput;

  const inputRef = useRef<TextInput>();

  return (
    <View style={{ width: '100%' }}>
      <TouchableWithoutFeedback
        onPress={() => {
          inputRef.current.focus();
        }}>
        <View style={[styles.container, style, (isError || error) && { borderBottomColor: 'red' }]}>
          <Text numberOfLines={1} style={[styles.label, props.labelWidth ? { flex: props.labelWidth / 10 } : null, textStyles.styleLargeSemiBold, labelStyle]} ellipsizeMode={'clip'}>
            {label}
          </Text>
          <Comp
            ref={inputRef}
            {...props}
            secureTextEntry={isSecureTextEntry}
            style={[
              styles.main,
              inputStyle,
              props.labelWidth ? { flex: 10 - props.labelWidth / 10 } : null,
              { position: 'absolute', width: '100%', paddingLeft: width * 0.54 },
              textStyles.styleLargeSemiBold
            ]}
            placeholderTextColor={stores.brandingStore.currentTheme.hint}>
            {children}
          </Comp>
          {props.enableClear ? (
            <TouchableOpacity
              style={styles.closeIconContainer}
              onPress={() => {
                props.onClear();
                inputRef.current.focus();
              }}>
              <Image style={styles.closeIcon} source={images.sheetClose} />
            </TouchableOpacity>
          ) : null}

          <TouchableWithoutFeedback
            onPress={() => {
              setSecureTextEntry && setSecureTextEntry(prevState => !prevState);
            }}>
            {passwordInput ? <Image style={{ height: 15, width: 22 }} source={!isSecureTextEntry ? images.eye : images.eyeHidden} /> : <View />}
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
      <View
        style={{
          marginLeft: 25,
          width: '100%',
          height: 1,
          backgroundColor: isError || error ? stores.brandingStore.currentTheme.error : stores.brandingStore.currentTheme.separatorOpaque
        }}></View>
      {disableTooltip ? null : (
        <View style={{ backgroundColor: error ? stores.brandingStore.currentTheme.errorBackground : null }}>
          <Text style={[error ? styles.error : styles.tooltip, tooltipStyle, textStyles.styleSmallRegular]}>{error ? error : toolTip}</Text>
        </View>
      )}
    </View>
  );
};

//    <View style={[error ? styles.errorContainer : null]}></View>

export default CHTextInputIOS;
