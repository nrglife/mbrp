import { interfaces } from 'inversify';
import { TextInputProps, TextStyle } from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { RenderProps } from 'react-native-paper/lib/typescript/components/TextInput/types';
import { Dispatch, SetStateAction } from 'react';

export default interface CHTextInputProps extends TextInputProps {
  label: string;
  labelStyle?: TextStyle;
  inputStyle?: TextStyle;
  toolTip?: string;
  tooltipStyle?: TextStyle;
  error?: string;
  isError?: boolean;
  labelWidth?: number;
  disableTooltip?: boolean;
  passwordInput?: boolean;
  InputComponent?: React.ComponentType<TextInputProps>;
  enableClear?: boolean;
  onClear?: () => void;
  isSecureTextEntry?: boolean;
  setSecureTextEntry?: Dispatch<SetStateAction<boolean>>;
}
