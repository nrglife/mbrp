import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  const insents = useSafeAreaInsets();

  return StyleSheet.create({
    main: {
      backgroundColor: store.currentTheme.white,
      width: '100%',
      flexDirection: 'column',
      borderTopLeftRadius: 12,
      borderTopRightRadius: 12,
      overflow: 'hidden',
      borderBottomWidth: 0.5,
      borderBottomColor: store.currentTheme.separatorOpaque,

      paddingBottom: 13
    },
    barContainer: { flexDirection: 'row', justifyContent: 'center' },
    bar: { height: 5, width: 36, backgroundColor: '#3C3C43', opacity: 0.33, borderRadius: 2.5, marginTop: 8, marginBottom: 8 },
    mainRow: { flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' },
    title: { marginLeft: 20 },
    closeContainer: { flexDirection: 'row', justifyContent: 'flex-end', flex: 1 },
    closeImage: { width: 17, height: 17, resizeMode: 'contain', position: 'relative', tintColor: '#3C3C43', opacity: 0.6 },
    closeButton: { backgroundColor: '#E5E5EA', marginRight: 18, height: 30, width: 30, borderRadius: 15, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }
  });
};
