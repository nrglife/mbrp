import React, { Component, FC, useEffect, useRef, useState } from 'react';
import { FlatList, StyleSheet, View, Text, TouchableOpacity, Button, Alert, Image, LayoutChangeEvent } from 'react-native';
import Animated from 'react-native-reanimated';
import images from '../../assets/images/images';
import { styles as styleCreator } from './ch-bottom-sheet-header.styles';
import { useStores } from '../../hooks/useStores';

interface CHBottomSheetHeaderProps {
  title: string;
  onClose: () => void;
  onLayout: (event: LayoutChangeEvent) => void;
  headerLeft?: () => Component | FC;
}

const CHBottomSheetHeader: FC<CHBottomSheetHeaderProps> = ({ title, onClose, onLayout, headerLeft }) => {
  const { brandingStore } = useStores();
  const styles = styleCreator(useStores().brandingStore);

  const HeaderLeftComp = headerLeft && headerLeft();

  return (
    <View onLayout={onLayout} style={styles.main}>
      <View style={styles.barContainer}>
        <View style={styles.bar}></View>
      </View>
      <View style={styles.mainRow}>
        {headerLeft ? (
          <View style={{}}>
            <HeaderLeftComp />
          </View>
        ) : null}

        <Text style={[styles.title, brandingStore.textStyles.styleLargeSemiBold]}>{title}</Text>
        <View style={styles.closeContainer}>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Image style={styles.closeImage} source={images.sheetClose} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default CHBottomSheetHeader;
