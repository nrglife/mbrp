import { Button, ButtonProps, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { FC, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { CHTouchableOpacityProps } from './ch-touchable-opacity-props';
import Icon from 'react-native-vector-icons/Ionicons';
import { useStores } from '../../hooks/useStores';
import { styles as stylesCreator } from './ch-touchable-opacity.styles';
import colorString from 'color-string';

const CHTouchableOpacity: FC<CHTouchableOpacityProps> = props => {
  const { brandingStore } = useStores();
  const { onPress, style, pressedColor, pressedColorOpacity, children } = props;
  const styles = stylesCreator(brandingStore, pressedColor, pressedColorOpacity);
  const [pressed, setPressed] = useState<boolean>(false);

  const onPressIn = () => {
    setPressed(true);
  };

  const onPressOut = () => {
    setPressed(false);
  };
  const rgba = colorString.get.rgb(pressedColor);
  const pressedColorComputed = colorString.to.rgb([rgba[0], rgba[1], rgba[2], pressedColorOpacity]);
  return (
    <TouchableOpacity {...props} onPress={onPress} activeOpacity={1} onPressIn={onPressIn} onPressOut={onPressOut} style={[style, pressed ? { backgroundColor: pressedColorComputed } : null]}>
      {children}
    </TouchableOpacity>
  );
};

export { CHTouchableOpacityProps, CHTouchableOpacity };
