import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';


export const styles =  (store: BrandingStoreMobile, pressedColor: string, pressedColorOpacity: number, )=>{


    return StyleSheet.create({

})

}



