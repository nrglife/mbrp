import { Platform } from 'react-native'
import {CHTouchableOpacity} from './ch-touchable-opacity'


export default CHTouchableOpacity;