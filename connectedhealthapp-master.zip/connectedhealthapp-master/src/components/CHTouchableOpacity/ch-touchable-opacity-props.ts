import { ButtonProps, GestureResponderEvent, TouchableOpacityProps, ViewProps, ViewStyle } from 'react-native';

export interface CHTouchableOpacityProps extends TouchableOpacityProps{
  onPress:(e:GestureResponderEvent)=>void;
  style?: ViewStyle;
  pressedColor: string; 
  pressedColorOpacity: number;
}
