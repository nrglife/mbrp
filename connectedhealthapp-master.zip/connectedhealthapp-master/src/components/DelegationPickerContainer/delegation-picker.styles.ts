import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    main: { flex: 1, flexDirection: 'column' },
    children: { flex: 1 },
    picker: { position: 'absolute', flex: 1, width: '100%', height: '100%' }
  });
};
