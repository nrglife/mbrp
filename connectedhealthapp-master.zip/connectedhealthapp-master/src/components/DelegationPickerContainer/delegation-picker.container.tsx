import { useImperativeHandle, useState } from 'react';
import { View, ViewProps, ScrollView } from 'react-native';
import DelegationPickerComponent, { PickerType, VisiblityMode } from '../DelegationPicker/delegation-picker.component';
import React from 'react';
import { styles as styleCreator } from './delegation-picker.styles';
import { useStores } from '../../hooks/useStores';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';

interface DelegationPickerContainerProps extends ViewProps {
  pickerType?: PickerType;
  visiblityMode?: VisiblityMode;
  wrapInScrollView?: boolean;
}
export interface DelegationPickerContainerInterface {
  onMainViewScroll: (offset: number) => void;
  contentMarginTop: number;
}

export const DelegationPickerContainer = React.forwardRef<DelegationPickerContainerInterface, DelegationPickerContainerProps>((props, ref) => {
  const [show, setShow] = useState<boolean>(true);
  const { brandingStore, delegateStore } = useStores();
  const styles = styleCreator(brandingStore);
  const { wrapInScrollView = false, pickerType = PickerType.Default, visiblityMode = VisiblityMode.MoreThanOne } = props;

  const { delegateMenu } = delegateStore;
  const isVisible = visiblityMode === VisiblityMode.Always || (visiblityMode === VisiblityMode.MoreThanOne && delegateMenu);

  const delegateSelectorHeight = pickerType !== PickerType.ReadOnly ? DELEGATE_SELECTOR_HEIGHT : DELEGATE_SELECTOR_READONLY_HEIGHT;

  useImperativeHandle(ref, () => ({
    onMainViewScroll: (offset: number) => {
      if (offset <= delegateSelectorHeight) {
        setShow(true);
      } else {
        setShow(false);
      }
    },
    contentMarginTop: (delegateStore.state === DelegateStoreState.Running || delegateStore.state === DelegateStoreState.RunningShowError) && delegateStore.delegateMenu ? delegateSelectorHeight : 0
  }));
  return (
    <View pointerEvents="box-none" style={styles.main}>
      {wrapInScrollView !== true ? (
        <View style={styles.children}>{props.children}</View>
      ) : (
        <View style={styles.children}>
          <ScrollView
            style={{
              flex: 1,
              backgroundColor: brandingStore.currentTheme.white,
              paddingTop:
                (delegateStore.state === DelegateStoreState.Running || delegateStore.state === DelegateStoreState.RunningShowError) && delegateStore.delegateMenu ? delegateSelectorHeight : 0
            }}
            contentContainerStyle={{ flexGrow: 1 }}
            scrollEventThrottle={200}
            onScroll={event => {
              if (event.nativeEvent.contentOffset.y <= delegateSelectorHeight) {
                setShow(true);
              } else {
                setShow(false);
              }
            }}>
            {props.children}
          </ScrollView>
        </View>
      )}
      {(delegateStore.state === DelegateStoreState.Running || delegateStore.state === DelegateStoreState.RunningShowError) && isVisible && show && (
        <View pointerEvents="box-none" style={styles.picker}>
          {(delegateStore.state === DelegateStoreState.Running || delegateStore.state === DelegateStoreState.RunningShowError) && <DelegationPickerComponent pickerType={pickerType} />}
        </View>
      )}
    </View>
  );
});

export const DELEGATE_SELECTOR_HEIGHT = 41;
export const DELEGATE_SELECTOR_READONLY_HEIGHT = 33;
export { PickerType, VisiblityMode };
