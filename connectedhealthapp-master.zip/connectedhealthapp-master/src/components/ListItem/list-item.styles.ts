import { ImageStyle, Platform, StyleSheet, TextStyle, ViewStyle } from 'react-native';
import { globals } from '../../../../../globals';
import BrandingStoreMobile from '../../../../../stores/BrandingStoreMobile';

export const styles = (brandingStore: BrandingStoreMobile) => {
  return StyleSheet.create({
    icon: {
      marginLeft: 18,
      marginRight: 11,
      marginTop: 11,
      marginBottom: 11
    },
    text: {
      marginRight: 12,
      flexDirection: 'column',
      marginTop: 0,
      marginBottom: 0,
      flex: 1,
      justifyContent: 'center'
    },
    main: { flexDirection: 'column', width: '100%', alignItems: 'center' },
    borderContainer: { width: '100%', flexDirection: 'row' },
    border: { flex: 1, flexDirection: 'row', height: 1, backgroundColor: brandingStore.currentTheme.separatorOpaque, marginLeft: 90, marginRight: 12 }
  });
};
