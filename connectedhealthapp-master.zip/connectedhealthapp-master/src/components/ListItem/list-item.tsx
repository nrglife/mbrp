import React, { FC, useCallback, useState } from 'react';
import { Text, View } from 'react-native';

import { styles as styleCreator } from './list-item.styles';
import { useStores } from '../../hooks/useStores';
import { CHAppIcon, CHTouchableOpacity } from '../index';

interface ListItemProps {
  name: string;
  description: string;
  logo: string;
  onSelected?: () => void;
  last?: boolean;
}

export const ListItem: FC<ListItemProps> = ({ logo, name, description, onSelected, last }) => {
  const { brandingStore, payerStore, generalStore } = useStores();

  const textStyles = brandingStore.textStyles;
  const styles = styleCreator(brandingStore);
  const handleLinkPress = useCallback(() => {
    generalStore.contactUsSheetRef.current.open();
  }, []);
  const [titleLines, setTitleLines] = useState(0);

  const onTitleLayout = useCallback(({ nativeEvent: { lines } }) => {
    setTitleLines(lines.length);
  }, []);

  return (
    <CHTouchableOpacity pressedColor={brandingStore.currentTheme.backgroundMedium} pressedColorOpacity={0.5} onPress={onSelected} style={styles.main}>
      <View style={{ flexDirection: 'row' }}>
        <CHAppIcon style={styles.icon} source={{ uri: logo }} size={61} />
        <View style={styles.text}>
          <Text onTextLayout={onTitleLayout} numberOfLines={2} style={[textStyles.styleSmallSemiBold, { color: brandingStore.currentTheme.blackMain }]}>
            {name}
          </Text>
          <Text numberOfLines={3 - titleLines} style={[textStyles.styleXSmallRegular, { color: brandingStore.currentTheme.blackMain }]}>
            {description}
          </Text>
        </View>
      </View>
      {!last ? (
        <View style={styles.borderContainer}>
          <View style={styles.border} />
        </View>
      ) : null}
    </CHTouchableOpacity>
  );
};
