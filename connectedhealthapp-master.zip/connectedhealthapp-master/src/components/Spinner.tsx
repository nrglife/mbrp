import React, { FC } from 'react';
import {ActivityIndicator, ActivityIndicatorProps, Platform, View} from 'react-native';

declare interface AppSpinnerProps extends ActivityIndicatorProps{
  containerBackgroundColor?: string;
}

const Spinner: React.FC<AppSpinnerProps> = ({ containerBackgroundColor,...props }) => {
  return (
    <View
      style={{
        backgroundColor: containerBackgroundColor ? containerBackgroundColor : 'transparent',
        width: '100%',
        height: '100%',
        position: 'absolute',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
      }}>
      <ActivityIndicator {...props} />
    </View>
  );
};

export default Spinner;
