import { StyleSheet } from 'react-native';
import BrandingStoreMobile from "../../../stores/BrandingStoreMobile";


export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: {
      flexDirection: 'row',
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center'
    },
    url: {
      marginStart: 5
    },
    urlSecure: {
      color: '#63ae75'
    }  });
};


