import React, { useCallback } from 'react';
import { View, StyleProp } from 'react-native';
//third party

import { WebView, WebViewProps } from 'react-native-webview';

//styles
import { styles } from './ciam-login.styles';
import { OnShouldStartLoadWithRequest } from 'react-native-webview/lib/WebViewTypes';

interface CIAMLoginComponentProps extends WebViewProps {
  source: any;
  webViewStyles: StyleProp<any>;
  onShouldStartLoadWithRequest: OnShouldStartLoadWithRequest & Function;
  onError: () => void;
  onLoadStart: ({ nativeEvent }: any) => void;
  onLoadEnd: ({ nativeEvent }: any) => void;
  renderLoadingComponent: JSX.Element;
}

export const CIAMLoginComponent = React.forwardRef<WebView, CIAMLoginComponentProps>(
  ({ source, onLoadStart, onLoadEnd, webViewStyles, onShouldStartLoadWithRequest, onError, renderLoadingComponent }, forwardedRef) => {
    const errorCallback = useCallback(onError, []);
    const startCallback = useCallback(onLoadStart, []);
    const endCallback = useCallback(onLoadEnd, []);
    return (
      <View style={styles.container}>
        {renderLoadingComponent}

        <WebView
          style={webViewStyles}
          onShouldStartLoadWithRequest={onShouldStartLoadWithRequest}
          onError={errorCallback}
          incognito={false}
          ref={forwardedRef}
          source={source}
          onLoadStart={startCallback}
          onLoadEnd={endCallback}
        />
      </View>
    );
  }
);
