import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { View, TouchableOpacity, Image } from 'react-native';

import { styles } from './back-button.styles';
import images from "../../../assets/images/images";
export const BackButton = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image source={images.backButton} style={styles.iconStyle} />
      </TouchableOpacity>
    </View>
  );
};
