import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: { marginStart: 10 },
  iconStyle: { width: 25, height: 25, tintColor: '#307cf6', resizeMode: 'center' }
});
