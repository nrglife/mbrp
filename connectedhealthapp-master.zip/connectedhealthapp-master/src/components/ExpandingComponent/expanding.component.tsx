import React, { FC, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';

import { styles as stylesCreator } from './expanding.styles';

import Animated, { Easing, Transition, Transitioning, TransitioningView } from 'react-native-reanimated';
import { useStores } from '../../hooks/useStores';
import { ServicesItem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
import { CHTouchableOpacity } from '../index';

interface ExpandingComponentProps {
  titleComponent: Element;
  bodyComponent: Element;
  transitioningViewRef: React.MutableRefObject<TransitioningView>;
  //data: ServicesItem;
  onExpendedCallback?: (boolean) => void;
}

export interface ExpandingComponentInterface {
  expand: () => void;
}

export const ExpandingComponent = React.forwardRef<ExpandingComponentInterface, ExpandingComponentProps>(({ onExpendedCallback, titleComponent, bodyComponent, transitioningViewRef }, ref) => {
  const [expanded, setExpanded] = useState<boolean>(false);
  const { brandingStore } = useStores();

  useImperativeHandle(ref, () => ({
    expand: () => {
      expandHandler();
    }
  }));

  const expandHandler = () => {
    transitioningViewRef.current.animateNextTransition();

    setExpanded(prev => {
      onExpendedCallback && onExpendedCallback(!prev);
      return !prev;
    });
  };

  const styles = stylesCreator(brandingStore);

  return (
    <View style={styles.main}>
      <CHTouchableOpacity pressedColor={brandingStore.currentTheme.backgroundMedium} pressedColorOpacity={0.5} onPress={expandHandler} style={styles.touchableOpacity}>
        {titleComponent}
      </CHTouchableOpacity>

      <View style={styles.expandable}>{expanded ? bodyComponent : null}</View>
    </View>
  );
});
