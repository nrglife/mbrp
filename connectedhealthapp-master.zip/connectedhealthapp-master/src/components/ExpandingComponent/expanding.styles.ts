import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';


export const styles =  (store: BrandingStoreMobile)=>{


  return StyleSheet.create({
    main: { width: '100%', flexDirection: 'column', flexGrow: 1 },
    touchableOpacity: { width: '100%', backgroundColor:'white' },
    expandable: { width: '100%', flexGrow: 1, flexDirection: 'column' }

    })
}




