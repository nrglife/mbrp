import React, { Dispatch, FC, SetStateAction, useCallback, useState } from 'react';
import { observer } from 'mobx-react';
import { Text, View, Image, ViewStyle, Linking, NativeSyntheticEvent, TextLayoutEventData } from 'react-native';

import { styles as styleCreator } from './contact-box.styles';
import { useStores } from '../../../hooks/useStores';

import images from '../../../assets/images/images';
import SendEmailHelper from '../../../utilities/helpers/SendEmailHelper';
import { callNumber } from '../../../utilities/linking';

interface ContactBoxProps {
  title?: string;
  companyName?: string;
  description: string;
  email?: string;
  phone?: string;
  style?: ViewStyle;
  address?: string;
}

const ContactBox: FC<ContactBoxProps> = ({ title, companyName, description, email, phone, style, address }) => {
  const { brandingStore, payerStore } = useStores();
  const [breakEmail, setBreakEmail] = useState<boolean | undefined>();
  const onEmailLayout = useCallback((e: NativeSyntheticEvent<TextLayoutEventData>) => {
    setBreakEmail(e.nativeEvent.lines.length > 1);
  }, []);
  const styles = styleCreator(brandingStore);
  const textStyles = brandingStore.textStyles;

  const handleCall = () => {
    callNumber(phone);
  };
  const callPhoneCallBack = useCallback(handleCall, [phone]);
  const handleSendEmail = () => {
    const subject = '';
    const recipients = [email];
    const body = '';

    const mailOptions = {
      subject,
      recipients,
      body,
      isHTML: true
    };

    try {
      SendEmailHelper((isError, message) => {}, mailOptions);
    } catch (error) {}
  };
  const sendEmailCallback = useCallback(handleSendEmail, [email]);

  return (
    <View style={[styles.main, style]}>
      {!!title && <Text style={[styles.title, textStyles.styleLargeBold]}>{title}</Text>}
      {!!companyName && <Text style={[styles.companyName, textStyles.styleLargeRegular]}>{companyName}</Text>}
      {!!description && <Text style={[styles.description, textStyles.styleSmallRegular]}>{description}</Text>}
      {!!phone && (
        <View style={styles.phoneContainer}>
          <Image style={styles.phoneImage} source={images.contactPhone} />
          <Text onPress={callPhoneCallBack} style={[styles.phone, textStyles.styleSmallSemiBoldLink]}>
            {phone}
          </Text>
        </View>
      )}
      {!!email && (
        <View style={styles.emailContainer}>
          <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <Text style={[{ opacity: 0 }, textStyles.styleSmallSemiBold]}>C</Text>
            <Image style={styles.emailImage} source={images.newEmailIcon} />
          </View>
          <Text onTextLayout={onEmailLayout} onPress={sendEmailCallback} style={[styles.email, textStyles.styleSmallSemiBoldLink]}>
            {breakEmail ? email.split('@')[0] + '\n@' + email.split('@')[1] : email}
          </Text>
        </View>
      )}
      {!!address && (
        <View style={styles.addressContainer}>
          <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <Text style={[{ opacity: 0 }, textStyles.styleSmallSemiBold]}>C</Text>
            <Image style={styles.addressImage} source={images.contactEmail} />
          </View>
          <Text style={[styles.address, textStyles.styleSmallRegular]}>{address}</Text>
        </View>
      )}
    </View>
  );
};

export default observer(ContactBox);
