import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../../stores/BrandingStoreMobile';

export const styles = (brandingStore: BrandingStoreMobile) => {
  return StyleSheet.create({
    main: {},
    title: { color: brandingStore.currentTheme.blackSecondary },
    companyName: { color: brandingStore.currentTheme.blackMain, marginTop: 13 },
    description: { color: brandingStore.currentTheme.blackSecondary, marginTop: 10 },
    phoneContainer: { flexDirection: 'row', marginTop: 21, alignItems: 'center' },
    emailContainer: { flexDirection: 'row', marginTop: 16, alignItems: 'flex-start' },
    addressContainer: { flexDirection: 'row', marginTop: 19, alignItems: 'flex-start', justifyContent: 'flex-start' },

    phone: { color: brandingStore.currentTheme.actionMedium, marginLeft: 10 },
    email: { color: brandingStore.currentTheme.actionMedium, marginLeft: 10 },
    address: { color: brandingStore.currentTheme.blackMain, marginLeft: 10 },
    phoneImage: { width: 15, height: 15, tintColor: brandingStore.currentTheme.actionMedium, resizeMode: 'contain' },
    addressImage: { width: 15, height: 15, tintColor: brandingStore.currentTheme.tooltip, resizeMode: 'contain', opacity: 1, position: 'absolute' },
    emailImage: { width: 15, height: 15, tintColor: brandingStore.currentTheme.actionMedium, resizeMode: 'contain', position: 'absolute' }
  });
};
