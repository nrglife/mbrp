import React, { Dispatch, FC, SetStateAction } from 'react';
import { observer } from 'mobx-react';
import { Text, View } from 'react-native';

import { styles as styleCreator } from './contact-modal.styles';
import { useStores } from '../../hooks/useStores';
import ContactBox from './Components/contact-box';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface ContactModalProps {
  reverse?: boolean;
}

const ContactModal: FC<ContactModalProps> = ({ reverse }) => {
  const { brandingStore, payerStore, generalStore, appConfigStore } = useStores();
  const { bottom } = useSafeAreaInsets();
  const styles = styleCreator(brandingStore, bottom);

  const technicalAppSupportDisplay = !!(generalStore.primaryPhone?.trim() || generalStore.primaryEmail?.trim())
    && generalStore.appSupportVisible;

  const insuranceSupportDisplay = !!(payerStore?.primaryPhone?.trim() || payerStore?.primaryEmail?.trim() || payerStore?.payer?.address?.trim())
    && generalStore.insuranceSupportVisible;

  let boxes: JSX.Element[] = [];
  if (technicalAppSupportDisplay)
    boxes.push(<ContactBox
      key={0}
      style={{ marginTop: insuranceSupportDisplay && reverse ? 41 : 0 }}
      title={insuranceSupportDisplay ? 'Technical & App Issues' : generalStore.supportName}
      companyName={insuranceSupportDisplay ? generalStore.supportName : null}
      description={insuranceSupportDisplay ? 'For technical issues with the website or app' : null}
      phone={generalStore.primaryPhone}
      email={generalStore.primaryEmail}
    />);

  let payerNameMemberSupport = !!payerStore?.payerName ? payerStore?.payerName + ' Member Support' : '';
  let payerAddress = "";
  if(payerStore?.payer?.address?.trim())
  {
    payerAddress = payerStore.payerName ? payerStore.payerName + '\n' + payerStore.payer.address : payerStore.payer.address
  }

  if (insuranceSupportDisplay)
    boxes.push(<ContactBox
      key={1}
      style={{ marginTop: technicalAppSupportDisplay && !reverse ? 41 : 0 }}
      title={technicalAppSupportDisplay ? 'Insurance, Billing & Benefits' : payerNameMemberSupport}
      companyName={technicalAppSupportDisplay ? payerNameMemberSupport : null}
      description={technicalAppSupportDisplay ? 'For general questions related to insurance coverage, provider networks, billing, and medical.' : null}
      phone={payerStore.primaryPhone}
      email={payerStore.primaryEmail}
      address={payerAddress}
    />);

  if (!technicalAppSupportDisplay && !insuranceSupportDisplay)
    boxes.push(<ContactBox
      key={2}
      description={`Call the number on your ${!!payerStore?.payerName ? payerStore?.payerName + ' ' : ''}insurance card.`}
    />);

  return <View style={styles.main}>{reverse ? boxes.reverse() : boxes}</View>;
};
export default observer(ContactModal);

