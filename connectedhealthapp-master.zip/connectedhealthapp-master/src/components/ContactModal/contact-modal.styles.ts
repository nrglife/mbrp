import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile, bottom: number) => {
  return StyleSheet.create({
    main: {
      width: '100%',
      paddingTop: 20,
      paddingLeft: 21,
      paddingRight: 21,
      backgroundColor: store.currentTheme.white,
      paddingBottom: bottom == 0 ? 20 : 0
    }
  });
};
