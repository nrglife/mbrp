import {Text, View, ViewProps} from "react-native";
import BrandingStoreMobile from "../../stores/BrandingStoreMobile";
import {InsuranceData} from "../../hooks/useModularNavigation";
import React, {FC} from "react";
import {CHAppIcon} from "../index";

declare interface PayerIconProps extends ViewProps {
  brandingStore: BrandingStoreMobile;
  insuranceData: InsuranceData;
}

const PayerIcon: FC<PayerIconProps> = ({ brandingStore, insuranceData, ...props }) => {
  return (
    <View {...props}>
      <CHAppIcon
        size={104}
        style={{
          marginRight: 12,
          marginBottom: 20,
          resizeMode: 'contain'
        }}
        source={{ uri: insuranceData.icon }}
      />

      <View style={{ flex: 1 }}>
        <Text style={{ ...brandingStore.textStyles.styleLargeSemiBold }}>{insuranceData.name}</Text>
        <View style={{ flexDirection: 'row' }}>
          <Text
            style={{
              flex: 1,
              flexWrap: 'wrap',
              ...brandingStore.textStyles.styleXSmallRegular
            }}>
            {insuranceData.types}
          </Text>
        </View>
      </View>
    </View>
  );
};

export default PayerIcon
