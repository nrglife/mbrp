import React, { useEffect, useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Animated, Easing, LayoutAnimation, UIManager, Dimensions, TextStyle } from 'react-native';
import { CHReadMoreProps } from './read-more-component-props';

const CustomLayoutSpring = {
  duration: 450,
  create: {
    type: LayoutAnimation.Types.spring,
    property: LayoutAnimation.Properties.scaleXY,
    springDamping: 0.7
  },
  update: {
    type: LayoutAnimation.Types.spring,
    springDamping: 0.7
  }
};

const CHReadMore: React.FC<CHReadMoreProps> = ({ moreText = 'more', lessText = 'less', children, maxLines = 2, style, moreStyle, lessStyle }) => {
  const [expanded, setExpanded] = useState<boolean>(false);
  const [displayTextLength, setDisplayTextLength] = useState<number>(0);
  const [subtractLetters, setSubtractLetters] = useState<number>(0);
  const [layoutComplete, setLayoutComplete] = useState<boolean>(false);
  const [expandable, setExpandable] = useState<boolean>(false);
  const [firstPassLayoutDone, setFirstPassLayoutDone] = useState<boolean>(false);

  useEffect(() => {
    UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);
  }, []);

  const _onReadMorePressHandler = () => {
    LayoutAnimation.configureNext(CustomLayoutSpring);
    setExpanded(val => !val);
  };

  const _renderHiddenTextElement = () => {
    return (
      <View style={{ position: 'absolute', left: Dimensions.get('window').width + 20 }}>
        {React.cloneElement(
          <Text
            style={style}
            onTextLayout={({ nativeEvent: { lines } }) => {
              setFirstPassLayoutDone(true);
              let shortTextLength = 0;
              lines.forEach((line, index) => {
                if (index < maxLines) {
                  shortTextLength = shortTextLength + line.text.length;
                }
              });
              setDisplayTextLength(shortTextLength);
              if (lines.length > maxLines) {
                setExpandable(true);
              } else {
                setExpandable(false);
                setLayoutComplete(true);
              }
            }}>
            {children}
          </Text>
        )}
      </View>
    );
  };

  let shortText = children ? children.substring(0, displayTextLength - subtractLetters) + '...' : '';

  const _renderHiddenTextElement2 = () => {
    return (
      <View style={{ position: 'absolute', left: Dimensions.get('window').width + 20 }}>
        {React.cloneElement(
          <Text
            style={style}
            onTextLayout={({ nativeEvent: { lines } }) => {
              if (lines.length > maxLines) {
                setSubtractLetters(subtractLetters + 1);
              } else {
                setLayoutComplete(true);
              }
            }}>
            {shortText}
            <Text style={moreStyle}>{' ' + moreText}</Text>
          </Text>
        )}
      </View>
    );
  };

  return (
    <View pointerEvents={'box-none'}>
      {layoutComplete ? (
        <Text numberOfLines={expanded ? null : maxLines} style={style}>
          {expanded || !expandable ? children : shortText}
          {expandable ? (
            <Text style={expanded ? lessStyle : moreStyle} onPress={_onReadMorePressHandler}>
              {!expanded ? ' ' + moreText : ' ' + lessText}
            </Text>
          ) : null}
        </Text>
      ) : null}
      {!firstPassLayoutDone ? _renderHiddenTextElement() : null}
      {!layoutComplete && firstPassLayoutDone ? _renderHiddenTextElement2() : null}
    </View>
  );
};

export default CHReadMore;
