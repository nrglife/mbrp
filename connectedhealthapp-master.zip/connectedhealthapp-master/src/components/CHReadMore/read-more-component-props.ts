import { StyleProp, TextStyle } from "react-native";

export interface CHReadMoreProps {
    moreText?: string;
    lessText?: string;
    maxLines?: number;
    style?: StyleProp<TextStyle>;
    children: string;
    moreStyle?: TextStyle;
    lessStyle?: TextStyle;
}
