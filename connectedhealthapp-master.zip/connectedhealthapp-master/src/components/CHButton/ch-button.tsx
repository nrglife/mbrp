import { Button, ButtonProps} from 'react-native';
import React, { FC } from 'react';

const CHButton: FC<ButtonProps> = (props) => {
    return <Button    {...props}  >{props.children}</Button>
}

export default CHButton