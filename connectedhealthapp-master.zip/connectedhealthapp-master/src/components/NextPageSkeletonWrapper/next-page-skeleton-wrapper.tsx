import React, { FC } from 'react';
import { View } from 'react-native';

import SkeletonNextPageError from '../SkeletonNextPageError/skeleton-next-page-error';

const NextPageSkeletonWrapper: React.FC<{
  nextPageError: boolean;
  loadNextPage: () => void;
  loadingNextPage: boolean;
}> = ({ loadingNextPage, loadNextPage, nextPageError, children }) => {
  if (!loadingNextPage && !nextPageError) {
    return null;
  }
  return (
    <View style={{ backgroundColor: !loadingNextPage && nextPageError ? 'transparent' : 'white' , marginTop:10}}>
      <View style={{ opacity: !loadingNextPage && nextPageError ? 0 : 1 }}>{children}</View>
      {!loadingNextPage && nextPageError && (
        <View style={{ position: 'absolute' }}>
          <SkeletonNextPageError loadNextPage={loadNextPage} loadingNextPage={loadingNextPage} />
        </View>
      )}
    </View>
  );
};

export default NextPageSkeletonWrapper;
