import React, { Component } from 'react';
import { ButtonProps, TouchableOpacityProps, ViewProps, ViewStyle } from 'react-native';

export interface CHBottomSheetProps extends ViewProps{
 
  label: string;
  children: any;
  snapPoints: (number | string)[];
  backgroundInteractions: boolean;
  onMeasureHeight?: (h:number)=>void;
  onOpenEnd?:()=>void;
  onClose?:()=>void;
  headerLeft?: ()=>Component| React.FC
}

export interface CHBottomSheetInterface {
  open: () => void;
  close: () => void;
}
