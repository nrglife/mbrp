import { Button, ButtonProps, Keyboard, Text, TouchableOpacity, View, Platform } from 'react-native';
import React, { FC, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { CHBottomSheetProps, CHBottomSheetInterface } from './ch-bottom-sheet-props';
import Icon from 'react-native-vector-icons/Ionicons';
import { useStores } from '../../hooks/useStores';
import BottomSheet from 'reanimated-bottom-sheet';
import CHBottomSheetHeader from '../CHBottomSheetHeader/ch-bottom-sheet-header';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { styles as stylesCreator } from './ch-bottom-sheet.styles';

const CHBottomSheet = React.forwardRef<CHBottomSheetInterface, CHBottomSheetProps>((props, ref) => {
  const { brandingStore } = useStores();

  const textStyles = brandingStore.textStyles;
  const sheetRef = React.useRef<BottomSheet>(null);

  const [sheetVisible, setSheetVisible] = useState<boolean>(false);
  const { top } = useSafeAreaInsets();
  const styles = stylesCreator(brandingStore);
  const [headerHeight, setHeaderHeight] = useState<number>(0);
  const [contentHeight, setContentHeight] = useState<number>(0);
  const [keyoardVisible, setKeyboardVisible] = useState<boolean>(false);
  const [closeTime, setCloseTime] = useState<Date>(new Date());

  const _keyboardDidHide = () => {
    setKeyboardVisible(false);
  };

  const _keyboardDidShow = () => {
    setKeyboardVisible(true);
  };

  useEffect(() => {
    const keyboardDidShowSub = Keyboard.addListener('keyboardDidShow', _keyboardDidShow);
    const keyboardDidHideSub = Keyboard.addListener('keyboardDidHide', _keyboardDidHide);
    return () => {
      keyboardDidShowSub.remove()
      keyboardDidHideSub.remove()
    };
  }, []);
  useEffect(() => {
    props.onMeasureHeight && props.onMeasureHeight(headerHeight + contentHeight);
  }, [headerHeight, contentHeight]);

  // console.log('sheet snap points', props.snapPoints);

  const renderContent = () => {
    return (
      <View style={styles.content}>
        <View style={{ width: '100%' }}>{props.children}</View>
      </View>
    );
  };

  const closeInternal = () => {
    sheetRef.current.snapTo(props.snapPoints.length - 1);
  };

  let key = 'sheet_' + keyoardVisible + '_' + closeTime + '_';
  props.snapPoints.forEach(point => {
    key = key + '_' + point;
  });

  useImperativeHandle(ref, () => ({
    open: () => {
      //

      if (keyoardVisible) {
        Keyboard.dismiss();

        setTimeout(
          () => {
            sheetRef.current.snapTo(props.snapPoints.length - 2);
          },
          Platform.OS === 'android' ? 1500 : 1000
        );
      } else {
        sheetRef.current.snapTo(props.snapPoints.length - 2);
      }
    },
    close: () => {
      closeInternal();
    }
  }));

  const onCloseEnd = () => {
    setSheetVisible(false);
    if (props.onClose) {
      props.onClose();
    }
    setCloseTime(new Date());
  };

  const onOpenEnd = () => {
    if (props.onOpenEnd) {
      props.onOpenEnd();
    }
  };

  const onOpenStart = () => {
    setSheetVisible(true);
  };

  //console.log('keyyyyyyyyyyyyyyy', key, sheetVisible);

  return (
    <View pointerEvents={'box-none'} style={styles.main}>
      <View pointerEvents={'none'} style={styles.duplicateView}>
        <View
          style={{ width: '100%' }}
          onLayout={e => {
            if (e.nativeEvent.layout.height !== 0) {
              setContentHeight(e.nativeEvent.layout.height);
            }
          }}>
          {React.cloneElement(props.children)}
        </View>
      </View>
      {sheetVisible ? <View pointerEvents={props.backgroundInteractions ? 'box-none' : 'auto'} style={styles.overlay}></View> : null}
      <View pointerEvents={sheetVisible == false ? 'none' : 'box-none'} style={[styles.sheetContainer, { opacity: sheetVisible ? 1 : 0 }]}>
        <BottomSheet
          key={key}
          ref={sheetRef}
          renderHeader={() => {
            return (
              <CHBottomSheetHeader
                headerLeft={props.headerLeft}
                onLayout={e => {
                  if (e.nativeEvent.layout.height !== 0) {
                    setHeaderHeight(e.nativeEvent.layout.height);
                  }
                }}
                onClose={closeInternal}
                title={props.label}
              />
            );
          }}
          snapPoints={props.snapPoints}
          initialSnap={sheetVisible ? props.snapPoints.length - 2 : props.snapPoints.length - 1}
          renderContent={renderContent}
          onCloseEnd={onCloseEnd}
          onOpenStart={onOpenStart}
          onOpenEnd={onOpenEnd}
          enabledHeaderGestureInteraction={true}
          enabledGestureInteraction={true}
          enabledContentGestureInteraction={true}
        />
      </View>
    </View>
  );
});

export { CHBottomSheet, CHBottomSheetProps, CHBottomSheetInterface };
