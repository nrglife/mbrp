import { StatusBar, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (brandingStore: BrandingStoreMobile) => {
  const { top } = useSafeAreaInsets();
  return StyleSheet.create({
    main: { width: '100%', height: '100%', position: 'absolute', flexDirection: 'column' },
    overlay: { width: '100%', height: '100%', position: 'absolute', backgroundColor: 'black', opacity: 0.2 },
    sheetContainer: { marginTop: top ? top : StatusBar.currentHeight, width: '100%', flex: 1, position: 'relative' },
    content: { width: '100%', backgroundColor: brandingStore.currentTheme.white, height: '100%' },
    duplicateView: { width: '100%', backgroundColor: brandingStore.currentTheme.white, height: '100%', opacity: 0, position: 'absolute' }
  });
};
