import { StyleSheet } from 'react-native';
import BrandingStoreMobile from '../../stores/BrandingStoreMobile';

export const styles = (store: BrandingStoreMobile) => {
  return StyleSheet.create({
    container: {
      marginTop: 12,
      marginBottom: 12,
      marginLeft: 21,
      flexDirection: 'row'
    },
    tooltipStyles: { color: store.currentTheme.tooltip, paddingBottom: 0, ...store.textStyles.styleSmallRegular },
    touchableOpacityStyles: { paddingBottom: 0 },
    touchableOpacityTextStyles: { color: store.currentTheme.actionMedium, ...store.textStyles.styleSmallSemiBold },
    sectionDate: { ...store.textStyles.styleXSmallSemiBold },
    sectionFacility: { ...store.textStyles.styleXSmallRegular },
    textStyle: { textAlign: 'center', color: store.currentTheme.tooltip, marginTop: 16 },
    logoAndTitleContainer: { marginTop: 99, justifyContent: 'center', alignItems: 'center' },
    flexGrow: { flexGrow: 1 },
    flex: { flex: 1 },
    listFooterComponentStyles: { marginTop: 18, marginBottom: 36 }
  });
};
