import React, { FC } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

import { styles as stylesCreator } from './next-page-error-styles';
import { useStores } from '../../hooks/useStores';

type MedicationListProps = { loadNextPage: () => void; isNextPageLoading: boolean; errorMessage: string; actionText: string };

const NextPageError: FC<MedicationListProps> = ({ loadNextPage, isNextPageLoading, errorMessage, actionText }) => {
  const { brandingStore } = useStores();
  const styles = stylesCreator(brandingStore);

  return (
    <View style={styles.container}>
      <Text style={styles.tooltipStyles}>{`${errorMessage}. `}</Text>
      <TouchableOpacity
        style={styles.touchableOpacityStyles}
        onPress={() => {
          if (!isNextPageLoading) {
            loadNextPage();
          }
        }}>
        <Text style={styles.touchableOpacityTextStyles}>{actionText}</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NextPageError;
