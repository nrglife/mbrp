import 'reflect-metadata';
import { IocTypes as IocTypesCommon, IocContainer as CommonContainer } from '@healthcareapp/connected-health-common-services';
const IocContainer = CommonContainer;
const IocTypesMobile = {
  ...IocTypesCommon,
  EnrollmentStore: Symbol.for('EnrollmentStoreMobile'),
  AppConfigStore: Symbol.for('AppConfigStoreMobile'),
  GeneralStore: Symbol.for('GeneralStoreMobile')
};
export { IocTypesMobile, IocContainer };
