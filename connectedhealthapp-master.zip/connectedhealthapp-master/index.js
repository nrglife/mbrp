/**
 * @format
 */
import 'react-native-gesture-handler';
import "reflect-metadata";
import { IocContainer } from './src/inversify.config';
import { AppRegistry } from 'react-native';
import { App } from './src/App';
import * as React from 'react';

import { name as appName } from './app.json';
import { gestureHandlerRootHOC } from 'react-native-gesture-handler';
import Loader from "./src/components/Loader";

const AppWithSuspense = () => (
  <React.Suspense fallback={<Loader isLoading={true} />}>
    <App />
  </React.Suspense>
);

AppRegistry.registerComponent(appName, () => gestureHandlerRootHOC(AppWithSuspense));
