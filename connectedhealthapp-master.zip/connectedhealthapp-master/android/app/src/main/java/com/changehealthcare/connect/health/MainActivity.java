package com.changehealthcare.connect.health;

import com.facebook.react.ReactActivity;

import org.devio.rn.splashscreen.SplashScreen; // Import this.

import android.content.Intent;
import android.os.Bundle; // Import this.
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends ReactActivity {

    /**
     * Returns the name of the main component registered from JavaScript. This is used to schedule
     * rendering of the component.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen.show(this, false);
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

    }



    @Override
    protected void onResume() {
        super.onResume();

      /*  super.onResume();
        Log.d("TAG", "run: showe dialog resume");
        View v = getWindow().getDecorView().getRootView();
        View aaa = SplashScreen.mSplashDialog.findViewById(R.id.aaa);
        //aaa.setVisibility(View.GONE);


        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation);
        aaa.startAnimation(animation);*/
    }

    @Override
    protected String getMainComponentName() {
        return "connectedHealth";
    }
}
