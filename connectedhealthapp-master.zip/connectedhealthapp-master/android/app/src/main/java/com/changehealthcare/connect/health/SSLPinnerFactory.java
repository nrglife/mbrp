package com.blogreactnativesslpinning;

import com.facebook.react.modules.network.OkHttpClientFactory;
import com.facebook.react.modules.network.OkHttpClientProvider;
import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;

public class SSLPinnerFactory implements OkHttpClientFactory {
    private static String prod_hostname = "apis.changehealthcare.com";
    private static String preprod_hostname = "sandbox.apis.changehealthcare.com";
    private static String dev_hostname = "api-dev.apip.awsnonprod.healthcareit.net";
//     private static String sso_hostname = "sso.changehealthcare.com";
//     private static String sso_test_hostname = "sso-test.changehealthcare.com";
//     private static String sso_cert_hostname = "sso-cert.changehealthcare.com";

    public OkHttpClient createNewNetworkModuleClient() {
        CertificatePinner certificatePinner = new CertificatePinner.Builder()
                .add(prod_hostname, "sha256/xFdH4vy/AT2RDi3DIPfgCRuiKMoMK+4CGTgIoGf1OIM=")
                .add(preprod_hostname, "sha256/+ju7lLmnoxt2ezMhm5XaiN43+swdLKPptvrUHxHQYLg=")
//                 .add(sso_hostname, "JqIEtMPFFldTG7zyLnOlUvNYvs2XdV4r0ezh14/sWl8=")
                .add(dev_hostname, "sha256/nygbovA2Qsgv1azNKZjXr2uGwBX1sQjWNfMJuH9g94w=")
//                 .add(sso_test_hostname, "sha256/1YNGhULvuODnt3Cfi9H9BHdOn4eiP9QwZeLUmDhWFiU=")
//                 .add(sso_cert_hostname, "sha256/XRyYvV9b1uCjYEmglLibTtAoUi+MNm2cP0jAR+krdSY=")
                .build();
        // Get a OkHttpClient builder with all the React Native defaults
        OkHttpClient.Builder clientBuilder = OkHttpClientProvider.createClientBuilder();
        return clientBuilder
                .certificatePinner(certificatePinner)
                .build();
    }
}
