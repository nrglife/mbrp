import { fixLocalUrl } from '../src/inversify.config';
import { Platform } from 'react-native';
import {
  addCommasToNumber,
  roundFloatToHundredths
} from '@healthcareapp/connected-health-common-services/dist/utilities/Money';

jest.useFakeTimers();

describe('utils', () => {
  it('should replace localhost to 10.0.2.2 on android', async () => {
    const res = fixLocalUrl('http://localhost:4000/dev-v2');
    expect(res).toMatch(Platform.OS === 'ios' ? 'http://localhost:4000/dev-v2' : 'http://10.0.2.2:4000/dev-v2');
  });
  it('should add comma to number', function () {
    const number = addCommasToNumber('12222223');
    expect(number).toBe('12,222,223');
  });

  // it('should be falsy', function () {
  //   const nullNumber = addCommasToNumber(null);
  //   expect(nullNumber).toBeFalsy();
  // });

  it('should round floats to 100', function () {
    const res = roundFloatToHundredths(100.222222222222222)
    expect(res).toBe("100.22")
  });
  it('should be 0', function () {
    const res = roundFloatToHundredths(null)
    expect(res).toBe("0.00")
  });
});
