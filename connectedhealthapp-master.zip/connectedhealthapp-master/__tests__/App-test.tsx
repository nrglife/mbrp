import React from 'react';
import createStores, { StoresContext } from '../src/stores';
import { cleanup, render, waitFor } from '@testing-library/react-native';
import StatusLabel from '../src/screens/health-profile/components/HealthTicketNew/health-ticket-clinical-status-label.component';

jest.useFakeTimers();
afterEach(cleanup);
const stores = createStores();

describe('Clinical UI', () => {
  describe('Clinical UI', () => {
    test('StatusLabel is right ', async () => {
      const StatusLabelComponent = () => (
        <StoresContext.Provider value={stores}>
          <React.Suspense fallback={'loading'}>
            <StatusLabel backgroundColor={'red'} cardStatus={'error'} useDarkTextColor={false} />
          </React.Suspense>
        </StoresContext.Provider>
      );

      const { getByTestId } = render(<StatusLabelComponent />);
      await waitFor(() => {
        const textLabelColor = getByTestId('textLabel').props.style.color;
        expect(textLabelColor).toBe('white');
      });
    });
  });
});
