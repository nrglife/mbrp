import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { DefaultLocales } from '@healthcareapp/connected-health-common-services';
import { IocContainer, IocTypesMobile } from './src/inversify.config';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import { AppLocalesApiType, IocContainer, IocTypes } from '../../inversify.config';

import { AppLocalesApi } from '@healthcareapp/connected-health-common-services';

import resourcesToBackend from 'i18next-resources-to-backend';
import { I18N_CACHE } from './src/utilities/async-storage-keys';
import i18next from 'i18next';

export const DEFAULT_LOCALE = 'en';

const SEPARATOR = '_';

export const i18nReloadTranslations = () => {
  return new Promise((resolve, reject) => {
    i18next.changeLanguage(DEFAULT_LOCALE + SEPARATOR + new Date().getTime(), error => {
      if (error) {
        reject();
      } else {
        resolve(null);
      }
    });
  });
};

i18n
  .use(
    resourcesToBackend((language, namespace, callback) => {
      if (language.includes(SEPARATOR)) {
        language = language.split(SEPARATOR)[0];
      }
      const appLocalesApi = IocContainer.get<AppLocalesApi>(IocTypesMobile.AppLocalesApi);

      const loadDefault = async callback => {
        try {
          const dataString = await AsyncStorage.getItem(I18N_CACHE);
          // console.log(dataString);
          if (dataString) {
            const data = JSON.parse(dataString);
            if (data && data[language] && data[language][namespace]) {
              callback(null, data[language][namespace]);
              return;
            }
          }
        } catch (err) {
          console.log(err);
        }
        callback(null, DefaultLocales[language][namespace]);
      };
      appLocalesApi
        .getLocales()
        .then(async response => {
          const data = response?.data?.data;
          if (data[language] && data[language][namespace]) {
            await AsyncStorage.setItem(I18N_CACHE, JSON.stringify(data));
            callback(null, data[language][namespace]);
          } else {
            loadDefault(callback);
          }
        })
        .catch(error => {
          console.log(error);
          loadDefault(callback);
        });
    })
  )
  // pass the i18n instance to react-i18next.
  .use(initReactI18next)
  // init i18next
  // for all options read: https://www.i18next.com/overview/configuration-options
  .init({
    debug: true,
    fallbackLng: DEFAULT_LOCALE,
    // resources: DefaultLocale,
    interpolation: {
      escapeValue: false // not needed for react as it escapes by default
    }
  });

export default i18n;
