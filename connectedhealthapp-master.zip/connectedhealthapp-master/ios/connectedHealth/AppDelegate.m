#import <TrustKit/TrustKit.h>
#import <TrustKit/TSKPinningValidator.h>
#import <TrustKit/TSKPinningValidatorCallback.h>
#import "AppDelegate.h"
#import <React/RCTBridge.h>
#import <React/RCTBundleURLProvider.h>
#import <React/RCTRootView.h>
#import <React/RCTLinkingManager.h>
#import "RNSplashScreen.h"
#ifdef FB_SONARKIT_ENABLED
#import <FlipperKit/FlipperClient.h>
#import <FlipperKitLayoutPlugin/FlipperKitLayoutPlugin.h>
#import <FlipperKitUserDefaultsPlugin/FKUserDefaultsPlugin.h>
#import <FlipperKitNetworkPlugin/FlipperKitNetworkPlugin.h>
#import <SKIOSNetworkPlugin/SKIOSNetworkAdapter.h>
#import <FlipperKitReactPlugin/FlipperKitReactPlugin.h>


static void InitializeFlipper(UIApplication *application) {
  FlipperClient *client = [FlipperClient sharedClient];
  SKDescriptorMapper *layoutDescriptorMapper = [[SKDescriptorMapper alloc] initWithDefaults];
  [client addPlugin:[[FlipperKitLayoutPlugin alloc] initWithRootNode:application withDescriptorMapper:layoutDescriptorMapper]];
  [client addPlugin:[[FKUserDefaultsPlugin alloc] initWithSuiteName:nil]];
  [client addPlugin:[FlipperKitReactPlugin new]];
  [client addPlugin:[[FlipperKitNetworkPlugin alloc] initWithNetworkAdapter:[SKIOSNetworkAdapter new]]];
  [client start];
}
#endif

@implementation AppDelegate


- (void)applicationWillResignActive:(UIApplication *)application {
  // fill screen with our own colour
  UIView *colourView = [[UIView alloc]initWithFrame:self.window.frame];
  UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"change_logo"]];
  
  imageView.frame = CGRectMake(self.window.frame.size.width/2 - 50, self.window.frame.size.height/2 - 50, 100, 100);
  [colourView addSubview:imageView];
  colourView.backgroundColor = [UIColor whiteColor];
  colourView.tag = 1234;
  colourView.alpha = 0;
  
  [self.window addSubview:colourView];
  [self.window bringSubviewToFront:colourView];
  // fade in the view
  [UIView animateWithDuration:0.5 animations:^{
    colourView.alpha = 1;
  }];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
  // grab a reference to our coloured view
  UIView *colourView = [self.window viewWithTag:1234];
  // fade away colour view from main view
  [UIView animateWithDuration:0.5 animations:^{
    colourView.alpha = 0;
  } completion:^(BOOL finished) {
    // remove when finished fading
    [colourView removeFromSuperview];
  }];
}


// iOS 9.x or newer
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
            options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
  return [RCTLinkingManager application:application openURL:url options:options];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(nonnull NSUserActivity *)userActivity
 restorationHandler:(nonnull void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
  return [RCTLinkingManager application:application
                   continueUserActivity:userActivity
                     restorationHandler:restorationHandler];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
#ifdef FB_SONARKIT_ENABLED
  InitializeFlipper(application);
#endif
  
  
  
  
  // Override TrustKit's logger method, useful for local debugging
  void (^loggerBlock)(NSString *) = ^void(NSString *message)
  {
    NSLog(@"TrustKit log: %@", message);
  };
  [TrustKit setLoggerBlock:loggerBlock];
  
  NSDictionary *trustKitConfig =
  @{
    // Swizzling because we can't access the NSURLSession instance used in React Native's fetch method
    kTSKSwizzleNetworkDelegates: @YES,
    kTSKPinnedDomains: @{
      @"apis.changehealthcare.com" : @{
        kTSKIncludeSubdomains: @YES, // Pin all subdomains
        kTSKEnforcePinning: @YES, // Block connections if pinning validation failed
        kTSKDisableDefaultReportUri: @YES,
        kTSKPublicKeyHashes : @[
          @"xFdH4vy/AT2RDi3DIPfgCRuiKMoMK+4CGTgIoGf1OIM=",
          @"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=", // Fake backup key but we need to provide 2 pins
        ],
      },
      @"sandbox.apis.changehealthcare.com" : @{
        kTSKIncludeSubdomains: @YES, // Pin all subdomains
        kTSKEnforcePinning: @YES, // Block connections if pinning validation failed
        kTSKDisableDefaultReportUri: @YES,
        kTSKPublicKeyHashes : @[
          @"+ju7lLmnoxt2ezMhm5XaiN43+swdLKPptvrUHxHQYLg=",
          @"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=", // Fake backup key but we need to provide 2 pins
        ],
      },
      @"api-dev.apip.awsnonprod.healthcareit.net" : @{
        kTSKIncludeSubdomains: @YES, // Pin all subdomains
        kTSKEnforcePinning: @YES, // Block connections if pinning validation failed
        kTSKDisableDefaultReportUri: @YES,
        kTSKPublicKeyHashes : @[
          @"nygbovA2Qsgv1azNKZjXr2uGwBX1sQjWNfMJuH9g94w=",
          @"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=", // Fake backup key but we need to provide 2 pins
        ],
      },
    }};
  [TrustKit initSharedInstanceWithConfiguration:trustKitConfig];
  [TrustKit sharedInstance].pinningValidatorCallback = ^(TSKPinningValidatorResult *result, NSString *notedHostname, TKSDomainPinningPolicy *policy) {
    if (result.finalTrustDecision == TSKTrustEvaluationFailedNoMatchingPin) {
      NSLog(@"TrustKit certificate matching failed");
      // Add more logging here. i.e. Sentry, BugSnag etc
    }
  };
  
  RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:launchOptions];
  RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge
                                                   moduleName:@"connectedHealth"
                                            initialProperties:nil];
  
  rootView.backgroundColor = [[UIColor alloc] initWithRed:1.0f green:1.0f blue:1.0f alpha:1];
  
  self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
  UIViewController *rootViewController = [UIViewController new];
  rootViewController.view = rootView;
  self.window.rootViewController = rootViewController;
  [self.window makeKeyAndVisible];
  [RNSplashScreen show];
  return YES;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index" fallbackResource:nil];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

@end
