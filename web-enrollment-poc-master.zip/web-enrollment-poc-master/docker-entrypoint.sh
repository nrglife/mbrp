#!/bin/sh
#exit the script on first error
set -e
echo "*** Starting nginx ***"
echo "$(export)"

# create .env.js from the AWS env vars - use var-names.txt to expouse the right AWS env vars 
echo "about to run env.sh script"
/usr/share/nginx/html/env.sh

#start app process
if [ "$1" = 'app' ]; then
    exec nginx -g "daemon off;"
fi

exec "$@"
