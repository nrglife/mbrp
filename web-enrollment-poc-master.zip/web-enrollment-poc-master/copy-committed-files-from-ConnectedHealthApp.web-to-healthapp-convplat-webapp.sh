#!/bin/bash

echo $(pwd)
ls -la
cd ..
rm -Rf healthapp-convplat-webapp || true
git clone --branch $CI_COMMIT_REF_SLUG git@gitlab.healthcareit.net:healthcareapp/edop/healthapp-convplat-webapp.git

#fix copy bug ##########
rm -Rf healthapp-convplat-webapp/repo-files || true
cd healthapp-convplat-webapp
mkdir repo-files || true
cd ..
########################

cp -R web-enrollment-poc/ healthapp-convplat-webapp/repo-files/

ls -la healthapp-convplat-webapp/repo-files/
cd healthapp-convplat-webapp/repo-files/
rm copy-committed-files-from-ConnectedHealthApp.web-to-healthapp-convplat-webapp.sh
rm -Rf .git
rm .git*

cd ..
#echo "Sleeping for 10 seconds"
#SEC=10 && for i in $(seq $(($SEC)) -1 1); do echo -n "$i, "; sleep 1; done
git status
git add .
git commit -m "$CI_COMMIT_MESSAGE"
git push
