const { generateVarNamesFile } = require('./parse-tf-file');

generateVarNamesFile();
