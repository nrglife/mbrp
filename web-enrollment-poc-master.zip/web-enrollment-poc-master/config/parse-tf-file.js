const fs = require('fs');
const path = require('path');

//terraform vars - used in the constants file
const variables_tf_location = path.join(__dirname, '..', 'tf', 'variables.tf');

//parse all vars to an object
const vars = {};
const variables_tf_lines = fs.readFileSync(variables_tf_location, 'utf8').split('\n');

let startParse = false;
let key = '';
let value = '';

for (let i = 0; i < variables_tf_lines.length; i++) {
  const line = variables_tf_lines[i];
  if (line.includes('variable') && !line.includes('#')) {
    //parse the key
    startParse = true;
    key = line.replace('variable', '').replace('{', '').replace(/"/g, '').trim();
  }

  if (startParse && line.includes('default')) {
    //parse the value correlate with the key and insert both to the object vars
    startParse = false;
    value = line.split('=').pop().replace(/"/g, '').trim();
    vars[key] = value;
  }
}

//terraform constants - env vars for - dev, int(qa), preprod. prod
const constants_tf_location = path.join(__dirname, '..', 'tf', 'constants.tf');

//parse all constants to an object
let constantsSTR = fs
  .readFileSync(constants_tf_location, 'utf8')
  .replace('locals', '')
  .replace(/=/g, ':')
  .replace(/var./g, 'vars.')
  .split('\n')
  .filter(l => !l.trim().startsWith('#'))
  .map(l => {
    const withSeperator = l.trim().endsWith('"') || l.trim().endsWith('}') ? ',' : '';

    if (l.includes(' : ')) {
      return (
        l
          .split(' : ')
          .map((line, i) => (i === 0 ? '"' + line.trim() + '"' : line.trim()))
          .join(' : ') + withSeperator
      );
    }
    return l + withSeperator;
  })
  .join('\n');

//replace all ${vars.key} with the content from vars object we created in the start of the script
for (const key of Object.keys(vars)) {
  stringToReplace = '${vars.' + key + '}';
  valueToReplace = vars[key];
  constantsSTR = constantsSTR
    .split('\n')
    .map(l => l.replace(stringToReplace, valueToReplace))
    .join('\n');
}

// remove all trailing commas that case the JSON string to be not legal syntax
let regex = /\,(?!\s*?[\{\[\"\'\w])/g;
constantsSTR = constantsSTR.replace(regex, '');

const constants = JSON.parse(constantsSTR);

//terraform service - the actual env vars for the client - found under application_custom_environment_variables key
const getEnvVarsFromTFFiles = (env = 'dev') => {
  const service_tf_location = path.join(__dirname, '..', 'tf', 'service.tf');
  let serviceSTR =
    '{' +
    fs
      .readFileSync(service_tf_location, 'utf8')
      .split('application_custom_environment_variables = {')
      .pop()
      .split('}')
      .filter((l, i) => i === 0)
      .join('')
      .split('\n')
      .filter(l => !l.trim().startsWith('#'))
      .map(l => l.replace(/[\u0000-\u001F\u007F-\u009F]/g, '').trim())
      .filter(l => l !== '')
      .map((l, i) => l.replace('[var.stage]', `.${env}`).replace('var.stage', `${env}`).replace(' = ', ': '))
      .map(l => {
        const constantObjKeys = l.split(':').pop().trim().replace('local.', '').split('.');
        let value = constants;
        for (const key of constantObjKeys) {
          value = value[key];
        }
        return value ? '"' + l.split(':')[0].trim() + '": ' + `"${value}"` : '"' + l.split(':')[0].trim() + '": ' + `"${l.split(':').pop().trim()}"`;
      })
      .join(',\n') +
    '}';

  const serviceEnvVars = JSON.parse(serviceSTR);
  return serviceEnvVars;
};

const createDotEnvFile = (env = 'dev') => {
  try {
    let tf_env = env;
    if (env === 'int') {
      tf_env = 'qa';
    } else if (env === 'preprod') {
      tf_env = 'cert';
    } else if (env === 'production') {
      tf_env = 'prod';
    }

    const serviceEnvVars = getEnvVarsFromTFFiles(tf_env);

    let envSTR = '';

    for (const key of Object.keys(serviceEnvVars)) {
      const line = key + '=' + serviceEnvVars[key] + '\n';
      envSTR = envSTR + line;
    }

    const env_file_location = path.join(__dirname, '..', `.env.${env}`);

    try {
      fs.writeFileSync(env_file_location, envSTR);
    } catch (error) {
      console.error(error);
    }
  } catch (error) {
    console.error(error);
  }
};

const generateVarNamesFile = () => {
  try {
    const service_tf_location = path.join(__dirname, '..', 'tf', 'service.tf');
    let var_names_STR = fs
      .readFileSync(service_tf_location, 'utf8')
      .split('application_custom_environment_variables = {')
      .pop()
      .split('}')
      .filter((l, i) => i === 0)
      .join('')
      .split('\n')
      .filter(l => !l.trim().startsWith('#'))
      .map(l => l.replace(/[\u0000-\u001F\u007F-\u009F]/g, '').trim())
      .filter(l => l !== '')
      .map(l => l.split(' = ')[0].trim())
      .filter(l => l.startsWith('REACT_APP'))
      .join('\n');

    const var_names_file_location = path.join(__dirname, '..', 'var-names.txt');
    try {
      fs.writeFileSync(var_names_file_location, var_names_STR);
    } catch (error) {
      console.error(error);
    }
  } catch (error) {
    console.error(error);
  }
};

module.exports = { getEnvVarsFromTFFiles, createDotEnvFile, generateVarNamesFile };
