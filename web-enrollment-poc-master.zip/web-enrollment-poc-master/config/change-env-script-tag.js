const fs = require('fs');
const path = require('path');

const resetBackToNormalScript = process.argv.slice(2)[0];
const IndexHtmlPublicFileLocation = path.join(__dirname, '..', 'public', 'index.html');

try {
  const htmlFileLines = fs.readFileSync(IndexHtmlPublicFileLocation, 'utf8').split('\n');

  for (let i = 0; i < htmlFileLines.length; i++) {
    const line = htmlFileLines[i];
    if (line.includes('%PUBLIC_URL%/env.js')) {
      const today = new Date();
      htmlFileLines[i] = resetBackToNormalScript === 'reset' ? `    <script src="%PUBLIC_URL%/env.js"></script>` : `    <script src="%PUBLIC_URL%/env.js?time_stamp=${today.toISOString()}"></script>`;
    }
  }

  const htmlFileAsText = htmlFileLines.join('\n');
  fs.writeFileSync(IndexHtmlPublicFileLocation, htmlFileAsText);
} catch (error) {
  console.error(err);
}
