const fs = require('fs');
const path = require('path');
const { createDotEnvFile } = require('./parse-tf-file');

const envName = process.argv.slice(2)[0];

envName && envName.trim() !== '' && createDotEnvFile(envName.trim());

const EnvJSPublicFileLocation = path.join(__dirname, '..', 'public', 'env.js');
const EnvFileLocation = envName ? path.join(__dirname, '..', `.env.${envName.trim()}`) : path.join(__dirname, '..', `.env.local`);
//getting info from the package.json of the app
const packageJson = require(path.join(__dirname, '..', 'package.json'));
const specialParams = {
  $npm_package_version: packageJson.version,
  $npm_package_name: packageJson.name
};

const generateKeyValueStrings = (line = '') => {
  const splitLine = line.split('=');
  let key = null;
  let value = null;

  if (splitLine.length > 1) {
    key = splitLine[0].trim();
    if (specialParams[splitLine[1].trim()]) {
      value = `'${specialParams[splitLine[1].trim()]}'`;
    } else {
      value = splitLine[1].includes('${') ? '`' + splitLine[1].trim() + '`' : `'${splitLine[1].trim()}'`;
    }
  }
  return { key, value };
};

try {
  const data = fs.readFileSync(EnvFileLocation, 'utf8');
  //remove \n and comments (line with #)
  envFileData = data
    .split('\n')
    .filter(line => line.trim() !== '' && !line.trim().startsWith('#'))
    .map(line => line.trim());

  const varsLines = [];
  const keysLines = [];

  //sort the lines to lines that contain consts data and lines that contain key value data for env.js window.env obj
  for (const line of envFileData) {
    if (line.startsWith('REACT_APP')) {
      const { key, value } = generateKeyValueStrings(line);
      key && value && keysLines.push(`${key}: ${value}`);
    } else {
      const { key, value } = generateKeyValueStrings(line);
      key && value && varsLines.push(`const ${key}=${value};`);
    }
  }

  const dataToWrite = `${varsLines.join('\n')} \n\nwindow.env = {\n${keysLines.map(line => '\t' + line).join(',\n')}\n};`;

  try {
    fs.writeFileSync(EnvJSPublicFileLocation, dataToWrite);
  } catch (err) {
    console.error(err);
  }
} catch (err) {
  console.error(err);
}
