import { useEffect, memo, FC } from 'react';
/** @jsxImportSource @emotion/core */
//third party
import { observer } from 'mobx-react';
import moment from 'moment';
//developed

import { useStores } from './stores/useStores';
import AppRouter from 'routers/AppRouter';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { ImageState, StoreRequestStatus } from 'stores';
import { RouteName } from 'stores/RoutesStore';
import { useRouteUtils } from 'customHooks/useRouteUtils';
//styles
import 'App.scss';
import { globalStyles } from 'styles/global.styles';
import BeatingHeartLoader, { AnimationType } from 'components/general/beating-heart-loader/beating-heart-loader.component';
import './i18n';

const WithFontWrapper = observer(props => {
  const { themeStore } = useStores();
  return <div css={{ width: 'inherit', height: 'inherit', '& *': { fontFamily: themeStore.theme.font.published } }}>{props.children}</div>;
});

const App: FC = () => {
  const { userStore, routesStore, themeStore, authStore, appConfigStore, storageStore, payerStore, delegateStore, imageStore, payerDocumentsStore } = useStores();
  const { getPath } = useRouteUtils();

  useEffect(() => {
    //print cap deployment in case the application served from cap service and not dataservices service
    (window as any)?.env?.REACT_APP_CAP_DEPLOYMENT && console.log('cap deployment');
  }, []);

  const getPayerNameFromUrl = (url: string): string | null => {
    let payerName: string | null = null;
    if (url && url.length > 0) {
      let path: string = new URL(url)?.pathname;
      if (path && path.length > 0) {
        path = path.replace((window as any)?.env?.REACT_APP_RELATIVE_URL_PREFIX || '', '');
        const splitted = path.split('/');
        payerName = splitted.length > 0 && splitted[1] && splitted[1].length > 0 ? splitted[1] : null;
      }
    }

    return payerName;
  };

  const loadPayerAndRoutes = async (payerName: string, isUserLoggedIn: boolean) => {
    const useSessionData = storageStore.getValueByKey('useSessionData');

    await payerStore.loadPayerFullDataByName(payerName, {
      loadConfig: true,
      loadTheme: true,
      loadDocuments: true,
      loadImageLogos: true,
      loadImageLandingBackground: !isUserLoggedIn,
      useStorageCache: useSessionData ? true : false
    });

    if (payerStore.payer) {
      routesStore.setPayerName(payerName.toLocaleLowerCase());
    } else {
      console.log('No correct payer is available in the url.');
      routesStore.setNoPayerName();
    }

    storageStore.removeItemByKey('useSessionData');
  };

  const isPayerNameNotChanged = (currentPayerName: string): boolean => {
    const originalLandingPageUrl = storageStore.getValueByKey('targetLocation');
    const originalPayerName = originalLandingPageUrl && getPayerNameFromUrl(originalLandingPageUrl);
    const isPayerNameNotChanged = originalPayerName ? originalPayerName === currentPayerName : true;
    return isPayerNameNotChanged;
  };

  const setInitialData = async () => {
    console.log(`Version ${(window as any)?.env?.REACT_APP_VERSION}`);

    const initializationExcludeList = ['auth', 'p2pauth', 'error']; // on these pages there is no payername and initazlization should be avoided
    const payerNameFromUrl = getPayerNameFromUrl(window.location.href);
    const isInitDataNeeded = payerNameFromUrl ? !initializationExcludeList.includes(payerNameFromUrl) : true;

    if (isInitDataNeeded) {
      userStore.tryLoadUserFromToken(); // If the user is logged in, loading user from the token in local storage.

      appConfigStore.loadConfig().then(async () => {
        if (!!payerNameFromUrl) {
          await loadPayerAndRoutes(payerNameFromUrl, !!userStore.currentUser);
          if (routesStore.status === StoreRequestStatus.Loaded && routesStore.payer) {
            if (userStore.currentUser) {
              if (isPayerNameNotChanged(routesStore.payer)) {
                if (userStore.isUserLoggedInApproved) {
                  delegateStore.init();
                }
              } else {
                // payer name has changed manually on the browser, redirecting to the landing page of the new payername.
                authStore.removePayerStorageKeys();
                authStore.removeUserStorageKeys();
                window.location.href = getPath(RouteName.landing);
              }
            }
          }
        } else {
          routesStore.setNoPayerName();
          console.log('No payer in url.');
        }
      });
    }
  };

  useEffect(() => {
    setInitialData();
    authStore.setAuthTimeouts(
      (promptTimer: number) => console.log('SOON TO BE TIMEOUT OUT Minutes left: ', moment(promptTimer).format()),
      (expirationTimer: number) => {
        console.log('TIMEOUT: ', window.location);
        console.log('LEFT UNTILL LOG OUT: ', moment(expirationTimer).format());
        authStore.logout(false);
      },
      5
    );
  }, [authStore]);

  const isShowHeartLoader = () => {
    let isShowLoader = false;

    if (routesStore.status === StoreRequestStatus.Error) {
      // Must remove loader and show an error when payer name couldnt been loaded
      isShowLoader = false;
    } else if (
      appConfigStore.isLoading === true ||
      themeStore.isLoading === true ||
      payerStore?.loading === true ||
      payerDocumentsStore.docs.landing.loading === true ||
      imageStore.logos.light.state === ImageState.Init ||
      imageStore.logos.light.state === ImageState.Loading ||
      imageStore.logos.dark.state === ImageState.Init ||
      imageStore.logos.dark.state === ImageState.Loading ||
      (userStore.isUserLoggedInApproved && (delegateStore.state === DelegateStoreState.PreInit || delegateStore.state === DelegateStoreState.ReloadingPayer))
    ) {
      isShowLoader = true;
    }

    return isShowLoader;
  };

  return (
    <div className="App">
      <BeatingHeartLoader loading={isShowHeartLoader()} position="absolute" containerStyle={{ background: globalStyles.COLOR.baseNeutral5 }} withFadeOut animationType={AnimationType.Slow} />
      <WithFontWrapper>
        <AppRouter />
      </WithFontWrapper>
    </div>
  );
};

export default memo(observer(App));
