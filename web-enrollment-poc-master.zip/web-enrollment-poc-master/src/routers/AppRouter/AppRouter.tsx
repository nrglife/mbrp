import { FC, ReactNode } from 'react';
//third party
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import { StoreRequestStatus } from 'stores';
import ConsentPage from 'pages/consent/consent-page.component';
import { CIAMAuth, P2PAuth, CIAMNotAuthorized } from 'pages/auth';
import HomeWrapper from 'components/home/home-wrapper/home-wrapper.component';
import LandingPage from 'pages/landing/landing-page.component';
import NotFoundPage from 'pages/404/not-found-page.component';
import HealthCheck from 'pages/healthcheck/healthcheck.component';
import { DelegateError } from 'pages/delegateError/DelegateError';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
//common
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';

interface AppRouterProps {}

const AppRouter: FC<AppRouterProps> = () => {
  const { userStore, routesStore, payerStore, delegateStore } = useStores();
  const { getPath } = useRouteUtils();

  const routes: any[] = [];
  let pageNotFoundComponent: ReactNode = <NotFoundPage />;

  if (routesStore.status === StoreRequestStatus.Loaded) {
    if (!userStore.currentUser || (userStore.currentUser && userStore.isConsent == null)) {
      const generalRoute = <Route key={'general'} path={`/${routesStore.payer}`} exact render={() => <Redirect to={getPath(RouteName.landing)} />} />;
      routes.push(generalRoute);
    } else if (userStore.currentUser && userStore.isConsent === false) {
      const consent = <Route key={'navigation-consent'} path={getPath(RouteName.consent)} exact component={ConsentPage} />;
      const redirectToConsent = <Redirect key={'navigation-redirect-consent-page'} to={{ pathname: getPath(RouteName.consent) }} />;
      routes.push(consent, redirectToConsent);
    } else if (delegateStore.state === DelegateStoreState.Error || delegateStore.state === DelegateStoreState.InitError) {
      const delegateErrorRoute = <Route key={'navigation-delegate-error'} path={getPath(RouteName.home)} component={DelegateError} />;
      routes.push(delegateErrorRoute);
    } else if (userStore.currentUser && userStore.isConsent && delegateStore.state !== DelegateStoreState.PreInit) {
      const homeWrapper = <Route key={'navigation-home-wrapper'} path={getPath(RouteName.home)} component={HomeWrapper} />;
      routes.push(homeWrapper);
    }
    pageNotFoundComponent = <NotFoundPage isBranded={true} showBackLink={true} />;
  }

  // mutual routes for both enrollment and home flows
  const healthcheckRoute = <Route key={'healthcheck'} path={'*/healthcheck'} component={HealthCheck} />;
  const auth = <Route key={'navigation-auth'} path={'/auth'} exact component={CIAMAuth} />;
  const p2pAuth = <Route key={'navigation-p2p-auth'} path={'/p2pauth'} exact component={P2PAuth} />;
  const error = <Route key={'navigation-auth-error'} path={'/error'} exact component={CIAMNotAuthorized} />;
  const landing = <Route key={'navigation-landing'} path={getPath(RouteName.landing) ? getPath(RouteName.landing) : `/${routesStore.payer}/landing`} exact component={LandingPage} />;
  routes.unshift(healthcheckRoute, landing, auth, p2pAuth, error);

  const pageNotFoundRoute = <Route key={'page-not-found'} path={'*'} children={pageNotFoundComponent} />;
  !payerStore.loading && routes.push(pageNotFoundRoute);

  return (
    <Router>
      <Switch>{routes}</Switch>
    </Router>
  );
};

export default observer(AppRouter);
