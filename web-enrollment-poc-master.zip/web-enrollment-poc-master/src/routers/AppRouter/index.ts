// import loadable from '@loadable/component';
import AppRouter from './AppRouter';

// const LoadableAppRouter = loadable(() => import('./AppRouter'));

// export { LoadableAppRouter as default };
export { AppRouter as default };
