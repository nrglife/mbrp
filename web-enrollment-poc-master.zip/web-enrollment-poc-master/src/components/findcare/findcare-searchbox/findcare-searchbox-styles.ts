import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const searchBoxTitle = (theme: Preferences) =>
  css({
    fontSize: '1.3rem',
    color: theme.colors.actionMedium.published,
    width: '100%',
    textAlign: 'left'
  });

export const container = css({
  width: '30.2rem',
  height: '6rem',
  display: 'flex',
  alignItems: 'left',
  alignContent: 'center',
  flexDirection: 'column',
  backgroundColor: 'white',
  padding: '9px 9px 9px 9px',
  border: 'solid 1px #cccccc'
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const searchInputStyle = css({
  width: '100%',
  height: '2.8rem',
  fontSize: '1.4rem',
  textAlign: 'left',
  //transition: 'all 0.3s ease-in-out',
  padding: '0 0.2rem',
  //marginRight: 5, // defaults to px
  border: 'none',
  //borderBottom: '1px solid rgba(0,0,0,0.2)',
  borderRadius: 'unset',

  '&:focus': {
    //borderBottom: '1px  solid #333333'
    //transition: 'all 0.3s ease-in-out'
  }
  // '&:disabled': {
  //   backgroundColor: 'transparent'
  // }
});

export const textLimit1Line = css({
  display: '-webkit-box',
  WebkitLineClamp: 1,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});
