import { FC, useCallback, useEffect, useRef, useState } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

//styles
import * as styles from './findcare-searchbox-styles';
import { useStores } from 'stores/useStores';
import { ReactComponent as SearchIcon } from 'assets/icons/icons-interactions-search.svg';
import { globalStyles } from 'styles/global.styles';
import debounce from 'lodash/debounce';

interface IFindCareSearchBox {
  onSearchbyValueChanged: (searchbyValue: string) => void;
  title?: string;
  placeholder?: string;
}

const FindCareSearchBox: FC<IFindCareSearchBox> = ({ onSearchbyValueChanged, title = '', placeholder = '' }) => {
  const { themeStore } = useStores();
  const [searchbyValue, setSearchbyValue] = useState('');

  const searchRef = useRef<HTMLInputElement>(null);

  const onSearchChanged = event => {
    setSearchbyValue(event.target.value);
  };

  const updateSearchby = () => {
    // A search query
    onSearchbyValueChanged(searchbyValue);
  };

  const delayedSearchby = useCallback(debounce(updateSearchby, 600), [searchbyValue]);

  useEffect(() => {
    delayedSearchby();

    // Cancel previous debounce calls during useEffect cleanup.
    return delayedSearchby.cancel;
  }, [searchbyValue, delayedSearchby]);

  const textPlaceholder = placeholder ? placeholder : '';
  return (
    <div css={styles.container}>
      <div css={[styles.searchBoxTitle(themeStore.currentTheme), styles.textLimit1Line]} title={title}>
        {title ? title : ''}
      </div>
      <div css={{ flex: 1, display: 'flex', flexDirection: 'row', alignItems: 'center', alignContent: 'space-between' }}>
        <input
          ref={searchRef}
          placeholder={textPlaceholder}
          value={searchbyValue}
          onChange={event => onSearchChanged(event)}
          maxLength={40}
          width={'26.3rem'}
          height={'2.8rem'}
          css={[styles.searchInputStyle]}
        />

        <div>
          <SearchIcon css={{ color: globalStyles.COLOR.blueyGreyTwo, width: '2.4rem', height: '2.4rem' }} />
        </div>
      </div>
    </div>
  );
};

export default FindCareSearchBox;
