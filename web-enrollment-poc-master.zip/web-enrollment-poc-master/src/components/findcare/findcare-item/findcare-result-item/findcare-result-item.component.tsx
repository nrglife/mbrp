import React, { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles } from '@emotion/core';

import { ReactComponent as ChevronIcon } from 'assets/icons/icons-interactions-next.svg';
import * as styles from './findcare-result-item.styles';
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';

import { globalStyles } from 'styles/global.styles';
import FindCareResultStore from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareResultStore';
import { toJS } from 'mobx';
import { FindCareResourcesTypes, OrganizationAffiliation, PractitionerRole } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/findcare-types';
import {getFirstContainedByReferenceId} from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/findcare-helper';
import {calculateDistanceInMiles} from '@healthcareapp/connected-health-common-services/dist/utilities/maps';
import { Point } from '@healthcareapp/connected-health-common-services/dist/utilities/maps/types';

interface IFindCareResultItem {
  isSelected?: boolean;
  item: FindCareResultStore;
  style: SerializedStyles;
  onClick: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}

export const FindCareResultItem: FC<IFindCareResultItem> = observer(({ item, style,isSelected, onClick }) => {
  const { themeStore } = useStores();
  
  let name: string | null = item?.Name;
  let additionalData: string | null = null;
  //let distance = getDistance(findCareStore.homeLocation);
  let distance = item?.Distance;

  if (item?.result?.resourceType === FindCareResourcesTypes.PractitionerRole) {
    additionalData = item?.OrganizationName;
  } else {
    // TO BE IMPLEMENTED
  }

  return (
    <div
      onClick={onClick}
      css={[ style, styles.container, {  borderColor: isSelected ? themeStore.currentTheme.colors.actionLight.published : globalStyles.COLOR.white, borderBottomColor: isSelected ? themeStore.currentTheme.colors.actionLight.published : globalStyles.COLOR.veryLightPinkFour }, isSelected ? styles.containerSelected : styles.containerNotSelected]}>
      <div css={styles.leftSectionContainerStyle}>
        {additionalData ? <p css={[styles.secondaryTitle, styles.textLimit1Line]}>{`${additionalData}`}</p> : null}
        {name ? <p css={[styles.mainTitle, styles.brandedFontColor(themeStore.currentTheme), styles.textLimit2Line]}>{`${name}`}</p> : null}
        {distance? <p css={styles.secondaryTitle}>{distance.toFixed(1)} mi</p>:null } 
      </div>
      <div css={[styles.chevronContainerStyle]}>
        <ChevronIcon css={styles.iconStyle} />
      </div>
    </div>
  );
});
