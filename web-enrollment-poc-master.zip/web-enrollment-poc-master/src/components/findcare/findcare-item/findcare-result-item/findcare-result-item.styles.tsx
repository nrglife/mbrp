/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const selectedStyle = (theme: Preferences) => css({ position: 'absolute', left: '1px', right: '1px', top: '3px', bottom: '2px', border: `3px solid ${theme.colors.actionLight.published}` });

export const brandedFontColor = (theme: Preferences) => css({ color: theme.colors.actionDark.published });

export const container = css({
  paddingLeft: '9px', 
  paddingRight: '2px',
  border: `3px solid ${globalStyles.COLOR.white}`,
  borderRightWidth: '4px',
  display: 'flex', 
  width: '100%', 
  alignItems: 'center'
})


export const containerNotSelected = css({
  paddingBottom: '2px',
  borderBottomWidth: '1px'
})

export const containerSelected =  css({
  paddingBottom: '0',
  borderBottomWidth: '3px'
})

export const secondaryTitle = css({
  fontSize: '1.2rem',
  fontWeight: 400,
  lineHeight: 1.2,
  color: globalStyles.COLOR.black
});

export const mainTitle = css({
  fontSize: '1.6rem',
  fontWeight: 400,
  lineHeight: 1.6
});

export const leftSectionContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 2, marginRight: 10, width: '100%' });

export const additionaInfoTextStyle = css({
  fontSize: '1.2rem',
  lineHeight: 1.3,
  color: globalStyles.COLOR.slateGrey
});

export const chevronContainerStyle = css({ display: 'flex', flexFlow: 'row nowrap', alignItems: 'flex' });

export const iconStyle = css({ marginTop: '-0.2rem', marginLeft: '0.5rem', color: '#9BA1A9', transform: 'rotate(180deg)' });

export const textLimit2Line = css({
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});

export const textLimit1Line = css({
  display: '-webkit-box',
  WebkitLineClamp: 1,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});
