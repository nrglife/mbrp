import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles } from '@emotion/core';

import { ReactComponent as ChevronIcon } from 'assets/icons/icons-interactions-next.svg';
import * as styles from './findcare-search-options-item.styles';
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';
import { FindCareSearchOptionsType } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/find-care-search-categorites';

import { globalStyles } from 'styles/global.styles';

interface IFindCareSearchOptionsListItem {
  item: FindCareSearchOptionsType;
  style: SerializedStyles;
  onClick: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}

export const FindCareSearchOptionsListItem: FC<IFindCareSearchOptionsListItem> = observer(({ item, style, onClick }) => {
  const { themeStore } = useStores();

  return (
    <div
      onClick={onClick}
      css={{ ...style, paddingLeft: '9px', paddingRight: '2px', borderBottom: `solid 1px ${globalStyles.COLOR.veryLightPinkFour}`, display: 'flex', width: '100%', alignItems: 'center' }}>
      <div css={[styles.leftSectionContainerStyle, !!item.additionaInfo ? { marginTop: '0.3rem', marginBottom: '1.2rem' } : {}]}>
        <p css={[styles.baseTextStyle, styles.displayTextStyle, styles.brandedFontColor(themeStore.currentTheme)]} title={item.code}>{`${item.display}`}</p>
        <p css={[styles.baseTextStyle, styles.additionaInfoTextStyle, styles.textLimit2Line]} title={item.additionaInfo ? `${item.additionaInfo}` : ''}>
          {item.additionaInfo ? `${item.additionaInfo}` : ''}
        </p>
      </div>
      <div css={[styles.chevronContainerStyle]}>
        <ChevronIcon css={styles.iconStyle} />
      </div>
    </div>
  );
});
