/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const selectedStyle = (theme: Preferences) => css({ position: 'absolute', left: '1px', right: '1px', top: '3px', bottom: '2px', border: `3px solid ${theme.colors.actionLight.published}` });

export const baseTextStyle = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: 1.43
});

export const brandedFontColor = (theme: Preferences) => css({ color: theme.colors.actionDark.published });

export const leftSectionContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 2, marginRight: 10, width: '100%' });

export const displayTextStyle = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: 1.43,
  paddingBottom: 1
});

export const additionaInfoTextStyle = css({
  fontSize: '1.2rem',
  lineHeight: 1.3,
  color: globalStyles.COLOR.slateGrey
});

export const chevronContainerStyle = css({ display: 'flex', flexFlow: 'row nowrap', alignItems: 'flex' });

export const iconStyle = css({ marginTop: '-0.2rem', marginLeft: '0.5rem', color: '#9BA1A9', transform: 'rotate(180deg)' });

export const textLimit2Line = css({
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});

export const textLimit1Line = css({
  display: '-webkit-box',
  WebkitLineClamp: 1,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});
