import React, { FC, useCallback, useEffect, useRef, useState } from 'react';
import { observer } from 'mobx-react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

//styles
import * as styles from './findcare-result-details.styles';
import { useStores } from '../../../stores/useStores';
import { SortTypes } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import FindCareMapAreaComponent from '../map-area/findcare-map-area.compontet';
import { ReactComponent as XIcon } from 'assets/icons/x-close.svg';
import { ReactComponent as PractitionerIcon } from '../../../assets/icons/practitioner-icon.svg';
import { ReactComponent as OrganizationIcon } from '../../../assets/icons/organization-icon.svg';
import { ReactComponent as LocationIcon } from '../../../assets/icons/location-icon.svg';
import { ReactComponent as EmptyLocationIcon } from '../../../assets/icons/icons-map-pin-label.svg';
import { ReactComponent as Accessibility } from '../../../assets/icons/accessibility-icon-final.svg';
import { ReactComponent as Navigation } from '../../../assets/icons/navigation.svg';
import { ReactComponent as Call } from '../../../assets/icons/call.svg';
import { ReactComponent as HomeIcon } from '../../../assets/icons/home.svg';
import { ReactComponent as TriangleRightArrowIcon } from '../../../assets/icons/arrow-dropdown-down.svg';
import { globalStyles } from 'styles/global.styles';
import Tabs, { TabType } from 'components/tabs/tabs.component';
import { content } from 'pages/enrollment/confirm-phone-number/components/confirm-phone-number.styles';
import { getAddressAs2Lines, getTelecom } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { ContactPoint, ContactPointSystem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { FindCareResourcesTypes } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/findcare-types';
interface IFindCareResultDetailsProps {}

const FindCareResultDetails: FC<IFindCareResultDetailsProps> = () => {
  const { themeStore, findCareStore } = useStores();

  const getLocationTab = () => {
    let locationStores = findCareStore.selected?.locations;

    return (
      <div css={styles.locationContainer}>
        <div css={styles.detailsCol}>
          {locationStores?.length && locationStores?.length > 1 && <div css={[styles.adress, styles.locationCount]}>{locationStores?.length} Locations</div>}
          {locationStores?.map((locationStore, i) => {
            const adress = getAddressAs2Lines(locationStore.location.address);
            let telecom: ContactPoint | null = null;
            if (locationStore.location.telecom != null) {
              telecom = getTelecom(locationStore.location.telecom, ContactPointSystem.Phone);
            }

            return (
              <div key={`resultDetails-${i}`}>
                {i > 0 && locationStores && locationStores[i].Distance > findCareStore.searchRadius && locationStores[i - 1].Distance < findCareStore.searchRadius && (
                  <div css={[styles.adress, styles.locationCount]}>
                    {locationStores?.length && locationStores?.length - i} {locationStores && locationStores?.length - i > 1 ? 'Locations' : 'Location'} outside of search distance
                  </div>
                )}
                <div css={styles.SingleLocation} key={locationStore.location.id}>
                  {<LocationIcon css={[styles.LocationIcon, { color: i == 0 ? themeStore.currentTheme.colors.actionLight.published : themeStore.currentTheme.colors.actionMedium.published }]} />}
                  <div>
                    <div css={styles.LocationTitle}>{locationStore.location.name}</div>
                    {adress ? (
                      <div css={styles.adress}>
                        {adress?.line1} {adress?.line1 && adress?.line2 && <br />}
                        {adress?.line2}
                      </div>
                    ) : null}
                    {locationStore.Distance && !isNaN(locationStore.Distance) && <div css={styles.distance}>{locationStore.Distance.toFixed(1)} mi</div>}
                    {/* <div css={styles.directions}>
                      <Navigation css={[styles.icon, styles.smallIcon]} />
                      Directions
                    </div> */}
                    {telecom ? (
                      <div css={styles.phone}>
                        <Call css={[styles.icon, styles.smallIcon]} />
                        {telecom?.value}
                      </div>
                    ) : null}
                    {/* <div css={styles.subTitle}>
                      <TriangleRightArrowIcon css={[styles.icon, styles.triangleIcon]} /> Facility Hours
                    </div> */}
                    {/* <div css={styles.hoursTable}>
                      <div>MON</div>
                      <div>10AM–8PM</div>
                      <div>TUES</div>
                      <div>10AM–6PM</div>
                      <div css={styles.boldHours}>WED</div>
                      <div css={styles.boldHours}>10AM–6PM</div>
                      <div>THU</div>
                      <div>10AM–10PM</div>
                      <div>FRI</div>
                      <div>10AM–10PM</div>
                    </div> */}
                    {/* <div css={styles.subTitle}>
                      <Accessibility css={styles.icon} /> ACCESSIBILITY
                      <div css={[styles.adress, styles.accesibilityContent]}>
                        Wheelchair access <br /> Public transportation
                      </div>
                    </div> */}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div css={styles.mapCol}>
          <FindCareMapAreaComponent />
        </div>
      </div>
    );
  };

  const getDetailsTab = () => {
    return (
      <div css={styles.detailsTab}>
        <div css={styles.detailsTitle}>Qualifications</div>
        <p css={styles.detailsContent}>
          {' '}
          • Graduate of George Washington University Medical School.
          <br /> • Internal medicine at the University of Oregon Health Sciences (UOHS) <br /> • Pulmonary critical care medicine at UOHS and the University of Southern California.
        </p>
      </div>
    );
  };

  const tabs: TabType[] = [
    { content: getLocationTab(), headline: 'Locations' }
    // { content: getDetailsTab(), headline: 'Details' }
  ];

  useEffect(() => {}, []);

  return (
    <div css={styles.container}>
      {/* <div css={styles.breadcrumContainer}>
        <div css={styles.linksContainer}>
          <div css={styles.breadcrumLink}>Find Care</div>
          <div css={styles.breadcrumDivider}>/</div>
          <div css={styles.breadcrumLink}>Specialties</div>
          <div css={styles.breadcrumDivider}>/</div>
          <div css={styles.breadcrumLink}>Oral Surgeons</div>
        </div>
        <div css={styles.closeBtn}>
          <XIcon color={globalStyles.COLOR.battleshipGrey}></XIcon>
        </div>
      </div> */}
      <div css={styles.headlineContainer}>
        <div css={styles.avatarContainer}>
          {findCareStore.selected?.result.resourceType == FindCareResourcesTypes.PractitionerRole ? 
          <PractitionerIcon css={styles.AvatarIcon} /> : <OrganizationIcon css={styles.AvatarIcon} /> }
        </div>
        <div>
          {/* <div css={styles.smallTitle}>Family Medicine, Dermatologist </div> */}
          <div css={styles.mainTitle}>{findCareStore.selected?.Name}</div>
          {/* <div css={styles.titleTags}>
                    <div css={styles.titleTag}>In Network</div>
                    <div css={styles.titleTag}>Accepting New Patients</div>
                    <div css={styles.titleTag}>Languages: English, Telegu</div>
                    <div css={styles.titleTag}>Male</div>
                </div> */}
        </div>
      </div>

      <Tabs tabs={tabs} />
    </div>
  );
};

export default observer(FindCareResultDetails);
