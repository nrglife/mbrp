import { css } from '@emotion/core';
import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const container = (theme: Preferences) =>
  css({
    flex: '1 1 300px',
    display: 'flex',
    alignItems: 'left',
    flexDirection: 'column',
    background: 'white',
    boxShadow: `0 2px 4px 0 ${globalStyles.COLOR.black15}`,
    minHeight: 0,
    overflowY: 'auto',
    padding: '0.2rem'
  });

export const breadcrumLink = css({
  fontSize: '1.4rem',
  color: globalStyles.COLOR.mediumBlue,
  textDecoration: 'underline',
  padding: '1rem 1rem 1.2rem 1rem'
});

export const breadcrumDivider = css({
  fontSize: '1.8rem',
  color: globalStyles.COLOR.veryLightPinkFour,
  paddingTop: '1rem'
});

export const breadcrumContainer = css({
  display: 'flex',
  justifyContent: 'space-between',
  borderBottom: `1px solid ${globalStyles.COLOR.veryLightPinkThree}`
});

export const linksContainer = css({
  display: 'flex'
});

export const closeBtn = css({
  paddingTop: '0.4rem'
});

export const headlineContainer = css({
  display: 'flex',
  padding: '1.5rem',
  alignItems: 'center'
});

export const titleTags = css({
  display: 'flex',
  color: globalStyles.COLOR.charcoalGreySix,
  fontSize: '1.3rem',
  '@media (max-width: 1000px)': {
    flexDirection: 'column'
  }
});

export const titleTag = css({
  marginRight: '3rem'
});

export const avatarContainer = css({
  maxWidth: '6rem',
  maxHeight: '6rem',
  marginRight: '1.5rem'
});

export const locationContainer = css({
  display: 'flex',
  flexFlow: 'row nowrap',
  width: '100%',
  '@media (max-width: 1000px)': {
    flexDirection: 'column-reverse'
  }
});

export const detailsCol = css({
  width: '30%',
  padding: '1rem',
  '@media (max-width: 1000px)': {
    width: '100%'
  }
});

export const mapCol = css({
  minWidth: '300px',
  minHeight: '300px',
  width: '70%',
  height: '450px',
  '@media (max-width: 1000px)': {
    width: '100%',
    height: '300px'
  }
});

export const smallTitle = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.blackTwo
});

export const detailsTab = css({
  padding: '2.5rem'
});

export const detailsTitle = css({
  fontSize: '1.6rem',
  color: globalStyles.COLOR.blackTwo
});

export const detailsContent = css({
  fontSize: '1.4rem',
  color: globalStyles.COLOR.charcoalGreySix,
  marginTop: '1rem',
  lineHeight: '1.6'
});

export const mainTitle = css({
  fontSize: '2.4rem',
  color: globalStyles.COLOR.charcoalGreyFour,
  margin: '.5rem 0'
});

export const locationCount = css({
  marginBottom: '1rem',
  lineHeight: '1.6rem',
  fontSize: '1.3rem'
});

export const adress = css({
  color: globalStyles.COLOR.slateGrey,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: '0.0',
  marginBottom: '0.5rem'
});

export const distance = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: '0.0',
  marginBottom: '0.8rem'
});

export const directions = css({
  color: globalStyles.COLOR.darkBlueGrey,
  fontSize: '1.4rem',
  textDecoration: 'underline',
  marginBottom: '0.5rem'
});

export const phone = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.4rem',
  marginBottom: '0.5rem'
});

export const icon = css({
  marginRight: '0.5rem',
  position: 'relative',
  top: '0.2rem',
  color: globalStyles.COLOR.charcoalGreySeven
});

export const smallIcon = css({
  width: '12px',
  height: '12px'
});

export const triangleIcon = css({
  width: '15px',
  height: '15px'
});

export const subTitle = css({
  color: globalStyles.COLOR.charcoalGreyFive,
  fontSize: '1.1rem',
  marginTop: '1.2rem',
  fontWeight: 'bold',
  textTransform: 'uppercase'
});

export const accesibilityContent = css({
  marginLeft: '2.2rem',
  fontWeight: 'normal',
  textTransform: 'none',
  marginTop: '0.5rem'
});

export const LocationTitle = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.4rem',
  fontWeight: 'bold',
  lineHeight: '2rem',
  marginBottom: '0.5rem'
});

export const SingleLocation = css({
  borderBottom: `1px solid ${globalStyles.COLOR.veryLightPinkThree}`,
  paddingBottom: '2rem',
  marginBottom: '2rem',
  display: 'flex',
  alignItems: 'flex-start'
});

export const LocationIcon = css({
  width: '2.8rem',
  minWidth: '2.8rem',
  height: '3.5rem',
  marginRight: '.5rem'
});

export const AvatarIcon = (theme: Preferences) =>
  css({
    color: theme.colors?.backgroundDark.published,
    width: '100%',
    height: '100%'
  });

export const boldHours = css({
  fontWeight: 'bold',
  color: globalStyles.COLOR.darkBlueGrey
});

export const hoursTable = css({
  color: globalStyles.COLOR.charcoalGreySix,
  fontSize: '1.2rem',
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  width: '200px',
  marginLeft: '2.2rem',
  marginTop: '1rem',
  gap: '.4rem'
});
