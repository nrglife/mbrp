/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
// import { globalStyles } from 'styles/global.styles';

export const selectedLocationMarker = (theme: Preferences) => {
  return {
    color: theme.colors.actionLight.published
  };
};

export const homeMarker = (theme: Preferences) => {
  return {
    color: theme.colors.actionLight.published
  };
};
