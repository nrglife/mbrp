import { FC, useState, useEffect, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
import { googleFindPlaceFromQuery, useGooglePlacesLoaded, initFormattedAddress  } from 'services/GoogleMapsService';

import { LocationSelectType, Location } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { useStores } from 'stores/useStores';
import { GoogleMap, MapController, GoogleMapsMarker } from 'components/google-maps/';

// import { ReactComponent as MarkerLocationItemIcon } from 'assets/icons/marker-location-item.svg';
import { ReactComponent as MarkerHomeIcon } from 'assets/icons/marker-home.svg';
import { ReactComponent as MarkerCurrentLocationIcon } from 'assets/icons/marker-current-location.svg';
import { ReactComponent as MarkerSelectedLocationIcon } from 'assets/icons/marker-selected-location.svg';

import * as styles from './findcare-map-area.styles';

const ZoomOption = {
  Default: 10,
  Far: 4
};

interface FindCareMapAreaProps {}

const FindCareMapAreaComponent: FC<FindCareMapAreaProps> = () => {
  const [isGooglePlacesLoaded] = useGooglePlacesLoaded();
  const [center, setCenter] = useState<Location | null>(null);
  const [zoom, setZoom] = useState<number>(ZoomOption.Default);
  const [mapController, setMapController] = useState<MapController | null>(null);
  const { findCareStore, themeStore } = useStores();

  const setDefaultCenter = async () => {
    if (findCareStore.selectedLocation) {
      setCenter(findCareStore.selectedLocation);
      setZoom(ZoomOption.Default);
    } else {
      const usaLocations: any = await googleFindPlaceFromQuery('USA');
      if (usaLocations && usaLocations.length > 0) {
        const usaLocation: Location = {
          formatted_address: initFormattedAddress(usaLocations[0].formatted_address),
          latitude: usaLocations[0].geometry.location.lat(),
          longitude: usaLocations[0].geometry.location.lng(),
          locationSelectType: LocationSelectType.None,
          placeId: usaLocations[0].place_id
        };
        setCenter(usaLocation);
        setZoom(ZoomOption.Far);
      }
    }
  };

  useEffect(() => {
    if (findCareStore.selectedLocation && mapController) {
      mapController.fitToCircle(findCareStore.selectedLocation, findCareStore.searchRadius);
      setCenter(findCareStore.selectedLocation);
    }
  }, [findCareStore.selectedLocation, findCareStore.searchRadius, mapController]);

  useEffect(() => {
    if (isGooglePlacesLoaded && !center) {
      setDefaultCenter();
    }
  }, [isGooglePlacesLoaded]);

  return (
    center && (
      <GoogleMap
        defaultZoom={zoom}
        defaultCenter={center}
        onLoad={mapController => {
          setMapController(mapController);
        }}>
        {findCareStore.homeLocation && (
          <GoogleMapsMarker
            location={findCareStore.homeLocation}
            title={'Home'}
            svgIcon={{
              svgElement: <MarkerHomeIcon color={styles.homeMarker(themeStore.currentTheme).color} />,
              anchor: { x: 10, y: 27 }
            }}
          />
        )}
        {findCareStore.currentLocation && (
          <GoogleMapsMarker
            location={findCareStore.currentLocation}
            title={'Current Location'}
            svgIcon={{
              svgElement: <MarkerCurrentLocationIcon />,
              anchor: { x: 14, y: 14 }
            }}
          />
        )}
        {findCareStore.selectedLocation && ![LocationSelectType.Home, LocationSelectType.CurrentLocation].includes(findCareStore.selectedLocation.locationSelectType) && (
          <GoogleMapsMarker
            location={findCareStore.selectedLocation}
            title={findCareStore.selectedLocation.formatted_address}
            svgIcon={{
              svgElement: <MarkerSelectedLocationIcon color={styles.selectedLocationMarker(themeStore.currentTheme).color} />,
              anchor: { x: 14, y: 27 }
            }}
          />
        )}

        {/* <GoogleMapsCircle
          center={findCareStore.selectedLocation}
          radius={1609.34 * findCareStore.searchRadius}
          strokeColor="#FF0000"
          strokeOpacity={0.15}
          strokeWeight={2}
          fillColor="#FF0000"
          fillOpacity={0.15}
        /> */}
      </GoogleMap>
    )
  );
};

export default observer(FindCareMapAreaComponent);
