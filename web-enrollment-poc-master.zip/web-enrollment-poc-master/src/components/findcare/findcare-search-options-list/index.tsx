import { SearchOptions } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { FindCareSearchOptionsType } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/find-care-search-categorites';

export { FindCareSearchOptionsListComponent } from './findcare-search-options-list.component';

export const PREDEFINED_SEARCH_OPTIONS: FindCareSearchOptionsType[] = [
  {
    display: 'Specialties',
    additionaInfo: '',
    code: SearchOptions.Specialties.toString()
  },
  {
    display: 'Services',
    additionaInfo: '',
    code: SearchOptions.Services.toString()
  },
  {
    display: 'Facilities',
    additionaInfo: '',
    code: SearchOptions.Organizations.toString()
  },
  {
    display: 'All Providers',
    additionaInfo: '',
    code: SearchOptions.Practitioners.toString()
  }
];
