import { FC, useCallback, useEffect, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { FindCareSearchOptionsListItem } from '../findcare-item/findcare-search-options-item';
import { useStores } from '../../../stores/useStores';

import * as styles from './findcare-search-options-list.styles';
import { observer } from 'mobx-react';
import { FindCareSearchOptionsType } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/find-care/find-care-search-categorites';
import { FixedSizeList as List } from 'react-window';
import AutoSizer from 'react-virtualized-auto-sizer';
import { Link, NavLink, useRouteMatch, useHistory, useLocation } from 'react-router-dom';
import FindCareSearchBox from '../findcare-searchbox/findcare-searchbox-component';
import { failureSource, FindCareResultStoreType } from '@healthcareapp/connected-health-common-services';
import { FindCareResultItem } from '../findcare-item/findcare-result-item/findcare-result-item.component';
import { SearchOptions } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { toJS } from 'mobx';
import { Error } from 'components/error';
import Loader from 'components/general/loader/loader.component';

const EmptyListMessage: FC<{ text: string }> = ({ text }) => (
  <div css={{ margin: '0 auto', marginTop: '15%' }}>
    <p css={{ color: globalStyles.COLOR.charcoalGrey, fontSize: '1.6rem', fontWeight: 400, fontStyle: 'italic', lineHeight: 1.25 }}>{text}</p>
  </div>
);

interface IFindCareSearchOptionsListComponent {
  categoriesList?: FindCareSearchOptionsType[] | null;
  emptyListMessage?: string;
  searchCategory: SearchOptions;
  isPageNotFoundError?: boolean;
}

export const FindCareSearchOptionsListComponent: FC<IFindCareSearchOptionsListComponent> = observer(
  ({ categoriesList = null, emptyListMessage = 'No results.', searchCategory, isPageNotFoundError = false }) => {
    const { routesStore, themeStore, findCareStore } = useStores();

    const [selectedResult, setSelectedResult] = useState('');
    const history = useHistory();
    const location = useLocation();

    useEffect(() => {
      //for seting the currect result on the page if back btn was preesed
      const findCareResultUUID = location.pathname.split('/').pop();
      const findCareSelectedResult = findCareStore.filteredResults.filter(res => res.uuid === findCareResultUUID).pop();

      findCareResultUUID && setSelectedResult(findCareResultUUID);
      if (findCareSelectedResult) findCareStore.setSelectedResult(findCareSelectedResult);
      else findCareStore.clearSelectedResult();
    }, [location]);

    useEffect(() => {
      findCareStore.setSearchType(searchCategory);
    });

    const searchboxTitle = {
      [SearchOptions.Specialties]: 'Search Specialties',
      [SearchOptions.Services]: 'Search Services',
      [SearchOptions.Practitioners]: 'Search Providers',
      [SearchOptions.Organizations]: 'Search Facilities',
      [SearchOptions.SpecialtiesResults]: 'Search ' + findCareStore.selectedSpecialty?.display,
      [SearchOptions.ServicesResults]: 'Search ' + findCareStore.selectedService?.display
    };

    const searchboxContentPlaceholder = {
      [SearchOptions.Specialties]: 'by name or code',
      [SearchOptions.Services]: 'by name or description',
      [SearchOptions.Practitioners]: 'by name or facility',
      [SearchOptions.Organizations]: 'by name',
      [SearchOptions.ServicesResults]: 'by name or facility',
      [SearchOptions.SpecialtiesResults]: 'by name or facility'
    };

    let match = useRouteMatch();

    const onSearchbyValueChanged = searchby => {
      findCareStore.setSearchByFilter(searchby);
    };

    const onSelectedResult = useCallback(
      (findCareResult: FindCareResultStoreType) => {
        setSelectedResult(findCareResult.uuid);
        findCareStore.setSelectedResult(findCareResult);
      },
      [findCareStore]
    );

    const onSelectedCategory = (findCareCategory: FindCareSearchOptionsType) => {
      if (findCareStore.selected) {
        findCareStore.clearSelectedResult();
      }
      if (findCareStore.searchType === SearchOptions.Specialties) {
        findCareStore.setSelectedSpecialty(findCareCategory);
        findCareStore.setSearchType(SearchOptions.SpecialtiesResults);
      } else if (findCareStore.searchType === SearchOptions.Services) {
        findCareStore.setSelectedService(findCareCategory);
        findCareStore.setSearchType(SearchOptions.ServicesResults);
      }
    };

    const listHeader = (showSearchBox: boolean = true) => (
      <div css={[styles.mainHeaderContainer, styles.activeBackgroundLight(themeStore.currentTheme)]}>
        {findCareStore.searchType === SearchOptions.All ? (
          <p css={styles.mainHeaderContainerTextStyle}>BROWSE OR SEARCH BY</p>
        ) : (
          <div>
            <div
              css={{ paddingBottom: '1.8rem', flex: 1, display: 'flex', alignItems: 'left' }}
              onClick={() => {
                history.goBack();
              }}>
              <span css={styles.backLink}>&lt; BACK</span>
            </div>

            {showSearchBox && (
              <div css={{ marginBottom: '2px', marginTop: '' }}>
                <FindCareSearchBox
                  onSearchbyValueChanged={onSearchbyValueChanged}
                  title={searchboxTitle[findCareStore.searchType] || 'Search'}
                  placeholder={searchboxContentPlaceholder[findCareStore.searchType] || ''}
                />
              </div>
            )}
          </div>
        )}
      </div>
    );

    const errorToShow = (
      <div css={styles.errorContainer(themeStore.currentTheme)}>
        <Error errorText={'Something went wrong.'} additionalText={'Try reloading the page or try again later.'} style={styles.errorStyle} errorIconStyle={styles.errorIconStyle} />
      </div>
    );

    const pageNotFoundError = (
      <div css={styles.errorContainer(themeStore.currentTheme)}>
        <Error
          errorText={'Sorry, we couldn’t find this page'}
          additionalText={'You may have mistyped the address or the page may have moved.'}
          errorSource={failureSource.Page_Not_found}
          style={styles.errorStyle}
          errorIconStyle={styles.errorIconStyle}
        />
      </div>
    );

    const Row = ({ index, style }) =>
      findCareStore.searchType === SearchOptions.Specialties || findCareStore.searchType === SearchOptions.Services || findCareStore.searchType === SearchOptions.All ? (
        <div>
          {categoriesList && index >= 0 && index < categoriesList.length && (
            <NavLink to={`${match.url}/${categoriesList[index].code}`} css={styles.navLinkStyle} key={categoriesList[index].code}>
              <div>
                <FindCareSearchOptionsListItem key={categoriesList[index].code} item={categoriesList[index]} style={style} onClick={() => onSelectedCategory(categoriesList[index])} />
              </div>
            </NavLink>
          )}
        </div>
      ) : (
        <div>
          {findCareStore.filteredResults && index >= 0 && index < findCareStore.filteredResults.length && (
            <NavLink
              activeStyle={{ pointerEvents: 'none', cursor: 'pointer' }}
              to={`${match.url}/${findCareStore.filteredResults[index].uuid}`}
              css={styles.navLinkStyle}
              key={findCareStore.filteredResults[index].uuid}>
              <div>
                <FindCareResultItem
                  key={findCareStore.filteredResults[index].uuid}
                  item={findCareStore.filteredResults[index]}
                  style={style}
                  isSelected={selectedResult === findCareStore.filteredResults[index].uuid}
                  onClick={() => findCareStore.filteredResults && onSelectedResult(findCareStore.filteredResults[index])}
                />
              </div>
            </NavLink>
          )}
        </div>
      );

    const itemsCollection = (
      <div css={styles.infiniteContainerStyle}>
        <AutoSizer>
          {({ height, width }) => (
            <List
              css={{ marginLeft: '20px' }}
              height={height}
              itemCount={
                findCareStore.searchType === SearchOptions.Specialties || findCareStore.searchType === SearchOptions.Services || findCareStore.searchType === SearchOptions.All
                  ? categoriesList?.length
                  : findCareStore.filteredResults?.length
              }
              itemSize={80}
              width={width - 20}>
              {Row}
            </List>
          )}
        </AutoSizer>
      </div>
    );

    const resultsError = () => {
      return (
        findCareStore.isError &&
        (findCareStore.searchType === SearchOptions.Practitioners ||
          findCareStore.searchType === SearchOptions.Organizations ||
          findCareStore.searchType === SearchOptions.SpecialtiesResults ||
          findCareStore.searchType === SearchOptions.ServicesResults)
      );
    };

    return (
      <>
        {findCareStore.showSearchOptions && (
          <div css={[styles.container, styles.boxShadow]}>
            {listHeader(!isPageNotFoundError && !resultsError())}
            {findCareStore.isLoading ? (
              <Loader loading={findCareStore.isLoading} color={themeStore.currentTheme.colors.actionMedium.published} />
            ) : isPageNotFoundError ? (
              pageNotFoundError
            ) : resultsError() ? (
              errorToShow
            ) : (findCareStore.filteredResults == null || findCareStore.filteredResults?.length === 0) && (categoriesList == null || categoriesList?.length === 0) ? (
              <div css={styles.container}>
                <EmptyListMessage text={emptyListMessage} />
              </div>
            ) : (
              itemsCollection
            )}
          </div>
        )}
      </>
    );
  }
);
