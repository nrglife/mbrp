/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const container = css({
  display: 'flex',
  flex: '1',
  flexFlow: 'column nowrap',
  backgroundColor: 'white'
});

export const errorContainer = (theme: Preferences) =>
  css({
    display: 'flex',
    flex: '1',
    flexFlow: 'column nowrap',

    backgroundColor: theme.colors.backgroundLight.published
  });

export const errorStyle = css({
  marginTop: '5rem'
});

export const errorIconStyle = css({ width: '5rem', height: '5rem' });

export const boxShadow = css({
  // boxShadow: '0 2px 4px 0 rgba(0,0,0,0.15)',
  // border: `solid 1px ${globalStyles.COLOR.veryLightPinkFour}`
});

export const mainHeaderContainer = css({ flexFlow: 'column nowrap', paddingLeft: '14px', paddingRight: '18px', paddingTop: '17px', paddingBottom: '17px' });

export const headerContainer = css({
  display: 'flex',
  flexFlow: 'row nowrap',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: '12px'
});

export const activeBackgroundLight = (theme: Preferences) =>
  css({
    backgroundColor: theme.colors.backgroundLight.published
  });

export const mainHeaderContainerTextStyle = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.1rem',
  fontWeight: 'bold',
  lineHeight: 1.45
});

export const headerTextStyle = css({ fontSize: '1.3rem', fontWeight: 400, lineHeight: 1.38 });

export const infiniteContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: '1 0 300px', overflowY: 'auto', backgroundColor: 'white' });

export const navLinkStyle = css({
  textDecoration: 'none',
  '&:focus': { textDecoration: 'none' },
  '&:hover': { textDecoration: 'none' },
  '&:visited': { textDecoration: 'none' },
  '&:link': { textDecoration: 'none' },
  '&:active': { textDecoration: 'none' }
});

export const selectedStyle = (theme: Preferences) => css({ position: 'absolute', left: '1px', right: '1px', top: '3px', bottom: '2px', border: `3px solid ${theme.colors.actionLight.published}` });

export const leftSectionContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 2, marginRight: 10, width: '100%' });

export const containerSeperator = css({ marginLeft: '25px', borderBottom: `solid 9px ${globalStyles.COLOR.veryLightPinkFour}` });

export const backLink = css({
  fontSize: '1.2rem',
  fontWeight: 'bold',
  cursor: 'pointer',
  color: globalStyles.COLOR.charcoalGreyTwo,
  textDecoration: 'none'
});
