import { FC, useState, useEffect, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
import { getAddressFromLocation, useGooglePlacesLoaded, initFormattedAddress } from 'services/GoogleMapsService';
import * as styles from './find-care-browsing-area.styles';
import { ReactComponent as TriangleRightArrowIcon } from '../../../assets/icons/arrow-dropdown-down.svg';
import { ReactComponent as LocationPinIcon } from '../../../assets/icons/icons-interactions-location.svg';
import { LocationSelectType, searchRadiusOptions, Location } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { useStores } from 'stores/useStores';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import GeolocationSearchBox from '../../../components/geolocation/geolocation-search-box/geolocation-search-box.component';
import Select, { SelectOption } from 'components/general/select/select.component';

interface BrowsingAreaProps {}

const BrowsingAreaComponent: FC<BrowsingAreaProps> = () => {
  const [visible, setVisible] = useState(true);
  const { findCareStore } = useStores();
  const [isGooglePlacesLoaded] = useGooglePlacesLoaded();
  const collapsedOnStart = useRef<boolean>(false);
  const { NotificationModal, setNotificationModalVisibility } = useNotificationModal({ buttonText: 'CLOSE', useThemeForBackgroundColor: false });
  const searchRadius = findCareStore.searchRadius;

  const selectOptions: SelectOption[] = searchRadiusOptions.map(option => ({
    key: option.radius,
    value: option.display
  }));

  const onSelectchange = value => {
    findCareStore.setSearchRadius(parseInt(value));
  };

  const hasBrowserLocationPermission = async () => {
    let hasPermission = false;
    try {
      if (navigator.permissions) {
        const permissionStatus = await navigator?.permissions?.query({ name: 'geolocation' });
        const { state } = permissionStatus;
        if (state === 'granted') {
          hasPermission = true;
        }
      }
    } catch (err) {}

    return hasPermission;
  };

  const trySetCurrentLocation = async (isOriginFromDefaultInit = false) => {
    if (navigator.geolocation) {
      let askForCurrentPosition = true;
      if (isOriginFromDefaultInit) {
        askForCurrentPosition = await hasBrowserLocationPermission();
      }

      if (askForCurrentPosition) {
        try {
          navigator.geolocation.getCurrentPosition(
            async position => {
              const currentLocationResult: any = await getAddressFromLocation(position.coords.latitude, position.coords.longitude);
              const currentLocation: Location = {
                formatted_address: initFormattedAddress(currentLocationResult.formatted_address),
                placeId: currentLocationResult.place_id,
                latitude: currentLocationResult.geometry.location.lat(),
                longitude: currentLocationResult.geometry.location.lng(),
                locationSelectType: LocationSelectType.CurrentLocation
              };
              findCareStore.setCurrentLocation(currentLocation);
              findCareStore.setSelectedLocation(currentLocation);

              if (isOriginFromDefaultInit && !collapsedOnStart.current) {
                setVisible(false);
                collapsedOnStart.current = true;
              }
            },
            error => {
              setNotificationModalVisibility(
                true,
                'Something went wrong',
                'Sorry, we were unable to get your location. \r\n\r\n Check your browser settings to make sure Connected Health is allowed to access your location.'
              );
              console.log(`Cant get current position, error code: ${error.code}, message: ${error.message}`);
            }
          );
        } catch (err) {
          console.log(err);
        }
      }
    }
  };

  useEffect(() => {
    if (!findCareStore.selectedLocation) {
      if (findCareStore.homeLocation && !collapsedOnStart.current) {
        findCareStore.setSelectedLocation(findCareStore.homeLocation);
        setVisible(false);
        collapsedOnStart.current = true;
      }
    }
  }, [findCareStore.homeLocation]);

  useEffect(() => {
    if (isGooglePlacesLoaded && !findCareStore.homeLocation) {
      trySetCurrentLocation(true);
    }
  }, [isGooglePlacesLoaded]);

  return (
    <div css={styles.container}>
      <div css={[styles.titleContainer, !!findCareStore.selectedLocation && styles.pointer]} onClick={() => setVisible(!findCareStore.selectedLocation ? true : !visible)}>
        <TriangleRightArrowIcon css={[styles.arrowIcon, !findCareStore.selectedLocation && styles.hiddenArrowIcon, visible && styles.rotateArrowIcon]} />
        {visible ? (
          <div css={styles.title}>{!findCareStore.selectedLocation ? 'Select' : 'Change'} your browsing area</div>
        ) : (
          <div css={styles.location}>
            <LocationPinIcon css={styles.locationIcon} />
            {findCareStore.selectedLocation ? (
              <>
                {`Within ${searchRadius} ${searchRadius > 1 ? 'miles' : 'mile'} of `}
                {findCareStore.selectedLocation?.locationSelectType === LocationSelectType.Home ? (
                  <span css={styles.homeSelected}>Home</span>
                ) : findCareStore.selectedLocation?.locationSelectType === LocationSelectType.CurrentLocation ? (
                  <span css={styles.homeSelected}>Current Location</span>
                ) : (
                  findCareStore.selectedLocation?.formatted_address
                )}
              </>
            ) : (
              <>No location selected</>
            )}
          </div>
        )}
      </div>
      {visible && (
        <div css={styles.geolocationSearchBoxContainer}>
          <GeolocationSearchBox
            onLocationSelected={location => {
              findCareStore.setSelectedLocation(location);
            }}
            onCurrentLocationClicked={() => trySetCurrentLocation()}
            selectedLocation={findCareStore.selectedLocation}
            homeLocation={findCareStore.homeLocation}
          />
        </div>
      )}
      {visible && (
        <div css={styles.searchContainer}>
          <div css={styles.title}>Search Radius</div>
          <Select onChange={onSelectchange} options={selectOptions} value={searchRadius} />
        </div>
      )}
      <NotificationModal />
    </div>
  );
};

export default observer(BrowsingAreaComponent);
