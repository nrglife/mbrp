/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';
import { now } from 'moment';

export const arrowIconSize = '1.7rem';
export const pinIconSize = '1.4rem';

export const container = css({
  padding: '1.1rem 1.8rem 1.8rem 1rem',
  backgroundColor: globalStyles.COLOR.white
});

export const title = css({
  fontSize: '1.1rem',
  color: globalStyles.COLOR.charcoalGreyFive,
  fontWeight: 'bold',
  textTransform: 'uppercase'
});

export const geolocationSearchBoxContainer = css({
  marginTop: '1.6rem',
  marginLeft: '1.6rem'
});

export const location = css({
  ...globalStyles.STYLES.ellipsis,
  whiteSpace: 'nowrap',
  fontSize: '1.4rem',
  color: globalStyles.COLOR.charcoalGreyFive
});

export const titleContainer = css({
  display: 'flex',
  justifyContent: 'flex-start',
  alignItems: 'center',
  alignContent: 'center'
});

export const pointer = css({
  cursor: 'pointer'
});

export const searchContainer = css({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingLeft: '1.8rem',
  margin: '1rem 0'
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const arrowIcon = css({
  color: globalStyles.COLOR.charcoalGrey,
  transform: 'rotate(-90deg)',
  width: arrowIconSize,
  height: arrowIconSize,
  '&:hover': {
    cursor: 'pointer'
  }
});

export const locationIcon = css({
  color: globalStyles.COLOR.charcoalGrey,
  width: pinIconSize,
  height: pinIconSize,
  marginRight: '0.2rem'
});

export const homeSelected = css({
  fontWeight: 'bold'
})

export const rotateArrowIcon = css({ transform: 'none' });

export const hiddenArrowIcon = css({ visibility: 'hidden' });
