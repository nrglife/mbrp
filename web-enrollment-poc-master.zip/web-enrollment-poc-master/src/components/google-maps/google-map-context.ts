import { useContext, createContext } from 'react'

const GoogleMapContext = createContext<google.maps.Map | null>(null)

export function useGoogleMap(): google.maps.Map | null {
  const map = useContext(GoogleMapContext)
  return map
}
 
export default GoogleMapContext
