import { FC, useEffect, useRef } from 'react';
import { MapLocation, useGoogleMap } from 'components/google-maps';

export interface IGoogleMapsCircle {
  center: MapLocation;
  radius: number;
  strokeColor?: string;
  strokeOpacity?: number;
  strokeWeight?: number;
  fillColor?: string;
  fillOpacity?: number;
}


export const GoogleMapsCircle: FC<IGoogleMapsCircle> = ({ center, radius, strokeColor, strokeOpacity, strokeWeight, fillColor, fillOpacity }) => {
  const circleInstance = useRef<google.maps.Circle | null>(null);
  const map = useGoogleMap();

  useEffect(() => {
    if (map) {
      circleInstance.current?.setMap(null);

      if (center && center.latitude && center.longitude && radius && radius > 0) {
        circleInstance.current = new google.maps.Circle({
          center: { lat: center.latitude, lng: center.longitude },
          radius: radius,
          map: map,
          strokeColor: strokeColor,
          strokeOpacity: strokeOpacity,
          strokeWeight: strokeWeight,
          fillColor: fillColor,
          fillOpacity: fillOpacity
        });
      }
    }
    return () => {
      circleInstance.current?.setMap(null);
      circleInstance.current = null;
    };
  }, [center, radius, map]);

  return null;
};
