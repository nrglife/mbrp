import { FC, useEffect, useRef } from 'react';
import { MapLocation, useGoogleMap } from 'components/google-maps';

export interface IGoogleMapsMarker {
  location: MapLocation;
  title?: string;
  svgIcon?: MarkerSVG;
}

export type MarkerSVG = {
  svgElement: any;
  // size?: { width: number; height: number };
  // scaledSize?: { width: number; height: number };
  // origin?: { x: number; y: number };
  anchor?: { x: number; y: number };
};

export const GoogleMapsMarker: FC<IGoogleMapsMarker> = ({ location, title, svgIcon }) => {
  const markerInstance = useRef<google.maps.Marker | null>(null);
  const svgDivRef = useRef<HTMLDivElement | null>(null);
  const map = useGoogleMap();

  useEffect(() => {
    if (map) {
      markerInstance.current?.setMap(null);
      const svg = svgIcon && svgDivRef.current?.innerHTML;

      markerInstance.current = new google.maps.Marker(
        Object.assign(
          {
            position: { lat: location?.latitude, lng: location?.longitude },
            map: map,
            title: title,
            // label: { text: '2', color: 'white' },
          },
          svgIcon &&
            svg && {
              icon: {
                url: 'data:image/svg+xml;charset=UTF-8;base64,' + btoa(svg || ''),
                anchor: (svgIcon.anchor) && new google.maps.Point(svgIcon.anchor.x, svgIcon.anchor.y)
              }
            }
        )
      );
    }
    return () => {
      markerInstance.current?.setMap(null);
      markerInstance.current = null;
    };
  }, [location, title, svgIcon, map]);

  return <>{svgIcon?.svgElement && <div ref={svgDivRef}>{svgIcon?.svgElement}</div>}</>;
};
