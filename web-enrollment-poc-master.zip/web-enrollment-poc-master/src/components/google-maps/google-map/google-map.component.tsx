import React, { FC, useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { IGoogleMapsMarker, GoogleMapContext } from 'components/google-maps';
import { useGooglePlacesLoaded } from 'services/GoogleMapsService';

//styles
import * as styles from './google-map.styles';

export type MapLocation = {
  longitude: number;
  latitude: number;
};

export class MapController {
  protected readonly mapInstance: google.maps.Map;

  constructor(map: google.maps.Map) {
    this.mapInstance = map;
  }

  public get map(): google.maps.Map {
    return this.mapInstance;
  }

  public setZoom(zoom: number) {
    this.mapInstance.setZoom(zoom);
  }

  public setCenter(center: MapLocation) {
    this.mapInstance.setCenter({ lat: center.latitude, lng: center.longitude });
  }

  public fitToCircle(center: MapLocation, radiusInMiles: number) {
    const radiusCircle = new google.maps.Circle({
      center: { lat: center.latitude, lng: center.longitude },
      radius: 1609.34 * radiusInMiles
    });
    this.mapInstance.fitBounds(radiusCircle.getBounds());
  }
}

interface IGoogleMapProps {
  defaultCenter?: MapLocation;
  defaultZoom?: number;
  centerMarker?: IGoogleMapsMarker;
  onLoad?: (map: any) => void;
}

export const GoogleMap: FC<IGoogleMapProps> = ({ defaultZoom = 4, defaultCenter, onLoad, centerMarker, children }) => {
  const [isGooglePlacesLoaded] = useGooglePlacesLoaded();
  const [isLoaded, setIsLoaded] = useState(false);
  const mapElementRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);

  const initMap = (): void => {
    const center = defaultCenter ? { lat: defaultCenter?.latitude, lng: defaultCenter?.longitude } : null;
    const node = ReactDOM.findDOMNode(mapElementRef.current);
    const map = new (window as any).google.maps.Map(node, {
      zoom: defaultZoom,
      center: center
    });
    mapRef.current = map;
    setIsLoaded(true);

    if (onLoad) {
      onLoad(new MapController(mapRef.current));
    }
  };

  useEffect(() => {
    if (isGooglePlacesLoaded) {
      initMap();
    }
  }, [isGooglePlacesLoaded]);

  // const getChildrenElements = () => {
  //   let childrenElements: any[] = React.Children.toArray(children);
  //   const elements = childrenElements.map(child => {
  //     return React.cloneElement(child, { map: mapRef.current });
  //   });
  //   return elements;
  // };

  return (
    <div ref={mapElementRef} css={styles.mapElement}>
      {isLoaded && <GoogleMapContext.Provider value={mapRef.current}>{children}</GoogleMapContext.Provider>}
      {/* {isLoaded && getChildrenElements()} */}
    </div>
  );
};
