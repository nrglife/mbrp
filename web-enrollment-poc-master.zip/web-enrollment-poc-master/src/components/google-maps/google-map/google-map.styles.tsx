import { css } from '@emotion/core';

export const mapElement = css({ width: '100%', height: '100%', display: 'flex' });
