import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { SerializedStyles } from '@emotion/core';
//consts
import * as styles from './general-error.styles';
import { ReactComponent as DefaultIcon } from '../../assets/icons/icons-general-settings.svg';

interface GeneralErrorProps {
  generalErrorContainerStyle?: SerializedStyles;
  showIcon?: boolean;
  Icon?: React.FunctionComponent;
  iconStyle?: SerializedStyles;
  h1Style?: SerializedStyles;
  h1Contant?: string;
  h2Style?: SerializedStyles;
  h2Contant?: string;
}

const GeneralError: FC<GeneralErrorProps> = ({
  generalErrorContainerStyle = {},
  showIcon = true,
  Icon = null,
  iconStyle = {},
  h1Style = {},
  h1Contant = null,
  h2Style = {},
  h2Contant = null,
  children
}) => {
  const default_h1Contant: string = 'Connected Health uses cookies';
  const default_h2Contant: string = 'Enable cookies on your browser and reload this page';

  return (
    <div css={[styles.default_generalErrorContainer, generalErrorContainerStyle]}>
      {showIcon && (Icon ? <Icon css={[styles.default_icon, iconStyle]} /> : <DefaultIcon css={[styles.default_icon, iconStyle]} />)}
      <div css={[styles.default_h1, h1Style]}>{h1Contant ? h1Contant : default_h1Contant}</div>
      <div css={[styles.default_h2, h2Style]}>{h2Contant ? h2Contant : default_h2Contant}</div>
      {children}
    </div>
  );
};

export default GeneralError;
