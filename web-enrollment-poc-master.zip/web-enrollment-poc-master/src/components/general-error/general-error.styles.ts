/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';

export const default_generalErrorContainer = css({
  width: '100%',
  height: '100%',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'column',
  background: 'white',
  color: globalStyles.COLOR.charcoalGrey
});

export const default_icon = css({
  width: '7.9rem',
  height: '7.9rem',
  marginBottom: '4.4rem',
  '@media (max-width: 900px)': {
    width: '5.9rem',
    height: '5.9rem'
  },
  '@media (max-width: 550px)': {
    width: '4.9rem',
    height: '4.9rem',
    marginBottom: '1.4rem'
  }
});

export const default_h1 = css({
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '4.3rem',
  lineHeight: '3.5rem',
  letterSpacing: '-0.22px',
  marginBottom: '1.5rem',
  '@media (max-width: 900px)': {
    fontSize: '3.5rem'
  },
  '@media (max-width: 550px)': {
    fontSize: '2.3rem',
    marginBottom: '.5rem'
  }
});

export const default_h2 = css({
  textAlign: 'center',
  fontSize: '2.5rem',
  lineHeight: '3.5rem',
  letterSpacing: '-0.13px',
  '@media (max-width: 900px)': {
    fontSize: '2.5rem'
  },
  '@media (max-width: 550px)': {
    fontSize: '1.5rem'
  }
});
