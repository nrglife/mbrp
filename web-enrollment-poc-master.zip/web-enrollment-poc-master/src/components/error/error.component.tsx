import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles } from '@emotion/core';
import { ReactComponent as WarningThin } from 'assets/icons/warning-thin.svg';
import ErrorCode from 'components/error-code/error-code.component';

import * as styles from './error.styles';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useStores } from 'stores/useStores';

interface IErrorProps {
  errorText?: string[] | string;
  style?: SerializedStyles;
  errorIconStyle?: SerializedStyles;
  additionalText?: string;
  showErrorIcon?: boolean;
  //ErrorCode component params
  errorSource?: failureSource | failureSource[];
  Image?: any;
  ignoreNextPage?: boolean;
}

export const Error: FC<IErrorProps> = ({ errorText, style, showErrorIcon = true, errorIconStyle, additionalText, errorSource, Image, ignoreNextPage }) => {
  const { t } = useTranslation('translation');
  const { responsiveStore } = useStores();
  const defaultText = [`${t(LocaleKeys.errors.something_went_wrong)}.`, `${t(LocaleKeys.errors.try_reloading_the_page)}`];
  const selectedImage = Image ? <Image css={[styles.iconStyle, errorIconStyle]}></Image> : <WarningThin css={[styles.iconStyle, errorIconStyle]} />;
  const textToDisplay = errorText ? errorText : defaultText;
  return (
    <div css={[styles.container, responsiveStore.isMobile && styles.mobileContainerUpdate]}>
      <div css={styles.errorContainerStyle}>
        <div css={[styles.errorDetailsContainerStyle, style]}>
          {showErrorIcon && selectedImage}
          <h1 css={styles.errorTextStyle}>
            {typeof textToDisplay !== 'string' ? (
              textToDisplay.map((part, i) => {
                return <p key={i.toString()}>{part}</p>;
              })
            ) : (
              <p>{textToDisplay}</p>
            )}
          </h1>
          <h1 css={styles.additionalTextStyle}></h1>
        </div>
        {errorSource && <ErrorCode componentStyle={styles.errorCodeTextStyle} errorSource={errorSource} ignoreNextPage={ignoreNextPage} />}
      </div>
    </div>
  );
};
