/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const container = css({ display: 'flex', justifyContent: 'center', width: '100%', padding: '0 11px', height: '100%' });

export const mobileContainerUpdate = css({ padding: '0 7rem' });

export const errorContainerStyle = css({ backgroundcolor: 'red', display: 'flex', flexFlow: 'row wrap', width: '100%', maxWidth: '400px' });

export const iconStyle = css({ color: '#c3c5cd' });

export const errorDetailsContainerStyle = css({ display: 'flex', flexFlow: 'column wrap', width: '100%', alignItems: 'center', marginTop: '189px' });

export const errorTextStyle = css({
  marginTop: '20px',
  textAlign: 'center',
  fontSize: '1.6rem',
  fontWeight: 400,
  fontStyle: 'italic',
  lineHeight: 1.25,
  color: globalStyles.COLOR.charcoalGreyFive
});

export const additionalTextStyle = css({
  marginTop: '2.5rem',
  textAlign: 'center',
  fontSize: '1.6rem',
  fontWeight: 400,
  fontStyle: 'italic',
  lineHeight: 1.25,
  width: '80%',
  color: globalStyles.COLOR.charcoalGreyFive
});

export const errorCodeTextStyle = css({
  width: '100%',
  textAlign: 'center',
  alignSelf: 'flex-end',
  marginBottom: '2.3rem',
  fontSize: '1.2rem',
  fontWeight: 400,
  lineHeight: 1.33,
  color: globalStyles.COLOR.battleshipGrey
});
