import { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { css, jsx, SerializedStyles } from '@emotion/core';
//developed
import { useStores } from 'stores/useStores';
import { Preferences } from 'stores/ThemeStore';
//styles
import { globalStyles } from '../../../../../styles/global.styles';

interface SearchBoxItemProps {
  onClick?: Function;
  onMouseDown?: Function;
  itemContainerStyle?: SerializedStyles;
  withBottomBorder?: boolean;
  textStyle?: SerializedStyles;
  text?: string;
  icon?: any;
}

const SearchBoxItem: FC<SearchBoxItemProps> = ({ onClick, onMouseDown, itemContainerStyle, withBottomBorder = false, textStyle, text = '', icon = null }) => {
  const { themeStore } = useStores();
  return (
    <div
      onClick={() => onClick && onClick()}
      onMouseDown={() => onMouseDown && onMouseDown()}
      css={[styles.itemContainer, withBottomBorder && styles.itemBottomBorder, styles.itemContainerHover(themeStore.currentTheme), itemContainerStyle, {display:'flex', flexDirectiondire: 'row', alignItems: 'center', flexFlow: 'row nowrap',}]}>
      {icon}
      <div css={[styles.text, textStyle]}>        
        {text}
      </div>
    </div>
  );
};

const styles = {
  itemContainer: css({
    display: 'flex',
    flexDirection: 'row',
    padding: '1rem 1rem'
  }),

  itemContainerHover: (theme: Preferences) =>
    css({
      '&:hover': {
        cursor: 'pointer',
        background: `${theme.colors.actionLight.published}90`
      }
    }),

  itemBottomBorder: css({
    borderBottomColor: globalStyles.COLOR.veryLightPink,
    borderBottomWidth: '.1rem'
  }),

  text: css({
    fontSize: '1.4rem',
    lineHeight: '2rem',
    color: globalStyles.COLOR.slateGrey
  }),
};

export default SearchBoxItem;
