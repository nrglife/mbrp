/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const Container = css({
  position: 'relative'
});

export const searchBoxContainer = css({
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '.2em',
  border: `solid .1rem ${globalStyles.COLOR.veryLightPinkFive}`,
  backgroundColor: globalStyles.COLOR.white
});

export const hoveringContainer = css({
  boxShadow: `0 0.2rem 0.4rem 0 rgba(0, 0, 0, 0.2), 0 0.2rem 0.6rem 0 rgba(0, 0, 0, 0.15)`,
  borderBottom: '0',
  borderRadius: '0.2em .2em 0 0',
  paddingBottom: '.1rem'
});

export const resultHoveringContainer = css({
  boxShadow: `0 0.4rem 0.4rem 0 rgba(0, 0, 0, 0.2), 0 0.6rem 0.6rem 0 rgba(0, 0, 0, 0.15)`,
  alignItems: 'center',
  justifyContent: 'center',
  border: `solid .1rem ${globalStyles.COLOR.veryLightPinkFive}`,
  backgroundColor: globalStyles.COLOR.white,
  position: 'absolute',
  zIndex: 3,
  width: '100%',
  maxWidth: '30rem',
  borderRadius: '0 0 0.2em .2em',
  borderTop: '0',
  paddingTop: '4px',
  marginTop: '-4px'
});

export const searchBox = css({
  display: 'flex',
  flexDirection: 'column',
  padding: '1rem'
});

export const searchBoxHeadline = (theme: Preferences) =>
  css({
    textTransform: 'capitalize',
    fontSize: '1.3rem',
    color: `${theme.colors.actionMedium.published}`
  });

export const searchBoxInputRow = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginTop: '.3rem',
  alignItems: 'center'
});

export const searchIcon = {
  color: globalStyles.COLOR.coolGrey,
  width: '2.4rem',
  height: '2.4rem',
  alignSelf: 'center'
};

export const xIcon = {
  ...searchIcon,
  cursor: 'pointer',
  color: globalStyles.COLOR.blackTwo
};

export const homeIcon = css({
  color: globalStyles.COLOR.coolGrey,
  width: '1.4rem',
  height: '1.4rem',
  marginRight: '0.6rem'
});

export const textInput = css({
  flex: 1,
  borderWidth: 0,
  fontSize: '1.4rem',
  lineHeight: '2.8rem',
  color: globalStyles.COLOR.blackTwo,
  '&::placeholder': {
    fontSize: '1.4rem',
    lineHeight: '2.8rem',
    color: globalStyles.COLOR.slateGrey
  }
});

export const textInputSelected = css({
  color: globalStyles.COLOR.blackTwo,
  ...globalStyles.STYLES.ellipsis
});

export const searchResultItem = css({
  color: globalStyles.COLOR.blackTwo,
});

export const homeCurrentLocationItem = css({
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});

export const homeCurrentLocationIcon = css({
  color: globalStyles.COLOR.slateGrey,
  width: '1.5rem',
  height: '1.5rem',
  marginRight: '0.7rem'
});
