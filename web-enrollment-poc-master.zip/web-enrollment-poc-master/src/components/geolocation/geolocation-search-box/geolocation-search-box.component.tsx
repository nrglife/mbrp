import { FC, useState, useEffect, useCallback, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
//third party
import { debounce } from 'lodash';
//developed
import { useStores } from 'stores/useStores';
import { loadGooglePlacesApiScript, googleAutocomplete, googlePlaceDetailsByID, initFormattedAddress } from 'services/GoogleMapsService';
import Loader from 'components/general/loader/loader.component';
import SearchBoxItem from './components/search-box-item/search-box-item.component';
import { Location, LocationSelectType } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
//icons
import { ReactComponent as SearchIcon } from 'assets/icons/icons-interactions-search.svg';
import { ReactComponent as XIcon } from 'assets/icons/x-close.svg';
import { ReactComponent as HomeIcon } from 'assets/icons/home.svg';
import { ReactComponent as LocationPinIcon } from 'assets/icons/icons-interactions-location.svg';

//styles
import * as styles from './geolocation-search-box.style';
import { globalStyles } from 'styles/global.styles';

type Item = {
  description: string;
  place_id: string;
};

interface GeoLocationSearchBoxProps {
  onLocationSelected?: (location: Location | null) => void;
  onCurrentLocationClicked?: () => void;
  searchDebounce?: number; //milisec
  selectedLocation?: Location | null;
  homeLocation?: Location | null;
}

const GeoLocationSearchBox: FC<GeoLocationSearchBoxProps> = ({ onLocationSelected, onCurrentLocationClicked, searchDebounce = 800, selectedLocation = null, homeLocation = null }) => {
  const { themeStore } = useStores();
  const [textInput, setTextInput] = useState('');
  const [isFocus, setIsFocus] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<Item[]>([]);
  const [loadingSearchResults, setLoadingSearchResults] = useState(false);
  const searchTextInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadGooglePlacesApiScript();
  }, []);

  useEffect(() => {
    setTextInput(selectedLocation?.formatted_address ? selectedLocation?.formatted_address : '');
  }, [selectedLocation]);

  const searchLocation = async (text: string) => {
    setLoadingSearchResults(true);
    try {
      const predictions = await googleAutocomplete(text);
      let searchResults: Item[] = [];
      if (Array.isArray(predictions)) {
        for (const prediction of predictions) {
          const { description = null, place_id = null } = prediction;
          description && place_id && searchResults.push({ description: initFormattedAddress(description), place_id });
        }
      }
      searchResults.length > 0 && setSearchResults(searchResults);
    } catch (error) {
      console.log('Error -', error);
    } finally {
      setLoadingSearchResults(false);
    }
  };

  const clearSearchBox = () => {
    setTextInput('');
    searchTextInput.current?.focus();
    setSearchResults([]);
    onLocationSelected && onLocationSelected(null);
  };

  const changeLocation = (text: string) => {
    text && text.trim().toLowerCase() !== textInput.trim().toLowerCase() && text.trim() !== '' && searchLocation(text.trim());

    (!text || text.trim() === '') && setSearchResults([]) && onLocationSelected && onLocationSelected(null);
  };

  const changeTextHandler = useCallback(debounce(changeLocation, searchDebounce), []);

  const onChangeText = (text: string) => {
    setTextInput(text);
    changeTextHandler(text);
  };

  const selectItem = async (locationDescription: string, place_id: string) => {
    setSearchResults([]);

    try {
      const placeDetails = await googlePlaceDetailsByID(place_id);
      const { formatted_address = locationDescription, geometry = {} } = placeDetails as any;
      const { location = {} } = geometry;
      const latitude = location?.lat ? (typeof location.lat === 'function' ? location.lat() : `${location.lat}`) : null;
      const longitude = location?.lng ? (typeof location.lng === 'function' ? location.lng() : `${location.lng}`) : null;

      if (latitude && longitude) {
        //set location to new one
        const newLocation: Location = {
          formatted_address: initFormattedAddress(formatted_address),
          placeId: location?.place_id,
          latitude: latitude,
          longitude: longitude,
          locationSelectType: LocationSelectType.None
        };
        onLocationSelected && onLocationSelected(newLocation);
      } else {
        // alert user there was a problem retrieving the coordinates of the location he choose
        console.log('Error - there was a problem retrieving the coordinates of the location');
      }
    } catch (error) {
      console.log('Error -', error);
    }
  };

  const searchOnFocus = e => {
    setIsFocus(true);
  };
  const searchOnBlur = e => {
    setIsFocus(false);
  };

  const onHomeItemClicked = () => {
    onLocationSelected && onLocationSelected(homeLocation);
  };

  const onCurrentLocationItemClicked = () => {
    onCurrentLocationClicked && onCurrentLocationClicked();
  };

  const showSearchResult = searchResults && searchResults.length > 0;
  const showHomeLocationItem = isFocus && textInput.length === 0 && (!searchResults || searchResults.length === 0) && !!homeLocation;
  const showCurrentLocationItem = isFocus && textInput.length === 0 && (!searchResults || searchResults.length === 0);
  const showAnyItem = isFocus && (showSearchResult || showHomeLocationItem || showCurrentLocationItem);

  return (
    <div css={styles.Container}>
      <div css={[styles.searchBoxContainer, showAnyItem && styles.hoveringContainer]}>
        <div css={styles.searchBox}>
          <div css={styles.searchBoxHeadline(themeStore.currentTheme)}>location</div>
          <div css={styles.searchBoxInputRow}>
            {selectedLocation && !isFocus && selectedLocation.locationSelectType === LocationSelectType.Home && <HomeIcon css={styles.homeIcon} />}
            <input
              css={[styles.textInput, !isFocus && styles.textInputSelected]}
              ref={searchTextInput}
              placeholder={isFocus ? '' : 'Search for a location'}
              onChange={e => onChangeText(e.target.value)}
              value={textInput}
              onFocus={e => searchOnFocus(e)}
              onBlur={e => searchOnBlur(e)}
            />
            {loadingSearchResults ? (
              <Loader loading={loadingSearchResults} position="inline"  color={themeStore.currentTheme.colors.actionMedium.published} />
            ) : (searchResults && searchResults.length > 0) || textInput.length > 0 ? (
              <XIcon style={styles.xIcon} onClick={clearSearchBox} />
            ) : (
              <SearchIcon style={styles.searchIcon} />
            )}
          </div>
        </div>
      </div>
      {showAnyItem && (
        <div css={styles.resultHoveringContainer}>
          {showSearchResult &&
            searchResults.map((item, index) => (
              <SearchBoxItem key={`searchResult${index}`} textStyle={styles.searchResultItem} onMouseDown={() => selectItem(item.description, item.place_id)} text={item.description} />
            ))}
          {showHomeLocationItem && (
            <SearchBoxItem key={`homeItem`} onMouseDown={onHomeItemClicked} text={'Home'} textStyle={styles.homeCurrentLocationItem} icon={<HomeIcon css={styles.homeCurrentLocationIcon} />} />
          )}
          {showCurrentLocationItem && (
            <SearchBoxItem
              key={`currentLocationItem`}
              onMouseDown={onCurrentLocationItemClicked}
              text={'Current Location'}
              textStyle={styles.homeCurrentLocationItem}
              icon={<LocationPinIcon css={styles.homeCurrentLocationIcon} />}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default GeoLocationSearchBox;
