/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';
import { Preferences } from '../../stores/ThemeStore';

export const test = (theme: Preferences) =>
  css({
    backgroundColor: globalStyles.COLOR.coolGrey,
    color: theme.colors.actionDark.published
  });

export const container = css({
  flex: 1
});

export const tabsHeadlinesContainer = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'row'
});

export const tabHeadline = css({
  padding: '1.5rem',
  fontWeight: 'bold',
  color: globalStyles.COLOR.battleshipGrey,
  fontSize: '1.3rem',
  letterSpacing: '0.5',
  borderBottom: `${globalStyles.COLOR.coolGrey} solid .2rem`,
  cursor: 'default'
});

export const hover = css({
  '&:hover': {
    transition: 'all .3s',
    cursor: 'pointer',
    position: 'relative',
    top: -1
  }
});

export const selectedTab = (theme: Preferences) =>
  css({
    color: theme.colors.actionDark.published,
    borderBottomColor: theme.colors.actionDark.published
  });

export const separator = css({
  margin: '.1rem',
  fontWeight: 'bold',
  color: globalStyles.COLOR.battleshipGrey,
  fontSize: '1.3rem',
  letterSpacing: '0.5',
  borderRight: `${globalStyles.COLOR.veryLightPink} solid .1rem`
});

export const tabContentContainer = css({
  display: 'flex',
  flex: 1
});
