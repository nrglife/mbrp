import { FC, useState } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';
//developed
import { useStores } from '../../stores/useStores';
//styles
import * as styles from './tabs.styles';

export type TabType = {
  isDisable?: boolean;
  content: React.ReactNode;
  headline: string;
};

interface TabsProps {
  tabs: TabType[];
  initialSelectedTabIndex?: number;
  withDefaultUpperCase?: boolean;
  onTabPressCallback?: ((event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void) | undefined;
}

const Tabs: FC<TabsProps> = ({ tabs, initialSelectedTabIndex = 0, withDefaultUpperCase = true, onTabPressCallback }) => {
  const {
    themeStore: { currentTheme }
  } = useStores();

  const [tabSelectedIndex, setTabSelectedIndex] = useState(initialSelectedTabIndex > 0 && initialSelectedTabIndex < tabs.length ? initialSelectedTabIndex : 0);

  const onTabPress = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, index: number) => {
    setTabSelectedIndex(index);
    onTabPressCallback && onTabPressCallback(event);
  };

  return (
    <div css={[styles.container]}>
      <div css={[styles.tabsHeadlinesContainer]}>
        {tabs.map((tab, i) => (
          <React.Fragment key={`tab-${tab.headline}-${i}`}>
            <div
              css={[styles.tabHeadline, i === tabSelectedIndex && styles.selectedTab(currentTheme), !tab.isDisable || (tabs.length > 1 && styles.hover)]}
              onClick={e => !tab.isDisable && tabs.length > 1 && onTabPress(e, i)}>
              {withDefaultUpperCase ? tab.headline.toUpperCase() : tab.headline}
            </div>
            {i < tabs.length && <div css={[styles.separator]} />}
          </React.Fragment>
        ))}
        {/* div to fill the void tile the end of the row */}
        <div css={[styles.tabHeadline, { flex: 1 }]}> </div>
      </div>
      <div css={[styles.tabContentContainer]}>{tabs && tabSelectedIndex != null && tabs[tabSelectedIndex].content}</div>
    </div>
  );
};

export default Tabs;
