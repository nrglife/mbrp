import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const galleryWrapper = css({
  width: '100%',
  maxWidth: '30rem',
  minHeight: '20rem',
  overflowX: 'auto',
  display: 'flex',
  boxSizing: 'content-box',
  marginBottom: '1rem',
  scrollSnapType: 'x mandatory',
  ...globalStyles.STYLES.horizontalScroll,
  '::-webkit-scrollbar-thumb': {
    backgroundColor: globalStyles.COLOR.coolGrey
 },
 ':hover::-webkit-scrollbar-thumb': {
    backgroundColor: globalStyles.COLOR.coolGrey
  },
  '::-webkit-scrollbar-track': {
    backgroundColor: globalStyles.COLOR.veryLightPinkFive
  },

});

export const singleImageContainer = css({ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' });
export const singleImage = css({ maxHeight: '20rem', maxWidth: '30rem', marginBottom: '1.8rem' });



export const imageLoader = css({ height: '20rem', margin: '.5rem',marginLeft: '0', scrollSnapAlign: 'start', /* scrollSnapStop: 'always'*/ });
