import { FC, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';

//developed
import { useStores } from 'stores/useStores';
import ImageLoader from 'components/general/image-loader/image-loader.component';
//styles
import * as styles from './service-image-gallery.styles';

interface IServiceImageGallery {
  galleryImages: string[];
}

const ServiceImageGallery: FC<IServiceImageGallery> = ({ galleryImages }) => {
  const { themeStore } = useStores();

  return (
    <>
      {galleryImages.length === 1 && (
        <div css={styles.singleImageContainer}>
          <ImageLoader
            spinnerColor={themeStore.currentTheme.colors.actionMedium.published}
            imageSource={galleryImages[0]}
            loaderPosition="centered"
            loadingContainerStyle={css({ height: '20rem' })}
            imageStyle={styles.singleImage}></ImageLoader>
        </div>
      )}
      {galleryImages.length >= 2 && (
        <div css={styles.galleryWrapper}>
          {galleryImages.map((imageSrc, i) => (
            <ImageLoader
              key={'ImageLoader_' + i}
              spinnerColor={themeStore.currentTheme.colors.actionMedium.published}
              imageSource={imageSrc}
              loadingContainerStyle={styles.imageLoader}
              loaderPosition="centered"
              spinnerSize="15rem"
              imageStyle={styles.imageLoader}></ImageLoader>
          ))}
        </div>
      )}
    </>
  );
};

export default observer(ServiceImageGallery);
