import { FC, useEffect, useState, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
//developed
import { LinkedServiceStoreType } from 'inversify.config';
import { useStores } from 'stores/useStores';
import ServiceImageGallery from '../service-image-gallery/service-image-gallery.component';
//styles
import * as styles from './service-details.styles';
//common
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface IServiceDetailsProps {
  currentService: LinkedServiceStoreType;
}

const ServiceDetails: FC<IServiceDetailsProps> = ({ currentService }) => {
  const { themeStore } = useStores();
  const [readMoreNeeded, setReadMoreNeeded] = useState(false);
  const [descriptionCollapsed, setDescriptionCollapsed] = useState(true);
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const { t } = useTranslation();

  const maxWordCount = 50;
  let shortDesciption = currentService?.appdescription;
  if (currentService?.appdescription?.split(' ').length > maxWordCount) {
    shortDesciption = currentService?.appdescription.split(' ').splice(0,maxWordCount).join(' ');
    shortDesciption = shortDesciption?.trim() || '';
  }

  const onReadMoreClicked = () => {
    setDescriptionCollapsed(!descriptionCollapsed);
  };

  useEffect(() => {
    if (currentService?.appdescription?.split(' ').length > maxWordCount) {
      setReadMoreNeeded(true);
    }
    let images: string[] = [];

    if (!!currentService?.productImages) {
      images = currentService?.productImages;
    }
    setGalleryImages(images);
  }, [currentService]);

  return (
    <div css={styles.serviceDetailsCol}>
      {galleryImages && galleryImages.length > 0 && <ServiceImageGallery galleryImages={galleryImages} />}
      <div css={styles.textDetailsContainer}>
        <div css={[styles.longDescription]}>{readMoreNeeded && descriptionCollapsed ? `${shortDesciption}...` : currentService?.appdescription}</div>
        {readMoreNeeded && (
          <div css={styles.readMore(themeStore.currentTheme)} onClick={onReadMoreClicked}>
            {descriptionCollapsed ? t(LocaleKeys.screens.linkedServices.more) : t(LocaleKeys.screens.linkedServices.less)}
          </div>
        )}
        <div css={styles.contactDetails}>
          <a css={styles.companyLink(themeStore.currentTheme)} href={currentService?.appwebsitehomepageLink} target="_blank" rel="noopener noreferrer">
            {currentService?.appName}
          </a>
          <a css={styles.companyLink(themeStore.currentTheme)} href={`mailto:${currentService?.customersupportEmail}`} target="_blank" rel="noopener noreferrer">
            {currentService?.customersupportEmail}
          </a>
        </div>
      </div>
    </div>
  );
};

export default observer(ServiceDetails);
