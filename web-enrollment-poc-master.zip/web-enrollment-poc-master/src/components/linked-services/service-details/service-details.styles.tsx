import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const serviceDetailsCol = css({
  width: '50%',
  paddingRight: '1rem',
  marginBottom: '4rem',
  '@media (max-width: 1150px)': {
    width: '100%',
    paddingRight: '0'
  }
});
export const textDetailsContainer = css({
  maxWidth: '30rem',
  '@media (max-width: 1150px)': {
    maxWidth: 'none'
  }
});

export const longDescription = css({
  fontSize: '1.4rem',
  color: globalStyles.COLOR.slateGrey,
  lineHeight: '1.29',
  textOverflow: 'ellipsis',
  overflow: 'hidden',
  whiteSpace: 'pre-line',

  p: {
    marginBottom: '1rem'
  }
});

export const readMore = (theme: Preferences) =>
  css({
    fontSize: '1.4rem',
    color: theme.colors.actionMedium.published,
    marginTop: '0.5rem',
    cursor: 'pointer'
  });

export const serviceLargeImage = css({
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  backgroundColor: globalStyles.COLOR.veryLightBlue,
  height: '20rem',
  marginBottom: '1.8rem'
});

export const contactDetails = css({
  marginTop: '2.5rem',
  fontSize: '1.4rem',
  color: '#28837e'
});

export const companyLink = (theme: Preferences) =>
  css({
    marginTop: '1rem',
    display: 'block',
    color: theme.colors.actionMedium.published,
    cursor: 'pointer',
    textDecoration: 'none'
  });
