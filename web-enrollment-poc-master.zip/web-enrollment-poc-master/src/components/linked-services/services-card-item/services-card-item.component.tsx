import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { NavLink, useRouteMatch } from 'react-router-dom';
//developed
import { useStores } from '../../../stores/useStores';
import { PayerItem } from 'stores';
import ServiceCardIcon from 'components/linked-services/service-card-icon/service-card-icon.component';
import { useTranslation } from 'react-i18next';
//styles
import * as styles from './services-card-item.styles';
//assets
import { ReactComponent as RedTriangle } from 'assets/icons/red-triangle.svg';
//common
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
interface IServicesCardItemProps {
  service: PayerItem;
}

const ServicesCardItem: FC<IServicesCardItemProps> = ({ service }) => {
  const match = useRouteMatch();
  const { responsiveStore } = useStores();
  const { t } = useTranslation('translation');

  return (
    <NavLink
      to={`${match.url}/Payer/${service.payerId}`}
      css={[styles.serviceBox, responsiveStore.isTablet !== true && styles.serviceBoxNotTablet, responsiveStore.isMobile && styles.serviceBoxMobile]}>
      {service.isLinked && (
        <div css={styles.serviceBoxImage}>
          <ServiceCardIcon service={service} />
        </div>
      )}
      <div css={[styles.serviceBoxDetails, responsiveStore.isMobile && styles.serviceBoxDetailsMobile]}>
        <div css={styles.serviceBoxAppName} title={service.name || ''}>
          {service.name}
        </div>
        <div css={styles.serviceBoxDescription} title={service.types || ''}>
          {service.types}
        </div>
        {!service.isLinked && (
          <div css={styles.serviceWarningText}>
            <RedTriangle />
            <span>{t(LocaleKeys.errors.not_linked_to_connected_health)}</span>
          </div>
        )}
      </div>
    </NavLink>
  );
};

export default ServicesCardItem;
