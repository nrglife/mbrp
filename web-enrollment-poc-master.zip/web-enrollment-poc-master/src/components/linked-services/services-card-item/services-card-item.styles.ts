/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { fontStyle, COLOR } from "styles/global";

export const serviceBox = css({
  boxSizing: 'border-box',
  display: 'flex',
  flexDirection: 'row',
  textDecoration: 'none',
  textOverflow: 'ellipsis',
  overflow: 'hidden',
  alignItems: 'center',
  paddingLeft: '2.4rem',
  marginBottom: '2.4rem',
  minWidth: '35%',
  maxWidth: '48.5%',
  width: '48.5%',
  height: '9rem',
  boxShadow: '0px 1px 2px rgba(17, 80, 244, 0.1), 0px 2px 12px rgba(131, 144, 175, 0.3)',
  borderRadius: '8px'
});

export const serviceBoxNotTablet = css({
  '@media (max-width: 1200px)': {
    maxWidth: '100%',
    width: '100%'
  }
});

export const serviceBoxMobile = css({
  minWidth: '100%'
});

export const serviceBoxImage = css({
  marginRight: '1rem'
});

export const serviceBoxDetails = css({
  display: 'flex',
  flexDirection: 'column',
  flex: 1,
  overflow: 'hidden',
  lineHeight: 'normal',
  maxHeight: '7.2rem'
});

export const serviceBoxDetailsMobile = css({
  maxWidth: '70%'
});

export const serviceBoxDescription = [fontStyle.Small, css({
  color: COLOR.ContentPrimary
})];

export const multipleServiceBoxDescription = css({
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});

export const serviceBoxAppName = [fontStyle.MediumBold, css({
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden',
  color: COLOR.ContentPrimary
})];

export const serviceWarningText = css({
  display: 'flex',
  alignItems: 'center',
  span: {
    color: globalStyles.COLOR.rustyRed,
    fontSize: '1.1rem',
    lineHeight: '150%',
    display: 'inline-block',
    marginLeft: '0.8rem'
  }
});
