import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { PayerItem } from 'stores';
import ServicesCardItem from '../services-card-item/services-card-item.component';
import { useStores } from '../../../stores/useStores';
//styles
import * as styles from './services-cards-list.styles';

interface IServicesCardsListProps {
  data: PayerItem[];
}

const ServicesCardsList: FC<IServicesCardsListProps> = ({ data = [] }) => {
  const { responsiveStore } = useStores();
  
  return (
    <div css={[styles.cardsListContainer, responsiveStore.isTablet && styles.cardsListContainerTablet, responsiveStore.isMobile && styles.cardsListContainerMobile]}>
      <div css={styles.cardsListBox}>
        {data.map((service, i) => (
          <ServicesCardItem service={service} key={`service-link-${i}`} />
        ))}
      </div>
    </div>
  );
};

export default ServicesCardsList;
