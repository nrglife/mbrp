/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const cardsListContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  alignItems: 'left',
  // paddingLeft: '4.8rem',
  // paddingRight: '15%',
  // '@media (min-width: 992px) and (max-width: 1450px)': {
  //   paddingRight: '8%'
  // }
});

export const cardsListContainerMobile = css({
  // paddingLeft: '2rem',
  // paddingRight: '2rem',
  paddingBottom: '10%'
});

export const cardsListContainerTablet = css({
  // paddingLeft: '2rem',
  // paddingRight: '2rem'
});

export const cardsListBox = css({
  display: 'flex',
  flexFlow: 'row wrap',
  margin: '3rem 0 2rem 0',
  justifyContent: 'space-between',
  // paddingLeft: '1.6rem'
});
