import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { LinkedServiceStoreType } from 'inversify.config';
import ImageLoader from 'components/general/image-loader/image-loader.component';
//styles
import * as styles from './service-icon.styles';
// assests
import applicationDefaultIcon from 'assets/icons/app-default-icon.png';
import { useStores } from 'stores/useStores';

interface IServiceIconProps {
  iconLink: string; 
}

const ServiceIcon: FC<IServiceIconProps> = ({ iconLink }) => {
  const { themeStore } = useStores();
  return iconLink ? (
    <div css={styles.serviceImageContainer}>
      <ImageLoader
        imageSource={iconLink}
        loadingContainerStyle={styles.loadingContainerStyle}
        failureImageSource={applicationDefaultIcon}
        imageStyle={styles.serviceImage}
        imageLoadedStyle={styles.serviceImageLoaded}
        spinnerColor={themeStore.currentTheme.colors.actionMedium.published}
      />
    </div>
  ) : null;
};

export default ServiceIcon;
