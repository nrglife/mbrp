import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const serviceImageContainer = css({
  maxWidth: '7.2rem',
  maxHeight: '7.2rem',
  minWidth: '7.2rem',
  minHeight: '5.5rem',
  display: 'flex',
  alignItems: 'center'
});

export const serviceImage = css({
  width: '100%',
  height: '100%'
});

export const serviceImageLoaded = css({
  borderRadius: '1.7rem',
  boxShadow: `0 0.2rem 0.4rem 0 rgba(0, 0, 0, 0.2), 0 0.2rem 0.6rem 0 ${globalStyles.COLOR.black15}`,
  backgroundColor: globalStyles.COLOR.white
});

export const loadingContainerStyle = css({
  display: 'flex',
  minWidth: '100%',
  justifyContent: 'center'
})

export const spinner = {
  color: globalStyles.COLOR.greyishBrown + '99' // 99 = 60% opacity
};
