import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

import { NavLink, useRouteMatch } from 'react-router-dom';
//developed
import { useStores } from '../../../stores/useStores';
import { LinkedServiceStoreType } from 'inversify.config';
import ServiceIcon from 'components/linked-services/service-icon/service-icon.component';
//styles
import * as styles from './services-list-item.styles';
interface IServicesListItemProps {
  service: LinkedServiceStoreType;
  isSingleService?: boolean; // true when there is only one item in the connected services list
}

const ServicesListItem: FC<IServicesListItemProps> = ({ service, isSingleService = false }) => {
  let match = useRouteMatch();
  const { responsiveStore } = useStores();

  return (
    <NavLink
      to={`${match.url}/ServiceDetails/${service.id}`}
      css={[styles.serviceBox, isSingleService && styles.singleServiceBox, responsiveStore.isTablet && styles.serviceBoxTablet, responsiveStore.isMobile && styles.serviceBoxMobile]}>
      <ServiceIcon iconLink={service.appIconLink} />
      <div css={[styles.serviceBoxDetails, isSingleService && styles.singleServiceBoxDetails, responsiveStore.isMobile && styles.serviceBoxDetailsMobile]}>
        <div css={styles.serviceBoxAppName} title={service.appName}>
          {service.appName}
        </div>
        <div css={[styles.serviceBoxDescription, !isSingleService && styles.multipleServiceBoxDescription]} title={service.appsubtitle}>
          {service.appsubtitle}
        </div>
      </div>
    </NavLink>
  );
};

export default ServicesListItem;
