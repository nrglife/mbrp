/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const serviceBox = css({
  boxSizing: 'border-box',
  display: 'flex',
  flexDirection: 'row',
  textDecoration: 'none',
  textOverflow: 'ellipsis',
  overflow: 'hidden',
  alignItems: 'center',
  paddingLeft: '3rem',
  marginBottom: '3rem',
  minWidth: '35rem',
  height: '8rem',
  width: '45%'
});

export const serviceBoxTablet = css({
  width: '100%'
});

export const serviceBoxMobile = css({
  paddingLeft: '.5rem'
});

export const singleServiceBox = css({
  height: 'auto'
});

export const serviceBoxDetails = css({
  display: 'flex',
  flexDirection: 'column',
  flex: 1,
  overflow: 'hidden',
  marginLeft: '1rem',
  lineHeight: 'normal',
  maxHeight: '7.2rem'
});

export const serviceBoxDetailsMobile = css({
  maxWidth: '70%'
});

export const singleServiceBoxDetails = css({
  maxHeight: 'none'
});

export const serviceBoxDescription = css({
  fontSize: '1.4rem',
  fontWeight: 'normal',
  color: globalStyles.COLOR.blackTwo
});

export const multipleServiceBoxDescription = css({
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});

export const serviceBoxAppName = css({
  fontSize: '1.6rem',
  fontWeight: 'bold',
  color: globalStyles.COLOR.blackTwo,
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden'
});
