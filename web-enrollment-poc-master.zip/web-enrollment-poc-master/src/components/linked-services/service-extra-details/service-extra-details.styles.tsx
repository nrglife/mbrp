import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const serviceDetailsCol = css({
  width: '50%',
  paddingLeft: '2rem',
  '@media (max-width: 1150px)': {
    paddingLeft: '0',
    width: '100%'
  }
});

export const serviceExtraDetails = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.6rem',
  lineHeight: 1.25
});

export const serviceExtraDetailsTitle = css({
  fontWeight: 'bold'
});

export const whatHappens = css({
  marginTop: '0.6rem'
});

export const dataCategoriesTitle = css({
  marginTop: '1.2rem',
  marginBottom: '1.2rem'
});

export const dataCategoryItem = css({
  marginBottom: '0.6rem'
});

export const dataCategoryBullet = css({
  marginRight: '1rem',
});
