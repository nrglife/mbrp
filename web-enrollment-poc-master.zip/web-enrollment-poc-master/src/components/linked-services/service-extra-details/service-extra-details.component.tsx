import { FC, Fragment } from 'react';
import * as React from 'react';
import { useTranslation } from 'react-i18next';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { LinkedServiceStoreType } from 'inversify.config';

//styles
import * as styles from './service-extra-details.styles';
//common
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface IServiceExtraDetailsProps {
  currentService: LinkedServiceStoreType;
  payerName: string;
}

const ServiceExtraDetails: FC<IServiceExtraDetailsProps> = ({ currentService, payerName }) => {
  const { t } = useTranslation('translation');

  return (
    <div css={[styles.serviceDetailsCol, styles.serviceExtraDetails]}>
      <div id="what-happens">
        <div css={styles.serviceExtraDetailsTitle}>{t(LocaleKeys.screens.linkedServices.whatHappensWhenYouConnect)}</div>
        <div css={styles.whatHappens}>
          {currentService?.appName}
          &nbsp;{t(LocaleKeys.screens.linkedServices.linkedServicesDetailsDescription)}
          {/* will use your personal information to optimize services and conduct business operations. This app meets our standards for privacy and security. */}
          <br />
          <br />
          {t(LocaleKeys.screens.linkedServices.thisWillGive)} {currentService?.appName}&nbsp;{t(LocaleKeys.screens.linkedServices.linkedServicesDetailsDescription2)}
          {/* access to all health and personal information from your Connected Health account. */}
        </div>
      </div>
      {currentService?.requestedDataCategories && currentService?.requestedDataCategories.length > 0 && (
        <div>
          <div css={[styles.serviceExtraDetailsTitle, styles.dataCategoriesTitle]}>{t(LocaleKeys.screens.linkedServices.appDetails, { appName: currentService?.appName })}</div>
          {currentService?.requestedDataCategories?.join(', ')}
          {currentService?.requestedDataCategories?.length > 1 ? '.' : ''}
        </div>
      )}
    </div>
  );
};

export default ServiceExtraDetails;
