import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { LinkedServiceStoreType } from 'inversify.config';
import ServicesListItem from '../services-list-item/services-list-item.component';
//styles
import * as styles from './service-list.styles';
import {useTranslation} from "react-i18next";
import {LocaleKeys} from "@healthcareapp/connected-health-common-services";

interface IServiceListProps {
  data: LinkedServiceStoreType[];
  linkUrl: string;
}

const ServiceList: FC<IServiceListProps> = ({ data = [], linkUrl }) => {
  const { t } = useTranslation('translation');
  return (
    <div css={styles.servicesListContainer}>
      {!!data && data.length > 0 ? (
        <div css={styles.servicesListBox}>
          {data.map((service, i) => (
            <ServicesListItem service={service} isSingleService={data.length === 1} key={`service-link-${i}`} />
          ))}
        </div>
      ) : (
        <div css={styles.emptyServicesListContainer}>{t(LocaleKeys.errors.no_apps_to_show)}</div>
      )}
    </div>
  );
};

export default ServiceList;
