/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { Preferences } from 'stores/ThemeStore';

export const servicesListContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
});

export const servicesListBox = css({
  display: 'flex',
  flexFlow: 'row wrap',
  margin: '3rem 0 2rem 0'
});

export const separationBorder = css({
  width: '100%',
  borderBottom: `0.2rem solid ${globalStyles.COLOR.veryLightPink}`
});

export const emptyServicesListContainer = css({
  textAlign: 'center',
  margin: '10rem 0',
  fontStyle: 'italic',
  fontSize: '1.8rem',
  color: globalStyles.COLOR.charcoalGreyThree,
  flex: 1
});
