import { css } from '@emotion/core';
// import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const insurerBox = css({
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  margin: '1.6rem 0 4.1rem',
  minHeight: '5.5rem'
});

export const insurerIcon = css({
  maxHeight: '6rem',
  verticalAlign: 'middle',
  height: '6rem',
  display: 'flex',
  alignItems: 'center',
  marginRight: '1.5rem'
});

export const insurerBoxDetails = css({
  lineHeight: '1.5'
});

export const insurerName = css({
  fontSize: '1.6rem',
  fontWeight: 'bold'
});

export const insurerDetail = css({
  fontSize: '1.2rem',
  color: globalStyles.COLOR.blackTwo
});
