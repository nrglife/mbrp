import { FC, useEffect, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import useBase64Image from 'customHooks/useBase64Image';
import { useStores } from 'stores/useStores';
//common services
import { formatDate, FULL_DATE_FORMAT } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
// assests
import applicationDefaultIcon from 'assets/icons/app-default-icon.png';
//styles
import * as styles from './insurer-details.styles';

interface InsurerDetailsProps {
  // darkLogoUrl: string | undefined;
}

const InsurerDetails: FC<InsurerDetailsProps> = () => {
  const { imageStore, payerStore, whoAmIStore, delegateStore } = useStores();
  const [payerName, setPayerName] = useState('');
  const { image: darkLogo, scaledWidth, scaledHeight } = useBase64Image({ dataUrl: imageStore.logos.dark.data, maxWidth: 250, maxHeight: 60 });

  useEffect(() => {
    setPayerName(payerStore.payerName);
    payerStore?.payer?.guid && imageStore.loadLogoByType(payerStore.payer.guid, 'dark', false);
    whoAmIStore.loadPayerInfo();
  }, [delegateStore.selectedMemberForDelegateIndex]);

  return (
    <div css={styles.insurerBox}>
      {darkLogo != null ? (
        <div css={[styles.insurerIcon, { width: scaledWidth && scaledWidth > 0 ? scaledWidth : 0 }]}>
          <img
            src={darkLogo.src}
            width={scaledWidth}
            height={scaledHeight}
            onError={(e: any) => {
              e.target.onError = null;
              e.target.src = applicationDefaultIcon;
            }}
            alt="Insurer Icon"
          />
        </div>
      ) : null}
      <div css={styles.insurerBoxDetails}>
        {!!payerName && <div css={styles.insurerName}>{payerName}</div>}

        {whoAmIStore.payerInfo?.healthCoverage?.coverageStart && (
          <>
            <div css={styles.insurerDetail}>Current Member</div>
            <div css={styles.insurerDetail}>{`Since ${formatDate(whoAmIStore.payerInfo?.healthCoverage?.coverageStart, FULL_DATE_FORMAT, false)}`}</div>
          </>
        )}
      </div>
    </div>
  );
};

export default observer(InsurerDetails);
