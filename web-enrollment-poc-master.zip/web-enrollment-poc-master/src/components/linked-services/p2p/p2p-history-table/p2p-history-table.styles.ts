import { ColorsPreferences } from './../../../../stores/ThemeStore';
/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';
import { fontStyle, COLOR } from 'styles/global';

export const recordsTableContainer = css({
  flex: 1,
  alignItems: 'center',
  flexDirection: 'column',
  width: '100%'
});

export const tableRow = css({ width: '100%', display: 'flex' });

export const tableRowLine = css({
  borderBottom: '.1rem solid #efefef'
});

export const tableHeaderContainer = css([
  fontStyle.Small,
  {
    height: '4rem',
    lineHeight: '4rem',
    color: COLOR.ContentPrimary,
  }
]);

export const status = css({
  height: '1.8rem',
  lineHeight: '1.8rem',
  textAlign: 'center',
  display: 'inline-block',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '1rem',
  fontWeight: 'bold',
  letterSpacing: '0.05rem',
  // marginLeft: '1.2rem',
  borderRadius: '2px',
  padding: '0 0.8rem',
  backgroundColor: globalStyles.COLOR.blueGrey,
  color: globalStyles.COLOR.white
});

export const statusColors = (bkgdColor, useDarkTextColor) =>
  css({
    backgroundColor: bkgdColor,
    color: useDarkTextColor === true ? globalStyles.COLOR.blackTwo : globalStyles.COLOR.white
  });

export const defaultBackgroundColor = (theme: Preferences) => css({ background: theme.colors.backgroundMedium.published, color: globalStyles.COLOR.blackTwo });
export const tableColumn = css({
  flex: 1,
  flexDirection: 'column',
  paddingLeft: 'min(3rem,3%)',
  textAlign: 'left',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  textOverflow: 'ellipsis'
});

export const recordsErrorOrLoading = css({
  marginTop: '4rem',
  textAlign: 'center'
});

export const recordsErrorOrLoadingMobile = css({
  marginTop: '2rem',
  marginBottom: '4rem',
  textAlign: 'center',
  color: globalStyles.COLOR.steelGreyThree,
  fontSize: '1.3rem'
});

export const spinnerContainer = (spinnerSize: string) =>
  css({
    width: spinnerSize,
    minHeight: spinnerSize,
    height: spinnerSize
  });

export const recordCard = css({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  padding: '0.8rem 0 1.3rem 0'
});

export const recordCardSeparator = css({
  borderBottom: '.1rem solid #efefef'
});

export const recordCardProperty = css(fontStyle.Small, {
  width: '100%',
  display: 'flex',
  flexDirection: 'row',
  marginBottom: '.4rem'
});

export const recordCardPropertyName = css({
  color: globalStyles.COLOR.steelGreyThree,
  width: '50%'
});

export const recordCardPropertyValue = css({
  color: COLOR.ContentPrimary,
  width: '50%',
  textAlign: 'right'
});

export const whiteRectangle = css({
  marginBottom: '1.2rem',
  backgroundColor: globalStyles.COLOR.white,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  borderRadius: '1rem',
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  padding: '0.8rem 2.4rem'
});
