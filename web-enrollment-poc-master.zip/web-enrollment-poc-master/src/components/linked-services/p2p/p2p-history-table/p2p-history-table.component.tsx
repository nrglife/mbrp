import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
import { css } from '@emotion/core';
//developed
import { useStores } from 'stores/useStores';
import { Request_Record } from 'stores';
// import ServiceCardIcon from 'components/linked-services/service-card-icon/service-card-icon.component';
import { useTranslation } from 'react-i18next';
//styles
import * as styles from './p2p-history-table.styles';
// developed
import Loader from 'components/general/loader/loader.component';
import { Error } from 'components/error';

//common
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { formatDate, isValidDate, FULL_DATE_FORMAT } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';

export enum RecordsStatus {
  Loading = 'Loading',
  Error = 'Error',
  Empty = 'Empty',
  Loaded = 'Loaded'
}
export interface P2pHistoryTableProps {
  tableColumns: string[];
  payerRecords?: Request_Record[];
  status: RecordsStatus;
}

const P2pHistoryTable: FC<P2pHistoryTableProps> = ({ tableColumns, payerRecords, status }) => {
  const { t } = useTranslation('translation');
  const { responsiveStore, themeStore } = useStores();

  const isShowCardsInsteadOfTable = responsiveStore.isMobile || (!responsiveStore.isTablet && responsiveStore.innerWidth <= 1300);

  return (
    <div css={[styles.recordsTableContainer]}>
      {!isShowCardsInsteadOfTable && (
        <>
          <div css={[styles.tableRow, styles.tableHeaderContainer]}>
            {tableColumns.map(header => (
              <div key={'header' + header} css={[styles.tableColumn, styles.defaultBackgroundColor(themeStore.currentTheme)]}>
                <div>{header}</div>
              </div>
            ))}
          </div>

          {status === RecordsStatus.Loading ? (
            <div css={styles.recordsErrorOrLoading}>
              <Loader color={themeStore.currentTheme.colors.actionMedium.published} position={'inline'} loading={true} />
            </div>
          ) : status === RecordsStatus.Error ? (
            <Error errorText={t(LocaleKeys.screens.P2p.emptyRecords)} style={styles.recordsErrorOrLoading} />
          ) : status === RecordsStatus.Empty ? (
            <div key={'noRecords'} css={[styles.tableRow, styles.tableHeaderContainer]}>
              <div css={styles.tableColumn}>{t(LocaleKeys.screens.P2p.emptyRecords)}</div>
            </div>
          ) : (
            payerRecords?.map(record => (
              <div key={'request' + record.requestId} css={[styles.tableRow, styles.tableHeaderContainer, styles.tableRowLine]}>
                <div css={styles.tableColumn} title={'Request'}>
                  {'Request'}
                </div>
                <div css={styles.tableColumn} title={record.humanName?.fullName || ''}>
                  {record.humanName?.fullName}
                </div>
                <div css={styles.tableColumn} />
                <div css={styles.tableColumn} />
                <div css={styles.tableColumn} title={record.requestDate}>
                  {isValidDate(record?.requestDate) ? formatDate(record?.requestDate, FULL_DATE_FORMAT, false) : ''}
                </div>
                <div css={styles.tableColumn} title={record.status}>
                  <div css={[styles.status]}>{record?.status?.toString().toUpperCase()}</div>
                </div>
              </div>
            ))
          )}
        </>
      )}
      {isShowCardsInsteadOfTable && (
        <>
          {status === RecordsStatus.Loading ? (
            <div css={[styles.recordsErrorOrLoadingMobile]}>
              <Loader color={themeStore.currentTheme.colors.actionMedium.published} position={'inline'} loading={true} />
            </div>
          ) : status === RecordsStatus.Error ? (
            <Error errorText={t(LocaleKeys.screens.P2p.emptyRecords)} style={styles.recordsErrorOrLoadingMobile} />
          ) : status === RecordsStatus.Empty ? (
            <div css={[styles.whiteRectangle, styles.recordsErrorOrLoadingMobile, css({ textAlign: 'left' })]}>
              <div>{t(LocaleKeys.screens.P2p.emptyRecords)}</div>
            </div>
          ) : (
            <div css={styles.whiteRectangle}>
              {payerRecords?.map((record, i) => (
                <div key={'request' + record.requestId} css={[styles.recordCard, i + 1 !== payerRecords.length && styles.recordCardSeparator]}>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[0]}</div>
                    <div css={styles.recordCardPropertyValue} title={'Request'}>
                      {'Request'}
                    </div>
                  </div>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[1]}</div>
                    <div css={styles.recordCardPropertyValue} title={record.humanName?.fullName || ''}>
                      {record.humanName?.fullName}
                    </div>
                  </div>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[2]}</div>
                    <div css={styles.recordCardPropertyValue}></div>
                  </div>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[3]}</div>
                    <div css={styles.recordCardPropertyValue}></div>
                  </div>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[4]}</div>
                    <div css={styles.recordCardPropertyValue} title={record.requestDate}>
                      {isValidDate(record?.requestDate) ? formatDate(record?.requestDate, FULL_DATE_FORMAT, false) : ''}
                    </div>
                  </div>
                  <div css={styles.recordCardProperty}>
                    <div css={styles.recordCardPropertyName}>{tableColumns[5]}</div>
                    <div css={styles.recordCardPropertyValue} title={record.status}>
                      <div css={[styles.status]}>{record?.status?.toString().toUpperCase()}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default observer(P2pHistoryTable);
