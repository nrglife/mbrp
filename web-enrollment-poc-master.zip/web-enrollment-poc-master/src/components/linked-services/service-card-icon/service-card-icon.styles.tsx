import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const serviceCardImageContainer = css({
  maxWidth: '4.8rem',
  maxHeight: '4.8rem',
  minWidth: '4.8rem',
  minHeight: '4.8rem',
  display: 'flex',
  alignItems: 'center'
});

export const serviceCardImage = css({
  width: '100%',
  height: '100%'
});

export const serviceCardImageLoaded = css({
  borderRadius: '0.6rem',
  backgroundColor: globalStyles.COLOR.white,
  boxShadow: '0px 1px 2px rgba(17, 80, 244, 0.1), 0px 2px 12px rgba(131, 144, 175, 0.3)'
});

export const loadingContainerStyle = css({
  display: 'flex',
  minWidth: '100%',
  justifyContent: 'center'
})

export const spinner = {
  color: globalStyles.COLOR.greyishBrown + '99' // 99 = 60% opacity
};
