import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { PayerItem } from 'stores';
import ImageLoader from 'components/general/image-loader/image-loader.component';
//styles
import * as styles from './service-card-icon.styles';
// assests
import applicationDefaultIcon from 'assets/icons/app-default-icon.png';
import { useStores } from 'stores/useStores';

interface IServiceCardIconProps {
  service: PayerItem;
}

const ServiceCardIcon: FC<IServiceCardIconProps> = ({ service }) => {
  const { themeStore } = useStores();
  return service ? (
    <div css={styles.serviceCardImageContainer}>
      <ImageLoader
        imageSource={service.icon}
        loadingContainerStyle={styles.loadingContainerStyle}
        failureImageSource={applicationDefaultIcon}
        imageStyle={styles.serviceCardImage}
        imageLoadedStyle={styles.serviceCardImageLoaded}
        spinnerColor={themeStore.currentTheme.colors.actionMedium.published}
      />
    </div>
  ) : null;
};

export default ServiceCardIcon;
