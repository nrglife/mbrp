import React, { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { NavLink, useRouteMatch } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { PayerItem } from 'stores';
import { useStores } from 'stores/useStores';
//styles
import * as styles from './service-alphabetical-list.style';
interface IServicesAlphabeticalListProps {
  data: PayerItem[];
}

const ServicesAlphabeticalList: FC<IServicesAlphabeticalListProps> = ({ data = [] }) => {
  const { responsiveStore } = useStores();
  const match = useRouteMatch();
  const sortedData = data.sort(function (a, b) {
    if (a.name && b.name) {
      const nameA = a.name.toUpperCase();
      const nameB = b.name.toUpperCase();
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    }
    return 0;
  });

  return (
    <div css={[styles.listContainer, responsiveStore.isTablet && styles.cardsListContainerTablet, responsiveStore.isMobile && styles.listContainerMobile]}>
      <div css={styles.listColumn}>
        {sortedData.map((service, i) => (
          <div key={service.payerId + i.toString()} css={[styles.listItem, responsiveStore.isTablet && styles.listItemTablet, responsiveStore.isMobile && styles.listItemMobile]}>
            {service.name && (
              <NavLink to={`${match.url}/Payer/${service.payerId}`} key={`service-link-${i}`}>{service.name}</NavLink>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default observer(ServicesAlphabeticalList);
