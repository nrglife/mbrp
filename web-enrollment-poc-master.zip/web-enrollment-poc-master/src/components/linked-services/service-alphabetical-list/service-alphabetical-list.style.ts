/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { Preferences } from 'stores/ThemeStore';

export const listContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  alignItems: 'left',
  // paddingLeft: '4.8rem',
  // paddingRight: '15%',
  // '@media (min-width: 992px) and (max-width: 1450px)': {
  //   paddingRight: '8%'
  // }
});

export const listContainerMobile = css({
  // paddingLeft: '2rem',
  // paddingRight: '2rem',
  paddingBottom: '10%'
});

export const cardsListContainerTablet = css({
  // paddingLeft: '4rem',
  // paddingRight: '4rem'
});

export const listColumn = css({
  display: 'flex',
  flexFlow: 'row wrap',
  margin: '3rem 0 2rem 0',
  justifyContent: 'flex-start'
});

export const listItem = css({
  marginBottom: '1rem',
  width: '33%',
  '@media (min-width: 992px) and (max-width: 1450px)': {
    width: '50%'
  },
  a: {
    color: globalStyles.COLOR.darkBlueGrey,
    fontSize: '13px',
    lineHeight: '150%',
    paddingLeft: '1.5rem'
  }
})

export const listItemTablet = css({
  width: '50%'
})

export const listItemMobile = css({
  width: '100%'
});
