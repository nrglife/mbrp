import { Children, FC } from 'react';
import { IntlProvider } from 'react-intl';

interface LanguageProviderProps {
  locale?: string;
  messages: object;
}

const LanguageProvider: FC<LanguageProviderProps> = ({ locale = 'en', messages, children }) => {
  return (
    <IntlProvider locale={locale} key={locale} messages={messages[locale]}>
      {Children.only(children)}
    </IntlProvider>
  );
};

export default LanguageProvider;
