import { Fragment, FC, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//developed
import { useStores } from '../../stores/useStores';

const ActivityTracker: FC = () => {
  //default value for INACTIVE_USER_TIME_THRESHOLD 15 min = 900000 ms
  const INACTIVE_USER_TIME_THRESHOLD = Number(`${(window as any)?.env?.REACT_APP_INACTIVE_USER_TIME_THRESHOLD}`) || 900000;
  //default value for USER_ACTIVITY_THROTTLER_TIME (check the user activity evry x time ) 10s = 10000 ms
  const USER_ACTIVITY_THROTTLER_TIME = Number(`${(window as any)?.env?.REACT_APP_USER_ACTIVITY_THROTTLER_TIME}`) || 10000;
  const { authStore } = useStores();

  let userActivityTimeout: any = null;

  const resetUserActivityTimeout = () => {
    //console.log('reset user inactivity');
    clearTimeout(userActivityTimeout);
    userActivityTimeout = setTimeout(() => {
      inactiveUserAction();
    }, INACTIVE_USER_TIME_THRESHOLD);
  };

  let userActivityThrottlerTimeout: any = null;

  const userActivityThrottler = () => {
    if (!userActivityThrottlerTimeout) {
      userActivityThrottlerTimeout = setTimeout(() => {
        resetUserActivityTimeout();

        clearTimeout(userActivityThrottlerTimeout);
        userActivityThrottlerTimeout = null;
      }, USER_ACTIVITY_THROTTLER_TIME);
    }
  };

  const inactiveUserAction = () => {
    // logout logic
    console.log('user inactive - logout');
    authStore.logout(false);
  };

  const activateActivityTracker = () => {
    userActivityThrottler();
    window.addEventListener('mousemove', userActivityThrottler);
    window.addEventListener('scroll', userActivityThrottler);
    window.addEventListener('keydown', userActivityThrottler);
    window.addEventListener('resize', userActivityThrottler);
  };

  const clearActivateActivityTracker = () => {
    window.removeEventListener('mousemove', userActivityThrottler);
    window.removeEventListener('scroll', userActivityThrottler);
    window.removeEventListener('keydown', userActivityThrottler);
    window.removeEventListener('resize', userActivityThrottler);

    clearTimeout(userActivityTimeout);
    clearTimeout(userActivityThrottlerTimeout);
  };

  //component mount
  useEffect(() => {
    activateActivityTracker();
    //component unmount
    return () => clearActivateActivityTracker();
  }, [activateActivityTracker, clearActivateActivityTracker]);

  return <Fragment />;
};

export default ActivityTracker;
