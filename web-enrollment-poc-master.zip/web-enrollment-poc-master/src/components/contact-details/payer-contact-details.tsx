import React, { FC, Fragment, useEffect } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import { ReactComponent as EmailIcon } from '../../assets/icons/email.svg';
import { ReactComponent as PhoneIcon } from '../../assets/icons/phone.svg';
import { ReactComponent as ComputerIcon } from '../../assets/icons/computer-screen.svg';

//styles
import * as styles from './contact-details.styles';
import { globalStyles } from '../../styles/global.styles';

interface PayerContactDetailsProps {
  isReduceView?: boolean;
}

const PayerContactDetails: FC<PayerContactDetailsProps> = ({ isReduceView = false }) => {
  //consts

  const { themeStore, routesStore, payerStore } = useStores();

  return (
    <Fragment>
      <p css={[styles.tertiaryTitle, isReduceView && {fontSize: '2rem'}]}>{payerStore?.payerName} Member Support</p>
      {!isReduceView && <p css={styles.textSmall}>{'For general questions related to insurance coverage,\nprovider networks, billing, and medical.'}</p>}
      {payerStore?.primaryPhone?.trim() != '' && (
        <div css={styles.phoneContainer}>
          <PhoneIcon style={{ color: globalStyles.COLOR.charcoalGreyFive }} />
          <a css={[styles.phoneText]} href={`tel:${payerStore?.primaryPhone}`}>
            {payerStore?.primaryPhone}
          </a>
        </div>
      )}
      {payerStore?.primaryEmail?.trim() != '' && (
        <div css={styles.emailContainer}>
          <div css={styles.emailIconContainer}>
            <ComputerIcon style={{ color: globalStyles.COLOR.charcoalGreyFive }} />
          </div>
          <div css={styles.emailPartsContainer}>
            <a css={[styles.href(themeStore.currentTheme)]} href={`mailto:${payerStore?.primaryEmail}`} target="_blank">
              {payerStore?.primaryEmailPart1}
            </a>
            <a css={[styles.href(themeStore.currentTheme)]} href={`mailto:${payerStore?.primaryEmail}`} target="_blank">
              {payerStore?.primaryEmailPart2}
            </a>
          </div>
        </div>
      )}
      {payerStore?.payer?.address?.trim() != '' && (
        <div css={styles.mailContainer}>
          <div css={styles.emailIconContainer}>
            <EmailIcon style={{ color: globalStyles.COLOR.charcoalGreyFive }} />
          </div>
          <div>
            <p css={styles.adress}>{payerStore?.payerName}</p>
            <p css={[styles.adress]}>{payerStore?.payer?.address}</p>
          </div>
        </div>
      )}
    </Fragment>
  );
};

export default observer(PayerContactDetails);

