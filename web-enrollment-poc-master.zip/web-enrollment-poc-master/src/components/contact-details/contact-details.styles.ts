/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';
import { Preferences } from '../../stores/ThemeStore';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });



  export const tertiaryTitle = css({
    fontSize: '1.8rem',
    marginBottom: '.5rem',
    fontWeight: 400,
    color: globalStyles.COLOR.black,
   // height: '2.2rem'
  });
  
  export const phoneContainer = css({
    paddingTop: '1.5rem'
  });
  
  export const phoneText = css({
    paddingLeft: '1rem',
    fontSize: '1.6rem',
    color: globalStyles.COLOR.black,
    lineHeight: '2.0rem',
    textDecoration: 'none'
  });
  
  export const emailContainer = css({
    paddingTop: '0.5rem',
    fontSize: '1.6rem',
    lineHeight: '2.0rem',
    display: 'flex'
  });
  
  export const emailIconContainer = css({
    paddingRight: '1rem',
    marginTop: '.2rem'
  });
  
  export const emailPartsContainer = css({ 
    display: 'flex', 
    flexWrap: 'wrap' });
  
  
  export const mailContainer = css({
    paddingTop: '0.5rem',
    display: 'flex'
  });
  
  export const emailText = css({
    paddingLeft: '1rem'
  });
  
  export const adress = css({
    fontSize: '1.6rem',
    lineHeight: '2.0rem',
    color: globalStyles.COLOR.blackTwo,
    whiteSpace: 'pre-wrap'
  });
  
  export const textSmall = css({
    fontSize: '1.4rem',
    fontWeight: 400,
    color: globalStyles.COLOR.slateGrey,
    lineHeight: '1.8rem',
    maxWidth: '42.4rem',
    whiteSpace: 'pre-wrap'
  });
  