import React, { FC, Fragment, useEffect } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import { ReactComponent as ComputerIcon } from '../../assets/icons/computer-screen.svg';
import { ReactComponent as PhoneIcon } from '../../assets/icons/phone.svg';


//styles
import * as styles from './contact-details.styles'
import { globalStyles } from '../../styles/global.styles';

interface AppContactDetailsProps {
    isReduceView?: boolean
}

const AppContactDetails: FC<AppContactDetailsProps> = ({isReduceView = false}) => {
  //consts

  const { themeStore, appConfigStore} = useStores();

  return (
    <Fragment>    
        <p css={[styles.tertiaryTitle, isReduceView && {fontSize: '2rem'}]}>{appConfigStore?.name?.trim()}</p>
        {!isReduceView && <p css={styles.textSmall}>For technical issues with the web site, app, or linked services.</p>}
        {appConfigStore?.phone?.trim() && (
        <div css={styles.phoneContainer}>
            <PhoneIcon style={{ color: globalStyles.COLOR.charcoalGreyFive }} />
            <a css={[styles.phoneText]} href={`tel:${appConfigStore?.phone?.trim()}`}>
            {appConfigStore?.phone?.trim()}
            </a>
        </div>
        )}
        {appConfigStore?.email?.trim() && (
        <div css={styles.emailContainer}>
            <div css={styles.emailIconContainer}>
            <ComputerIcon style={{ color: globalStyles.COLOR.charcoalGreyFive }} />
            </div>
            <div css={styles.emailPartsContainer}>
            <a css={[styles.href(themeStore.currentTheme)]} href={`mailto:${appConfigStore?.email?.trim()}`} target="_blank">
                {appConfigStore?.emailPart1}
            </a>
            <a css={[styles.href(themeStore.currentTheme)]} href={`mailto:${appConfigStore?.email?.trim()}`} target="_blank">
                {appConfigStore?.emailPart2}
            </a>
            </div>
        </div>
        )}
    </Fragment>
  );
};

export default observer(AppContactDetails);

