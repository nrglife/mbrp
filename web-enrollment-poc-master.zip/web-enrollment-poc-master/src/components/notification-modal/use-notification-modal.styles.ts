import { css } from '@emotion/core';
import { Preferences } from '../../stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const modalContainer = css({
  padding: '0',
  paddingBottom: '20px',
  flex: '0 1 441px',
  alignItems: 'stretch',
  flexDirection: 'column',
  display: 'flex',
  borderRadius: '2px',
  width: '100%',
  maxWidth: '650px'
});

export const modalHeader = css({ justifySelf: 'flex-start', padding: '4.5rem 5rem' });
export const modalHeaderTheme = (theme: Preferences) => css({ backgroundColor: theme.colors.backgroundMedium.published });

export const modalContent = css({ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, padding: '0 4rem', marginTop: '2rem' });

export const modalTitleStyle = (theme: Preferences) =>
  css({
    fontFamily: theme?.font?.published,
    fontSize: '2rem',
    color: '#37474f',
    lineHeight: '3.2rem',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 'bold'
  });

export const modalTextStyle = (theme: Preferences) =>
  css({
    fontFamily: theme?.font?.published,
    fontSize: '1.8rem',
    lineHeight: '2.2rem',
    color: '#37474f',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 'normal',
    whiteSpace: 'pre-line'
  });

export const modalContentStyle = (theme: Preferences) =>
  css({
    fontFamily: theme?.font?.published,
    fontSize: '1.8rem',
    lineHeight: '2.2rem',
    color: '#37474f',
    letterSpacing: '0',
    fontWeight: 'normal',
    whiteSpace: 'pre-line'
  });

export const closeButtonStyle = (theme: Preferences) =>
  css({
    backgroundColor: theme?.colors?.actionLight?.published,
    color: theme?.colors?.actionDark?.published,
    paddingLeft: '4.2rem',
    paddingRight: '4.2rem'
  });

export const secondaryButtonStyle = (theme: Preferences) =>
  css({
    color: globalStyles.COLOR.charcoalGrey,
    // color: theme?.colors?.actionDark?.published,
    border: `solid .1rem ${globalStyles.COLOR.charcoalGrey}`,
    backgroundColor: 'transparent',
    paddingLeft: '4.2rem',
    paddingRight: '4.2rem'
  });
