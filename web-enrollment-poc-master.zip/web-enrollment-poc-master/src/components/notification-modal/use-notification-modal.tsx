import * as React from 'react';
import { useCallback, ReactNode } from 'react';
/** @jsxImportSource @emotion/core */
import Modal from '../general/modal/modal.component';
import Button from '../general/button/button.component';

import { useStores } from '../../stores/useStores';
import { observer } from 'mobx-react';
import * as styles from './use-notification-modal.styles';
import { Preferences } from 'stores/ThemeStore';
import ErrorCode from 'components/error-code/error-code.component';

export interface ModalProps {
  children?: ReactNode;
}

export const useNotificationModal = ({
  onClose,
  customTheme,
  useThemeForBackgroundColor = true,
  useThemeForHeader = false,
  buttonText = 'OK',
  onButtonClickHandler,
  disableClose = false,
  onSecondButtonClickHandler,
  secondButtonText,
  isUseState = false,
  showErrorCode = true
}: {
  onClose?: () => void;
  customTheme?: Preferences;
  useThemeForBackgroundColor?: boolean;
  useThemeForHeader?: boolean;
  buttonText?: string;
  secondButtonText?: string;
  onButtonClickHandler?: () => void;
  onSecondButtonClickHandler?: () => void;
  disableClose?: boolean;
  isUseState?: boolean;
  showErrorCode?: boolean;
}) => {
  const { notificationModalStore, themeStore } = useStores();
  const [isVisible, setIsVisible] = React.useState<boolean>(false);
  const [title, setTitle] = React.useState<string | null>(null);
  const [text, setText] = React.useState<string | null>(null);

  const selectedTheme = customTheme ? customTheme : themeStore.currentTheme;

  const OnDefaultCloseModal = () => {
    if (isUseState) {
      setIsVisible(false);
    } else {
      notificationModalStore.setModalVisibility(false);
    }
  };
  const buttonClickHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event && event.preventDefault();
    OnDefaultCloseModal();
    onButtonClickHandler && onButtonClickHandler();
  };

  const secondButtonClickHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event && event.preventDefault();
    OnDefaultCloseModal();
    onSecondButtonClickHandler && onSecondButtonClickHandler();
  };

  const getModalTitle = () => {
    return isUseState ? title : notificationModalStore.modalTitle;
  };

  const getModalText = () => {
    return isUseState ? text : notificationModalStore.modalText;
  };

  const NotificationModal = useCallback(
    observer(({ children }: ModalProps) => (
      <Modal
        closeButtonStyle={disableClose ? { display: 'none' } : {}}
        open={isUseState ? isVisible : notificationModalStore.showModal}
        onModalClose={() => {
          OnDefaultCloseModal();
          onClose && onClose();
        }}
        center
        modalStyle={useThemeForHeader ? { padding: 0 } : undefined}
        overlayStyle={useThemeForBackgroundColor ? { backgroundColor: selectedTheme?.colors?.actionDark?.published } : undefined}>
        <div css={styles.modalContainer}>
          {
            // in case modalTitle is null don't show title
            // in case modalTitle is '' take default title
            <div css={[styles.modalHeader, useThemeForHeader && styles.modalHeaderTheme(selectedTheme)]}>
              <h2 css={[styles.modalTitleStyle(selectedTheme), { margin: 0 }]}>{getModalTitle() !== '' ? getModalTitle() : `Something went wrong, please try again`}</h2>
            </div>
          }
          <div css={styles.modalContent}>
            {children ? <div css={styles.modalContentStyle(selectedTheme)}>{children}</div> : <p css={styles.modalContentStyle(selectedTheme)}>{getModalText()}</p>}
            <div css={{ marginTop: children ? '4rem' : '10rem' }}>
              <Button buttonStyle={styles.closeButtonStyle(selectedTheme)} text={buttonText.toUpperCase()} onClick={buttonClickHandler} css={{ paddingLeft: '3.3rem' }} />
              {secondButtonText && (
                // <Button buttonStyle={styles.closeButtonStyle(selectedTheme)} text={secondButtonText.toUpperCase()} onClick={secondButtonClickHandler} css={{ paddingLeft: '3.3rem' }} />
                <Button buttonStyle={styles.secondaryButtonStyle(selectedTheme)} text={secondButtonText.toUpperCase()} onClick={secondButtonClickHandler} css={{ paddingLeft: '3.3rem' }} />
              )}
            </div>
            {showErrorCode && <ErrorCode />}
          </div>
        </div>
      </Modal>
    )),
    [isVisible, notificationModalStore.showModal]
  );

  const setNotificationModalVisibility = (isVisible: boolean, title: string = '', text: string = '') => {
    if (isUseState) {
      setTitle(title);
      setText(text);
      setIsVisible(isVisible);
    } else {
      notificationModalStore.setModalVisibility(isVisible, title, text);
    }
  };

  return { NotificationModal, setNotificationModalVisibility };
};
