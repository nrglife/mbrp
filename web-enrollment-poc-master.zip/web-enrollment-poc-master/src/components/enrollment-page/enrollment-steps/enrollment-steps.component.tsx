import React, { FC } from 'react';
import { observer } from 'mobx-react';

import InvitationCodeContainer from '../../../pages/enrollment/invitation-code';
import PersonalInfoContainer from '../../../pages/enrollment/personal-info';
import ConfirmPhoneNumberContainer from '../../../pages/enrollment/confirm-phone-number';
import ConfirmPhoneNumberCustomerSupportContainer from '../../../pages/enrollment/confirm-phone-number-customer-support';
import EmailVerificationContainer from '../../../pages/enrollment/email-verification';
import CreatePasswordContainer from '../../../pages/enrollment/create-password';
import LockedContainer from '../../../pages/enrollment/locked';
import EnrolledContainer from '../../../pages/enrollment/enrolled';

import { useStores } from '../../../stores/useStores';
import { EnrollmentSteps as Steps } from '../../../stores';
import MissingInfoContainer from '../../../pages/enrollment/missing-info';
import AlreadyEnrolledContainer from '../../../pages/enrollment/already-enrolled';
import GeneralErrorContainer from '../../../pages/enrollment/enrollment-errors/general-error';
import WrongPayerError from '../../../pages/enrollment/enrollment-errors/wrong-payer-error';
import RecaptchaClientError from '../../../pages/enrollment/enrollment-errors/recaptcha-client-error';
import RecaptchaServerError from '../../../pages/enrollment/enrollment-errors/recaptcha-server-error';
import TimeoutContainer from '../../../pages/enrollment/timeout';
import ContactUsContainer from '../../../pages/enrollment/contact-us';

interface EnrollmentStepsProps {}
const EnrollmentSteps: FC<EnrollmentStepsProps> = props => {
  const { enrollmentStore } = useStores();

  const renderSwitch = () => {
    switch (enrollmentStore.step) {
      case Steps.PersonalInfo:
        return <PersonalInfoContainer />;
      case Steps.ConfirmPhoneNumber:
        return <ConfirmPhoneNumberContainer />;
      case Steps.NoUserPhone:
        return <ConfirmPhoneNumberCustomerSupportContainer />;
      case Steps.EmailVerification:
        return <EmailVerificationContainer />;
      case Steps.CreatePassword:
        return <CreatePasswordContainer />;
      case Steps.Locked:
        return <LockedContainer />;
      case Steps.Enrolled:
        return <EnrolledContainer />;
      case Steps.MissingInfo:
        return <MissingInfoContainer />;
      case Steps.GeneralError:
        return <GeneralErrorContainer />;
      case Steps.WrongPayerError:
        return <WrongPayerError />;
      case Steps.Timeout:
        return <TimeoutContainer />;
      case Steps.RecaptchaClientError:
        return <RecaptchaClientError />;
      case Steps.RecaptchaServerError:
        return <RecaptchaServerError />;
      case Steps.AlreadyEnrolled:
        return <AlreadyEnrolledContainer />;
      default:
        return <InvitationCodeContainer />;
    }
  };

  return renderSwitch();
};

export default observer(EnrollmentSteps);
