import { FC } from "react";
import OtpInput from "react-otp-input";

import "./code-otp.styles.scss";

interface CodeOTPProps {
  value: string | null;
  onOTPChange: (otp: string) => void;
  shouldAutoFocus?: boolean;
  numInputs: number;
  hasError?: boolean;
}

const CodeOTP: FC<CodeOTPProps> = ({
  value,
  onOTPChange,
  shouldAutoFocus,
  numInputs,
  hasError,
}) => {
  return (
    <div className="">
      <OtpInput
        containerStyle="otp-code"
        inputStyle="otp-code__input"
        focusStyle="otp-code__input--focused"
        shouldAutoFocus={shouldAutoFocus}
        onChange={onOTPChange}
        numInputs={numInputs}
        value={value}
        hasErrored={hasError}
        errorStyle="otp-code-has-error"
      />

      <div className="otp-code-error-message">
        {hasError && (
          <p className="otp-code-error-message__text">{`Invitation code is not valid`}</p>
        )}
      </div>
    </div>
  );
};

export default CodeOTP;
