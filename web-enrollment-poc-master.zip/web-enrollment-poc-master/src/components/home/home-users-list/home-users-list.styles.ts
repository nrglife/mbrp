/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const mainContainer = css({
  width: '100%',
  display: 'flex',
  marginTop: '1rem',
  marginBottom: '3rem',
  overflow: 'hidden',
  alignItems: 'center',
  justifyContent: 'center'
});

export const styles = {
  mainContainer
};
