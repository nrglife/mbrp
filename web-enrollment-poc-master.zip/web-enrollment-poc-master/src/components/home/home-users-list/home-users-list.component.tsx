import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//third party
import { NavLink } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../stores/useStores';
//consts
import { styles } from './home-users-list.styles';
import { ReactComponent as AvatarFemaleIcon } from '../../../assets/icons/avatar-female.svg';
import { ReactComponent as AvatarMaleIcon } from '../../../assets/icons/avatar-male.svg';
import { ReactComponent as FamilyIcon } from '../../../assets/icons/family-icon.svg';
import { Preferences } from '../../../stores/ThemeStore';

const EverybodyIcon = props => (
  <div css={{ width: '100%', justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
    <FamilyIcon css={{ border: '0.1rem solid white', padding: '0.2rem', borderRadius: '100%', width: '4rem', height: '4rem' }} {...props} />
  </div>
);

interface HomeUsersListProps {}

const HomeUsersList: FC<HomeUsersListProps> = () => {
  const { themeStore } = useStores();

  const usersImgs = [
    { icon: <EverybodyIcon />, userName: 'Everybody', active: true }

    // { icon: <AvatarEverybodyIcon css={{display: 'block', margin: 'auto'}}/>, userName: 'Everybody', active: true },
    // { icon: <AvatarFemaleIcon />, userName: 'Jane', active: false },
    // { icon: <AvatarMaleIcon />, userName: 'Greg', active: false }
  ];
  return (
    <div css={{ position: 'relative', borderBottom: '1px solid #121212' }}>
      <div css={{ textAlign: 'center', fontSize: '1.1rem', marginTop: '3rem', fontWeight: 'bold', opacity: '0.3' }}>FILTER BY</div>
      <div css={styles.mainContainer}>
        <div css={{ display: 'flex', position: 'relative', alignItems: 'center', justifyContent: 'center' }}>
          {usersImgs.map((userImg, i) => (
            <div key={`userImg-${i}`}>
              <div css={{ color: userImg.active ? themeStore.currentTheme.colors.actionLight.published : 'none' }}>{userImg.icon}</div>
              <div css={[{ textAlign: 'center', fontSize: '1.3rem', marginBottom: '1rem', marginTop: '1rem' }, userImg.active && { fontWeight: 'bold', marginTop: '0.5rem' }]}>{userImg.userName}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default observer(HomeUsersList);
