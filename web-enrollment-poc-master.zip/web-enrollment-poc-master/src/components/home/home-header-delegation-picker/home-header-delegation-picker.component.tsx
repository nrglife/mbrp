import { forwardRef, useEffect, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { styles } from './home-header-delegation-picker.styles';
import { useStores } from '../../../stores/useStores';
import { DelegateMenu } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { useHistory } from 'react-router';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';

interface Props {
  selectedDelegateName: string;
  showMenuButton?: boolean;
  onDropdownButtonClick?: () => void;
  onAddDelegateButtonClick: () => void;
  // onDelegateButtonClick: (member: MemberForDelegate | null) => void;
  showDelegateDropdown?: boolean;
  //userProfile: UserProfile | null;
  //membersForDelegateList?: MemberForDelegate[] | null;
  //memberForDelegate: MemberForDelegate | null;
  payer?: string;
  isMobile: boolean;
  menu: DelegateMenu;
}

const DelegationPicker = forwardRef<HTMLDivElement, Props>((props, ref) => {
  //const [title, setTitle] = useState<string>('');
  const { themeStore } = useStores();
  const history = useHistory();
  const { getPath } = useRouteUtils();
  //const [showMenu, setShowMenu] = useState<boolean>(false);
  const {
    selectedDelegateName,
    showMenuButton,
    onAddDelegateButtonClick,

    onDropdownButtonClick,
    showDelegateDropdown /**/ /*, userProfile, membersForDelegateList,*/,
    menu,
    /*onDelegateButtonClick, */ payer,
    isMobile
  } = props;

  const handleAddNewAccount = () => {
    onDropdownButtonClick && onDropdownButtonClick();
    //setShowMenu(false);
    onAddDelegateButtonClick && onAddDelegateButtonClick();
  };

  return (
    <div
      css={[
        styles.delegationPickerContainer,
        showMenuButton ? (menu ? { marginRight: '60px' } : { marginRight: '30px' }) : { marginRight: '37px' },
        isMobile && [styles.delegationPickerContainerMobile, { background: themeStore.currentTheme.colors.backgroundDark.published }]
      ]}>
      <div ref={ref}>
        {menu ? (
          <button
            css={[styles.delegationPickerButton, isMobile && styles.delegationPickerButtonMobile]}
            onClick={() => {
              onDropdownButtonClick && onDropdownButtonClick();
              //setShowMenu(true);
            }}>
            {selectedDelegateName} <span css={[styles.buttonTriangle]}></span>
          </button>
        ) : (
          <p css={[styles.memberNameTitle]}>{selectedDelegateName}</p>
        )}
        {menu && showDelegateDropdown && (
          <div css={[styles.dropdownMenu, isMobile && styles.dropdownMenuMobile]}>
            {menu.mainMember && (
              <>
                <p css={[styles.subTitle]}>{payer}</p>
                <p
                  css={[
                    styles.memberNameTitleInList,
                    menu.mainMember.isHighlighted ? styles.itemTextNoHover(themeStore.currentTheme) : styles.itemText(themeStore.currentTheme),
                    menu.mainMember.isHighlighted && styles.activeItem(themeStore.currentTheme)
                  ]}
                  onClick={() => {
                    onDropdownButtonClick && onDropdownButtonClick();
                    menu.mainMember.onClick();
                  }}>
                  {menu.mainMember.name}
                </p>
              </>
            )}
            <p css={[styles.subTitle]}>Delegate Accounts</p>
            {menu.otherMembers.length > 0 ? (
              <ul css={[styles.fullWidth]}>
                {menu.otherMembers?.map((item, index) => {
                  return (
                    <li
                      key={index.toString()}
                      css={[
                        item.isHighlighted ? styles.itemTextNoHover(themeStore.currentTheme) : styles.itemText(themeStore.currentTheme),
                        item.isHighlighted && styles.activeItem(themeStore.currentTheme)
                      ]}
                      onClick={() => {
                        onDropdownButtonClick && onDropdownButtonClick();
                        //setShowMenu(false);
                        //history.replace(getPath(RouteName.home));

                        item.onClick();
                        //onDelegateButtonClick(item);
                        //setTitle(item?.humanName?.fullName ? item?.humanName?.fullName : '');
                      }}>
                      {item?.name}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p css={[styles.emptyItemText]}>No accounts to show</p>
            )}
            {/* <p css={[styles.itemText(themeStore.currentTheme)]} onClick={handleAddNewAccount}>
              Add New Delegate Account
            </p> */}
          </div>
        )}
      </div>
    </div>
  );
});

export default DelegationPicker;
