/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

const delegationPickerContainer = css({
  flex: 1,
  justifyContent: 'flex-end',
  marginLeft: 'auto',
  display: 'flex',
  position: 'relative'
});

const delegationPickerContainerMobile = css({
  position: 'fixed',
  left: 0,
  width: '100%',
  top: '57px',
  height: '48px',
  zIndex: 10,
  justifyContent: 'center',
  alignItems: 'center'
});

const delegationPickerButton = css({
  padding: '0px 23px 0 12px',
  minWidth: '64px',
  height: '26px',
  border: '1px solid',
  borderColor: globalStyles.COLOR.blueGrey,
  borderRadius: '8px',
  background: 'transparent',
  color: '#fff',
  cursor: 'pointer',
  position: 'relative',
  display: 'block',
  fontSize: '12px',
  lineHeight: '15px',
  textAlign: 'left'
});

const memberNameTitle = css({
  color: '#fff',
  fontSize: '12px',
  lineHeight: '15px'
});

const memberNameTitleInList = css({
  marginBottom: '23px'
});

const delegationPickerButtonMobile = css({
  minWidth: 'auto',
  width: '319px',
  maxWidth: '319px',
  borderColor: globalStyles.COLOR.white
});

const buttonTriangle = css({
  position: 'absolute',
  content: '""',
  width: 0,
  height: 0,
  borderStyle: 'solid',
  borderWidth: '5px 4px 0 4px',
  borderColor: '#ffffff transparent transparent transparent',
  top: 'calc(50% - 2.5px)',
  right: '10px'
});

const dropdownMenu = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-start',
  padding: '0px 0px 16px',
  position: 'absolute',
  width: '275px',
  right: '18px',
  top: '100%',
  background: globalStyles.COLOR.white,
  boxShadow: '0px 1px 4px rgba(17, 80, 244, 0.12), 0px 10px 32px rgba(131, 144, 175, 0.35)',
  borderRadius: '8px',
  zIndex: 10
});

const dropdownMenuMobile = css({
  width: '319px',
  right: 'auto',
  top: '37px'
});

const subTitle = css({
  fontSize: '10px',
  lineHeight: '125%',
  letterSpacing: '0.5px',
  textTransform: 'uppercase',
  padding: '14px 35px 14px 24px'
});

const itemText = (theme: Preferences) =>
  css({
    fontSize: '13px',
    lineHeight: '150%',
    padding: '12px 35px 12px 24px',
    width: '100%',
    cursor: 'pointer',
    '&:hover': {
      backgroundColor: `${theme.colors.actionLight.published}90`,

      boxShadow: `inset 2px 0px 0px ${globalStyles.COLOR.sea}`
    }
  });

const itemTextNoHover = (theme: Preferences) =>
  css({
    fontSize: '13px',
    lineHeight: '150%',
    padding: '12px 35px 12px 24px',
    width: '100%',
    cursor: 'pointer'
  });

const activeItem = (theme: Preferences) =>
  css({
    background: theme.colors.actionLight.published,
    boxShadow: `inset 2px 0px 0px ${globalStyles.COLOR.sea}`
  });

const emptyItemText = css({
  fontSize: '13px',
  lineHeight: '150%',
  padding: '12px 35px 12px 24px',
  width: '100%',
  fontWeight: 'bold'
});

const fullWidth = css({
  width: '100%'
});

export const styles = {
  delegationPickerContainer,
  delegationPickerContainerMobile,
  delegationPickerButton,
  memberNameTitle,
  memberNameTitleInList,
  delegationPickerButtonMobile,
  buttonTriangle,
  dropdownMenu,
  dropdownMenuMobile,
  subTitle,
  itemText,
  activeItem,
  emptyItemText,
  fullWidth,
  itemTextNoHover
};
