import { useCallback, useMemo } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import NavLinksMenu from '../../general/nav-links-menu/nav-links-menu.component';
import { usePagesMenu } from '../../../customHooks/usePagesMenu';
//consts
import { styles } from './home-menu.styles';
import { Logout } from 'components/general/logout/logout.component';
import { useStores } from '../../../stores/useStores';

interface HomeMenuProps {}

const HomeMenu = React.forwardRef<HTMLDivElement, HomeMenuProps>(({}, ref) => {
  const { themeStore, authStore, responsiveStore, payerStore } = useStores();
  const pagesMenu = usePagesMenu();

  const onLogout = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
    authStore.logout();
  };

  const showCopyrightStatement = useMemo(() => payerStore.payer?.copyrightStatement && payerStore.payer.copyrightStatement.trim() !== '', [payerStore.payer]);

  return (
    <div css={styles.menuBar} ref={ref}>
      {/* <HomeUsersList /> */}
      <NavLinksMenu
        links={pagesMenu.primaryLinks}
        linkStyle={!responsiveStore.isTablet ? styles.link(themeStore.currentTheme) : styles.linkMobileDesign(themeStore.currentTheme)}
        showSubMenuLinks={responsiveStore.isTablet}
        subLinkStyle={styles.subLink(themeStore.currentTheme)}
        parentLinkStyle={styles.parentLink(themeStore.currentTheme)}
      />
      <Logout onClick={useCallback(onLogout, [])} style={responsiveStore.isTablet ? styles.logoutMobileDesign : undefined} />
      <div css={[styles.poweredBy]}>Powered by Change Healthcare</div>
      <div css={[styles.poweredBy, styles.poweredByBottom]}>{showCopyrightStatement ? payerStore?.payer?.copyrightStatement : 'Copyright Ⓒ 2022. All Rights Reserved'}</div>
    </div>
  );
});

export default observer(HomeMenu);
