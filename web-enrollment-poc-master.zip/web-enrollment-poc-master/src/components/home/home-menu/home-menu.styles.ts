/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

const menuBar = css({
  width: '100%',
  display: 'flex',
  flexDirection: 'column'
});

const menuText = css({
  paddingTop: '1rem'
});

const linksContainer = css({
  display: 'flex',
  flexDirection: 'column'
});

const link = (theme: Preferences) =>
  css({
    color: 'white',
    width: '100%',
    textDecoration: 'none',
    paddingLeft: '1.5rem',
    display: 'flex',
    alignItems: 'center',
    paddingTop: '1rem',
    paddingBottom: '1rem',
    '&.active': { color: theme.colors.actionDark.published, backgroundColor: theme.colors.actionLight.published, fontWeight: 'bold' }
  });

const linkMobileDesign = (theme: Preferences) =>
  css({
    color: 'white',
    width: '100%',
    textDecoration: 'none',
    padding: '1.5rem',
    display: 'flex',
    lineHeight: '2rem',
    fontSize: '1.6rem',
    borderBottom: `.1rem solid ${globalStyles.COLOR.white}`,
    '&.active': { color: theme.colors.actionDark.published, backgroundColor: theme.colors.actionLight.published, fontWeight: 'bold', borderBottom: `none` }
  });

const subLink = (theme: Preferences) =>
  css({
    transition: 'all .2s',
    color: 'white',
    width: '100%',
    textDecoration: 'none',
    paddingTop: '1.5rem',
    paddingBottom: '1.5rem',
    display: 'flex',
    lineHeight: '2rem',
    fontSize: '1.6rem',
    borderBottom: `.1rem solid rgba(255,255,255,0.5)`,
    '&.active': { color: theme.colors.actionDark.published, backgroundColor: theme.colors.actionLight.published, fontWeight: 'bold', borderBottom: `none` }
  });

const parentLink = (theme: Preferences) =>
  css({
    transition: 'all .2s',
    color: 'white',
    width: '100%',
    textDecoration: 'none',
    paddingTop: '1.5rem',
    paddingBottom: '1.5rem',
    display: 'flex',
    lineHeight: '2rem',
    fontSize: '1.6rem',
    borderBottom: `.1rem solid ${globalStyles.COLOR.white}`,
    '&.active': { fontWeight: 'bold' }
  });

const disable = css({ pointerEvents: 'none' });

const logoutMobileDesign = css({ borderTop: 'none', paddingTop: '4.5rem' });

const poweredBy = css({ paddingLeft: '1.8rem', fontSize: '1rem', lineHeight: '1.8rem', letterSpacing: '0.0', color: globalStyles.COLOR.veryLightPink });

const poweredByBottom = css({ paddingBottom: '1.8rem' });

export const styles = {
  menuBar,
  menuText,
  linksContainer,
  link,
  linkMobileDesign,
  disable,
  logoutMobileDesign,
  subLink,
  parentLink,
  poweredBy,
  poweredByBottom
};
