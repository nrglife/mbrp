import { Fragment, FC, useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react';
/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
//third party
import { useLocation, useHistory } from 'react-router-dom';
//developed
import HomeHeader from '../home-header/home-header.component';
import HomeMenu from '../home-menu/home-menu.component';
import { FindCarePageContainer as FindCarePage } from 'pages/find-care';
import HealthProfileWrapper from '../../../pages/health-profile/health-profile-wrapper/health-profile-wrapper.component';
import ProfileAndSettingsWrapper from '../../../pages/profile-and-settings/profile-and-settings-wrapper/profile-and-settings-wrapper.component';
import { LinkedServicesWrapper } from '../../../pages/linked-services/linked-services-wrapper/linked-services-wrapper.component';
import HelpWrapper from '../../../pages/help/help-wrapper/help-wrapper.component';
import PageLayout from '../../page-layout/page-layout.component';
import ActivityTracker from '../../../components/user-inactivity/user-inactivity.component';
import { EOBsPageContainer as EOBsPage } from 'pages/eobs';
//consts
import { styles } from './home-wrapper.styles';

import { useStores } from '../../../stores/useStores';
import { RouteName } from 'stores/RoutesStore';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { DelegateStoreState } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';

interface HomeWrapperProps {}

const switchConfig: BuildRouteParams[] = [
  { key: 'navigation-eobs-page', name: RouteName.eobs, component: EOBsPage },
  { key: 'navigation-profile-and-settings-page', name: RouteName.profileAndSettings, component: ProfileAndSettingsWrapper },
  { key: 'navigation-linked-services-page', name: RouteName.linkedServices, component: LinkedServicesWrapper },
  { key: 'navigation-findcare-page', name: RouteName.findCare, component: FindCarePage },
  { key: 'navigation-health-profile-page', name: RouteName.healthProfile, component: HealthProfileWrapper },
  { key: 'navigation-help-page', name: RouteName.help, component: HelpWrapper }
];

const HomeWrapper: FC<HomeWrapperProps> = () => {
  // const homeRoutes: any[] = [];
  const { delegateStore, themeStore, responsiveStore } = useStores();
  const { t } = useTranslation('translation');
  const history = useHistory();

  let notificationModalConfig = {
    onClose: () => {
      setShowingModal(false);
      delegateStore.clearError();
    },
    customTheme: undefined,
    buttonText: t(LocaleKeys.errors.try_again_button),
    onButtonClickHandler: () => {
      setShowingModal(false);
      delegateStore.retrySelectMember();
    },
    useThemeForBackgroundColor: false
  };
  const { setNotificationModalVisibility, NotificationModal } = useNotificationModal(notificationModalConfig);
  const [showingModal, setShowingModal] = useState<boolean>(false);
  const location = useLocation();
  const [showMenu, setShowMenu] = useState(false);
  const [showMenuBtnWasPressed, setShowMenuBtnWasPressed] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { buildSwitch, getPath } = useRouteUtils();
  const [showDelegateDropdown, setShowDelegateDropdown] = useState(false);
  const [isFirstDelegateId, setIsFirstDelegateId] = useState<boolean>(true);

  useEffect(() => {
    //reset the show menu state
    !responsiveStore.isTablet && showMenu && setShowMenu(false);
    !responsiveStore.isTablet && showMenuBtnWasPressed && setShowMenuBtnWasPressed(false);
  }, [responsiveStore.isTablet]);

  useEffect(() => {
    if (delegateStore.state === DelegateStoreState.RunningShowError && !showingModal) {
      setNotificationModalVisibility(true, t(LocaleKeys.errors.something_went_wrong), t(LocaleKeys.errors.unable_to_get_account_information));
      setShowingModal(true);
    }
  }, [delegateStore.state, showingModal]);

  useEffect(() => {
    if (delegateStore.selectedDelegateId) {
      if (!isFirstDelegateId) {
        history.replace(getPath(RouteName.home));
      }
      setIsFirstDelegateId(false);
    }
  }, [delegateStore.selectedDelegateId]);

  useEffect(() => {
    //reset menu when a new page reload
    responsiveStore.isTablet && showMenu && setShowMenu(false);
  }, [location.pathname]);

  // Hide menu or dropdown when clicked outside
  const onClickOutside = event => {
    if (showMenu && menuRef && menuRef.current && !menuRef.current.contains(event.target)) {
      setShowMenu(false);
    }
    if (dropdownRef && dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowDelegateDropdown(false);
    }
  };

  const handleDropdownToggle = () => {
    setShowDelegateDropdown(!showDelegateDropdown);
  };

  useEffect(() => {
    if (showMenu && menuRef && menuRef.current != null) {
      window.addEventListener('click', onClickOutside);
    }
    return () => {
      window.removeEventListener('click', onClickOutside);
    };
  }, [showMenu]);

  useEffect(() => {
    if (showDelegateDropdown && dropdownRef && !dropdownRef.current != null) {
      window.addEventListener('click', onClickOutside);
    }
    return () => {
      window.removeEventListener('click', onClickOutside);
    };
  }, [showDelegateDropdown]);

  return (
    <Fragment>
      <ActivityTracker />
      <PageLayout
        top={
          <HomeHeader
            selectedDelegateName={delegateStore.selectedDelegateName}
            menu={delegateStore.delegateMenu}
            showMenuButton={responsiveStore.isTablet}
            isMenuButtonClicked={showMenu}
            onMenuButtonClick={() => {
              setShowMenu(!showMenu);
              !showMenuBtnWasPressed && setShowMenuBtnWasPressed(true);
            }}
            onDropdownButtonClick={handleDropdownToggle}
            showDelegateDropdown={showDelegateDropdown}
            dropdownRef={dropdownRef}
          />
        }
        topStyle={styles.header(themeStore.currentTheme)}
        mainBodyStyle={styles.body(themeStore.currentTheme)}
        left={<HomeMenu ref={menuRef} />}
        leftStyle={[
          styles.leftMainMenu(themeStore.currentTheme),
          showMenuBtnWasPressed ? styles.collapsibleMenuTransition : css({}),
          responsiveStore.isTablet ? styles.collapsibleMenu : css({}),
          responsiveStore.isTablet && showMenu ? styles.showCollapsibleMenu : css({})
        ]}
        center={
          <>
            {buildSwitch(switchConfig, true, RouteName.home)}
            {/* Covering content with transparent div to avoid clicks outside the menu when its open */}
            {showMenu && <div css={styles.outerMenuCoveringArea}></div>}
          </>
        }
        centerStyle={[styles.pagesContainer, responsiveStore.isTablet ? css({ boxShadow: 'none' }) : css({})]}
      />
      <NotificationModal />
    </Fragment>
  );
};

export default observer(HomeWrapper);
