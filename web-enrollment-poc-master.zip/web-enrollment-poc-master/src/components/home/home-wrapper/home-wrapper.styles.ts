/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

const header = (theme: Preferences) =>
  css([
    {
      paddingTop: '1rem',
      paddingBottom: '1rem',
      display: 'flex',
      justifyContent: 'left',
      verticalAlign: 'center',
      alignItems: 'left',
      backgroundColor: theme.colors.actionDark.published
    },
    //heandel desktop view till all the web app will be responsive
    (window as any)?.env?.REACT_APP_RESPONSIVE_ENABLED === 'false' && { minWidth: '130rem' }
  ]);

const content = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: 'white',
  boxShadow: `0px 2px 5px ${globalStyles.COLOR.darkBlueGrey}`
});

const body = (theme: Preferences) =>
  css([
    {
      background: theme.colors.backgroundMedium.published
    },
    //heandel desktop view till all the web app will be responsive
    (window as any)?.env?.REACT_APP_RESPONSIVE_ENABLED === 'false' && { minWidth: '130rem' }
  ]);

const leftMainMenu = (theme: Preferences) =>
  css({
    width: '19.9rem',
    display: 'flex',
    color: 'white',
    background: theme.colors.backgroundDark.published,
    overflowY: 'scroll'
  });

const collapsibleMenu = css({
  position: 'absolute',
  zIndex: 12,
  //beacuse the element now is absolute his height driven from the screen - meaning the menu real height need to be the sane as center style at the page-layout component
  maxHeight: '95.3vh',
  right: 0,

  width: '15rem',
  visibility: 'hidden',
  opacity: 0
});

const collapsibleMenuTransition = css({
  transition: 'all .3s'
});

const showCollapsibleMenu = css({
  width: '30rem',
  visibility: 'visible',
  opacity: 1
});

const pagesContainer = css({
  display: 'flex',
  // width: 'calc(100% - 19.9rem)',
  flex: 1,
  boxShadow: '-10px 0px 15px -4px rgba(0,0,0, .5)',
  position: 'relative'
});

const outerMenuCoveringArea = css({
  width: '100%',
  height: '100%',
  opacity: 0,
  position: 'absolute',
  zIndex: 11
});

export const styles = {
  header,
  body,
  leftMainMenu,
  collapsibleMenu,
  collapsibleMenuTransition,
  showCollapsibleMenu,
  content,
  pagesContainer,
  outerMenuCoveringArea
};
