/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { absoluteContainer } from 'components/general/beating-heart-loader/beating-heart-loader.styles';
import { relative } from 'path';
import { globalStyles } from '../../../styles/global.styles';

const headerPanel = css({
  flex: 1,
  flexDirection: 'row',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  position: 'relative'
});

const headerText = css({
  color: globalStyles.COLOR.white,
  fontSize: '2.4rem',
  letterSpacing: '0',
  paddingLeft: '2.1rem'
});

const headerTextMobile = css({
  flex: 2,
  textAlign: 'center',
  padding: 0,
  fontSize: '2rem',
  justifyContent: 'center'
});

const menuIconContainer = css({ cursor: 'pointer', position: 'relative', width: '3rem', height: '1.9rem', marginRight: '1.9rem' });
const menuTopBar = css({ width: '3rem', height: '.3rem', background: 'white', borderRadius: '1rem', transition: 'all .3s' });
const menuTopBarChange = css({ width: '2.5rem', position: 'absolute', transform: 'rotate(45deg)', right: '0.2rem', marginTop: '0.8rem' });
const menuMiddleBar = css({ width: '3rem', height: '.3rem', background: 'white', borderRadius: '1rem', margin: '.5rem 0', transition: 'all .3s' });
const menuMiddleBarChange = css({ opacity: 0, width: 0, margin: 0 });
const menuBottomBar = css({ width: '3rem', height: '.3rem', background: 'white', borderRadius: '1rem', transition: 'all .3s' });
const menuBottomBarChange = css({ width: '2.5rem', position: 'absolute', transform: 'rotate(-45deg)', right: '0.22rem', marginTop: '0.5rem', zIndex: 2 });

const leftArrowWrapMobile = css({
  minWidth: '1px',
  display: 'flex',
  flex: 1,
  justifyContent: 'flex-start',
  marginRight: 'auto'
});

const leftArrowIcon = css({
  width: '2.4rem',
  height: '2.4rem',
  color: 'white',
  cursor: 'pointer',
  marginLeft: '1rem'
});

const menuWrap = css({
  justifyContent: 'flex-end',
  marginLeft: 'auto',
  display: 'flex',
});

const linkStyles = css({
  height: '100%',
  display: 'flex',
  alignItems: 'center'
});

export const styles = {
  headerPanel,
  headerText,
  headerTextMobile,
  menuIconContainer,
  menuTopBar,
  menuTopBarChange,
  menuMiddleBar,
  menuMiddleBarChange,
  menuBottomBar,
  menuBottomBarChange,
  leftArrowWrapMobile,
  leftArrowIcon,
  menuWrap,
  linkStyles,
};
