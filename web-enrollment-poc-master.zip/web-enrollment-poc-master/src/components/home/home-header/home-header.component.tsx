import { FC, useState, useEffect } from 'react';
import { observer } from 'mobx-react';
//third party
import { Link, useLocation, useHistory } from 'react-router-dom';
/** @jsxImportSource @emotion/core */
//developed
import { useStores } from '../../../stores/useStores';
import { EnrollmentOrigin } from 'stores';
import { mobileRoutesPageNames, RouteName } from '../../../stores/RoutesStore';
import DelegationPicker from '../home-header-delegation-picker/home-header-delegation-picker.component';
import { useEnrollment } from 'pages/enrollment/useEnrollment';
//consts
import { ReactComponent as BackArrowIcon } from '../../../assets/icons/chevron-left.svg';
import { styles } from './home-header.styles';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { DelegateMenu } from '@healthcareapp/connected-health-common-services/dist/stores/DelegateStore';

interface HomeHeaderProps {
  showMenuButton?: boolean;
  isMenuButtonClicked?: boolean;
  onMenuButtonClick?: () => void;
  onDropdownButtonClick?: () => void;
  //onDelegateButtonClick: (member: MemberForDelegate | null) => void;
  showDelegateDropdown?: boolean;
  dropdownRef?: React.Ref<HTMLDivElement> | null;
  menu: DelegateMenu;
  selectedDelegateName: string;
}

const HomeHeader: FC<HomeHeaderProps> = ({
  selectedDelegateName,
  menu,
  showMenuButton = false,
  isMenuButtonClicked,
  onMenuButtonClick,
  onDropdownButtonClick,
  showDelegateDropdown,
  dropdownRef /*onDelegateButtonClick*/
}) => {
  const { imageStore, responsiveStore, payerStore, routesStore } = useStores();
  const location = useLocation();
  const history = useHistory();
  const { getPath } = useRouteUtils();
  const [historyLocations] = useState<string[]>([`/${routesStore.payer}`]);
  const { EnrollmentModal, initEnrollment } = useEnrollment();

  const pagePathParts = location.pathname.split('/');
  let pageNameFromPath = pagePathParts.pop()?.toLocaleLowerCase();

  // If pathname dees not exsits, go back untill find one
  if (responsiveStore.isMobile && pageNameFromPath && !mobileRoutesPageNames[pageNameFromPath]) {
    var i = pagePathParts.length;
    while (i-- && !mobileRoutesPageNames[pageNameFromPath]) {
      pageNameFromPath = pagePathParts[i]?.toLocaleLowerCase();
    }
  }
  const [pageName, setPageName] = useState((pageNameFromPath && showMenuButton && responsiveStore.isMobile && mobileRoutesPageNames[pageNameFromPath]) || 'Connected Health');
  useEffect(() => {
    const newPageName =
      (pageNameFromPath && showMenuButton && responsiveStore.isMobile && !isMenuButtonClicked && mobileRoutesPageNames[pageNameFromPath]) || (isMenuButtonClicked && 'Menu') || 'Connected Health';
    setPageName(newPageName);
    if (location.pathname !== historyLocations[historyLocations.length - 1]) {
      historyLocations.push(location.pathname);
    }
  }, [showMenuButton, isMenuButtonClicked, responsiveStore.isMobile, location.pathname]);

  const lastUrl = [...historyLocations].reverse().find(item => item !== location.pathname);

  const goBack = () => {
    let goBackUrl = historyLocations.pop();
    if (historyLocations.length > 0 && goBackUrl === location.pathname) {
      goBackUrl = historyLocations.pop();
    }
    history.goBack();
  };

  return (
    <div css={styles.headerPanel}>
      <div css={[responsiveStore.isMobile && styles.leftArrowWrapMobile]}>
        {responsiveStore.isMobile && lastUrl !== `/${routesStore.payer}` && <BackArrowIcon onClick={goBack} css={styles.leftArrowIcon} />}
      </div>
      <h3 css={[styles.headerText, responsiveStore.isMobile && styles.headerTextMobile]}>{pageName}</h3>
      <DelegationPicker
        selectedDelegateName={selectedDelegateName}
        showMenuButton={showMenuButton}
        onDropdownButtonClick={onDropdownButtonClick}
        onAddDelegateButtonClick={() => initEnrollment(EnrollmentOrigin.AddDelegateButton)}
        showDelegateDropdown={showDelegateDropdown}
        ref={dropdownRef}
        // userProfile={userProfileDefault || null}
        //membersForDelegateList={membersForDelegateList}
        //onDelegateButtonClick={onDelegateButtonClick}
        payer={payerStore?.payerName}
        isMobile={responsiveStore.isMobile}
        menu={menu}
      />
      <div css={[styles.menuWrap, responsiveStore.isMobile && { flex: 1 }, !responsiveStore.isMobile && !responsiveStore.isTablet && { paddingRight: '2rem' }]}>
        {!showMenuButton ? (
          <>
            {/* {!responsiveStore.isTablet && (
              <Button
                text="Add delegate"
                onClick={() => {
                  initEnrollment(EnrollmentOrigin.AddDelegateButton);
                }}
                buttonStyle={css({ width: '100px', margin: '0px', padding: '5px', right: '150px', fontSize: '12px' })}
              />
            )} */}

            <Link to={getPath(RouteName.home)} css={styles.linkStyles}>
              <img src={imageStore.logos.light.data} height="34px" alt="" />
            </Link>
          </>
        ) : (
          <div
            onClick={() => {
              onMenuButtonClick && onMenuButtonClick();
            }}
            css={[styles.menuIconContainer]}>
            <div css={[styles.menuTopBar, isMenuButtonClicked && styles.menuTopBarChange]} />
            <div css={[styles.menuMiddleBar, isMenuButtonClicked && styles.menuMiddleBarChange]} />
            <div css={[styles.menuBottomBar, isMenuButtonClicked && styles.menuBottomBarChange]} />
          </div>
        )}
      </div>
      <EnrollmentModal />
    </div>
  );
};

export default observer(HomeHeader);
