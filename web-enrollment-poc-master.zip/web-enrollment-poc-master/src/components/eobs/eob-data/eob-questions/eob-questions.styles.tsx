/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const careContainer = css({
  // width: '100%',
  display: 'flex',
  justifyContent: 'start',
  flexWrap: 'wrap',
  flexDirection: 'row'
});

export const headlineContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'flex-end',
  flexDirection: 'column'
});

export const headline2 = (theme: Preferences) =>
  css({
    fontSize: '1.8rem',
    lineHeight: '3rem',
    letterSpacing: '0',
    color: theme.colors.backgroundDark.published
  });

export const plainText = (color: string = globalStyles.COLOR.redPink) =>
  css({
    fontSize: '1.3rem',
    lineHeight: '1.8rem',
    letterSpacing: '0',
    color: color
  });
export const plainTextHighlighted = css({
  fontSize: '1.3rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});
