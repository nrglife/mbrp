/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';

//CommonServices
import { getAddressAs2Lines, getTelecom } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { ContactPointSystem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';

//developed
import { useStores } from '../../../../stores/useStores';

//styles
import * as styles from './eob-questions.styles';
import { globalStyles } from '../../../../styles/global.styles';

const EobQuestions = () => {
  const { themeStore, eobListStore } = useStores();
  //implement get data from store/api according to the eob the user select on the screen
  const billingAddressIn2Lines = getAddressAs2Lines(eobListStore.selected?.providerAddress);
  const billingPhoneNumber = eobListStore.selected?.provider?.telecom ? getTelecom(eobListStore.selected?.provider?.telecom, ContactPointSystem.Phone) : null;
  const billingEmail = eobListStore.selected?.provider?.telecom ? getTelecom(eobListStore.selected?.provider?.telecom, ContactPointSystem.Email) : null;

  const showQuestions =
    ((eobListStore.selected?.providerFullName && eobListStore.selected?.providerFullName.trim() !== '') ||
      (billingAddressIn2Lines.line1 && billingAddressIn2Lines.line1.trim() !== '') ||
      (billingAddressIn2Lines.line2 && billingAddressIn2Lines.line2.trim() !== '') ||
      (billingPhoneNumber && billingPhoneNumber.value != null && billingPhoneNumber.value !== '') ||
      (billingEmail && billingEmail.value != null && billingEmail.value !== '')) === true;

  const value = showQuestions ? (
    <div css={[styles.headlineContainer, { paddingTop: '7.3rem' }]}>
      <div css={styles.headline2(themeStore.currentTheme)}>Questions?</div>
      <div css={[styles.careContainer, { paddingLeft: '1.5rem' }]}>
        <div>
          <div css={styles.plainText(globalStyles.COLOR.slateGrey)}>Service Charges</div>
          {eobListStore.selected?.providerFullName && eobListStore.selected?.providerFullName.trim() !== '' && <div css={[styles.plainTextHighlighted]}>{eobListStore.selected?.providerFullName}</div>}
          {billingAddressIn2Lines.line1 && billingAddressIn2Lines.line1.trim() !== '' && <div css={[styles.plainText(globalStyles.COLOR.blackTwo)]}>{billingAddressIn2Lines.line1}</div>}
          {billingAddressIn2Lines.line2 && billingAddressIn2Lines.line2.trim() !== '' && <div css={[styles.plainText(globalStyles.COLOR.blackTwo)]}>{billingAddressIn2Lines.line2}</div>}

          {billingPhoneNumber && billingPhoneNumber.value != null && billingPhoneNumber.value !== '' && <div css={[styles.plainText(globalStyles.COLOR.blackTwo)]}>{billingPhoneNumber.value}</div>}
          {billingEmail && billingEmail.value != null && billingEmail.value !== '' && <div css={[styles.plainText(globalStyles.COLOR.blackTwo)]}>{billingEmail.value}</div>}
        </div>
      </div>
    </div>
  ) : (
    <div css={{ paddingTop: '8rem' }} />
  );

  return value;
};

export default observer(EobQuestions);
