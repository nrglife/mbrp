import { useMemo } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';

//CommonServices
import { EOB } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
import { formatDate, INVALID_DATE, isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import { getAddressAs2Lines } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';

//developed
import { useStores } from '../../../../stores/useStores';

//styles
import * as styles from './eob-care-details.styles';
import { globalStyles } from '../../../../styles/global.styles';
import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';

import { IdentifierCodeType } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import InlineWarning from 'components/general/inline-warning/inline-warning.component';

const PractitionerContent = observer(() => {
  const { eobListStore } = useStores();
  const showPractitionerContent = eobListStore.selected?.performingPractitionerFullName != null && eobListStore.selected?.performingPractitionerFullName !== '';
  const practitionerContent = showPractitionerContent ? (
    <>
      <div css={styles.plainTextHighlighted}>{eobListStore.selected?.performingPractitionerFullName}</div>
      <div css={styles.plainText(globalStyles.COLOR.blackTwo)}>{eobListStore.selected?.practitionerRole}</div>
    </>
  ) : (
    <div css={styles.unavailableText}>{`Unavailable`}</div>
  );
  return practitionerContent;
});

const ServicesData = observer(() => {
  const { eobListStore } = useStores();
  const name = eobListStore.selected?.patientName;
  const nameLabel = name !== null && name !== '' ? name : <span css={[styles.unavailableText, { fontSize: '1.4rem', lineHeight: '2rem' }]}>Unavailable</span>;
  const eobDatesLabel: string | null = useMemo(() => {
    const date = eobListStore.selected?.EOBDate;

    if (isValidDate(date?.start) && isValidDate(date?.end)) {
      if (formatDate(date?.start) === formatDate(date?.end)) return `, ${formatDate(date?.start)}`;
      return `, ${formatDate(date?.start)} - ${formatDate(date?.end)}`;
    }
    if (isValidDate(date?.start)) return `, ${formatDate(date?.start)}`;
    if (isValidDate(date?.end)) return `, ${formatDate(date?.end)}`;
    return '';
  }, [eobListStore.selected]);

  const servicesLine =
    eobDatesLabel != '' ? (
      <div>
        {`Services for `}
        {nameLabel}
        {eobDatesLabel}
      </div>
    ) : (
      <div>
        {`Services for `}
        {nameLabel}
      </div>
    );
  return servicesLine;
});

const ReferenceLine = observer(() => {
  const { eobListStore } = useStores();
  const referenceNum = eobListStore.selected?.referenceNum;
  const eobCreationDate = useMemo(() => (isValidDate(eobListStore.selected?.eob?.created) ? formatDate(eobListStore.selected?.eob?.created) : null), [eobListStore.selected]);

  const eobReferenceLabel = referenceNum != null && referenceNum !== '' ? `Reference: ${referenceNum}` : '';
  const eobCreationDateLabel = eobCreationDate != null && eobCreationDate !== INVALID_DATE && eobCreationDate !== '' ? eobCreationDate : '';

  const eobReferenceLabelAndDate = eobReferenceLabel ? (eobCreationDateLabel ? `${eobReferenceLabel}, ${eobCreationDate}` : eobReferenceLabel) : eobCreationDateLabel;
  return <div css={[styles.plainText(globalStyles.COLOR.slateGrey)]}>{eobReferenceLabelAndDate && eobReferenceLabelAndDate.trim() !== '' && <div>{eobReferenceLabelAndDate.trim()}</div>}</div>;
});

const FacilityContent = observer(() => {
  const { eobListStore } = useStores();
  const facilityName = eobListStore.selected?.facility?.name;
  const facilityAddressIn2Lines = getAddressAs2Lines(eobListStore.selected?.facility?.address);
  const showFacilityContent =
    (facilityName && facilityName.trim() !== '') ||
    (facilityAddressIn2Lines.line1 && facilityAddressIn2Lines.line1.trim() !== '') ||
    (facilityAddressIn2Lines.line2 && facilityAddressIn2Lines.line2.trim() !== '');

  const facilityContent = showFacilityContent ? (
    <div>
      {facilityName && facilityName.trim() !== '' && <div css={styles.plainTextHighlighted}>{facilityName.trim()}</div>}
      {facilityAddressIn2Lines.line1 && facilityAddressIn2Lines.line1.trim() !== '' && <div css={styles.plainText(globalStyles.COLOR.blackTwo)}>{facilityAddressIn2Lines.line1}</div>}
      {facilityAddressIn2Lines.line2 && facilityAddressIn2Lines.line2.trim() !== '' && <div css={styles.plainText(globalStyles.COLOR.blackTwo)}>{facilityAddressIn2Lines.line2}</div>}
    </div>
  ) : (
    <div css={styles.unavailableText}>{'Unavailable'}</div>
  );
  return facilityContent;
});

const WarningsContent = observer(() => {
  const { eobListStore } = useStores();

  let warningContent = eobListStore?.selected?.showMissingDataWarning === true && <InlineWarning text={'Some details of this EOB are not viewable at this time.'} />;

  let currencyContent = !!eobListStore?.selected?.showForeignCurrencyDataWarningPerEOB === true && <InlineWarning text={'This EOB contains mixed currencies.'} />;

  let currencyUnknownContent = !!eobListStore?.selected?.showUnknownCurrencyDataWarningPerEOB === true && <InlineWarning text={'This EOB contains unknown currency.'} />;

  return (
    <div>
      {warningContent}
      {currencyContent}
      {currencyUnknownContent}
    </div>
  );
});

const EobCareDetails = () => {
  const { themeStore, responsiveStore } = useStores();
  //implement get data from store/api according to the eob the user select on the screen
  //for now its conts

  return (
    <div css={styles.headlineContainer}>
      {!responsiveStore.isMobile && <div css={styles.headline}>Explanation of Benefits</div>}

      <div css={styles.headline2(themeStore.currentTheme)}>This is not a bill</div>

      <WarningsContent />

      <div css={[styles.plainTextHighlighted, { paddingTop: '1.8rem' }]}>
        <ServicesData />
      </div>

      <ReferenceLine />
      <div css={[styles.careContainer]}>
        <div css={[styles.practitionerInfoContainer, styles.facilityInfoContainer]}>
          <div css={styles.plainText(globalStyles.COLOR.slateGrey)}>Facility</div>
          <FacilityContent />
        </div>
        <div css={styles.practitionerInfoContainer}>
          <div css={styles.plainText(globalStyles.COLOR.slateGrey)}>Practitioner</div>
          <PractitionerContent />
        </div>
      </div>
    </div>
  );
};

export default observer(EobCareDetails);
