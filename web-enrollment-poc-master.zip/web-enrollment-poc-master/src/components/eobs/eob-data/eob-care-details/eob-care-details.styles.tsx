/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const careContainer = css({
  // width: '100%',
  display: 'flex',
  justifyContent: 'start',
  flexWrap: 'wrap',
  flexDirection: 'row'
});

export const headlineContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'start',
  flexDirection: 'column'
});

export const headline = css({
  fontSize: '2.4rem',
  lineHeight: '3.4rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.charcoalGrey
});

export const headline2 = (theme: Preferences) =>
  css({
    fontSize: '1.8rem',
    lineHeight: '3rem',
    letterSpacing: '0',
    color: theme.colors.backgroundDark.published
  });

export const plainText = (color: string = globalStyles.COLOR.redPink) =>
  css({
    fontSize: '1.3rem',
    lineHeight: '1.8rem',
    letterSpacing: '0',
    color: color
  });

export const plainTextHighlighted = css({
  fontSize: '1.4rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold',
  verticalAlign: 'bottom'
});

export const unavailableText = css({
  fontSize: '1.2rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.coolGrey,
  fontStyle: 'italic',
  fontWeight: 'normal'
});

export const facilityInfoContainer = css({
  width: '20rem',
  marginRight: '2rem'
});

export const practitionerInfoContainer = css({ marginTop: '2rem' });
