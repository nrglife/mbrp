/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const careContainer = css({
  // width: '100%',
  display: 'flex',
  justifyContent: 'start',
  flexWrap: 'wrap',
  flexDirection: 'row'
});

export const headlineContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'start',
  flexDirection: 'column'
});

export const headline = css({
  fontSize: '2.4rem',
  lineHeight: '3.4rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.charcoalGrey
});

export const headline2 = (theme: Preferences) =>
  css({
    fontSize: '1.8rem',
    lineHeight: '3rem',
    letterSpacing: '0',
    color: theme.colors.backgroundDark.published
  });

export const plainText = (color: string = globalStyles.COLOR.redPink) =>
  css({
    fontSize: '1.3rem',
    lineHeight: '1.8rem',
    letterSpacing: '0',
    color: color
  });
export const plainTextHighlighted = css({
  fontSize: '1.4rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});

export const totalsContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'space-around',
  alignItems: 'center',
  flexWrap: 'wrap',
  maxWidth: '21.6rem',
  height: '14.3rem',
  flexDirection: 'column',
  padding: '1rem 0 1rem 0'
});

export const totalsContainerMobile = css({
  maxWidth: '35rem',
  minWidth: '27rem'
});

export const warningTotalsContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'space-around',
  alignItems: 'center',
  maxWidth: '21.6rem',
  minWidth: '18.3rem',
  height: '18.3rem',
  flexDirection: 'column'
});

export const coloredBorder = css({
  border: `solid .2rem ${globalStyles.COLOR.veryLightPink}`
});

export const totalsHeadline = css({
  fontSize: '1.8rem',
  lineHeight: '3.4rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  textAlign: 'center',
  fontWeight: 'bold'
});

export const totalsBalanse = (theme: Preferences) =>
  css({
    backgroundColor: `${theme.colors.actionLight.published}90`,
    width: '20.1rem',
    height: '6rem',
    paddingTop: '0.9rem'
  });

export const numbersHeadline = css({
  fontSize: '1.4rem',
  lineHeight: '1.6rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackThree,
  textAlign: 'center',
  verticalAlign: 'center'
});

export const numbersData = css({
  fontSize: '2rem',
  lineHeight: '3rem',
  letterSpacing: '0',
  textAlign: 'center',
  verticalAlign: 'center',
  color: globalStyles.COLOR.blackThree
});

export const totalsMissingText = css({
  fontSize: '1.4rem',
  fontStyle: 'italic',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.charcoalGrey,
  textAlign: 'center',
  verticalAlign: 'center'
});

export const warningIconStyle = css({ color: globalStyles.COLOR.battleshipGrey, width: '5.6rem', height: '5.6rem' });
