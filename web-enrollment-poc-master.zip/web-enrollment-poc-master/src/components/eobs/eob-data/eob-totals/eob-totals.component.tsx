/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../../stores/useStores';

//CommonServices
import { isValidAmount } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';

//styles
import * as styles from './eob-totals.styles';
import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';
import { AmountPreviewComponent } from 'components/eobs/amount-preview/amount-preview.component';

const EobTotals = () => {
  const { themeStore, eobListStore, responsiveStore } = useStores();
  const showTotals =
    isValidAmount(eobListStore.selected?.totalPrice?.amount, eobListStore.selected?.totalPrice?.isComplete, eobListStore.selected?.totalPrice?.isContainUnknownCurrency, eobListStore.selected?.isForeignCurrencyExist) ||
    isValidAmount(eobListStore.selected?.estimatedBalance?.amount, eobListStore.selected?.estimatedBalance?.isComplete, eobListStore.selected?.estimatedBalance?.isContainUnknownCurrency, eobListStore.selected?.isForeignCurrencyExist);

  const value = showTotals ? (
    <div css={[styles.totalsContainer, styles.coloredBorder, responsiveStore.isMobile && styles.totalsContainerMobile]}>
      <div>
        <div css={styles.numbersHeadline}>Total Price</div>
        <div css={styles.numbersData}>
          <AmountPreviewComponent 
            amount={eobListStore.selected?.totalPrice?.amount} 
            isComplete={eobListStore.selected?.totalPrice?.isComplete} 
            isContainUnknownCurrency={eobListStore.selected?.totalPrice?.isContainUnknownCurrency}
            isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}/>
        </div>
      </div>
      <div css={styles.totalsBalanse(themeStore.currentTheme)}>
        <div css={[styles.numbersHeadline, { fontWeight: 'bold' }]}>Your Balance</div>
        <div css={[styles.numbersData, { fontWeight: 'bold' }]}>
          <AmountPreviewComponent 
            amount={eobListStore.selected?.estimatedBalance?.amount} 
            isComplete={eobListStore.selected?.estimatedBalance?.isComplete} 
            isContainUnknownCurrency={eobListStore.selected?.estimatedBalance?.isContainUnknownCurrency}
            isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}/>
        </div>
      </div>
    </div>
  ) : (
    <div css={[styles.warningTotalsContainer, styles.coloredBorder, { padding: '3rem 2rem' }]}>
      <WarningTriangle css={styles.warningIconStyle} />
      <div css={styles.totalsMissingText}>
        <span>There was a problem processing the amounts for this EOB</span>
      </div>
    </div>
  );

  return value;
};

export default observer(EobTotals);
