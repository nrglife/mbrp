/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import EobTotals from './eob-totals/eob-totals.component';
import EobQuestions from './eob-questions/eob-questions.component';
import EobCareDetails from './eob-care-details/eob-care-details.component';
import EOBsServiceDetails from '../service-details/eobs-service-details.component';
//styles
import * as styles from './eob-data.styles';

const EOBData = () => {
  const { responsiveStore } = useStores();
  return (
    <div css={[styles.eobDataContainer, responsiveStore.isMobile && styles.eobDataContainerMobile]}>
      <div css={styles.eobDetailsContainer}>
        <div css={[styles.eobTotalsContainer, styles.eobCareDetailsContainer]}>
          <EobCareDetails />
        </div>
        <div css={[styles.eobTotalsContainer, responsiveStore.isMobile && styles.eobTotalsContainerMobile]}>
          <EobTotals />
        </div>
      </div>
      <EOBsServiceDetails />
      <EobQuestions />
    </div>
  );
};

export default observer(EOBData);
