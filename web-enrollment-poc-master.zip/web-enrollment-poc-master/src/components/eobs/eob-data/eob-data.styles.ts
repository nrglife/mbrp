/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const eobDataContainer = css({
  flex: '1 1 300px',
  display: 'flex',
  alignItems: 'left',
  flexDirection: 'column',
  background: 'white',
  boxShadow: `0 2px 4px 0 ${globalStyles.COLOR.black15}`,
  margin: '2.3rem',
  padding: '1.9rem',
  paddingTop: '1.7rem',
  minHeight: 0,
  overflowY: 'auto'
});

export const eobDataContainerMobile = css({
  margin: '0'
});

export const eobDetailsContainer = css({
  width: '100%',
  display: 'flex',
  justifyContent: 'start',
  alignItems: 'start',
  flexWrap: 'wrap',
  flexDirection: 'row',
  marginTop: '0.5rem'
});

export const eobCareDetailsContainer = css({
  marginRight: '1rem'
});

export const eobTotalsContainer = css({
  marginBottom: '1.7rem',
  display: 'flex',
  flex: 1,
  justifyContent: 'flex-end'
});

export const eobTotalsContainerMobile = css({
  justifyContent: 'center'
});
