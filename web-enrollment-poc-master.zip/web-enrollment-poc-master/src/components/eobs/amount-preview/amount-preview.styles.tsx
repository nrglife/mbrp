/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const codeStyle = (fontSize: number) =>
  css({
    fontSize: (fontSize / 10).toString() + 'rem'
  });

export const strikeThroughStyle = css({
  textDecoration: 'line-through',
  fontWeight: 'normal'
});

export const emptyAmountStyle = css({
  fontWeight: 'normal',
  color: globalStyles.COLOR.blackTwo
});
