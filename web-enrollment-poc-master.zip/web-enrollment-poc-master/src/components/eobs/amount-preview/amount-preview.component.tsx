import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

//CommonServices
import { isValidAmount, isEmptyString } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { CurrencyCodes, Money } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';
import { setNumberPreview } from '@healthcareapp/connected-health-common-services/dist/utilities/Money';

import * as styles from './amount-preview.styles';
import { useStores } from 'stores/useStores';

interface IAmountPreviewComponent {
  amount: Money | null | undefined;
  isComplete?: boolean;
  fontSize?: number;
  withMinus?: boolean;
  isStrikeThrough?: boolean;
  isContainUnknownCurrency?: boolean;
  isForeignCurrencyExist?: boolean;
}

export const AmountPreviewComponent: FC<IAmountPreviewComponent> =
  ({ amount, isComplete = true, fontSize = null, withMinus = false, isStrikeThrough = false, isContainUnknownCurrency = false, isForeignCurrencyExist = undefined }) => {

    const { eobListStore } = useStores();
    if (isForeignCurrencyExist === undefined)
      isForeignCurrencyExist = eobListStore?.selected?.isForeignCurrencyExist;
    
    if (!isValidAmount(amount, isComplete, isContainUnknownCurrency, isForeignCurrencyExist)) return <span css={styles.emptyAmountStyle}>{`$ —`}</span>;

    let minusAddition = withMinus === true ? `-` : ``;
    let amountValue = setNumberPreview(amount?.value);


    if (amount?.currency?.toUpperCase() === CurrencyCodes.USD ||
      (isEmptyString(amount?.currency) && !!isForeignCurrencyExist === false)) {
      return <span css={isStrikeThrough ? styles.strikeThroughStyle : null}>{`${minusAddition}$${amountValue}`}</span>;
    } else
      return (
        <span>
          <span css={isStrikeThrough ? styles.strikeThroughStyle : null}>{`${minusAddition}${amountValue}`}</span>{' '}
          <span css={fontSize != null ? styles.codeStyle(fontSize) : null}>{amount?.currency?.toUpperCase()} </span>
        </span>
      );
  };
