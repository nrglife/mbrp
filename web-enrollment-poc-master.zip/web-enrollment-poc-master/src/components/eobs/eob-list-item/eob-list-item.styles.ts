/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const container = css({
  display: 'flex',
  flexFlow: 'row wrap',
  justifyContent: 'space-between',
  alignItems: 'center',
  backgroundColor: 'white',
  paddingLeft: '25px',
  paddingRight: '6px',
  paddingTop: '13px',
  paddingBottom: '13px',
  position: 'relative',
  flex: '0 0 auto',
  cursor: 'pointer'
});

export const containerSeperator = css({
  marginLeft: '25px',
  borderBottom: `solid 1px ${globalStyles.COLOR.veryLightPinkFour}`
});

export const containerSeperatorMobile = css({
  marginLeft: '0'
});

export const selectedStyle = (theme: Preferences) => css({ position: 'absolute', left: '1px', right: '1px', top: '3px', bottom: '2px', border: `3px solid ${theme.colors.actionLight.published}` });

export const baseTextStyle = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: 1.43
});

export const dateTextStyle = css({
  fontSize: '1.2rem',
  color: globalStyles.COLOR.black
});

export const brandedFontColor = (theme: Preferences) => css({ color: theme.colors.actionDark.published });

export const leftSectionContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 2, marginRight: 10, width: '100%' });

export const totalBalanceTextStyle = css({ lineHeight: 1.29, color: globalStyles.COLOR.blackTwo });

export const practitionerNameTextStyle = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: 1.43,
  paddingBottom: 1
});

export const patientNameTextStyle = css({
  fontSize: '1.2rem',
  lineHeight: 1.3
});

export const totalBalanceContainerStyle = css({ display: 'flex', flexFlow: 'row nowrap', alignItems: 'flex' });

export const iconStyle = css({ marginTop: '-0.2rem', marginLeft: '0.5rem', color: '#9BA1A9', transform: 'rotate(180deg)' });

export const unavailableText = css({
  fontSize: '1.2rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.coolGrey,
  fontStyle: 'italic'
});

export const warningIconStyle = css({ color: globalStyles.COLOR.charcoalGrey, width: '2rem', height: '2rem' });
