//CommonServices
import { formatDate, isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import { isValidAmount } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/helper';
import { CalculatedAmount, Period } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';

import { FC, Fragment, useMemo } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { ReactComponent as ChevronIcon } from 'assets/icons/icons-interactions-next.svg';
import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';
import * as styles from './eob-list-item.styles';
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';

import { AmountPreviewComponent } from '../amount-preview/amount-preview.component';

interface IEOBListItem {
  isSelected?: boolean;
  patientName: string | null | undefined;
  practitionerName: string | null | undefined;
  date: Period | string | undefined | null;
  estimatedBalance: CalculatedAmount | undefined | null;
  isForeignCurrencyExist?: boolean;
  onClick: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}

export const EOBListItem: FC<IEOBListItem> = observer(({ patientName, practitionerName, date = '', estimatedBalance, onClick, isSelected = false, isForeignCurrencyExist = false }) => {
  const { themeStore, responsiveStore } = useStores();
  const formattedDate: string | null = useMemo(() => {
    if (typeof date === 'string') {
      return isValidDate(date) ? formatDate(date) : null;
    }
    if (typeof date === 'object') {
      if (!isValidDate(date?.start) && !isValidDate(date?.end)) return '';
      if (!isValidDate(date?.start)) {
        // return end date because there is no start date
        return `${formatDate(date?.end)}`;
      }
      if (!isValidDate(date?.end)) {
        // return start date because there is no end date
        return `${formatDate(date?.start)}`;
      }
      // return BOTH end date and start date
      if (formatDate(date?.start) === formatDate(date?.end)) {
        return `${formatDate(date?.start)}`;
      }
      return `${formatDate(date?.start)} - ${formatDate(date?.end)}`;
    }

    return null;
  }, [date]);

  const setPractitioner = () => {
    const practitionerExists = practitionerName != null && practitionerName !== '';

    return practitionerExists ? (
      <p css={[styles.baseTextStyle, styles.practitionerNameTextStyle, styles.brandedFontColor(themeStore.currentTheme)]}>{`${practitionerName}`}</p>
    ) : (
      <p css={styles.unavailableText}>{'Practitioner unavailable'}</p>
    );
  };

  return (
    <Fragment>
      <div css={styles.container} onClick={onClick}>
        {isSelected ? <div css={styles.selectedStyle(themeStore.currentTheme)} /> : null}
        <div css={{ display: 'flex', width: '100%' }}>
          <div>{!!formattedDate ? <p css={[styles.baseTextStyle, styles.dateTextStyle]}>{formattedDate}</p> : null}</div>
        </div>
        <div css={{ display: 'flex', width: '100%', alignItems: 'center' }}>
          <div css={[styles.leftSectionContainerStyle, !!!patientName ? { marginTop: '0.3rem', marginBottom: '1.2rem' } : {}]}>
            {setPractitioner()}
            <p css={(styles.baseTextStyle, styles.patientNameTextStyle)}>{patientName ? `for ${patientName}` : ''}</p>
          </div>
          <div css={[styles.totalBalanceContainerStyle, formattedDate ? { marginTop: '-1.7rem' } : {}]}>
            {!isValidAmount(estimatedBalance?.amount, estimatedBalance?.isComplete, estimatedBalance?.isContainUnknownCurrency, isForeignCurrencyExist) && <WarningTriangle css={[styles.warningIconStyle, { marginRight: '1.2rem' }]} />}
            <p css={[styles.baseTextStyle, styles.totalBalanceTextStyle]}>
              <AmountPreviewComponent 
                amount={estimatedBalance?.amount} 
                isComplete={estimatedBalance?.isComplete} 
                isContainUnknownCurrency={estimatedBalance?.isContainUnknownCurrency}
                isForeignCurrencyExist={isForeignCurrencyExist}
                fontSize={10} />
            </p>
            <ChevronIcon css={styles.iconStyle} />
          </div>
        </div>
      </div>
      <div css={[styles.containerSeperator, responsiveStore.isMobile && styles.containerSeperatorMobile]} />
    </Fragment>
  );
});
