/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

export const eobsTableContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 1, maxWidth: '900px', marginRight: 'auto' });

export const emptyEOBListContainer = css({
  display: 'flex',
  flex: '1 0 auto',
  maxWidth: '900px',
  marginRight: 'auto',
  marginLeft: 'auto',
  justifyContent: 'center',
  marginTop: '269px',
  padding: '0 20px'
});
