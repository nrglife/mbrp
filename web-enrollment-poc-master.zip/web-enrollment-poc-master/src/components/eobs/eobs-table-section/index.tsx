import { FC, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
//developed
import EOBData from '../eob-data/eob-data.component';
import { useStores } from '../../../stores/useStores';
//styles
import * as styles from './eobs-table-section.styles';
import { Error } from 'components/error';
import { ReactComponent as EmptyEOBListIcon } from '../../../assets/icons/empty-eob-list-thin.svg';

interface EOBsTableSectionProps {}

const EOBsTableSection: FC<EOBsTableSectionProps> = () => {
  const { eobListStore } = useStores();
  const { t } = useTranslation('translation');

  return !!eobListStore.eobs && eobListStore.eobs.length > 0 ? (
    <div css={styles.eobsTableContainerStyle}>
      <EOBData />
    </div>
  ) : (
    <Error errorText={t(LocaleKeys.errors.no_eobs_to_show_yet)} Image={EmptyEOBListIcon}></Error>
  );
};

export default observer(EOBsTableSection);
