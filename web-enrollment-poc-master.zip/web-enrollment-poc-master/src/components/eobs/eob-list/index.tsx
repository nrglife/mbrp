export { EobListComponent } from './eob-list.component';

export const STATIC_EOBS: any[] = [
  {
    numberOfDocs: 9999,
    date: '2020-12-27T21:21:31',
    price: 900
  },
  {
    numberOfDocs: 10,
    date: '2010-12-27T21:21:31',
    price: 100
  },
  {
    numberOfDocs: 3,
    date: '2010-12-28T21:21:31',
    price: 200
  },
  {
    numberOfDocs: 5,
    date: '2010-11-27T21:21:31',
    price: 300
  },
  {
    numberOfDocs: 4,
    date: '2014-11-27T21:21:31',
    price: 400
  },
  {
    numberOfDocs: 7,
    date: '2014-11-30T21:21:31',
    price: 500
  },
  {
    numberOfDocs: 3,
    date: '2011-11-27T21:21:31',
    price: 600
  },
  {
    numberOfDocs: 2,
    date: '2012-11-27T21:21:31',
    price: 700
  },
  {
    numberOfDocs: 7,
    date: '2015-01-27T21:21:31',
    price: 800
  },
  {
    numberOfDocs: 4,
    date: '2016-11-27T21:21:31',
    price: 900
  },
  {
    numberOfDocs: 2,
    date: '2017-07-27T21:21:31',
    price: 1000
  },
  {
    numberOfDocs: 3,
    date: '2015-11-27T21:21:31',
    price: 1100
  },
  {
    numberOfDocs: 4,
    date: '2010-11-27T21:21:31',
    price: 1200
  },
  {
    numberOfDocs: 4,
    date: '2015-06-27T21:21:31',
    price: 1300
  },
  {
    numberOfDocs: 4,
    date: '2010-12-27T21:21:31',
    price: 1400
  },
  {
    numberOfDocs: 4,
    date: '2010-10-27T21:21:31',
    price: 1500
  },
  {
    numberOfDocs: 4,
    date: '2010-11-27T21:21:31',
    price: 1600
  }
];
