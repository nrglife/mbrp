/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const container = css({
  display: 'flex',
  flex: '1',
  flexFlow: 'column nowrap',
  backgroundColor: 'white'
  //marginTop: '8px'
});

export const boxShadow = css({
  // boxShadow: '0 2px 4px 0 rgba(0,0,0,0.15)',
  // border: `solid 1px ${globalStyles.COLOR.veryLightPinkFour}`
});

export const mainHeaderContainer = css({ flexFlow: 'column nowrap', paddingLeft: '28px', paddingRight: '18px', paddingTop: '17px', paddingBottom: '5px' });

export const headerContainer = css({
  display: 'flex',
  flexFlow: 'row nowrap',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: '12px'
});

export const activeBackgroundLight = (theme: Preferences) =>
  css({
    backgroundColor: theme.colors.backgroundLight.published
  });

export const mainHeaderContainerTextStyle = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.6rem',
  fontWeight: 400,
  lineHeight: 1.25
});

export const headerTextStyle = css({ fontSize: '1.3rem', fontWeight: 400, lineHeight: 1.38 });

export const eobListContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: '1 0 300px', overflowY: 'auto', backgroundColor: 'white' });

export const loadMoreEobsErrorDiv = css({ marginTop: '1rem', marginLeft: '1.5rem', marginBottom: '3rem' });
