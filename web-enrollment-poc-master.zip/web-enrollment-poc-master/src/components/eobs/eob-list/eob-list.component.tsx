import { FC } from 'react';
import { observer } from 'mobx-react';
/** @jsxImportSource @emotion/core */
import { useHistory } from 'react-router-dom';
import { globalStyles } from 'styles/global.styles';
import { useStores } from '../../../stores/useStores';
import { EOBStoreType } from 'inversify.config';
import { EOBListItem } from '../eob-list-item';
import InfiniteScroll from 'react-infinite-scroller';
import * as styles from './eob-list.styles';
import Loader from 'components/general/loader/loader.component';
import HealthProfileTryAgainComponent from 'components/general/try-again/try-again.component';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

interface IEobListComponent {
  list?: EOBStoreType[];
}

export const EobListComponent: FC<IEobListComponent> = observer(({ list = [] }) => {
  const history = useHistory();
  const { themeStore, eobListStore, responsiveStore } = useStores();
  const { getPath } = useRouteUtils();

  //const [selectedItem, setSelectedItem] = useState('');

  const onClick = (eobStore: EOBStoreType) => {
    eobListStore.setSelectedEOB(eobStore);

    const eobDetailsUrl = getPath(RouteName.eobDetails).replace('/:eobId', '');
    responsiveStore.isMobile && history.push(`${eobDetailsUrl}/${eobStore.id}`);
  };

  const loadEobsNextPage = async (numberOfRetries: number, isRetry: boolean) => {
    const selectedItem = eobListStore.selected;
    await eobListStore.getNextPage({ numberOfRetries: numberOfRetries }, isRetry);
    eobListStore.setSelectedEOB(selectedItem);
  };

  const onRetryLoadMoreEobs = () => {
    loadEobsNextPage(1, true);
  };

  return (
    <>
      {eobListStore.eobs && eobListStore.eobs.length > 0 && (
        <div css={[styles.container, styles.boxShadow]}>
          <div css={[styles.mainHeaderContainer, styles.activeBackgroundLight(themeStore.currentTheme)]}>
            <p css={styles.mainHeaderContainerTextStyle}>Showing All EOBs</p>
            <div css={[styles.headerContainer]}>
              <p css={[styles.headerTextStyle, { color: globalStyles.COLOR.blackTwo }]}>Service Dates</p>
              <p css={[styles.headerTextStyle, { color: globalStyles.COLOR.slateGrey }]}>Your Balance</p>
            </div>
          </div>
          <div css={styles.eobListContainerStyle}>
            <InfiniteScroll
              pageStart={0}
              loadMore={async () => {
                loadEobsNextPage(2, false);
              }}
              hasMore={eobListStore.nextPageKey !== null}
              loader={
                <div key={0}>
                  {eobListStore.nextPageStatus === ReqStatus.LOADING && (
                    <Loader
                      color={themeStore.currentTheme.colors.actionMedium.published}
                      position={'inline'}
                      loading={true}
                      height={'80px'}
                      style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
                      key={1}
                    />
                  )}
                  {eobListStore.nextPageStatus === ReqStatus.ERROR && (
                    <div key={2} css={styles.loadMoreEobsErrorDiv}>
                      <HealthProfileTryAgainComponent onTryAgain={async () => await onRetryLoadMoreEobs()}></HealthProfileTryAgainComponent>
                    </div>
                  )}
                </div>
              }
              useWindow={false}>
              {eobListStore.eobs.map((eobStoreObject: EOBStoreType, index: number) => {
                const date = eobStoreObject.EOBDate;
                const patientName = eobStoreObject.patientName;
                const practitionerName = eobStoreObject.performingPractitionerFullName;

                return (
                  <EOBListItem
                    key={eobStoreObject.uuid}
                    date={date}
                    patientName={patientName}
                    practitionerName={practitionerName}
                    estimatedBalance={eobStoreObject.estimatedBalance}
                    isSelected={eobListStore.selected?.uuid === eobStoreObject.uuid && !responsiveStore.isMobile}
                    isForeignCurrencyExist={eobStoreObject.isForeignCurrencyExist}
                    onClick={() => onClick(eobStoreObject)}
                  />
                );
              })}
            </InfiniteScroll>
            <div css={{ paddingBottom: '0.1rem' }} />
          </div>
        </div>
      )}
    </>
  );
});
