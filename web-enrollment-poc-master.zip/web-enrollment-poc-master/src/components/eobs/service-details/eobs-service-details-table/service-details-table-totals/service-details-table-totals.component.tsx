import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//CommonServices
import { ServicesItem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
//developed
import { useStores } from '../../../../../stores/useStores';
import { AmountPreviewComponent } from 'components/eobs/amount-preview/amount-preview.component';
//consta
import { tableHeaders } from '../service-details-table-headers/service-details-table-headers.component';
//styles
import * as tableStyles from '../eobs-service-details-table.styles';
import * as styles from './service-details-table-totals.styles';
import { Money } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/types';

interface ServiceDetailsTableTotalsProps {
  serviceDetails: ServicesItem[] | null | undefined;
}

const ServiceDetailsTableTotals: FC<ServiceDetailsTableTotalsProps> = ({ serviceDetails }) => {
  const { themeStore, eobListStore, responsiveStore } = useStores();

  return !responsiveStore.isMobile ? (
    <div css={[tableStyles.row, styles.totalsContainer]}>
      <div css={[tableStyles.col_first, styles.totalDescriptionStyle]}>Total:</div>
      <div css={tableStyles.col_second}>
        <AmountPreviewComponent 
        amount={eobListStore.selected?.totalPrice?.amount} 
        isComplete={eobListStore.selected?.totalPrice?.isComplete} 
        isContainUnknownCurrency={eobListStore.selected?.totalPrice?.isContainUnknownCurrency}
        isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
        fontSize={10} />
      </div>
      <div css={[tableStyles.col, tableStyles.col_extraPaddingRight]}>
        <AmountPreviewComponent
          amount={eobListStore.selected?.servicesTotalInsurancePaid?.amount}
          isComplete={eobListStore.selected?.servicesTotalInsurancePaid?.isComplete}
          isContainUnknownCurrency={eobListStore.selected?.servicesTotalInsurancePaid?.isContainUnknownCurrency}
          isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
          withMinus={true}
          fontSize={10}
        />
      </div>
      <div css={[tableStyles.col, styles.activeBackground(themeStore.currentTheme), tableStyles.col_last_extraPaddingRight]}>
        <AmountPreviewComponent 
          amount={eobListStore.selected?.estimatedBalance?.amount} 
          isComplete={eobListStore.selected?.estimatedBalance?.isComplete} 
          isContainUnknownCurrency={eobListStore.selected?.estimatedBalance?.isContainUnknownCurrency}
          isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
          fontSize={10} /> 
      </div>
    </div>
  ) : (
    <div css={styles.totalsContainerMobileView}>
      <div>Total</div>
      <div css={styles.totalsInfoRow}>
        <div css={styles.normalHeader}>{tableHeaders[1]}</div>
        <div css={styles.extraPaddingRight}>
          <AmountPreviewComponent 
            amount={eobListStore.selected?.totalPrice?.amount} 
            isComplete={eobListStore.selected?.totalPrice?.isComplete} 
            isContainUnknownCurrency={eobListStore.selected?.totalPrice?.isContainUnknownCurrency}
            isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
            fontSize={10} />
        </div>
      </div>
      <div css={styles.totalsInfoRow}>
        <div css={styles.normalHeader}>{tableHeaders[2]}</div>
        <div css={styles.extraPaddingRight}>
          <AmountPreviewComponent
            amount={eobListStore.selected?.servicesTotalInsurancePaid?.amount}
            isComplete={eobListStore.selected?.servicesTotalInsurancePaid?.isComplete}
            isContainUnknownCurrency={eobListStore.selected?.servicesTotalInsurancePaid?.isContainUnknownCurrency}
            isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
            withMinus={true}
            fontSize={10}
          />
        </div>
      </div>
      <div css={styles.totalsInfoRow}>
        <div>{tableHeaders[3]}</div>
        <div css={[tableStyles.col, styles.activeBackground(themeStore.currentTheme), styles.estimatedBalancContainer]}>
          <AmountPreviewComponent 
            amount={eobListStore.selected?.estimatedBalance?.amount} 
            isComplete={eobListStore.selected?.estimatedBalance?.isComplete} 
            isContainUnknownCurrency={eobListStore.selected?.estimatedBalance?.isContainUnknownCurrency}
            isForeignCurrencyExist={eobListStore.selected?.isForeignCurrencyExist}
            fontSize={10} />
        </div>
      </div>
    </div>
  );
};

export default observer(ServiceDetailsTableTotals);
