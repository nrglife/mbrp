/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';
import { Preferences } from '../../../../../stores/ThemeStore';

export const activeBackground = (theme: Preferences) =>
  css({
    background: `${theme.colors.actionLight.published}90`
  });

export const totalsContainer = css({
  marginTop: '1.2rem',
  fontSize: '1.4rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});

export const totalDescriptionStyle = css({
  textAlign: 'end',
  paddingLeft: '4rem',
  '@media (max-width: 1300px)': {
    padding: '1rem'
  }
});

export const totalsContainerMobileView = css({
  padding: '1rem 1rem 1rem 2rem',
  fontSize: '1.4rem',
  lineHeight: '2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});

export const totalsInfoRow = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'space-between',
  alignItems: 'center'
});

export const normalHeader = css({
  fontWeight: 'normal',
  color: globalStyles.COLOR.slateGrey
});

export const extraPaddingRight = css({ paddingRight: '.5rem' });

export const estimatedBalancContainer = css({
  maxWidth: '10rem',
  padding: '.5rem',
  marginTop: '.5rem'
});
