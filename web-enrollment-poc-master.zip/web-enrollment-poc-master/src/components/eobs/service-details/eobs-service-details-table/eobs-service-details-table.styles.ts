/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';

export const arrowIconSize = '1.7rem';
export const serviceDetailWidth = '38%';

export const eobsTableContainer = css({
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'column',
  width: '100%'
});

export const eobsTableRowsContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  width: '100%'
  //table scroll behavior
  // overflowY: 'auto',
  // maxHeight: '24rem'
});

//default table structure
const default_pading = css({ padding: '1rem' });
//table structure - row
export const row = css({ width: '100%', display: 'flex' });
//table structure - columns
export const col = css([default_pading, { textAlign: 'right', maxWidth: '13rem', flex: 1 }]);
export const col_first = css([default_pading, { flex: 1 }]);
export const col_second = css([col, { maxWidth: '10.5rem', flex: 1 }]);
export const col_extraPaddingRight = css({
  paddingRight: '2rem',
  '@media (max-width: 1300px)': {
    paddingRight: '1rem'
  }
});

export const col_last_extraPaddingRight = css({
  paddingRight: '2.8rem',
  '@media (max-width: 1300px)': {
    paddingRight: '1.5rem',
    maxWidth: '10rem'
  }
});
