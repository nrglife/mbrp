import { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//CommonServices
import { ServicesItem } from '@healthcareapp/connected-health-common-services/dist/utilities/fhir/eob-types';
//developed
import { AmountPreviewComponent } from 'components/eobs/amount-preview/amount-preview.component';
import { useStores } from '../../../../../stores/useStores';
//consts
import { tableHeaders } from '../service-details-table-headers/service-details-table-headers.component';
//styles
import * as tableStyles from '../eobs-service-details-table.styles';
import * as styles from './service-details-table-row.styles';

interface ServiceDetailsTableRowProps {
  data: ServicesItem;
}

const ServiceDetailsTableRow: FC<ServiceDetailsTableRowProps> = ({ data }) => {
  const { responsiveStore } = useStores();
  const { name, date, memberPrice, insurancePaid, estimatedBalance } = data;
  const serviceNameExists = name != null && name !== '';
  const serviceDateExists = date != null && date !== '';
  //check serviceDetails
  return (
    <Fragment>
      <div css={[tableStyles.row, styles.contentContainer]}>
        <div css={[tableStyles.col_first, styles.descriptionContainer]}>
          {serviceNameExists ? <div css={styles.name}>{name}</div> : <div css={styles.unavailable}>{`Service name unavailable`}</div>}
          {serviceDateExists ? <div css={styles.date}>{date}</div> : <div css={styles.unavailable}>{`Service date unavailable`}</div>}
        </div>
        {/* web section of memberPrice data */}
        {!responsiveStore.isMobile && (
          <div css={tableStyles.col_second}>
            <AmountPreviewComponent amount={memberPrice} fontSize={10} />
          </div>
        )}
        {/* web section of insurancePaid data */}
        {!responsiveStore.isMobile && (
          <div css={[tableStyles.col, tableStyles.col_extraPaddingRight]}>
            <AmountPreviewComponent amount={insurancePaid} fontSize={10} withMinus={true} />
          </div>
        )}
        <div css={[tableStyles.col, styles.estimatedBalance, tableStyles.col_last_extraPaddingRight]}>
          <AmountPreviewComponent 
            amount={estimatedBalance} fontSize={10} />
        </div>
      </div>
      {/* mobile section of insurancePaid and memberPrice data */}
      {responsiveStore.isMobile && (
        <div css={[styles.dataMobileViewContainer]}>
          <div css={[styles.dataMobileViewInfoRow]}>
            <div css={styles.date}>{tableHeaders[1]}</div>
            <AmountPreviewComponent amount={memberPrice} />
          </div>
          <div css={[styles.dataMobileViewInfoRow]}>
            <div css={styles.date}>{tableHeaders[2]}</div>
            <AmountPreviewComponent amount={insurancePaid} withMinus={true} />
          </div>
        </div>
      )}
      <div css={styles.separationBorder} />
    </Fragment>
  );
};

export default observer(ServiceDetailsTableRow);
