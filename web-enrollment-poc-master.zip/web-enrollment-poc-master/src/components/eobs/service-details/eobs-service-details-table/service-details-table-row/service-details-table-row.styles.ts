/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';
import { Preferences } from '../../../../../stores/ThemeStore';

export const activeBackground = (theme: Preferences) =>
  css({
    background: `${theme.colors.actionLight.published}90`
  });

export const contentContainer = css([
  {
    flexWrap: 'wrap',
    fontSize: '1.4rem',
    lineHeight: '2rem',
    letterSpacing: '0',
    color: globalStyles.COLOR.blackTwo,
    margin: '1rem 0'
  }
]);

export const descriptionContainer = css({
  paddingLeft: '4rem',
  '@media (max-width: 1300px)': {
    paddingLeft: '2rem'
  }
});

export const name = css({
  color: globalStyles.COLOR.blackTwo,
  fontSize: '1.4rem',
  lineHeight: '2rem',
  letterSpacing: '0'
});

export const date = css({
  color: globalStyles.COLOR.slateGrey,
  fontSize: '1.3rem',
  lineHeight: '1.8rem'
});

export const unavailable = css({
  color: globalStyles.COLOR.coolGrey,
  fontSize: '1.2rem',
  lineHeight: '2rem',
  fontStyle: 'italic',
  letterSpacing: '0'
});

export const estimatedBalance = css({
  fontWeight: 'bold'
});

export const separationBorder = css({
  width: '100%',
  borderBottom: `.1rem solid ${globalStyles.COLOR.veryLightPink}`
});

export const dataMobileViewContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  margin: '0 5rem',
  padding: '2rem 0',
  fontSize: '14px',
  borderTop: `.1rem solid ${globalStyles.COLOR.veryLightPink}`
});

export const dataMobileViewInfoRow = css({
  display: 'flex',
  justifyContent: 'space-between'
});
