/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';
import { Preferences } from '../../../../../stores/ThemeStore';

export const eobsHeaderContainer = css({
  height: '4.8rem',
  fontSize: '1.3rem',
  lineHeight: '1.5rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.steelGreyThree
});

export const defaultBackgroundColor = (theme: Preferences) => css({ background: theme.colors.backgroundMedium.published });

export const eobsHeader_firstHeader = css({
  display: 'flex',
  alignItems: 'center',
  paddingLeft: '2rem'
});

export const eobsHeader_basicStyle = css({
  flexDirection: 'column'
});

export const eobsHeader_black = css({
  color: globalStyles.COLOR.blackTwo
});

export const eobsHeader_lastHeader = (theme: Preferences) =>
  css({
    background: `${theme.colors.actionLight.published}90`,
    color: globalStyles.COLOR.blackTwo,
    fontWeight: 'bold',
    borderLeft: '.1rem solid white',
    justifyContent: 'center'
  });
