/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../../../stores/useStores';
//styles
import * as tableStyles from '../eobs-service-details-table.styles';
import * as styles from './service-details-table-headers.styles';

export const tableHeaders = ['Description', 'Total Price', 'Insurance Paid', 'Your Balance'];

const ServiceDetailsTableHeaders = () => {
  const { themeStore, responsiveStore } = useStores();

  return (
    <div css={[tableStyles.row, styles.eobsHeaderContainer]}>
      <div css={[tableStyles.col_first, styles.eobsHeader_firstHeader, styles.defaultBackgroundColor(themeStore.currentTheme)]}>
        <div>{tableHeaders[0]}</div>
      </div>
      {!responsiveStore.isMobile && (
        <div css={[tableStyles.col_second, styles.eobsHeader_basicStyle, styles.defaultBackgroundColor(themeStore.currentTheme), styles.eobsHeader_black]}>
          <div>{tableHeaders[1].split(' ')[0]}</div>
          <div>{tableHeaders[1].split(' ')[1]}</div>
        </div>
      )}
      {!responsiveStore.isMobile && (
        <div css={[tableStyles.col, tableStyles.col_extraPaddingRight, styles.eobsHeader_basicStyle, styles.defaultBackgroundColor(themeStore.currentTheme), styles.eobsHeader_black]}>
          <div>{tableHeaders[2].split(' ')[0]}</div>
          <div>{tableHeaders[2].split(' ')[1]}</div>
        </div>
      )}
      <div css={[tableStyles.col, styles.eobsHeader_basicStyle, styles.eobsHeader_lastHeader(themeStore.currentTheme), tableStyles.col_last_extraPaddingRight]}>
        <div>{tableHeaders[3].split(' ')[0]}</div>
        <div>{tableHeaders[3].split(' ')[1]}</div>
      </div>
    </div>
  );
};

export default observer(ServiceDetailsTableHeaders);
