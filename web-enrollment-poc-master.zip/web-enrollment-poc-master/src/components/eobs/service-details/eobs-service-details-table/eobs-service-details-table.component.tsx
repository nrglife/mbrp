import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../../stores/useStores';
import ServiceDetailsTableRow from './service-details-table-row/service-details-table-row.component';
import ServiceDetailsTableHeaders from './service-details-table-headers/service-details-table-headers.component';
import ServiceDetailsTableTotals from './service-details-table-totals/service-details-table-totals.component';

//styles
import * as styles from './eobs-service-details-table.styles';

const ServiceDetailsTable: FC = () => {
  const { eobListStore } = useStores();

  return (
    <div css={[styles.eobsTableContainer]}>
      {/* table header */}
      <ServiceDetailsTableHeaders />
      {/* table rows */}
      <div css={styles.eobsTableRowsContainer}>
        {eobListStore.selected?.servicesLevelData.map((data, i) => (
          <ServiceDetailsTableRow data={data} key={i} />
        ))}
        <ServiceDetailsTableTotals serviceDetails={eobListStore.selected?.servicesLevelData} />
      </div>
    </div>
  );
};

export default observer(ServiceDetailsTable);
