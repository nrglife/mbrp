/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const arrowIconSize = '1.7rem';
export const serviceDetailWidth = '38%';

export const eobsServiceDetailsContainer = css({
  display: 'flex',
  flexFlow: 'column nowrap',
  width: '100%',
  color: globalStyles.COLOR.blackTwo
  // marginBottom: '2rem'
});

export const headlineContainer = css({
  display: 'flex',
  alignItems: 'center'
});

export const arrowIcon = css({
  color: globalStyles.COLOR.charcoalGrey,
  transform: 'rotate(-90deg)',
  width: arrowIconSize,
  height: arrowIconSize,
  '&:hover': {
    cursor: 'pointer'
  }
});

export const rotateArrowIcon = css({ transform: 'none' });

export const headline = css({
  marginLeft: '.3rem',
  fontSize: '1.8rem',
  letterSpacing: '0',
  lineHeight: '3rem'
});

export const separationBorder = (theme: Preferences) =>
  css({
    borderBottom: `solid .3rem ${theme.colors.backgroundMedium.published}`
  });
