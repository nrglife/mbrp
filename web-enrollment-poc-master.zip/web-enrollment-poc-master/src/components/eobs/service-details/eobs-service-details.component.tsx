import { useEffect, FC, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../stores/useStores';
import ServiceDetailsTable from './eobs-service-details-table/eobs-service-details-table.component';
//styles
import * as styles from './eobs-service-details.styles';
import { ReactComponent as TriangleRightArrowIcon } from '../../../assets/icons/arrow-dropdown-down.svg';

const EOBsServiceDetails: FC = () => {
  const { themeStore, eobListStore } = useStores();
  const [visible, setVisible] = useState(eobListStore.selected ? eobListStore.selected.areServicesExist : false);

  useEffect(() => {
    setVisible(eobListStore.selected ? eobListStore.selected.areServicesExist : false);
  }, [eobListStore.selected]);

  return (
    <div css={[styles.eobsServiceDetailsContainer]}>
      <div css={styles.headlineContainer}>
        <div>
          <TriangleRightArrowIcon css={[styles.arrowIcon, visible && styles.rotateArrowIcon]} onClick={() => setVisible(!visible)} />
        </div>
        <span css={styles.headline}>Service Details</span>
      </div>
      {visible && <ServiceDetailsTable />}
      {!visible && <div css={[styles.separationBorder(themeStore.currentTheme)]} />}
    </div>
  );
};

export default observer(EOBsServiceDetails);
