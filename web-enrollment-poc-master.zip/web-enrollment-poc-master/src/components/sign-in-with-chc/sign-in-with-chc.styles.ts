/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';

export const container = css({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: globalStyles.COLOR.white,
  margin: '1rem 0',
  backgroundColor: globalStyles.COLOR.darkIndigo,
  padding: '1.8rem 2.5rem',
  borderRadius: '.3rem',
  '&:hover': {
    transition: 'all .3s',
    cursor: 'pointer',
    transform: 'scale(1.05)'
  }
});

export const text = css({
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: '0.5',
  marginRight: '2rem',
  fontWeight: 'bold'
});

export const imgStyle = css({ width: 84, height: 26 });
