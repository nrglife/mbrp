import { FC, ReactNode, useCallback } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles, CSSObject } from '@emotion/core';
//developed
import { useStores } from '../../stores/useStores';
//consts
import * as styles from './sign-in-with-chc.styles';
import chcLogiImg from '../../assets/icons/chc_red_white_logo_transparent.png';

interface SignInWithCHCProps {
  onClick?: ((event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void) | undefined;
  containerStyle?: SerializedStyles | CSSObject;
  ignoreDefaultContainerStyle?: boolean;
  textStyle?: SerializedStyles | CSSObject;
  ignoreDefaultTextStyle?: boolean;
  text?: string;
  showLogoImg?: boolean;
  logoImgSrc?: string;
  imgStyle?: SerializedStyles | CSSObject;
}

const SignInWithCHC: FC<SignInWithCHCProps> = ({ onClick, containerStyle, ignoreDefaultContainerStyle = false, text, textStyle, ignoreDefaultTextStyle = false, showLogoImg = true, logoImgSrc, imgStyle }) => {
  const _text: string = 'Sign In with';
  const { authStore } = useStores();

  const _signin = useCallback(() => {
    authStore.RedirectToCIAMLogin();
  }, [authStore]);

  return (
    <div css={[!ignoreDefaultContainerStyle && styles.container, containerStyle]} onClick={onClick || _signin}>
      <span css={[!ignoreDefaultTextStyle && styles.text, textStyle]}>{text || _text.toUpperCase()}</span>
      {showLogoImg && <img src={logoImgSrc || chcLogiImg} css={[styles.imgStyle, imgStyle]} />}
    </div>
  );
};

export default SignInWithCHC;
