import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles, CSSObject } from '@emotion/core';
//developed
import { useStores } from '../../stores/useStores';
//consts
import * as styles from './error-code.styles';

import { failureSource } from '@healthcareapp/connected-health-common-services';
import { observer } from 'mobx-react';

interface ErrorCodeProps {
  errorSource?: failureSource | failureSource[];
  ignoreNextPage?: boolean;
  componentStyle?: SerializedStyles;
}

const ErrorCode: FC<ErrorCodeProps> = ({ errorSource = null, ignoreNextPage = true, componentStyle = null }) => {
  const { errorStoreCommon, appConfigStore } = useStores();
  const latestError = errorStoreCommon.getLastFilteredError(errorSource, ignoreNextPage);

  if (appConfigStore.currentConfig.disableDisplayErrorCodes) {
    return null;
  }

  if (!latestError) {
    return null;
  }

  return (
    <div css={[styles.errorCodesAddition, componentStyle]}>
      {latestError.code ? `Code: ${(latestError?.source as string)?.toLowerCase()}-${latestError.code}` : `Code: ${(latestError?.source as string)?.toLowerCase()}`}
    </div>
  );
};

export default observer(ErrorCode);
