/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';

export const errorCodesAddition = css({
  fontSize: '1.2rem',
  color: globalStyles.COLOR.battleshipGrey,
  marginTop: '2rem'
});



