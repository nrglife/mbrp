import { FC } from 'react';
import * as React from 'react';

interface IFromProps {
  onSubmitHandler: (event: React.FormEvent<HTMLFormElement>) => void;
}
const Form: FC<IFromProps> = ({ children, onSubmitHandler }) => {
  return <form onSubmit={onSubmitHandler}>{children}</form>;
};

export default Form;
