import { ReactNode } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';
import { useStores } from '../../../stores/useStores';

import { observer } from 'mobx-react';

export interface ModalProps {
  open: boolean;
  onModalClose: () => void;
  children: ReactNode;
  center?: boolean;
  modalStyle?: object;
  overlayStyle?: object;
  closeButtonStyle?: object;
}

export default observer(({ children, modalStyle, overlayStyle, closeButtonStyle, onModalClose, ...props }: ModalProps) => {
  const { themeStore } = useStores();
  return (
    <Modal
      {...props}
      onClose={onModalClose}
      closeOnOverlayClick={false}
      styles={{
        modal: modalStyle && {
          fontFamily: themeStore.theme.font.published,
          ...modalStyle
        },
        overlay: { ...overlayStyle },
        closeButton: { ...closeButtonStyle }
      }}>
      {children}
    </Modal>
  );
});
