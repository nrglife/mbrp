/** @jsxImportSource @emotion/core */
import { css, jsx, keyframes } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

const rotateAnimation = keyframes(`
    0% {
      transform: rotate(0);
    }
    100% {
      transform: rotate(360deg);
    }
  `);


  export const globalSpinnerContainer = css({
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    position: 'fixed',
    width: '100vw',
    height: '100vh',
    zIndex: 5
 
});


export const centerContainer = css({
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    position: 'absolute',
    zIndex: 5
});

export const inlineContainer = css({
  display: 'inline'
});



export const spinner = css({
    animation: `${rotateAnimation} 1s infinite linear`,
    animationTimingFunction: 'liniar',
    maxWidth: '4.3rem',
    maxHeight: '4.3rem'
});