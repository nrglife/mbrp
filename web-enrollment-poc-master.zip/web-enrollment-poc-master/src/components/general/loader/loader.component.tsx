import { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
//third party
import { ReactComponent as Spinner } from '../../../assets/icons/loading-spinner.svg'
//styles
import { globalStyles } from '../../../styles/global.styles';
import * as styles from './loader.styles';

interface LoaderProps {
  loading?: boolean;
  width?: string;
  height?: string;
  color?: string;
  position?: 'inline' | 'global' | 'centered';
  backgroundColor?: string;
  style?: object;
}

const Loader: FC<LoaderProps> = ({ loading = false, width=defaults.width, height=defaults.height, 
  color = defaults.searchIcon.color, position = defaults.position, backgroundColor = defaults.background, style }) => {
  
  let containerDesign;
  if(position == 'global'){
    containerDesign = styles.globalSpinnerContainer;
  }
  else if(position == 'centered'){
    containerDesign = styles.centerContainer;
  }
  else if(position == 'inline'){
    containerDesign = styles.inlineContainer;
  }

  return loading ? (<div css={[{width: width, height: height, backgroundColor: backgroundColor},containerDesign, style]}>
    <Spinner color={color} css={[{width: defaults.width, height: defaults.height}, styles.spinner]}/>
  </div>) : null;
};

const defaults = {
  searchIcon: {
    color: globalStyles.COLOR.slateGrey
  },
  width: '100%',
  height: '100%',
  position: 'centered',
  background: 'transparent'
};


export default Loader;
