import { useEffect } from 'react';

/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

const payerContainer = css({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: '8%'
});

const payerTitle = css({
  textDecoration: 'underline',
  fontSize: '2.0rem',
  color: globalStyles.COLOR.tealBlue,
  lineHeight: '35px',
  letterSpacing: '-0.13px',
  textAlign: 'center',
  marginBottom: '5%'
});

const PayerLogo = props => {
  useEffect(() => {
    console.log('getting logo');
  }, []);

  return (
    <div css={payerContainer}>
      <h1 css={payerTitle}>{'Anthem'}</h1>
    </div>
  );
};

export { PayerLogo };
