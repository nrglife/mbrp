import React, { FC, useState, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';
//developed
import Loader from 'components/general/loader/loader.component';
//styles
import * as styles from './image-loader.styles';

enum ImageStatus {
  Loading = 'loading',
  Loaded = 'loaded',
  Failed = 'failed'
}

interface ImageLoaderProps {
  imageSource: string;
  loadingImageSource?: string;
  failureImageSource?: string;
  imageStyle?: SerializedStyles;
  imageLoadedStyle?: SerializedStyles;
  imageLoadingStyle?: SerializedStyles;
  imageFailedStyle?: SerializedStyles;
  loadingContainerStyle?: SerializedStyles;
  loaderPosition?: 'inline' | 'global' | 'centered';
  altText?: string;
  spinnerSize?: string;
  showSpinner?: boolean;
  spinnerColor?: string;
  onLoad?: () => void;
  onError?: () => void;
}

const ImageLoader: FC<ImageLoaderProps> = ({
  imageSource,
  loadingImageSource,
  failureImageSource,
  imageStyle,
  imageLoadedStyle,
  imageLoadingStyle,
  imageFailedStyle,
  loadingContainerStyle,
  loaderPosition = 'inline',
  altText = 'Image',
  spinnerSize = '4.3rem',
  showSpinner = true,
  spinnerColor = styles.loader.color,
  onLoad,
  onError
}) => {
  const [imageStatus, setImageStatus] = useState<ImageStatus>(ImageStatus.Loading);
  const imageRef = useRef<HTMLImageElement>(null);
  
  return (
    <>
      {imageStatus === ImageStatus.Loading && (
       <div css={[loadingContainerStyle, { position: 'relative' }]}>
          {loadingImageSource && (
            <img ref={imageRef} css={[imageStyle, imageLoadingStyle ]} src={loadingImageSource} onLoad={(e: any) => {}} onError={(e: any) => {}} alt={altText} />
          )}
          {showSpinner && (
            <div css={styles.spinnerContainer(spinnerSize)}>
              <Loader loading={imageStatus === ImageStatus.Loading} color={ spinnerColor} position={loaderPosition} />
            </div>
          )}
        </div>
      )}
      {imageStatus !== ImageStatus.Failed ? (
        <img
          ref={imageRef}
          css={[imageStyle, imageLoadedStyle, { opacity: '0'}]}
          src={imageSource}
          onLoad={(e: any) => {
            setImageStatus(ImageStatus.Loaded);
            if (imageRef.current) {
              imageRef.current.style.setProperty('opacity', '1');
              imageRef.current.style.setProperty('position', 'static');
            }

            if (onLoad) {
              onLoad();
            }
          }}
          onError={(e: any) => {
            if (onError) {
              onError();
            }
            setImageStatus(ImageStatus.Failed);
          }}
          alt={altText}
        />
      ) : (
        failureImageSource && <img css={[imageStyle, imageFailedStyle]} src={failureImageSource} alt={altText} />
      )}
    </>
  );
};

export default ImageLoader;
