import { css } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const spinnerContainer = (spinnerSize: string) =>
  css({
    width: spinnerSize,
    minHeight: spinnerSize,
    height: spinnerSize
  });

export const loader = {
  color: globalStyles.COLOR.slateGrey + '99' // 99 = 60% opacity
};
