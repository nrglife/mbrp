/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const btnStyle = (theme: Preferences) =>
  css({
    padding: '10px',
    margin: '10px 0',
    backgroundColor: theme.colors.actionLight.published,
    border: `1px solid transparent`,
    width: '100%',
    borderRadius: '4px',
    fontSize: '1.6rem',
    fontWeight: 'bold',
    fontStretch: 'normal',
    fontStyle: 'normal',
    lineHeight: 'normal',
    letterSpacing: '0.62px',
    textAlign: 'center',
    color: theme.colors.actionDark.published,
    position: 'relative',
    WebkitTransitionDuration: '0.4s' /* Safari */,
    transitionDuration: ' 0.4s',
    overflow: 'hidden',
    //cursor: 'pointer',

    '&:after': {
      content: 'none',
      background: 'white',
      display: 'block',
      position: 'absolute',
      paddingTop: '300%',
      paddingLeft: '350%',
      marginLeft: '-50% ',
      marginTop: '-120%',
      opacity: '0',
      transition: 'all 0.8s'
    },

    '&:active:after': {
      padding: 0,
      margin: 0,
      opacity: 1,
      transition: 'all 0.8s'
    },

    '&:disabled': {
      backgroundColor: globalStyles.COLOR.veryLightPink,
      border: `1px solid ${globalStyles.COLOR.veryLightPinkFour}`,
      color: globalStyles.COLOR.steelGrey
    },

    '&:enabled:hover': {
      transition: 'all .3s',
      cursor: 'pointer',
      transform: 'scale(1.05)'
    }
  });
