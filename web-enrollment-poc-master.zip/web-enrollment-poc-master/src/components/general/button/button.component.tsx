import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';

import * as styles from './button.styles';
import { useStores } from '../../../stores/useStores';

interface ButtonProps {
  onClick: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  isButtonDisabled?: boolean;
  text: string;
  buttonStyle?: SerializedStyles;
}

const Button: FC<ButtonProps> = ({ text, isButtonDisabled, onClick, buttonStyle }) => {
  const {
    themeStore: { currentTheme }
  } = useStores();

  return <button css={[styles.btnStyle(currentTheme), buttonStyle]} disabled={isButtonDisabled} onClick={onClick}>{`${text}`}</button>;
};

export default Button;
