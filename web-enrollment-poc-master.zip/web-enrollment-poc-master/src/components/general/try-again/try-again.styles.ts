/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const loadMoreErrorDiv = css({
  fontSize: '1.2rem',
  lineHeight: '1.8rem',
  color: globalStyles.COLOR.slateGrey
});
export const loadMoreTryAgainText = (color: string) => css({ fontSize: '1.1rem', color: color, fontWeight: 'bold', cursor: 'pointer' });
