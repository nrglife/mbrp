import React, { FC, Fragment, useEffect, useState } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
import { NavLink } from 'react-router-dom';
import moment from 'moment';
//developed
import { useStores } from 'stores/useStores';

//styles
import * as styles from './try-again.styles';
import { Error } from 'components/error';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import { toJS } from 'mobx';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { map } from 'lodash';

interface HealthProfileTryAgainProps {
  onTryAgain: () => {};
  errorSource?: failureSource;
}

const HealthProfileTryAgain: FC<HealthProfileTryAgainProps> = ({ onTryAgain, errorSource = null }) => {
  const { errorStoreCommon, themeStore } = useStores();

  const { t } = useTranslation('translation');

  return (
    <div css={styles.loadMoreErrorDiv} onClick={onTryAgain}>
      <span>{t(LocaleKeys.errors.something_went_wrong) + '.'}</span>
      <span css={styles.loadMoreTryAgainText(themeStore.currentTheme.colors.actionMedium.published)}> {' ' + t(LocaleKeys.errors.try_again)}</span>
      {errorSource && <span />}
    </div>
  );
};

export default observer(HealthProfileTryAgain);
