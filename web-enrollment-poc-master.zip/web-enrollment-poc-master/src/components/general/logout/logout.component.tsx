import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, InterpolationWithTheme, SerializedStyles } from '@emotion/core';
import { ReactComponent as SignOutIcon } from '../../../assets/icons/sign-out.svg';
import { styles as linkStyles } from '../nav-links-menu/components/menu-link.styles';
import { globalStyles } from '../../../styles/global.styles';

interface ILogoutProps {
  onClick?: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
  fillColor?: string;
  style?: SerializedStyles;
}

export const Logout: FC<ILogoutProps> = ({ onClick = () => {}, fillColor = 'white', style = {} }) => {
  return (
    <a onClick={onClick} css={[linkStyles.link, { cursor: 'pointer' }]}>
      <div css={[{ display: 'flex', flex: 1, paddingTop: 12, marginRight: 17, borderTop: `1px solid ${globalStyles.COLOR.darkBlueGrey}`, fontSize: '1.6rem' }, style]}>
        <div css={{ marginRight: '1rem' }}>
          <SignOutIcon css={{ color: fillColor }} />
        </div>
        <span css={{ fontSize: 'inherit', color: 'inherit' }}>Sign Out</span>
      </div>
    </a>
  );
};
