/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const arrowIconSize = '1.7rem';
export const checkmarkIconSize  = '1.4rem';

export const select = css({
    width: '130px',
    borderRadius: '3px',
    border: '1px solid ' + globalStyles.COLOR.veryLightPinkThree,
    textTransform: 'uppercase',
    fontSize: '1.1rem',
    padding: '.7rem 0.7rem',
    fontWeight: 'bold',
    color: globalStyles.COLOR.charcoalGreyFive,
    position: 'relative',
    cursor: 'pointer'
  });

  
export const optionsContainer = css({
  width: '130px',
  borderRadius: '3px',
  border: '1px solid ' + globalStyles.COLOR.veryLightPinkThree,
  backgroundColor: globalStyles.COLOR.white,
  position: 'absolute',
  top: '-1px',
  left: '-1px',
  zIndex: 1
});

export const arrowIcon = css({
  color: globalStyles.COLOR.charcoalGrey,
  width: arrowIconSize,
  height: arrowIconSize,
  position: 'absolute',
  right: '5px',
  top: '3px',
  zIndex: 2,
  '&:hover': {
    cursor: 'pointer'
  }
});

export const option = css({
  padding: '.8rem 1.5rem',
  display: 'flex',
  '&:hover': {
    backgroundColor: `${globalStyles.COLOR.wheat}80`
  }
})

export const checkFilledIcon = css({
  color: globalStyles.COLOR.charcoalGrey,
  width: '0.8rem',
  height: '0.8rem'
});


export const optionText = css({
  width: '80px' 
});