import { FC, useEffect, useRef } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';

import { ReactComponent as TriangleRightArrowIcon } from '../../../assets/icons/arrow-dropdown-down.svg';
import { ReactComponent as CheckEmptyIcon } from 'assets/icons/check-empty.svg';

import * as styles from './select.styles';
import { useStores } from '../../../stores/useStores';

interface SelectProps {
  onChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
  value: string | number;
  selectStyle?: SerializedStyles | null;
  options: any[];
}

const Select: FC<SelectProps> = ({ value, onChange, options, selectStyle }) => {

  const [visible, setVisible] = React.useState(false);
  const ref = useRef(null);

  const handleClickOutside = (event) => {
    
    if(ref && ref.current != null && (ref?.current as any).contains){
      if(!(ref.current as any).contains(event.target) && visible){
        setVisible(false);
      }
    }
  };

  const handleClickInside = (event) => {
    event.preventDefault();
    setVisible(true)
  }

  useEffect(() => {
      document.addEventListener('click', handleClickOutside, true);
      return () => {
          document.removeEventListener('click', handleClickOutside, true);
      };
  });
  
  const {themeStore: { currentTheme }} = useStores();

  const listItems = options.map(option => (
    <div css={styles.option} onClick={()=>onListItemClick(option.key)} key={option.key}>
      <div css={styles.optionText}>{option.value}</div> {(option.key === value ? <CheckEmptyIcon css={styles.checkFilledIcon} /> :'')}
    </div>
  ));

  const onListItemClick = (key) => {
    onChange(key);
    setVisible(false);
  }

  const selectedOption = options.find((option, index) => {
    return option.key === value;
  })


  return <div css={[styles.select, selectStyle]} ref={ref}>
        <div onClick={(event)=> handleClickInside(event)}>{selectedOption.value} <TriangleRightArrowIcon css={[styles.arrowIcon]} /></div>
        {visible ? (
        <div css={styles.optionsContainer}>
          {listItems}
        </div>):''}
        </div>
};

export interface SelectOption {
  key: string | number;
  value: string | number;
}

export default Select;
