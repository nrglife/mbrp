import { FC } from 'react';
/** @jsxImportSource @emotion/core */
//developed
import MenuLink from './components/menu-link.component';
//consts
import { styles } from './nav-links-menu.styles';
import { RouteName, screens } from 'stores/RoutesStore';
import { observer } from 'mobx-react';
import { useRouteUtils } from 'customHooks/useRouteUtils';

export type LinkType = {
  name: screens;
  to: RouteName;
  linkText: string;
  icon?: any;
  disable?: boolean;
  extra?: any;
  exact?: boolean;
  paddingLeftVal?: string;
  parent?: screens | null;
};

interface NavLinksMenuProps {
  links: LinkType[];
  linksContainerStyle?: object;
  linkStyle?: object;
  subLinkStyle?: object;
  parentLinkStyle?: object;
  activeLinkStyle?: object;
  activeSubLinkStyle?: object;
  disableLinkStyle?: object;
  disableWithOverlay?: boolean;
  showSubMenuLinks?: boolean;
  addAsPrimary?: boolean;
}

const NavLinksMenu: FC<NavLinksMenuProps> = ({
  links,
  linksContainerStyle,
  linkStyle,
  subLinkStyle,
  parentLinkStyle,
  activeLinkStyle,
  activeSubLinkStyle,
  disableLinkStyle,
  disableWithOverlay = false,
  showSubMenuLinks = false,
  addAsPrimary = false
}) => {
  const { isRouteAllowed } = useRouteUtils();
  const getSubMenuLinksForParent = (link: LinkType) => {
    const subMenu = links.filter(subLink => subLink.parent && subLink.parent === link.name && isRouteAllowed(subLink.to));
    return subMenu.length > 1 ? subMenu : [];
  };

  return (
    <div css={[styles.linksContainer, linksContainerStyle ? { ...linksContainerStyle } : {}]}>
      {links &&
        links
          ?.filter(link => !link.parent || addAsPrimary)
          ?.map((link, i) => (
            <MenuLink
              key={`link-${i}`}
              link={link}
              linkStyle={linkStyle}
              activeLinkStyle={activeLinkStyle}
              disableLinkStyle={disableLinkStyle}
              disableWithOverlay={disableWithOverlay}
              subMenuLinks={getSubMenuLinksForParent(link)}
              showSubMenuLinks={showSubMenuLinks}
              subLinkStyle={subLinkStyle}
              activeSubLinkStyle={activeSubLinkStyle}
              parentLinkStyle={parentLinkStyle}
            />
          ))}
    </div>
  );
};

export default observer(NavLinksMenu);
