/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const linksContainer = css({
  width: '100%',
  display: 'flex',
  flex: 1,
  flexDirection: 'column'
});

export const styles = {
  linksContainer
};
