import { FC, useState, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
//third party
import { NavLink } from 'react-router-dom';
//consts
import { ReactComponent as ArrowIcon } from '../../../../assets/icons/chevron-right.svg';
import { styles } from './menu-link.styles';
import { LinkType } from '../nav-links-menu.component';
import { observer } from 'mobx-react';
import { useRouteUtils } from 'customHooks/useRouteUtils';

interface MenuLinkProps {
  link: LinkType;
  subMenuLinks?: LinkType[];
  linkStyle?: object;
  subLinkStyle?: object;
  parentLinkStyle?: object;
  activeLinkStyle?: object;
  activeSubLinkStyle?: object;
  disableLinkStyle?: object;
  disableWithOverlay?: boolean;
  showSubMenuLinks?: boolean;
}

const MenuLink: FC<MenuLinkProps> = ({
  link,
  subMenuLinks = [],
  linkStyle,
  subLinkStyle,
  parentLinkStyle,
  activeLinkStyle,
  activeSubLinkStyle,
  disableLinkStyle,
  disableWithOverlay = false,
  showSubMenuLinks = false
}) => {
  const [isSubMenuOpened, setIsSubMenuOpened] = useState(false);
  const isParentMenuItem = showSubMenuLinks && subMenuLinks.length > 0;

  const { isRouteAllowed, getPath } = useRouteUtils();

  useEffect(() => {
    !showSubMenuLinks && isSubMenuOpened && setIsSubMenuOpened(false);
  }, [showSubMenuLinks]);

  return (
    <>
      {isRouteAllowed(link.to) && (
        <NavLink
          to={getPath(link.to)}
          css={[
            styles.link,
            (!isParentMenuItem || !parentLinkStyle) && linkStyle && { ...linkStyle },
            isParentMenuItem && parentLinkStyle && { ...parentLinkStyle },
            link.disable && (disableWithOverlay ? { background: 'rgba(255,255,255,.58)' } : { opacity: '0.30' }),
            link.disable && { ...styles.disable, ...disableLinkStyle },
            activeLinkStyle && { '&.active': { ...activeLinkStyle } }
          ]}
          exact={link.exact}
          key={`nav-links-menu-${link.to?.split('/').join().trim()}`}
          onClick={e => {
            if (isParentMenuItem) {
              e.preventDefault();
              setIsSubMenuOpened(!isSubMenuOpened);
            }
          }}>
          {link.icon && <div css={{ marginRight: '1rem' }}>{link.icon}</div>}
          <span css={{ fontSize: 'inherit', color: 'inherit' }}>{link.linkText}</span>
          {link.extra}

          {/* sub menu arrow */}
          {isParentMenuItem && (
            <div css={[{ display: 'flex', flex: 1, alignItems: 'flex-end', justifyContent: 'flex-end' }]}>
              <div css={{ '&:hover': { transform: 'scale(1.2)' }, transition: 'transform .2s' }}>
                <ArrowIcon css={[{ transition: 'transform .2s' }, isSubMenuOpened ? { transform: 'rotate(90deg)' } : {}]} />
              </div>
            </div>
          )}
        </NavLink>
      )}
      {/* sub menu section */}
      <div css={[{ transition: 'all .5s', opacity: 0 }, showSubMenuLinks && isSubMenuOpened && subMenuLinks.length > 0 && { opacity: 1 }]}>
        {showSubMenuLinks &&
          isSubMenuOpened &&
          subMenuLinks.length > 0 &&
          subMenuLinks.map(
            (link, i) =>
              isRouteAllowed(link.to) && (
                <NavLink
                  to={getPath(link.to)}
                  css={[
                    styles.subLink,
                    subLinkStyle && { ...subLinkStyle },
                    link.disable && (disableWithOverlay ? { background: 'rgba(255,255,255,.58)' } : { opacity: '0.30' }),
                    link.disable && { ...styles.disable, ...disableLinkStyle },
                    activeSubLinkStyle && { '&.active': { ...activeSubLinkStyle } }
                  ]}
                  exact={link.exact}
                  key={`sub-menu-link-${link.to.split('/').join().trim()}-${i}`}>
                  {link.icon && <div css={{ marginRight: '1rem' }}>{link.icon}</div>}
                  <span css={{ fontSize: 'inherit', color: 'inherit' }}>{link.linkText}</span>
                  {link.extra}
                </NavLink>
              )
          )}
      </div>
    </>
  );
};

export default observer(MenuLink);
