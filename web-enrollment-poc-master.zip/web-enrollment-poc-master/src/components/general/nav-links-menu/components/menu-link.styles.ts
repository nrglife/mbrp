/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const menuText = css({
  paddingTop: '1rem'
});

const linksContainer = css({
  width: '100%',
  display: 'flex',
  flexDirection: 'column'
});

const link = css({
  fontSize: '1.4rem',
  color: 'white',
  width: '100%',
  textDecoration: 'none',
  paddingLeft: '1.5rem',
  display: 'flex',
  alignItems: 'center',
  paddingTop: '1rem',
  paddingBottom: '1rem',

  '&.active': {
    fontWeight: 'bold'
  }
});

const subLink = css({
  fontSize: '1.4rem',
  color: 'white',
  width: '100%',
  textDecoration: 'none',
  paddingTop: '1rem',
  paddingBottom: '1rem',
  paddingLeft: '7rem',
  display: 'flex',
  alignItems: 'center',

  '&.active': {
    fontWeight: 'bold'
  }
});

const disable = css({ pointerEvents: 'none' });

export const styles = {
  menuText,
  linksContainer,
  link,
  subLink,
  disable
};
