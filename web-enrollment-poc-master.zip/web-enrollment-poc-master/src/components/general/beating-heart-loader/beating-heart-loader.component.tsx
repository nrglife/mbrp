import { FC, useState, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { CSSObject, SerializedStyles } from '@emotion/core';
//third party
import { ReactComponent as HeartLogo } from '../../../assets/icons/connected-health-logo-light-blue.svg';
import { useStores } from 'stores/useStores';
//styles
import * as styles from './beating-heart-loader.styles';

interface BeatingHeartLoaderProps {
  loading?: boolean;
  position?: 'normal' | 'center' | 'absolute';
  containerStyle?: CSSObject | SerializedStyles;
  logoStyle?: CSSObject | SerializedStyles;
  withFadeOut?: boolean;
  animationType?: AnimationType;
}

export enum AnimationType {
  Slow = 'Slow',
  DoubleBeat = 'DoubleBeat',
  DoubleBeatRevere = 'DoubleBeatRevere'
}

const BeatingHeartLoader: FC<BeatingHeartLoaderProps> = ({ loading = false, position = 'normal', containerStyle, logoStyle, withFadeOut = false, animationType = AnimationType.Slow }) => {
  const { responsiveStore } = useStores();
  const [loadingWithFadeOut, setLoadingWithFadeOut] = useState(loading);

  useEffect(() => {
    if (!loading && loadingWithFadeOut) {
      setTimeout(() => {
        setLoadingWithFadeOut(false);
      }, 800);
    }
    if (loading) {
      setLoadingWithFadeOut(true);
    }
  }, [loading]);

  //WithFadeOut behavior
  if (withFadeOut)
    return loadingWithFadeOut ? (
      <div css={[position === 'absolute' && styles.absoluteContainer, position === 'center' && styles.centerContainer, containerStyle, !loading && styles.fadeOut]}>
        <HeartLogo
          css={[
            animationType === AnimationType.DoubleBeat ? styles.loaderDoubleBeat : animationType === AnimationType.DoubleBeatRevere ? styles.loaderDoubleBeatReverse : styles.loaderSlow,
            responsiveStore.isTablet && { width: '20vw' },
            !responsiveStore.isTablet && { width: '7vw' },
            logoStyle
          ]}
        />
      </div>
    ) : null;

  //normal behavior
  return loading ? (
    <div css={[position === 'absolute' && styles.absoluteContainer, position === 'center' && styles.centerContainer, containerStyle]}>
      <HeartLogo
        css={[
          animationType === AnimationType.DoubleBeat ? styles.loaderDoubleBeat : animationType === AnimationType.DoubleBeatRevere ? styles.loaderDoubleBeat : styles.loaderSlow,
          responsiveStore.isTablet && { width: '20vw' },
          !responsiveStore.isTablet && { width: '7vw' },
          logoStyle
        ]}
      />
    </div>
  ) : null;
};

export default BeatingHeartLoader;
