/** @jsxImportSource @emotion/core */
import { css, jsx, keyframes } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

const HeartAnimationSlow = keyframes(`
    0% {
      transform: scale(1);
    }
    45% {
      transform: scale(1.25);
    }
    90% {
      transform: scale(1);
    }
    100% {
      transform: scale(1);
    }
  `);

const HeartAnimationDoubleBeat = keyframes(`
    0% {
      transform: scale(1);
    }
    15% {
      transform: scale(1.25);
    }
    30% {
      transform: scale(1);
    }
    45% {
      transform: scale(1.2);
    }
    60% {
      transform: scale(1);
    }
    100% {
      transform: scale(1);
    }
  `);

const HeartAnimationDoubleBeatReverse = keyframes(`
    0% {
      transform: scale(1);
    }
    40% {
      transform: scale(1);
    }
    55% {
      transform: scale(1.4);
    }
    70% {
      transform: scale(1);
    }
    85% {
      transform: scale(1.2);
    }
    100% {
      transform: scale(1);
    }
  `);

  export const loaderSlow = css({
    animation: `${HeartAnimationSlow} 2.2s infinite linear`
  });

  export const loaderDoubleBeat = css({
  animation: `${HeartAnimationDoubleBeat} 1.5s infinite linear`
});

export const loaderDoubleBeatReverse = css({
  animation: `${HeartAnimationDoubleBeatReverse} 1.5s infinite linear`
});

const fadeOutAnimation = keyframes(`
    0% {
      opacity:1;
    }
    50% {
      opacity:0;
    }
    100% {
      opacity:0;
    }
  `);

export const fadeOut = css({
  animation: `${fadeOutAnimation} 1s linear`
});

export const absoluteContainer = css({
  position: 'absolute',
  width: '100%',
  height: '100%',
  flex: 1,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 10
});

export const centerContainer = css({
  display: 'flex',
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center'
});
