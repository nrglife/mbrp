import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const warningIconStyle = css({ color: globalStyles.COLOR.greyishBrown, width: '2.5rem', height: '2.5rem' });

export const warningContainer = css({
  display: 'flex',
  flexFlow: 'row nowrap',
  alignItems: 'center',
  flex: 1,
  justifyContent: 'start'
});

export const warningText = css({
  fontSize: '1.4rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'normal',
  lineHeight: '2rem'
});
