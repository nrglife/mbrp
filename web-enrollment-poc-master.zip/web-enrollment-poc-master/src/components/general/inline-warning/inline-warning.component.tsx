import React, { FC, useState, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';

import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';

//styles
import * as styles from './inline-warning.styles';

interface InlineWarningProps {
  text: string;
}

const InlineWarning: FC<InlineWarningProps> = ({ text }) => {
  return (
    <div css={[styles.warningContainer, { paddingTop: '0rem' }]}>
      <WarningTriangle css={[styles.warningIconStyle, { marginRight: '0.6rem', paddingBottom: '0.2rem' }]} />
      <span css={[styles.warningText]}>{text}</span>
    </div>
  );
};

export default InlineWarning;
