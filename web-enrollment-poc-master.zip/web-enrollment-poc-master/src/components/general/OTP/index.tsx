// @flow
import { Component } from 'react';

import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { css, jsx, SerializedStyles } from '@emotion/core';
import _ from 'lodash';

import { defaultStyles } from './styles';

// keyCode constants
const BACKSPACE = 8;
const LEFT_ARROW = 37;
const RIGHT_ARROW = 39;
const DELETE = 46;
const SPACEBAR = 32;

interface IOTP {
  value: string;
  isEditable: boolean;
  placeholder: string;
}

interface OTPInputProps {
  // Required
  onChange: Function;
  // Optional
  isNumber?: boolean;
  inputClassName?: string; // Class for input
  setCodeFullFilled?: Function;
  onKeyDown?: Function;
  onInput?: Function;
  onCopy?: Function;
  onPaste?: Function;
  onFocus?: Function;
  onBlur?: Function;
  containerStyle?: SerializedStyles;
  inputStyle?: SerializedStyles;
  focusStyle?: SerializedStyles;
  isDisabled?: boolean;
  disabledStyle?: SerializedStyles;
  hasErrored?: boolean;
  errorStyle?: SerializedStyles;
  autoFocus?: boolean;
  isInputNum?: boolean;
  value?: string;
  format?: string;
  ignorePlaceholders?: string[];
  ignoreCharacters?: string[];
}

interface OTPInputDefaultProps {
  isNumber: boolean;
  isDisabled: boolean;
  hasErrored: boolean;
  autoFocus: boolean;
  isInputNum: boolean;
  format: string;
  ignorePlaceholders: string[];
  ignoreCharacters: string[];
}

type OTPInputPropsWithDefaults = OTPInputProps & OTPInputDefaultProps;

interface OTPInputState {
  activeInput: number;
  otp: IOTP[];
}

const defaultNumberOfInputs = 4;
const defaultIgnorePlaceholders = ['#'];
const defaultIgnoreCharacters = ['/', '-'];
class OtpInput extends Component<OTPInputProps, OTPInputState> {
  public static defaultProps: OTPInputDefaultProps = {
    isNumber: false,
    isDisabled: false,
    hasErrored: false,
    autoFocus: false,
    isInputNum: false,
    format: Array<string>(defaultNumberOfInputs).fill('#').join(''),
    ignorePlaceholders: defaultIgnorePlaceholders,
    ignoreCharacters: defaultIgnoreCharacters
  };

  otpLength: number = 0;
  inputRefs: (HTMLInputElement | null)[] = [];

  constructor(props) {
    super(props);
    this.state = {
      activeInput: 0,
      otp: this.formatToOtp(this.splitEnteredValue(props.value))
    };

    this.otpLength = _.filter(this.props.format ? this.props.format : [], char => !this.props.ignoreCharacters?.includes(char)).length;
  }

  componentDidMount() {
    const { activeInput } = this.state;
    const { autoFocus } = this.props as OTPInputPropsWithDefaults;
    if (autoFocus) {
      setTimeout(() => {
        this.inputRefs[activeInput]?.focus();
      }, 0);
    }
  }

  componentDidUpdate(prevProps) {
    const currentOtp = this.getOTPValue();
    const newOtp = this.props.value;

    if (currentOtp !== newOtp) {
      this.setOtp(this.props.value);
    }
  }

  splitEnteredValue = (value?: string, { format } = this.props as OTPInputPropsWithDefaults): string[] => {
    if (value !== null && value !== undefined && value.length >= 0) {
      return value.length === 0 ? Array(format.length).fill('') : value.slice(0, format.length).split('');
    } else {
      return [];
    }
  };

  formatToOtp(value: string[]): IOTP[] {
    return new Array<string>(this.props.format ? this.props.format.length : defaultNumberOfInputs).fill('').map((_, index) => ({
      value: value && value.length > 0 ? value[index] : '',
      isEditable: !this.props.ignoreCharacters?.includes(this.props.format ? this.props.format[index] : ''),
      placeholder: !this.props.ignorePlaceholders?.includes(this.props.format ? this.props.format[index] : '') ? (this.props.format ? this.props.format[index] : '') : ''
    }));
  }

  setBlur = () => {
    this.inputRefs[this.inputRefs.length - 1]?.blur();
  };

  setFocus = () => {
    this.focusInput(0);
  };

  setOtp = (value?: string) => {
    const { otp } = this.state;
    const { format } = this.props as OTPInputPropsWithDefaults;

    const otpValue = [...otp];

    const splitOtp = this.splitEnteredValue(value);
    if (splitOtp.length > 0) {
      for (let pos = 0; pos < format.length; ++pos) {
        if (otpValue[pos].isEditable && splitOtp.length) {
          const replaceElement = splitOtp.shift();
          otpValue[pos].value = !!replaceElement?.trim() ? replaceElement : '';
        }
      }

      this.handleOtpChange();
    }
  };

  focusInput = (inputIndex: number) => {
    const { format } = this.props as OTPInputPropsWithDefaults;

    const selectedIndex = Math.max(Math.min(format.length - 1, inputIndex), 0);

    this.inputRefs[selectedIndex]?.focus();
    this.setState(() => ({ activeInput: selectedIndex }));
  };

  handleOnFocus = (e: React.FocusEvent<HTMLInputElement>, index) => {
    const { otp: otpValue } = this.state;
    const { onFocus } = this.props as OTPInputPropsWithDefaults;
    if (otpValue[index].isEditable) {
      this.setState(() => ({ activeInput: index }));
      e.target.select();
      onFocus && onFocus();
    }
  };

  handleOnBlur = () => {
    const { onBlur } = this.props;
    this.setState(() => ({ activeInput: -1 }));

    onBlur && onBlur();
  };

  // Helper to return value with the right type: 'text' or 'number'
  getRightValue = (str: string) => {
    const { isNumber } = this.props as OTPInputPropsWithDefaults;
    let changedValue = str;
    if (!isNumber) {
      return changedValue;
    }
    return !changedValue || /\d/.test(changedValue) ? changedValue : '';
  };

  focusNextInput = () => {
    const { otp, activeInput } = this.state;
    let nextIndex = _.findIndex(otp, c => c.isEditable, activeInput + 1);

    if (nextIndex === -1) return;
    this.focusInput(nextIndex);
  };

  getOTPValue = () => {
    const { otp } = this.state;

    return otp.map(item => (item.isEditable ? item.value : '')).join('');
  };

  // Helper to return OTP from inputs
  handleOtpChange = () => {
    const { onChange, setCodeFullFilled } = this.props as OTPInputPropsWithDefaults;
    const otpValue = this.getOTPValue();

    onChange(otpValue, otpValue.length === this.otpLength);
    setCodeFullFilled && setCodeFullFilled(otpValue.length === this.otpLength);
  };

  // Change OTP value at focussing input
  changeCodeAtFocus = (str: string) => {
    const { otp, activeInput } = this.state;

    const updatedOTPValues = [...otp];

    if (updatedOTPValues[activeInput]) {
      updatedOTPValues[activeInput].value = str[0] || '';
    }

    this.setState(() => ({ otp: updatedOTPValues }));
    this.handleOtpChange();
  };

  isGetSameValueAtFocus = (str: string) => {
    const { otp, activeInput } = this.state;

    const updatedOTPValues = [...otp];

    if (str.length > 0 && updatedOTPValues.length >= activeInput) return updatedOTPValues[activeInput]?.value === str[0];
    return false;
  };

  handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = this.getRightValue(e.currentTarget.value);

    if (!val) {
      e.preventDefault();
      return;
    }
    this.changeCodeAtFocus(val);
    this.focusNextInput();
  };

  focusPrevInput = () => {
    const { otp, activeInput } = this.state;
    let nextIndex = _.findLastIndex(otp, c => c.isEditable, activeInput > 0 ? activeInput - 1 : activeInput);

    this.focusInput(nextIndex);
  };

  handleOnKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const { onKeyDown } = this.props;

    if (e.keyCode === BACKSPACE || e.key === 'Backspace') {
      e.preventDefault();
      this.changeCodeAtFocus('');
      this.focusPrevInput();
    } else if (e.keyCode === DELETE || e.key === 'Delete') {
      e.preventDefault();
      this.changeCodeAtFocus('');
    } else if (e.keyCode === LEFT_ARROW || e.key === 'ArrowLeft') {
      e.preventDefault();
      this.focusPrevInput();
    } else if (e.keyCode === RIGHT_ARROW || e.key === 'ArrowRight') {
      e.preventDefault();
      this.focusNextInput();
    } else if (e.keyCode === SPACEBAR || e.key === ' ' || e.key === 'Spacebar') {
      e.preventDefault();
    }

    onKeyDown && onKeyDown();
  };

  checkLength = (e: React.FormEvent<HTMLInputElement>) => {
    const { onInput } = this.props;
    const val = this.getRightValue(e.currentTarget.value);
    if ((e.target as HTMLInputElement).value.length > 1 || this.isGetSameValueAtFocus(val)) {
      e.preventDefault();
      this.focusNextInput();
    }

    onInput && onInput();
  };

  handleOnPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const { otp } = this.state;
    const { format, onPaste } = this.props as OTPInputPropsWithDefaults;

    e.preventDefault();

    const otpValue = [...otp];

    // Get pastedData in an array of max size (num of inputs - current position)
    const pastedData = e.clipboardData.getData('text/plain').slice(0, format.length).split('');
    // Paste data from focused input onwards
    if (pastedData.length > 0) {
      let nextFocuesInput = 0;
      for (let pos = 0; pos < format.length; ++pos) {
        if (otpValue[pos].isEditable && pastedData.length) {
          const pastedElement = pastedData.shift();
          otpValue[pos].value = !!pastedElement?.trim() ? pastedElement : '';
          // update the nextFocused field
          nextFocuesInput = pos;
        }
      }

      this.handleOtpChange();
      this.focusInput(nextFocuesInput + 1);
      onPaste && onPaste();
    }
  };

  handleOnCopy = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const { onCopy } = this.props;
    const otpValue = this.getOTPValue();

    e.clipboardData.setData('text/plain', otpValue);
    e.preventDefault();

    onCopy && onCopy(otpValue);
  };

  isInputDisabled = (index: number) => {
    const { otp } = this.state;
    const { isDisabled } = this.props;
    return isDisabled || !otp[index].isEditable;
  };

  render() {
    const { otp } = this.state;
    const { containerStyle, format, inputStyle, disabledStyle, errorStyle, hasErrored, isDisabled } = this.props as OTPInputPropsWithDefaults;

    return (
      <div css={[defaultStyles.containerStyle, containerStyle ? containerStyle : undefined]}>
        {Array(format?.length)
          .fill('')
          .map((_, index) => (
            <input
              ref={ref => (this.inputRefs[index] = ref)}
              key={`SingleInput-${index}`}
              value={otp && otp[index].value}
              placeholder={otp && otp[index].placeholder}
              onChange={this.handleOnChange}
              onKeyDown={this.handleOnKeyDown}
              onInput={this.checkLength}
              onCopy={this.handleOnCopy}
              onPaste={this.handleOnPaste}
              onFocus={(e: React.FocusEvent<HTMLInputElement>) => this.handleOnFocus(e, index)}
              onBlur={this.handleOnBlur}
              css={css([
                defaultStyles.inputStyle,
                inputStyle,
                otp[index].isEditable ? undefined : disabledStyle ? disabledStyle : defaultStyles.disabled,
                hasErrored && !isDisabled && otp[index].isEditable ? (errorStyle ? errorStyle : defaultStyles.errorStyle) : undefined
              ])}
              disabled={this.isInputDisabled(index)}
            />
          ))}
      </div>
    );
  }
}

export default OtpInput;
