import { FC, useRef, memo, RefObject } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';

import usePrevious from '../usePrevious';
import { useComponentDidMount, useComponentDidUpdate } from '../../../../customHooks';
import {} from './single-input.styles';

export interface SingleOTPInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  inputStyle: SerializedStyles;
  focus?: boolean;
  autoFocus?: boolean;
  isDisabled?: boolean;
  isFirstInput?: boolean;
  isLastChild?: boolean;
  ref?: RefObject<HTMLInputElement>;
}

const SingleOTPInput: FC<SingleOTPInputProps> = ({ value, focus, autoFocus, inputStyle, isDisabled, isLastChild, isFirstInput, ...rest }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const prevFocus = usePrevious(!!focus);

  // run this when component first mounts (for autoFocus and avoiding logic duplication)
  useComponentDidMount(() => {
    if (inputRef.current) {
      if (focus && autoFocus && !isDisabled) {
        inputRef.current.focus();
      }
    }
  });

  // update the focus of a current input
  useComponentDidUpdate(() => {
    if (inputRef.current) {
      if (focus && focus !== prevFocus) {
        inputRef.current.focus();
        inputRef.current.select();
      }
    }
  }, [focus]);

  return <input ref={inputRef} disabled={isDisabled} value={value} {...rest} css={inputStyle} />;
};

const SingleOtpInput = memo(SingleOTPInput);
export default SingleOtpInput;
