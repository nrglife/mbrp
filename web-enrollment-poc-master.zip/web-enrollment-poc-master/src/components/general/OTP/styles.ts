/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

const OTPInput = css({
  width: '3rem',
  height: '3rem',
  fontSize: '2rem',
  textAlign: 'center',
  transition: 'all 0.3s ease-in-out',
  marginRight: 5, // defaults to px
  border: 'none',
  borderBottom: `1px solid rgba(0,0,0,0.2)`,
  borderRadius: 'unset',
  '&::selection': {
    //backgroundColor: 'transparent',
    //color: 'none'
  },
  '&::-moz-selection': {
    //color: 'none',
    //backgroundColor: 'transparent'
  },
  '&:focus': {
    borderBottom: `1px solid ${globalStyles.COLOR.black}`,
    transition: 'all 0.3s ease-in-out'
  },
  '&:disabled': {
    backgroundColor: 'transparent'
  }
});

const containerStyle = css({
  display: 'flex',
  width: '100%',
  alignItems: 'center'
});

const errorStyle = css({
  borderBottom: '2px solid rgba(255,0,0,0.25)',
  color: globalStyles.COLOR.darkCoral,
  '&::selection': {
    //color: 'none',
    //backgroundColor: 'transparent'
  },
  '&::-moz-selection': {
    //color: 'none',
    //backgroundColor: 'transparent'
  },
  '&:focus': {
    borderBottom: `2px solid ${globalStyles.COLOR.darkCoral}`,
    transition: 'all 0.3s ease-in-out'
  },
  '&::placeholder': {
    color: globalStyles.COLOR.darkCoral
  }
});

const disabled = css([
  OTPInput,
  {
    border: 'none',
    '&:focus': {
      border: 'none'
    },
    '&::selection': {
      color: 'none',
      backgroundColor: 'transparent'
    },
    '&::-moz-selection': {
      color: 'none',
      backgroundColor: 'transparent'
    }
  }
]);

export const defaultStyles = {
  containerStyle,
  inputStyle: OTPInput,
  disabled,
  errorStyle
};
