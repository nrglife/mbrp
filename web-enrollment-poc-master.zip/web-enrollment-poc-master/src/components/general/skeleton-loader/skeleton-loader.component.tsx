import { FC, Fragment, useState, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import * as styles from './skeleton-loader.style';
import { globalStyles } from '../../../styles/global.styles';

interface SkeletonLoaderProps {
  isLoading: boolean;
  color1?: string;
  color2?: string;
  speed?: string;
  style?: any;
  withFadeOut?: boolean;
}

const defaultProps = {
  color1: globalStyles.COLOR.baseNeutral5,
  color2: globalStyles.COLOR.baseNeutral15,
  speed: '2.5s'
};

const SkeletonLoader: FC<SkeletonLoaderProps> = ({ isLoading, color1 = defaultProps.color1, color2 = defaultProps.color2, speed = defaultProps.speed, style, withFadeOut = false, children }) => {
  const [loadingWithFadeOut, setLoadingWithFadeOut] = useState(isLoading);

  useEffect(() => {
    if (!isLoading && loadingWithFadeOut) {
      setTimeout(() => {
        setLoadingWithFadeOut(false);
      }, 800);
    }
  }, [isLoading]);

  //WithFadeOut behavior
  if (withFadeOut)
    return loadingWithFadeOut ? (
      <div css={[styles.background(color1, color2, speed), children && { width: 'auto', height: 'auto' }, style, !isLoading && styles.fadeOut]}>
        {children && <div css={{ opacity: 0 }}>{children}</div>}
      </div>
    ) : (
      <Fragment>{children}</Fragment>
    );

  //normal behavior
  return isLoading ? (
    <div css={[styles.background(color1, color2, speed), children && { width: 'auto', height: 'auto' }, style]}>{children && <div css={{ opacity: 0 }}>{children}</div>}</div>
  ) : (
    <Fragment>{children}</Fragment>
  );
};

export default SkeletonLoader;
