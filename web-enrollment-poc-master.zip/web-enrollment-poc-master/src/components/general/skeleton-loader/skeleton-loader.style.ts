/** @jsxImportSource @emotion/core */
import { css, jsx, keyframes } from '@emotion/core';

const bgAnimation = (color1, color2) => keyframes`
0% {
  background-color: ${color1};
}
50% {
  background-color: ${color2};
}
0% {
  background-color: ${color1};
}
`;

export const background = (color1, color2, speed) =>
  css({
    backgroundColor: color1,
    animation: `${bgAnimation(color1, color2)} ${speed} infinite;`,
    width: '100%',
    height: '100%'
  });

const fadeOutAnimation = keyframes(`
    0% {
      opacity:1;
    }
    50% {
      opacity:0;
    }
    100% {
      opacity:0;
    }
  `);

export const fadeOut = css({
  animation: `${fadeOutAnimation} 1s linear`
});
