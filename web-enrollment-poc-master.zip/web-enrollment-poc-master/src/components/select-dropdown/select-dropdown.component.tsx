import { FC, forwardRef, useEffect, useState, useRef } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../stores/useStores';
//styles
import { styles } from './select-dropdown.styles';
import { any } from 'prop-types';

export type SelectOption = {
  label: string | null;
  value: string | null;
};

interface SelectDropdownProps {
  selectOptions: SelectOption[];
  onSelect: (val: string) => void;
  propStyles: any;
  optionPlaceholderPrefix?: string;
}

const SelectDropdown: FC<SelectDropdownProps> = (props) => {
  const { selectOptions, onSelect, propStyles, optionPlaceholderPrefix } = props;
  const [ isDropdownShown, setIsDropdownShown ] = useState<boolean>(false);
  const [ selected, setSelected ] = useState<SelectOption>(selectOptions[0]);
  const { themeStore, responsiveStore } = useStores();
  const { isTablet, isMobile } = responsiveStore;
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleClick = () => {
    setIsDropdownShown(!isDropdownShown)
  };

  const handleSelect = (option) => {
    setSelected(option);
    onSelect(option.value);
    setIsDropdownShown(false);
  };

  // Hide dropdown when clicked outside
  const onClickOutside = event => {
    if (dropdownRef && dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsDropdownShown(false);
    }
  };

  useEffect(() => {
    if (isDropdownShown && dropdownRef && !dropdownRef.current != null) {
      window.addEventListener('click', onClickOutside);
    }
    return () => {
      window.removeEventListener('click', onClickOutside);
    };
  }, [isDropdownShown]);

  return (
    <div css={[ styles.container ]}>
      <div ref={dropdownRef}>
        <button
          css={[{height: propStyles.containerHeight}, styles.buttonStyles(themeStore.currentTheme), isMobile && styles.buttonStylesMobile]}
          onClick={() => handleClick()}>
          {optionPlaceholderPrefix} {selected?.label} <span css={[styles.buttonTriangle]}></span>
        </button>
        {isDropdownShown && (
          <div css={[styles.dropdownMenu, isMobile && styles.dropdownMenuMobile]}>
            {selectOptions.length > 0 ? (
              <ul css={[styles.listStyles]}>
                {selectOptions.map((item, index) => {
                  return (
                    <li
                      key={item.value}
                      css={[
                        item.value === selected?.value ? styles.itemTextNoHover(themeStore.currentTheme) : styles.itemText(themeStore.currentTheme),
                        item.value === selected?.value && styles.activeItem(themeStore.currentTheme)
                      ]}
                      onClick={() => handleSelect(item)}>
                      {item.label}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p css={[styles.emptyItemText]}>No options</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default observer(SelectDropdown);
