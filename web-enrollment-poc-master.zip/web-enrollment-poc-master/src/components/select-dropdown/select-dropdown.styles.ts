/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';
import { Preferences } from '../../stores/ThemeStore';
import { bold } from 'pages/enrollment/enrolled/components/enrolled.styles';

const container = css({
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: '0',
  position: 'relative'
});

const buttonStyles = (theme: Preferences) =>
  css({
    width: '100%',
    background: globalStyles.COLOR.white,
    boxShadow: '0px 1px 3px rgba(17, 80, 244, 0.06), 0px 2px 12px rgba(131, 144, 175, 0.16)',
    borderRadius: '12px',
    fontWeight: 'bold',
    cursor: 'pointer',
    textAlign: 'left',
    paddingLeft: '2.2rem',
    border: '1px solid #8891AA',
    ':focus': {
      border: '1px solid',
      borderColor: theme.colors.actionMedium.published
    }
  });

const buttonTriangle = css({
  position: 'absolute',
  content: '""',
  width: 0,
  height: 0,
  borderStyle: 'solid',
  borderWidth: '5px 4px 0 4px',
  borderColor: '#000 transparent transparent transparent',
  top: 'calc(50% - 2.5px)',
  right: '18px'
});

const buttonStylesMobile = css({});

const dropdownMenu = css({
  position: 'absolute',
  background: globalStyles.COLOR.white,
  width: '100%',
  boxShadow: '0px 1px 4px rgba(17, 80, 244, 0.12), 0px 10px 32px rgba(131, 144, 175, 0.35)',
  borderRadius: '8px',
  padding: '12px 0'
});

const dropdownMenuMobile = css({});

const listStyles = css({});

const itemText = (theme: Preferences) =>
  css({
    fontSize: '13px',
    lineHeight: '150%',
    padding: '12px 35px 12px 24px',
    width: '100%',
    cursor: 'pointer',
    '&:hover': {
      backgroundColor: `${theme.colors.actionLight.published}90`,

      boxShadow: `inset 2px 0px 0px ${globalStyles.COLOR.sea}`
    }
  });

export const itemTextNoHover = (theme: Preferences) =>
  css({
    fontSize: '13px',
    lineHeight: '150%',
    padding: '12px 35px 12px 24px',
    width: '100%',
    cursor: 'pointer'
  });

const activeItem = (theme: Preferences) =>
  css({
    background: theme.colors.actionLight.published,
    boxShadow: `inset 2px 0px 0px ${globalStyles.COLOR.sea}`
  });

const emptyItemText = css({
  fontSize: '13px',
  lineHeight: '150%',
  padding: '12px 35px 12px 24px',
  width: '100%',
  fontWeight: 'bold'
});

export const styles = {
  container,
  buttonStyles,
  buttonTriangle,
  buttonStylesMobile,
  dropdownMenu,
  dropdownMenuMobile,
  listStyles,
  itemText,
  itemTextNoHover,
  activeItem,
  emptyItemText
};
