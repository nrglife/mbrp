/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';

import { useStores } from 'stores/useStores';

//styles
import * as styles from './next-page-inline-loader.styles';
import { globalStyles } from '../../../styles/global.styles';
import { FC } from 'react';
import Loader from 'components/general/loader/loader.component';
import { ThemeStore } from 'stores/ThemeStore';

interface InlineLoaderProps {}

const InlineLoader: FC<InlineLoaderProps> = ({}) => {
  const { themeStore } = useStores();
  return <Loader color={themeStore.currentTheme.colors.actionMedium.published} position={'inline'} loading={true} style={styles.main} />;
};

export default observer(InlineLoader);
