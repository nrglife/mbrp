/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const main = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center'
});
