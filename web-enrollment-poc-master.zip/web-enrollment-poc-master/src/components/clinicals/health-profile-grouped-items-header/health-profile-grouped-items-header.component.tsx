/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';

//styles
import * as styles from './health-profile-grouped-items-header.styles';
import { FC } from 'react';

interface HealthProfileGroupedItemsHeaderProps {
  headerText: string;
}

const HealthProfileGroupedItemsHeader: FC<HealthProfileGroupedItemsHeaderProps> = ({ headerText }) => {
  return (
    <div css={[styles.headerTextStyle]}>
      <span css={styles.main}>{headerText}</span>
    </div>
  );
};

export default observer(HealthProfileGroupedItemsHeader);
