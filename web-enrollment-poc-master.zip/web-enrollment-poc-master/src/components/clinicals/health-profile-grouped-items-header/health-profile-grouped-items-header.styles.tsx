/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const main = css({
  fontSize: '1.6rem',
  fontWeight: 'bold',
  marginBottom: '1.9rem',
  color: globalStyles.COLOR.blackTwo
});

export const headerTextStyle = css({
  marginTop: '2rem',
  marginBottom: '1.3rem'
});
