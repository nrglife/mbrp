/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
import { FC } from 'react';
//developed
import { useStores } from '../../../stores/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
//common
import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
//styles
import * as styles from './health-profile-item.styles';
import { unavailableText } from './health-profile-item.styles';
import { ReactComponent as ArrowIcon } from '../../../assets/icons/chevron-right.svg';
import HealthProfileItemFieldsComponent from './health-profile-item-fields.component';

interface HealthProfileItemComponentProps {
  item: DisplayableHealthProfileItem | null;
  maxItemsInRow: number;
  onSelect?: (item: DisplayableHealthProfileItem) => void;
}

const HealthProfileItemComponent: FC<HealthProfileItemComponentProps> = ({ item, maxItemsInRow, onSelect }) => {
  const { responsiveStore } = useStores();
  const { t } = useTranslation();
  const value = item ? (
    <div
      key={item.id}
      css={[styles.whiteRectangle, onSelect && item.isDetailedViewRequired() ? { cursor: 'pointer' } : null]}
      onClick={() => {
        onSelect && item.isDetailedViewRequired() && onSelect(item);
      }}>
      <div css={styles.header}>
        {onSelect && item.isDetailedViewRequired() && (
          <div css={styles.detailLinkContainer}>
            <span css={styles.detailLinkText}>More Details</span>
            <ArrowIcon css={styles.rightChevron}></ArrowIcon>
          </div>
        )}

        <div css={styles.titleStatusContainer}>
          {/* description   */}
          <div css={styles.titleContainer}>
            {item?.titles.map((title, index) => (
              <div key={'title_' + index} css={index + 1 < item?.titles.length && styles.titleFooter}>
                {title?.description ? <div css={styles.title}>{title?.description}</div> : <div css={styles.unavailableTitle}>{t(LocaleKeys.errors.description_unavailable)}</div>}
                <div css={styles.codeAndTitle}>
                  {title?.code ? (
                    <span css={styles.lighterText}>{'(' + title?.code + ') '}</span>
                  ) : (
                    <span css={styles.unavailableText(false)}>
                      (<span css={styles.unavailableText(true)}>{t(LocaleKeys.errors.code_unavailable)}</span>){' '}
                    </span>
                  )}
                  {item?.titles?.length === 1 && item?.secondaryTitle?.data && index + 1 === item.titles.length && (
                    <span css={styles.lighterText}>{item?.secondaryTitle?.label ? item?.secondaryTitle?.label + ' ' + item?.secondaryTitle?.data : item?.secondaryTitle?.data}</span>
                  )}
                </div>
              </div>
            ))}
            {item?.titles?.length > 1 && <div css={styles.secondaryTitle}>
              <span>{item?.secondaryTitle?.label ? item?.secondaryTitle?.label + ' ' + item?.secondaryTitle?.data : item?.secondaryTitle?.data}</span>
            </div>}
          </div>
          <div>
            {item?.status?.name && item.status?.bkgdColor && (
              <div css={[styles.status, styles.statusColors(item?.status?.bkgdColor, item?.status?.useDarkTextColor)]}>{item?.status?.name?.toString().toUpperCase()}</div>
            )}
          </div>
        </div>
      </div>

      {/* additional data */}
      <HealthProfileItemFieldsComponent maxItemsInRow={maxItemsInRow} extendedInfo={item.extendedInfo}></HealthProfileItemFieldsComponent>
    </div>
  ) : null;

  return value;
};

export default observer(HealthProfileItemComponent);
