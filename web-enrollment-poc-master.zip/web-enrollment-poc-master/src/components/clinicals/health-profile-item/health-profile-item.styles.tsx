/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';

export const whiteRectangle = css({
  marginTop: '1.2rem',
  marginBottom: '1.2rem',
  backgroundColor: globalStyles.COLOR.white,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  borderRadius: '1rem',
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  padding: '2rem 2.4rem',
  paddingBottom: '1rem',
  position: 'relative'
});

export const titleStatusContainer = css({
  display: 'flex',
  flex: '1',
  marginBottom: '0.1rem'
});

export const title = css({
  fontSize: '1.3rem',
  fontWeight: 'bold',
  color: globalStyles.COLOR.blackTwo,
  lineHeight: '1.95rem'
});

export const titleContainer = css({
  display: 'flex',
  flexDirection: 'column'
});

export const titleFooter = css({
  paddingBottom: '1.6rem'
});

export const secondaryTitle = css({
  paddingTop: '1.6rem',  
  fontSize: '1.3rem',
  color: globalStyles.COLOR.blackTwo,
  lineHeight: '1.95rem'
});

export const unavailableTitle = css({
  fontSize: '1.3rem',
  letterSpacing: '0',
  display: 'flex',
  alignItems: 'center',
  color: globalStyles.COLOR.coolGrey,
  fontStyle: 'italic',
  fontWeight: 'normal'
});

export const status = css({
  height: '1.8rem',
  lineHeight: '1.8rem',
  textAlign: 'center',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '1rem',
  fontWeight: 'bold',
  marginLeft: '1.2rem',
  borderRadius: '2px',
  padding: '0rem 0.8rem'
});

export const statusColors = (bkgdColor, useDarkTextColor) =>
  css({
    backgroundColor: bkgdColor,
    color: useDarkTextColor === true ? globalStyles.COLOR.blackTwo : globalStyles.COLOR.white
  });

export const lighterText = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.slateGrey
});

export const codeAndTitle = css({
  marginTop: '0.3rem'
});

export const unavailableText = (withItalic: boolean) =>
  css({
    fontSize: '1.3rem',
    letterSpacing: '0',
    color: globalStyles.COLOR.coolGrey,
    fontStyle: withItalic ? 'italic' : '',
    fontWeight: 'normal'
  });

export const additionalInfoContainer = css({
  marginTop: '2rem'
});

export const additionalInfoRowContainer = css({
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap'
});
export const additionalInfoContainerMobile = css({
  flexDirection: 'column'
});

export const itemContainer = marginBottom =>
  css({
    display: 'flex',
    flexDirection: 'column',
    paddingRight: '2rem',
    marginBottom: marginBottom
  });

export const itemLabel = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.slateGrey,
  lineHeight: '1.95rem'
});

export const itemText = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.blackTwo,
  lineHeight: '1.95rem'
});

export const detailLinkContainer = css({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'flex-end',
  alignItems: 'center',
  paddingLeft: '2rem'

  // padding: '2rem'
});

export const header = css({ display: 'flex', flexDirection: 'row-reverse', alignItems: 'flex-start' });

export const detailLinkText = css({ fontSize: '1.1rem', lineHeight: '1.1rem', color: globalStyles.COLOR.blackTwo });

export const rightChevron = css({ height: '1.65rem', color: globalStyles.COLOR.slateGrey });
