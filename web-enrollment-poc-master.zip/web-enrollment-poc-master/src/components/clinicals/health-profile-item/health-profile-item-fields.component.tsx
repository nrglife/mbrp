/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
import { FC } from 'react';
//developed
import { useStores } from '../../../stores/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
//common
import { ExtendedInfo, FieldType } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
//styles
import * as styles from './health-profile-item.styles';
import { TFunction } from 'i18next';

import { ReactComponent as ArrowIcon } from '../../../assets/icons/chevron-right.svg';

interface HealthProfileItemFieldsComponentProps {
  extendedInfo: ExtendedInfo[] | undefined;
  maxItemsInRow: number;
  verticalMargin?: string;
}

const HealthProfileItemFieldsComponent: FC<HealthProfileItemFieldsComponentProps> = ({ extendedInfo, maxItemsInRow, verticalMargin = '1rem' }) => {
  const { responsiveStore } = useStores();
  const { t } = useTranslation();
  const value =
    extendedInfo && extendedInfo.length > 0 ? (
      <div css={styles.additionalInfoContainer}>
        {extendedInfo
          .filter(item => !item.detailedViewOnly)
          .map((info, index) => {
            return (
              <div key={'extendedInfo_' + index}>
                {info.title && <div css={{ paddingBottom: '1rem', paddingTop: '1rem' }}>{info.title}</div>}
                {info.items.map((itemsList, index) => {
                  const filteredItemsList = itemsList.filter(field => {
                    return !field.detailedViewOnly;
                  });

                  return (
                    <div key={'fieldrow_' + index} css={[styles.additionalInfoRowContainer]}>
                      {filteredItemsList.map((filteredItem, index) => {
                        return (
                          (filteredItem?.data || filteredItem?.code) && (
                            <div key={'field_' + index} css={[styles.itemContainer(verticalMargin), responsiveStore.isMobile ? { minWidth: '50%' } : { width: Math.floor(100 / maxItemsInRow) + '%' }]}>
                              <span css={styles.itemLabel}>{filteredItem?.label}</span>
                              {filteredItem.type === FieldType.collection && Array.isArray(filteredItem.data) && filteredItem.data.length > 0
                                ? filteredItem.data.map((item, index) => {
                                    const endOfTheList = filteredItem.data!.length - 1 === index ? '' : ',';
                                    return <FieldDataTitle key={item.toString() + Math.random().toString()} title={`${item}${endOfTheList}`} t={t} />;
                                  })
                                : filteredItem?.data && <FieldDataTitle isBold={filteredItem.isHighlighted} title={filteredItem?.data} t={t} />}
                            </div>
                          )
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            );
          })}
      </div>
    ) : null;

  return value;
};

export default observer(HealthProfileItemFieldsComponent);

interface FieldDataTitleProps {
  t: TFunction;
  title?: string | string[];
  isBold?: boolean;
}

const FieldDataTitle: FC<FieldDataTitleProps> = ({ title, t, isBold }) => (
  <span css={[styles.itemText, isBold && { fontWeight: 'bold' }, t(LocaleKeys.screens.Clinical.LabObservation.resultNotViewableThisTime) === title && styles.unavailableText(true)]}>{title}</span>
);
