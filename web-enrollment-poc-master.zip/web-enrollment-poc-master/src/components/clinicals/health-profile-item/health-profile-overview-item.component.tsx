/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
import { FC } from 'react';
//developed
import { useStores } from '../../../stores/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
//common
import { HealthProfileOverviewData } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
//styles
import * as styles from './health-profile-item.styles';

import HealthProfileItemFieldsComponent from './health-profile-item-fields.component';

interface HealthProfileOVerviewItemComponentProps {
  item: HealthProfileOverviewData;
  maxItemsInRow: number;
}

const HealthProfileOverviewItemComponent: FC<HealthProfileOVerviewItemComponentProps> = ({ item, maxItemsInRow }) => {
  const { responsiveStore } = useStores();
  const { t } = useTranslation();

  return item ? (
    <div key={item.id} css={styles.whiteRectangle}>
      <HealthProfileItemFieldsComponent maxItemsInRow={maxItemsInRow} extendedInfo={item?.info} verticalMargin={'2.8rem'}></HealthProfileItemFieldsComponent>
    </div>
  ) : null;
};

export default observer(HealthProfileOverviewItemComponent);
