/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';

export const container = css({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: globalStyles.COLOR.charcoalGrey,
  margin: '1rem 0'
});

export const contant = css({
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: '0',
  marginRight: '.8rem'
});
