import { FC, ReactNode } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles, CSSObject } from '@emotion/core';
//consts
import * as styles from './powered-by-chc.styles';
import chcLogiImg from '../../assets/icons/change-logo-light.png';

interface PoweredByCHCProps {
  containerStyle?: SerializedStyles | CSSObject;
  contentStyle?: SerializedStyles | CSSObject;
  contentTxt?: string;
  showLogoImg?: boolean;
  logoImgSrc?: string;
  imgStyle?: SerializedStyles | CSSObject;
  children?: ReactNode;
}

const PoweredByCHC: FC<PoweredByCHCProps> = ({ containerStyle, contentStyle, contentTxt, showLogoImg = true, logoImgSrc, imgStyle, children }) => {
  const content: string = 'Powered by';

  return (
    <div css={[styles.container, containerStyle]}>
      <span css={[styles.contant, contentStyle]}>{contentTxt || content}</span>
      {showLogoImg && <img src={logoImgSrc || chcLogiImg} css={[imgStyle]} />}
      {children}
    </div>
  );
};

export default PoweredByCHC;
