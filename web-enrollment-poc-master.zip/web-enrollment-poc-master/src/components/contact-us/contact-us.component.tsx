import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles, CSSObject } from '@emotion/core';
//developed
import { useStores } from '../../stores/useStores';
//consts
import * as styles from './contact-us.styles';

//styles
import * as enrollmentGlobalStyles from '../../pages/enrollment/enrollment-page.styles';
import { EnrollmentSteps } from 'stores';

interface ContactUsProps {
  onClick?: ((event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void) | undefined;
  containerStyle?: SerializedStyles | CSSObject;
  ignoreDefaultContainerStyle?: boolean;
  textStyle?: SerializedStyles | CSSObject;
  ignoreDefaultTextStyle?: boolean;
  contactUsPrefixText?: string;
  contactUsText?: string;
  contactUsPostText?: string;
}

const ContactUs: FC<ContactUsProps> = ({
  onClick,
  containerStyle,
  ignoreDefaultContainerStyle = false,
  contactUsPrefixText = 'Need help? ',
  contactUsText = 'Contact us',
  contactUsPostText = '.',
  textStyle,
  ignoreDefaultTextStyle = false
}) => {
  const { enrollmentStore, themeStore } = useStores();

  const handleContactUsClick = () => {
    enrollmentStore.setContactUsVisibility(true);
  };

  return (
    <div css={[!ignoreDefaultContainerStyle && styles.container, !ignoreDefaultContainerStyle && enrollmentGlobalStyles.contactContainer, containerStyle]}>
      {contactUsPrefixText}
      <a css={[!ignoreDefaultTextStyle && enrollmentGlobalStyles.contactUs(themeStore.currentTheme.colors.actionMedium.published), textStyle]} onClick={onClick || handleContactUsClick}>
        {contactUsText}
      </a>
      {contactUsPostText}
    </div>
  );
};

export default ContactUs;
