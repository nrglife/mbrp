/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

export const container = css({
  display: 'flex',
  flexGrow: 1,
  flexDirection: 'column',
  justifyContent: 'space-between',
  alignItems: 'center',
  alignContent: 'center',
  backgroundColor: 'white'
});

