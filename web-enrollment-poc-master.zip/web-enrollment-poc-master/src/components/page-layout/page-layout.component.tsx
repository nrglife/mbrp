import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css, SerializedStyles } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../stores/useStores';
//consts
import { styles } from './page-layout.styles';

interface PageLayoutProps {
  // SerializedStyles is a type of css from '@emotion/core' library
  pageContainerStyle?: SerializedStyles | SerializedStyles[];
  top?: JSX.Element | null;
  topStyle?: SerializedStyles | SerializedStyles[];
  mainBodyStyle?: SerializedStyles;
  left?: JSX.Element | null;
  leftStyle?: SerializedStyles | SerializedStyles[];
  center?: JSX.Element | null;
  centerStyle?: SerializedStyles | SerializedStyles[];
  right?: JSX.Element | null;
  rightStyle?: SerializedStyles | SerializedStyles[];
  bottom?: JSX.Element | null;
  bottomStyle?: SerializedStyles | SerializedStyles[];
}

const PageLayout: FC<PageLayoutProps> = ({
  pageContainerStyle = {},
  top,
  topStyle = {},
  mainBodyStyle = {},
  left,
  leftStyle = {},
  center,
  centerStyle = {},
  right,
  rightStyle = {},
  bottom,
  bottomStyle = {}
}) => {
  const { responsiveStore } = useStores();

  return (
    <div css={[styles.pageContainer, pageContainerStyle]}>
      {top && <div css={[styles.top, topStyle, responsiveStore.isMobile && styles.withMarginBottom]}>{top}</div>}
      {center && (
        <div css={[styles.mainBody, mainBodyStyle]}>
          {left && <div css={[styles.left, leftStyle]}>{left}</div>}
          <div css={[styles.center, (responsiveStore.isMobile || responsiveStore.removeScrollbar) && styles.removeScrollBarVisibility, centerStyle]}>{center}</div>
          {right && <div css={[styles.right, rightStyle]}>{right}</div>}
        </div>
      )}
      {bottom && <div css={[styles.bottom, bottomStyle]}>{bottom}</div>}
    </div>
  );
};

export default observer(PageLayout);
