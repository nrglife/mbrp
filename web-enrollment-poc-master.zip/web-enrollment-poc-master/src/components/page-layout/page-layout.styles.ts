/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const removeScrollBarVisibility = css({
  msOverflowStyle: 'none' /* IE and Edge */,
  scrollbarWidth: 'none' /* Firefox */,
  '&::-webkit-scrollbar': {
    /* Hide scrollbar for Chrome, Safari and Opera */ width: 0
  }
});

const withMarginBottom = css({
  marginBottom: '48px'
});

const pageContainer = css({
  height: '100%',
  width: '100%',
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  //scroll behavior on the page container
  overflow: 'hidden'
});
const top = css({ minHeight: '57px', height: '57px' });
const mainBody = css({
  flex: 1,
  display: 'flex',
  flexDirection: 'row',
  maxHeight: 'calc(100vh - 57px)'
});
const left = css({ top: '57px', bottom: 0, minWidth: '15%', overflowY: 'scroll', boxSizing: 'content-box' });
const center = css({
  flex: 1,
  //for scroll behavior
  overflowY: 'scroll',
  boxSizing: 'content-box',
  '&::-webkit-scrollbar': {
    width: '.5rem'
  }
});

const right = css({ height: '100%', minWidth: '15%', overflowY: 'scroll', boxSizing: 'content-box' });
const bottom = css({ maxHeight: '10%' });

export const styles = {
  removeScrollBarVisibility,
  withMarginBottom,
  pageContainer,
  top,
  mainBody,
  left,
  center,
  right,
  bottom
};
