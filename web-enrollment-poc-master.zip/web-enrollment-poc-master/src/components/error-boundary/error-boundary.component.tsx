import { Component } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import GeneralError from '../general-error/general-error.component';
import TemporarilyDownError from './errors/temporarily-down/temporarily-down-error.component';
import  { ErrorBoundaryTypes , ErrorsStore, ErrorsStoreType} from '../../stores/ErrorsStore';
import { IocContainer, IocTypes } from 'inversify.config';

interface ErrorBoundaryProps {
  hasError: boolean;
  error: string;
}

class ErrorBoundary extends Component<{}, ErrorBoundaryProps> {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: '' };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error: error.toString() };
  }

  componentDidCatch(error, info) {
    // Display fallback UI
    this.setState({ hasError: true });
    // You can also log the error to an error reporting service
    // eslint-disable-next-line no-console
    console.log(error, info);
  }

  render() {
    const { hasError } = this.state;
    const { children } = this.props;

    if (IocContainer.get<ErrorsStoreType>(IocTypes.ErrorsStore).isError) {
      // You can render any custom fallback UI
      switch (IocContainer.get<ErrorsStoreType>(IocTypes.ErrorsStore).errorType) {
        case ErrorBoundaryTypes.TEMPORARILY_DOWN:
          return <TemporarilyDownError />;

        default:
          return <GeneralError h1Contant="Something went wrong." h2Contant=" " showIcon={false} />;
      }
    }

    if (hasError) return <GeneralError h1Contant="Something went wrong." h2Contant=" " showIcon={false} />;

    if (!navigator.cookieEnabled) return <GeneralError />;

    return children;
  }
}

export default observer(ErrorBoundary);
