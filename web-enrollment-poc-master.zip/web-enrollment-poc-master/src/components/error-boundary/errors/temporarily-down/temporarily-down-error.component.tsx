import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//developed
import GeneralError from '../../../general-error/general-error.component';
//consts
import * as styles from './temporarily-down-error.style';
import { ReactComponent as TemporarilyDownIcon } from '../../../../assets/icons/icons-group-general-settings.svg';

const TemporarilyDownError: FC = () => {
  return <GeneralError h1Contant="Sorry, we are temporarily down" h2Contant="We'll be back soon" Icon={TemporarilyDownIcon} iconStyle={styles.temporarilyDownIconStyle} />;
};

export default TemporarilyDownError;
