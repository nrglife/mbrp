/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

export const temporarilyDownIconStyle = css({
  width: '11.5rem',
  height: '12.8rem',
  marginBottom: '3.6rem',
  '@media (max-width: 900px)': {
    width: '8.5rem',
    height: '9.8rem'
  },
  '@media (max-width: 550px)': {
    width: '7.5rem',
    height: '8.8rem',
    marginBottom: '1rem'
  }
});
