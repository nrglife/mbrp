import { css } from '@emotion/core';
import { Preferences } from '../../stores/ThemeStore';

import { globalStyles } from '../../styles/global.styles';

export const modalContainer = css({
  padding: '0',
  paddingBottom: '20px',
  flex: '0 1 441px',
  width: '100%',
  alignItems: 'stretch',
  flexDirection: 'column',
  maxWidth: '650px',
  maxHeight: '500px',
  display: 'flex',
  borderRadius: '2px'
});

export const modalHeader = css({ justifySelf: 'flex-start', padding: '4.5rem 5rem' });

export const modalContent = css({ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, padding: '0 0rem', marginTop: '52px' });

export const modalTitleStyle = (theme: Preferences) =>
  css({
    fontFamily: theme?.font?.published,
    fontSize: '2rem',
    color: '#37474f',
    lineHeight: '3.2rem',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 500
  });

export const modalTextStyle = (theme: Preferences) =>
  css({
    fontFamily: theme?.font?.published,
    fontSize: '1.8rem',
    lineHeight: '2.2rem',
    color: '#37474f',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 'normal',
    whiteSpace: 'pre-line'
  });

export const closeButtonStyle = (theme: Preferences) =>
  css({
    backgroundColor: theme?.colors?.actionLight?.published,
    color: theme?.colors?.actionDark?.published,
    paddingLeft: '4.2rem',
    paddingRight: '4.2rem'
  });

export const xSign = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '58px'
});

export const text = css({
  fontSize: '1.8rem',
  fontWeight: 'normal',
  fontStretch: 'normal',
  lineHeight: 1.56,
  color: globalStyles.COLOR.greyishBrown,
  marginTop: '41px'
});

export const mainTitleStyle = color =>
  css({
    fontSize: '2.4rem',
    color: color,
    //lineHeight: '35px',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 500,
    whiteSpace: 'pre-line'
  });

  export const mainTitlebold = css({
    fontWeight: 'bold'
  });

export const modalMainContainerStyle = css({
  flex: 1,
  paddingBottom: '61px',
  flexDirection: 'column',
  justifyContent: 'space-between',
  overflow: 'auto'
});

export const titleContainerStyle = css({
  height: '13.3rem',
  width: '100%',
  flex: 1,
  flexDirection: 'column',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  '@media (max-width: 1000px)': {
    padding: '0 1.5rem'
  }
});
