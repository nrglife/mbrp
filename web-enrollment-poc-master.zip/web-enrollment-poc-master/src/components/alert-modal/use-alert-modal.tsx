import * as React from 'react';
/** @jsxImportSource @emotion/core */
import Modal from '../general/modal/modal.component';
import Button from '../general/button/button.component';

import { useStores } from '../../stores/useStores';
import { observer } from 'mobx-react';
import * as styles from './use-alert-modal.styles';

import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

const defaultStyle = {
  padding: '0 0',
  flex: 1,
  width: '100%',
  height: '100%',
  flexDirection: 'column',
  overflow: 'auto',
  display: 'flex',
  borderRadius: '2px'
};

export const useAlertModal = () => {
  const { themeStore, responsiveStore } = useStores();

  const selectedTheme = themeStore.currentTheme;

  const [alertModalVisibility, setAlertModalVisibility] = React.useState<{ isVisible: boolean; title: string; isTitleBold?: boolean; text: string; buttonText: string; showCloseButton: boolean }>({
    isVisible: false,
    title: '',
    isTitleBold: false,
    text: '',
    buttonText: 'OK',
    showCloseButton: true
  });

  const closeModal = () => {
    setAlertModalVisibility({ ...alertModalVisibility, isVisible: false });
  };

  const AlertModal = React.useCallback(
    observer(() => {
      const modalStyle = responsiveStore.isMobile ? defaultStyle : { ...defaultStyle, height: 'auto', maxWidth: '694px', maxHeight: '780px', minHeight: '0px', paddingBottom: 0 };

      return (
        <Modal modalStyle={modalStyle} open={alertModalVisibility.isVisible} onModalClose={() => {}} overlayStyle={{ padding: 0 }} closeButtonStyle={{ display: 'none' }} center>
          <div style={{ position: 'relative', overflow: 'auto' }}>
            <div style={{ position: 'absolute', width: '100%', textAlign: 'right', paddingTop: '5px', paddingRight: '5px' }}>
              {alertModalVisibility.showCloseButton ? <CloseIcon style={{ cursor: 'pointer' }} onClick={closeModal} /> : null}
            </div>
            <div css={styles.modalMainContainerStyle} tabIndex={0}>
              <div css={[{ backgroundColor: themeStore.currentTheme.colors.backgroundMedium.published }, styles.titleContainerStyle]}>
                <h1 css={[styles.mainTitleStyle(themeStore.currentTheme.colors.actionDark.published), alertModalVisibility.isTitleBold ? styles.mainTitlebold : '']}>{alertModalVisibility.title}</h1>
              </div>

              <div css={styles.modalContent}>
                <p css={styles.modalTextStyle(selectedTheme)}>{alertModalVisibility.text}</p>
                {alertModalVisibility.showCloseButton ? (
                  <div css={{ marginTop: '67px' }}>
                    <Button buttonStyle={styles.closeButtonStyle(selectedTheme)} text={alertModalVisibility.buttonText} onClick={closeModal} css={{ paddingLeft: '3.3rem' }} />
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </Modal>
      );
    }),
    [alertModalVisibility]
  );

  return { AlertModal, setAlertModalVisibility };
};
