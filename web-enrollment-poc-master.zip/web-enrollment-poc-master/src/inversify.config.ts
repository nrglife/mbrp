import 'reflect-metadata';
import { StorageServiceType, fillDefaultConfig } from './services';
import {
  IocContainer as commonContainer,
  IocTypes as IocTypesLocalCommon,
  ErrorStore as ErrorStoreCommon,
  ErrorStore as ErrorStoreCommonType,
  PayerStore as PayerStoreCommon,
  PayerStoreType as PayerStoreCommonType,
  ImageStoreType,
  ApiError,
  IStorageService,
  ITimeoutService,
  EnrollmentStore as EnrollmentStoreType,
  TimeoutServiceType,
  LinkedServicesListStoreType,
  LinkedServiceStoreType,
  PayerToPayerStoreType,
  FindCareStoreType,
  EOBListStoreType,
  EOBStoreType,
  MedicationRequestStoreType,
  ConditionsStoreType,
  AllergiesStoreType,
  EncountersStoreType,
  ImplantableDeviceStoreType,
  PayerDocumentsStoreType,
  EnrollmentApi as EnrollmentApiType,
  WhoAmIApi as WhoAmIApiType,
  ConsentApi as ConsentApiType,
  EOBSapi as EOBSapiType,
  LinkedServicesApi as LinkedServicesApiType,
  PayerToPayerApiType,
  AppConfigurationApi as AppConfigurationApiType,
  AppLocalesApi as AppLocalesApiType,
  DataServicesApi as DataServicesApiType,
  ProviderDirectoryServicesApi as ProviderDirectoryServicesApiType,
  ProceduresStoreType,
  ImmunizationsStoreType,
  I18nCommonType,
  ClinicalsOverviewStoreType
} from '@healthcareapp/connected-health-common-services';
import { UserStore, UserStore as UserStoreType } from 'stores/UserStore';
import { StorageStore as StorageStoreType } from 'stores/StorageStore';
import { AuthStoreType } from 'stores/AuthStore';
import { RoutesStoreType } from 'stores/RoutesStore';
import { NotificationModalStoreType } from 'stores/NotificationModalStore';
import { ThemeStoreType } from 'stores/ThemeStore';
import { ResponsiveStoreType } from 'stores/ResponsiveStore';
import { ErrorsStoreType } from 'stores/ErrorsStore';
import { ApiConfigsProvider, AuthProvider, ConsentDateProvider, ErrorStoreConfigProvider } from '@healthcareapp/connected-health-common-services/dist/services/apis/base-config';
import i18n from './i18n';

const IocTypes = {
  ...IocTypesLocalCommon,
  StorageStore: Symbol.for('StorageStoreLocal'),
  UserStore: Symbol.for('UserStoreLocal'),
  AuthStore: Symbol.for('AuthStoreLocal'),
  RoutesStore: Symbol.for('RoutesStoreLocal'),
  NotificationModalStore: Symbol.for('NotificationModalStoreLocal'),
  ResponsiveStore: Symbol.for('ResponsiveStoreLocal'),
  ErrorsStore: Symbol.for('ErrorsStoreLocal')
};

const IocContainer = commonContainer;

// Services

IocContainer.bind<ApiConfigsProvider>(IocTypes.ApiConfigsProvider).toConstantValue(() => {
  return {
    commonHeaders: {},
    connectionCheck: null,
    eobsApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_explanationOfBenefitApiUrl || '',
      maxEobs: parseInt((window as any)?.env?.REACT_APP_MAX_EOBS_PER_REQUEST || '150')
    }),
    whoAmIapi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_whoAmIServicesBaseUrl || ''
    }),
    enrollmentApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_SERVER_URL || '',
      apikey: (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID || ''
    }),
    consentApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_SERVER_URL || '',
      REACT_APP_ID_CONSENT: (window as any)?.env?.REACT_APP_ID_CONSENT || ''
    }),
    linkedServicesApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_linkedServicesBaseUrl || ''
    }),
    payerToPayerApi: {
      baseUrl: (window as any)?.env?.REACT_APP_SERVER_URL || ''
    },
    appConfigurationApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_SERVER_URL || '',
      apikey: (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID || ''
    }),
    appLocalesApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_SERVER_URL || '',
      apikey: (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID || ''
    }),
    dataServicesApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_dataServicesHCABaseUrl || '',
      XCHCClientId: (window as any)?.env?.REACT_APP_dataServicesHCAXChcClientID || ''
    }),
    providerDirectoryServicesApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_ProviderDirectoryBaseUrl || ''
    }),
    clinicalApi: fillDefaultConfig({
      baseUrl: (window as any)?.env?.REACT_APP_clinicalsApiUrl || '',
      maxItems: parseInt((window as any)?.env?.REACT_APP_MAX_CLINICAL_ITEMS_PER_REQUEST || '150')
    })
  };
});

IocContainer.bind<ErrorStoreConfigProvider>(IocTypes.ErrorStoreConfigProvider).toConstantValue(() => {
  return { disableLogging: false };
});

IocContainer.bind<I18nCommonType>(IocTypes.I18nProvider).toConstantValue(i18n);

IocContainer.bind<AuthProvider>(IocTypes.AuthProvider).toConstantValue(() => {
  return IocContainer.get<UserStore>(IocTypes.UserStore).storage.getValueByKey('token')?.accessToken;
});

IocContainer.bind<ConsentDateProvider>(IocTypes.ConsentDateProvider).toConstantValue(() => {
  return IocContainer.get<UserStore>(IocTypes.UserStore).storage.getValueByKey('token')?.consentDate;
});

IocContainer.bind<IStorageService>(IocTypes.StorageService).to(StorageServiceType);
IocContainer.bind<ITimeoutService>(IocTypes.ITimeoutService).to(TimeoutServiceType);

// Stores
IocContainer.bind<RoutesStoreType>(IocTypes.RoutesStore).to(RoutesStoreType).inSingletonScope();

IocContainer.bind<UserStoreType>(IocTypes.UserStore).to(UserStoreType);
IocContainer.bind<StorageStoreType>(IocTypes.StorageStore).to(StorageStoreType);
IocContainer.bind<EnrollmentStoreType>(IocTypes.EnrollmentStore).to(EnrollmentStoreType).inSingletonScope();
IocContainer.bind<AuthStoreType>(IocTypes.AuthStore).to(AuthStoreType).inSingletonScope();
IocContainer.bind<NotificationModalStoreType>(IocTypes.NotificationModalStore).to(NotificationModalStoreType).inSingletonScope();

IocContainer.bind<ThemeStoreType>(IocTypes.ThemeStore).to(ThemeStoreType).inSingletonScope();
IocContainer.bind<ResponsiveStoreType>(IocTypes.ResponsiveStore).to(ResponsiveStoreType).inSingletonScope();
IocContainer.bind<ErrorsStoreType>(IocTypes.ErrorsStore).to(ErrorsStoreType).inSingletonScope();

export type {
  IStorageService,
  ITimeoutService,
  EnrollmentApiType,
  EOBSapiType,
  WhoAmIApiType,
  ConsentApiType,
  LinkedServicesApiType,
  PayerToPayerApiType,
  AppConfigurationApiType,
  AppLocalesApiType,
  DataServicesApiType,
  ProviderDirectoryServicesApiType,
  ImageStoreType,
  ProceduresStoreType,
  PayerToPayerStoreType,
  PayerStoreCommonType,
  PayerDocumentsStoreType
};
export {
  EnrollmentStoreType,
  ErrorStoreCommonType,
  LinkedServicesListStoreType,
  LinkedServiceStoreType,
  FindCareStoreType,
  EOBListStoreType,
  EOBStoreType,
  MedicationRequestStoreType,
  ConditionsStoreType,
  AllergiesStoreType,
  EncountersStoreType,
  ImplantableDeviceStoreType,
  ImmunizationsStoreType,
  ClinicalsOverviewStoreType
};
export { IocContainer, IocTypes, ApiError };
