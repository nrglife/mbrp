import { StrictMode, Suspense } from 'react';
import App from 'App';
import createStores, { StoresContext } from 'stores';

import ErrorBoundary from 'components/error-boundary/error-boundary.component';
import LanguageProvider from 'components/language/language-provder.component';
import Loader from 'components/general/loader/loader.component';
import { globalStyles } from 'styles/global.styles';

export const AppRoot = ({ messages }) => (
  <ErrorBoundary>
    <StrictMode>
      <StoresContext.Provider value={createStores()}>
        <LanguageProvider messages={messages}>
          <Suspense fallback={<Loader loading={true} color={globalStyles.COLOR.slateGrey} backgroundColor={globalStyles.COLOR.white} position={'global'} />}>
            <App />
          </Suspense>
        </LanguageProvider>
      </StoresContext.Provider>
    </StrictMode>
  </ErrorBoundary>
);
