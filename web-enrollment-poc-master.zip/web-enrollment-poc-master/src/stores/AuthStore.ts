import { action, decorate } from 'mobx';
//Common Services
import { generateRandomNonce, tokenDecoder, ID_TOKEN_TYPE } from '@healthcareapp/connected-health-common-services/dist/utilities/Auth';
import { CIAM_CONFIG, DEFAULT_CONFIG, AUTH_DOMAINS } from './constants/auth';

import { RoutesStoreType } from './RoutesStore';
import { ThemeStoreType } from './ThemeStore';
import { StorageStoreType } from './StorageStore';
import { UserStoreType } from './UserStore';
import { getCookieValue, deleteCookie } from 'services/CookieService';
import { IocContainer, IocTypes, PayerStoreCommonType } from 'inversify.config';
import { injectable } from 'inversify';
import { failureSource, ErrorCode_CIAM, ErrorCode_TC_Get_Consent, AppConfigStoreType } from '@healthcareapp/connected-health-common-services';
import i18n from '../i18n';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { AuthErrors } from '../pages/auth';

export type hashResponse = { access_token?: string; id_token?: string; token_type?: string; expires_in?: number } & { error?: string; error_description?: string };
export type UserData = { isEnrolled: boolean | null; isConsent: boolean | null; consentDate?: string | null; hashResponse: hashResponse };

export type CIAM_SUCCESSFULL_RESPONSE = {
  isAuthenticated?: boolean;
  expiration?: number;
  accessToken?: string;
  idToken?: string;
  tokenType?: string;
};
@injectable()
class AuthStore {
  public timeouts: any = {};

  private get appConfigStore() {
    return IocContainer.get<AppConfigStoreType>(IocTypes.AppConfigStore);
  }

  public get storage() {
    return IocContainer.get<StorageStoreType>(IocTypes.StorageStore);
  }

  public get userStore() {
    return IocContainer.get<UserStoreType>(IocTypes.UserStore);
  }

  public get themeStore() {
    return IocContainer.get<ThemeStoreType>(IocTypes.ThemeStore);
  }

  public get payerStore() {
    return IocContainer.get<PayerStoreCommonType>(IocTypes.PayerStore);
  }

  public get routesStore() {
    return IocContainer.get<RoutesStoreType>(IocTypes.RoutesStore);
  }

  constructor() {
    this.initializeConfig({ CLIENT_ID: (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID });
  }
  private initializeConfig(config?: any) {
    this.storage.setItem('authConfig', Object.assign({}, this.getDefaults(), config));
  }

  private getDefaults(): CIAM_CONFIG {
    const origin = window.location.origin;

    return Object.assign({}, DEFAULT_CONFIG, { IMPLICIT_REDIRECT_URI: `${origin}/auth`, IMPLICIT_SILENT_REDIRECT_URI: `${origin}/auth` });
  }
  // used by gotoPingLogin with no argument, by updateTokenSilently with `silent` as `true`
  private generateCiamImplicitFlowUri(nonce: string, silent: boolean = false) {
    const authConfig = this.storage.getValueByKey('authConfig');
    const redirectUri = silent ? authConfig.IMPLICIT_SILENT_REDIRECT_URI : authConfig.IMPLICIT_REDIRECT_URI;

    const params = Object.assign(
      {},
      {
        client_id: authConfig.CLIENT_ID,
        response_type: authConfig.RESPONSE_TYPE,
        redirect_uri: redirectUri,
        scope: authConfig.SCOPE,
        nonce
      },
      silent ? { prompt: 'none' } : {}
    );

    return this.constractUri(authConfig.URL, params);
  }

  private generateCiamCodeFlowUri(nonce: string) {
    const authConfig = this.storage.getValueByKey('authConfig');

    const params = {
      response_type: 'code',
      scope: 'openid profile',
      nonce,
      client_id: (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID,
      redirect_uri: authConfig.CODEFLOW_REDIRECT_URI
    };

    return this.constractUri(authConfig.URL, params);
  }

  private constractUri(url: string, queryParamsObject: object) {
    const query = Object.keys(queryParamsObject)
      .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(queryParamsObject[k])}`)
      .join('&');
    return `${url}?${query}`;
  }

  RedirectToCIAMLogin() {
    // save the url we want to go back to after a successfull redirect
    const nonce = this.storage.getValueByKey('nonce') || generateRandomNonce(15);
    this.storage.setItem('nonce', nonce);
    this.storage.setItem('targetLocation', `${window.location.origin}/${this.routesStore.payer ? this.routesStore.payer : ''}`);
    this.storage.setItem('payerShortName', this.payerStore.payer?.shortName);
    this.storage.setItem('payerId', `${this.payerStore.payer?.shortName ? this.payerStore.payer.guid : ''}`);
    this.storage.setItem('theme', JSON.stringify(this.themeStore.currentTheme));
    this.storage.setItem('useSessionData', true);

    // redirect to CIAM
    if (this.appConfigStore.currentConfig.useAuthCodeFlow) {
      window.location.href = this.generateCiamCodeFlowUri(nonce);
    } else {
      window.location.href = this.generateCiamImplicitFlowUri(nonce);
    }
  }

  private validateIssuerClaim(token: ID_TOKEN_TYPE | null): boolean {
    const issuer = AUTH_DOMAINS[(window as any)?.env?.REACT_APP_ENV ? (window as any)?.env?.REACT_APP_ENV : 'development'];
    return token?.iss === issuer;
  }

  private validateAudienceClaim(token: ID_TOKEN_TYPE | null): boolean {
    const clientId = (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID ? (window as any)?.env?.REACT_APP_CIAM_CLIENT_ID : '';
    return token?.aud === clientId;
  }

  private validateNonce(token: ID_TOKEN_TYPE | null): boolean {
    const nonce = this.storage.getValueByKey('nonce') || '';
    return token?.nonce === nonce.toString();
  }

  private isValidApp(token: ID_TOKEN_TYPE): boolean {
    let isValid;

    if (Array.isArray(token.apps)) {
      isValid = token.apps.some(app => app.cmdbid === DEFAULT_CONFIG.CMDBID);
    } else {
      isValid = token.apps.cmdbid === DEFAULT_CONFIG.CMDBID;
    }

    return isValid;
  }

  private validateAllowedApplications(token: ID_TOKEN_TYPE | null): boolean {
    // This code should be used to validate user's allowed apps

    return !!token?.roles;
  }

  private getTokenFromHashParams(hashParams: any): ID_TOKEN_TYPE | null {
    let token;
    try {
      token = hashParams.id_token ? tokenDecoder(hashParams.id_token) : null;
    } catch (error) {
      token = null;
    }
    return token;
  }

  public isHashAuthenticated(hashParams: any): { errorSource: failureSource | null; errorCode: number | null } {
    const token: ID_TOKEN_TYPE | null = this.getTokenFromHashParams(hashParams);

    if (!token)
      return {
        errorSource: failureSource.CIAM,
        errorCode: ErrorCode_CIAM.NO_TOKEN //452 - CIAM with no token
      };

    if (!this.validateNonce(token))
      return {
        errorSource: failureSource.CIAM,
        errorCode: ErrorCode_CIAM.VALIDATE_NONCE //453 - CIAM validateNonce
      };

    if (!this.validateAudienceClaim(token))
      return {
        errorSource: failureSource.CIAM,
        errorCode: ErrorCode_CIAM.VALIDATE_AUDIENCE_CLAIM //454 - CIAM validateAudienceClaim
      };

    if (!this.validateIssuerClaim(token))
      return {
        errorSource: failureSource.CIAM,
        errorCode: ErrorCode_CIAM.VALIDATE_ISSUER_CLAIM //455 - CIAM validateIssuerClaim
      };

    if (!this.isValidApp(token))
      return {
        errorSource: failureSource.CIAM,
        errorCode: ErrorCode_CIAM.IS_VALID_APP //456 - CIAM isValidApp
      };

    return {
      errorSource: null,
      errorCode: null
    };
  }

  public getAndDeleteAccessTokenCookie() {
    let accessTokenCookie;

    if (this.appConfigStore.currentConfig.useAuthCodeFlow !== false) {
      let cookieValue = getCookieValue('accessToken');

      if (cookieValue) {
        cookieValue = JSON.parse(cookieValue);

        //commented out because we check it later in the flow
        // if (this.validateNonce(this.getTokenFromHashParams(cookieValue))) {
        accessTokenCookie = cookieValue;
        // }
      }
    }

    const accessTokenCookieDomain = (window as any)?.env?.REACT_APP_AUTH_COOKIE_TOP_COMMON_DOMAIN;
    deleteCookie({ name: 'accessToken', path: '/auth', domain: accessTokenCookieDomain });

    return accessTokenCookie;
  }

  public isUserAuthenticated(role: any = {}) {
    let authenticated = false;
    const token = this.storage.getValueByKey('token');

    if (!token) {
      return authenticated;
    }

    // const user: IUSER | null = this.userStore.currentUser;
    // const validRoles = role ? !!user.roles && user.roles.includes(role) : !!user.roles;
    const expired = Date.now() > token.expiration;

    if (token.isAuthenticated && !expired) {
      authenticated = true;
    } else {
      // TODO: Removing things here could break things, depending on what the app does if not authenticated
      this.logout();
    }

    return authenticated;
  }

  public removeUserStorageKeys() {
    //this.storage.removeItemByKey('useSessionData');
    this.storage.removeItemByKey('authConfig');
    this.storage.removeItemByKey('nonce');
    this.storage.removeItemByKey('token');
    // this.storage.removeItemByKey('theme');
    // this.storage.removeItemByKey('payerId');
    //this.storage.removeItemByKey('payerShortName');
    // this.storage.removeItemByKey('light_img');
    //this.storage.removeItemByKey('dark_img');
    // this.storage.removeItemByKey('landing_img');
    // this.storage.removeItemByKey('targetLocation');
  }

  public removePayerStorageKeys() {
    this.storage.removeItemByKey('useSessionData');
    // this.storage.removeItemByKey('authConfig');
    // this.storage.removeItemByKey('nonce');
    // this.storage.removeItemByKey('token');
    this.storage.removeItemByKey('theme');
    this.storage.removeItemByKey('payerId');
    this.storage.removeItemByKey('payerShortName');
    this.storage.removeItemByKey('light_img');
    this.storage.removeItemByKey('dark_img');
    this.storage.removeItemByKey('landing_img');
    this.storage.removeItemByKey('targetLocation');
  }

  public logout(openInNewTab: boolean = true) {
    this.userStore.setIsLoading(true);
    const authConfig = this.storage.getValueByKey('authConfig');
    this.removeUserStorageKeys();
    openInNewTab ? this.logoutInNewTab(authConfig?.LOGOUT_URI) : (window.location.href = authConfig?.LOGOUT_URI);
  }

  private logoutInNewTab(logoutUri: string) {
    if (!!logoutUri) window.open(logoutUri, '_blank')?.focus();
    this.storage.setItem('useSessionData', true);

    const targetLocation = this.storage.getValueByKey('targetLocation');

    if (targetLocation) {
      window.location.href = targetLocation;
    } else {
      window.location.reload();
    }
  }
  public setAuthTimeouts(promptCallback: (promptTimer: number) => void, expirationCallback: (expirationTimer: number) => void, timerInMinutes: number = 1) {
    const expiration = this.storage.getValueByKey('token')?.expiration;

    // time difference in ms, if 0 or negative will fire right away
    // actual timer that wll be fired when the access token gets expired
    const expirationTimer = Math.max(expiration - Date.now(), 0);

    // timer that wll be fired timerInMinutes before the access token expires
    const promptTimer = Math.max(expiration - Date.now() - timerInMinutes * 60 * 1000, 0);

    // clear any existing auth timeouts
    // specifically used to reset timers during silent refresh
    this.clearAuthTimeouts();

    // expiration timeout
    if (!isNaN(expirationTimer)) {
      this.timeouts.expirationTimeout = setTimeout(() => {
        expirationCallback && expirationCallback(expirationTimer);
      }, expirationTimer);
    }

    // prompt timeout
    if (!isNaN(promptTimer)) {
      this.timeouts.promptTimeout = setTimeout(() => {
        promptCallback && promptCallback(promptTimer);
      }, promptTimer);
    }
  }

  private clearAuthTimeouts = () => {
    if (this.timeouts.expirationTimeout) {
      window.clearTimeout(this.timeouts.expirationTimeout);
    }
    if (this.timeouts.promptTimeout) {
      window.clearTimeout(this.timeouts.promptTimeout);
    }
  };
}

decorate(AuthStore, {
  RedirectToCIAMLogin: action
});

export { AuthStore, AuthStore as AuthStoreType };
