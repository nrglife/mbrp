import { useContext } from 'react';
import { StoresContext, Stores } from './index';

export const useStores = () => useContext<Stores>(StoresContext);
