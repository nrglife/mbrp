import { observable, action, decorate } from 'mobx';
import { IocContainer, ITimeoutService } from '@healthcareapp/connected-health-common-services';
import { injectable } from 'inversify';
import { IocTypes } from 'inversify.config';
@injectable()
class NotificationModalStore {
  public showModal: boolean;
  public modalTitle: string;
  public modalText: string;

  public timeoutStore = IocContainer.get<ITimeoutService>(IocTypes.ITimeoutService);

  constructor() {
    this.showModal = false;
    this.modalText = '';
    this.modalTitle = '';
  }

  public setModalVisibility(show: boolean, title: string = '', text: string = '') {
    this.showModal = show;
    this.modalTitle = show ? title : this.modalTitle;
    this.modalText = show ? text : this.modalText;

    if (!show) {
      this.timeoutStore.setTimeout(
        'NotificationTimout',
        () => {
          this.resetModalContent();
        },
        400
      );
    }
  }

  resetModalContent() {
    this.modalTitle = '';
    this.modalText = '';
  }
}

decorate(NotificationModalStore, {
  showModal: observable,

  resetModalContent: action,
  setModalVisibility: action
});

export { NotificationModalStore, NotificationModalStore as NotificationModalStoreType };
