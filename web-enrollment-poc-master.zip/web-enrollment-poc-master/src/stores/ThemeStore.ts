import { observable, action, computed, decorate, runInAction } from 'mobx';
import { injectable } from 'inversify';
import { IocContainer, IocTypes, IStorageService, DataServicesApiType } from '../inversify.config';
import { ThemeStoreHandler } from 'stores';
import { HTTP_STATUS_CODES } from '../services';
import { ErrorsStoreType } from './ErrorsStore';

enum Category {
  //  Draft = 'draft',
  Published = 'published'
}

export type Categories = Category.Published;

export type ColorsPreferences = 'actionDark' | 'actionLight' | 'actionMedium' | 'backgroundDark' | 'backgroundLight' | 'backgroundMedium';

export interface Preferences {
  colors: Record<ColorsPreferences, Record<Categories, string>>;
  font: Record<Categories, string>;
}

const DEFAULT_THEME: Preferences = {
  colors: {
    actionDark: {
      published: '#0F0F59'
    },
    actionLight: {
      published: '#82D8FF'
    },
    actionMedium: {
      published: '#1188C1'
    },
    backgroundDark: {
      published: '#0F4E6D'
    },
    backgroundLight: {
      published: '#F2F8FA'
    },
    backgroundMedium: {
      published: '#E1EDF1'
    }
  },
  font: {
    published: 'Arial'
  }
};
@injectable()
class ThemeStore implements ThemeStoreHandler {
  public theme: Preferences = DEFAULT_THEME;
  public loading: boolean = true;

  public get errorsStore() {
    return IocContainer.get<ErrorsStoreType>(IocTypes.ErrorsStore);
  }

  private dataServicesApi = IocContainer.get<DataServicesApiType>(IocTypes.DataServicesApi);

  storageService = IocContainer.get<IStorageService>(IocTypes.StorageService);

  async loadPayerThemeRemote(payerId?: string) {
    try {
      if (payerId && payerId !== '') {
        this.loading = true;
        const response = await this.dataServicesApi.getPreferenceListByPayerId({ payerId, stage: 'published' });

        runInAction(() => {
          // check we got the theme obj from the server
          const isDataExist = response?.status === HTTP_STATUS_CODES.SUCCESS && typeof response.data === 'object' && Object.keys(response.data).length > 0;
          //check if one of the clors in the theme data not exist
          const responseColorsArray: { published?: string | null | undefined }[] = isDataExist && response.data?.colors ? Object.values(response.data?.colors) : [{}];
          const isAllColorsExist = !responseColorsArray.some(color => color.published == null || color.published === '');

          this.setCurrentTheme(isAllColorsExist ? response.data : DEFAULT_THEME);
          this.loading = false;
        });
      } else {
        this.loading = false;
        console.log('Payer data is not found - using default theme');
      }
    } catch (err) {
      runInAction(() => {
        // will use default theme
        this.loading = false;
        this.theme = DEFAULT_THEME;
      });
    }
  }

  async loadPayerTheme(payerId: string | undefined, useCache: boolean) {
    const theme = this.storageService.getValueByKey('theme');
    const themePayerId = this.storageService.getValueByKey('payerId');

    /*use cache only in case if requested to use cache and the payer id is not the original payer id prom landing page */
    if (useCache && themePayerId == payerId && theme) {
      runInAction(() => {
        this.theme = JSON.parse(theme);
        this.loading = false;
      });
    } else {
      return this.loadPayerThemeRemote(payerId);
    }
  }

  setCurrentTheme(theme: Preferences) {
    this.theme = theme;
  }

  setIsLoading(loading: boolean) {
    this.loading = loading;
  }

  resetStore() {
    this.theme = DEFAULT_THEME;
  }

  get currentTheme() {
    return this.theme;
  }

  get isLoading() {
    return this.loading;
  }
}

decorate(ThemeStore, {
  loading: observable,
  theme: observable,

  currentTheme: computed,
  isLoading: computed,

  loadPayerTheme: action,
  resetStore: action,
  setIsLoading: action,
  setCurrentTheme: action
});

export { ThemeStore, ThemeStore as ThemeStoreType };
