import { injectable } from 'inversify';
import instance, { WebStorageManager } from '../utils/webstorage-manager';
@injectable()
class StorageStore {
  private storage: WebStorageManager = instance;

  public getValueByKey(key: string) {
    return this.storage.getValue(key);
  }

  public setItem(key: string, value: any) {
    this.storage.add(key, value);
  }

  public removeItemByKey(key: string) {
    this.storage.remove(key);
  }
}

export { StorageStore, StorageStore as StorageStoreType };
