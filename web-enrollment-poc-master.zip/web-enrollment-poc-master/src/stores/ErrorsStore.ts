import { injectable } from 'inversify';
import { observable, action, decorate } from 'mobx';

export enum ErrorBoundaryTypes {
  TEMPORARILY_DOWN = 'TEMPORARILY_DOWN'
}
@injectable()
class ErrorsStore {
  public errorType: ErrorBoundaryTypes | null;
  public isError: boolean;

  constructor() {
    this.errorType = null;
    this.isError = false;
  }

  setError(isError: boolean, errorType: ErrorBoundaryTypes | null = null) {
    this.isError = isError;
    this.errorType = errorType;
  }
}

decorate(ErrorsStore, {
  isError: observable,
  errorType: observable,

  setError: action
});

export { ErrorsStore, ErrorsStore as ErrorsStoreType };
