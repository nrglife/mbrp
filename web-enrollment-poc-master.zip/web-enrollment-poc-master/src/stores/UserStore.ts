import { observable, action, computed, decorate } from 'mobx';
import { StorageStore as StorageStoreType } from './StorageStore';

import { cloneDeep } from 'lodash';
import { hashResponse, CIAM_SUCCESSFULL_RESPONSE, UserData } from './AuthStore';
//CommonServices
import { tokenDecoder, ADDRESS, APPS, COMPANY, ID_TOKEN_TYPE, PHONE_NUMBERES } from '@healthcareapp/connected-health-common-services/dist/utilities/Auth';
import { injectable } from 'inversify';
import { IocContainer, IocTypes } from 'inversify.config';

export interface IUSER {
  address: ADDRESS;
  phone_numbers: PHONE_NUMBERES;
  roles: string;
  photo: string;
  company: COMPANY;
  given_name: string;
  family_name: string;
  email: string;
  apps: APPS[] | APPS;
  auth_time: number;
}

@injectable()
class UserStore {
  public user: IUSER | null;
  public loading: boolean;
  public isEnrolled: boolean | null;
  public isConsent: boolean | null;
  public contractId: string | null;
  public contractHtml: string | null;
  public showConsentErrorModal: boolean;
  public modalMessage: string;

  public get storage() {
    return IocContainer.get<StorageStoreType>(IocTypes.StorageStore);
  }

  constructor() {
    this.loading = true;
    this.user = null;
    this.isEnrolled = null;
    this.isConsent = null;
    this.contractId = null;
    this.contractHtml = null;
    this.showConsentErrorModal = false;
    this.modalMessage = '';
  }

  public tryLoadUserFromToken() {
    try {
      console.log('Start loading user data if exists ');
      this.loading = true;
      const token = this.storage.getValueByKey('token') || null;

      if (!token || !token.idToken) {
        this.loading = false;
        return null;
      }

      const decoded: ID_TOKEN_TYPE | null = tokenDecoder(token.idToken);
      this.setUser(this.parseIdTokenIntoUser(decoded), token.isEnrolled, token.isConsent);

      this.loading = false;
    } catch (err) {
      console.log('ERROR LOADING USER');
    } finally {
      console.log('End loading user data ');
    }
  }

  public setUserToken(userData: UserData) {
    const hash = this.parseToken(userData.hashResponse);
    const dataToStore = userData ? { isEnrolled: userData.isEnrolled, isConsent: userData.isConsent, consentDate: userData.consentDate, ...hash } : null;
    this.storage.setItem('token', dataToStore);
    const decoded: ID_TOKEN_TYPE | null = tokenDecoder(userData.hashResponse.id_token);
    this.setUser(this.parseIdTokenIntoUser(decoded), userData.isEnrolled, userData.isConsent);
  }

  public updateUserTokenConsent(isConsent: boolean | null) {
    const currentTokenData = this.storage.getValueByKey('token');
    const consentDate = new Date().toISOString();

    const updatedData = { ...currentTokenData, isConsent, consentDate };

    this.storage.setItem('token', updatedData);

    this.setIsConsent(isConsent);
  }

  public setUser(user: IUSER | null, isEnrolled: boolean | null, isConsent: boolean | null) {
    this.user = user;
    this.setIsEnrolled(isEnrolled);
    this.setIsConsent(isConsent);
  }

  public getUserFromToken() {
    const idToken = this.storage.getValueByKey('token')?.idToken;

    const decoded: ID_TOKEN_TYPE | null = tokenDecoder(idToken);
    return this.parseIdTokenIntoUser(decoded);
  }

  public setIsEnrolled(isEnrolled: boolean | null) {
    this.isEnrolled = isEnrolled;
  }

  public setIsConsent(isConsent: boolean | null) {
    this.isConsent = isConsent;
  }

  public setIsLoading(isLoading: boolean) {
    this.loading = isLoading;
  }

  public setContractId(contractId: string | null) {
    this.contractId = contractId;
  }

  public setContractHtml(contractHtml: string | null) {
    this.contractHtml = contractHtml;
  }

  public get userContractHtml() {
    return this.contractHtml;
  }

  public get isLoading() {
    return this.loading;
  }

  public get currentUser() {
    return this.user;
  }

  public get isUserLoggedInApproved() {
    return this.user && this.isConsent === true && this.isEnrolled === true;
  }

  private parseToken(token: hashResponse): CIAM_SUCCESSFULL_RESPONSE {
    const tokenProps: CIAM_SUCCESSFULL_RESPONSE = {};
    const accessToken: ID_TOKEN_TYPE | null = tokenDecoder(token.access_token);
    tokenProps.isAuthenticated = true;
    tokenProps.expiration = accessToken?.exp * 1000;
    tokenProps.accessToken = token.access_token;
    tokenProps.idToken = token.id_token;
    tokenProps.tokenType = token.token_type;
    return tokenProps;
  }

  private parseIdTokenIntoUser(idToken: ID_TOKEN_TYPE | null): IUSER | null {
    if (!idToken) return null;
    const user = cloneDeep(idToken);
    return {
      address: user.address,
      phone_numbers: user.phone_numbers,
      roles: user.roles,
      photo: user.photo,
      company: user.company,
      given_name: user.given_name,
      family_name: user.family_name,
      email: user.email,
      apps: user.apps,
      auth_time: user.auth_time
    };
  }
}

decorate(UserStore, {
  loading: observable,
  user: observable,
  isEnrolled: observable,
  isConsent: observable,
  contractId: observable,
  contractHtml: observable,
  showConsentErrorModal: observable,
  //actions
  setIsLoading: action,
  tryLoadUserFromToken: action,
  setUser: action,
  setIsEnrolled: action,
  setIsConsent: action,
  setContractId: action,
  setContractHtml: action,
  updateUserTokenConsent: action,
  //computed
  currentUser: computed,
  isUserLoggedInApproved: computed,
  isLoading: computed
});

export { UserStore, UserStore as UserStoreType };
