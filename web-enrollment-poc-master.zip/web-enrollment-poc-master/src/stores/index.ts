import { createContext } from 'react';
import {
  IocContainer,
  IocTypes,
  EnrollmentStoreType,
  LinkedServicesListStoreType,
  PayerToPayerStoreType,
  FindCareStoreType,
  EOBListStoreType,
  ErrorStoreCommonType,
  PayerStoreCommonType,
  ImageStoreType,
  ConditionsStoreType,
  MedicationRequestStoreType,
  ImplantableDeviceStoreType,
  AllergiesStoreType,
  EncountersStoreType,
  PayerDocumentsStoreType,
  ProceduresStoreType,
  ImmunizationsStoreType,
  ClinicalsOverviewStoreType
} from './../inversify.config';
import {
  StoreRequestStatus,
  AppConfigStoreType,
  EnrollmentSteps,
  EnrollmentContext,
  EnrollmentOrigin,
  EnrollmentType,
  PersonalSecretIdentifier,
  WhoAmIStoreType,
  ThemeStoreHandler,
  LogoType,
  ImageState,
  Image,
  PayerItem, // P2P
  Request_Record,
  LabObservationStoreType // P2P
} from '@healthcareapp/connected-health-common-services';

import { UserStoreType } from './UserStore';
import { AuthStoreType } from './AuthStore';
import { RoutesStoreType } from './RoutesStore';
import { NotificationModalStoreType } from './NotificationModalStore';

import { StorageStore as StorageStoreType } from './StorageStore';
import { ThemeStore as ThemeStoreType } from './ThemeStore';
import { ResponsiveStoreType } from './ResponsiveStore';
import { ErrorsStoreType } from './ErrorsStore';
import { DelegateStoreType } from '@healthcareapp/connected-health-common-services/dist/stores';

const createStores = (): Stores => {
  const stores: Stores = {
    authStore: IocContainer.get<AuthStoreType>(IocTypes.AuthStore),
    routesStore: IocContainer.get<RoutesStoreType>(IocTypes.RoutesStore),
    imageStore: IocContainer.get<ImageStoreType>(IocTypes.ImageStore),
    notificationModalStore: IocContainer.get<NotificationModalStoreType>(IocTypes.NotificationModalStore),
    appConfigStore: IocContainer.get<AppConfigStoreType>(IocTypes.AppConfigStore),
    payerDocumentsStore: IocContainer.get<PayerDocumentsStoreType>(IocTypes.PayerDocumentsStore),
    themeStore: IocContainer.get<ThemeStoreType>(IocTypes.ThemeStore),
    responsiveStore: IocContainer.get<ResponsiveStoreType>(IocTypes.ResponsiveStore),
    enrollmentStore: IocContainer.get<EnrollmentStoreType>(IocTypes.EnrollmentStore),
    linkedServicesStore: IocContainer.get<LinkedServicesListStoreType>(IocTypes.LinkedServicesListStore),
    payerToPayerStore: IocContainer.get<PayerToPayerStoreType>(IocTypes.PayerToPayerStore),
    findCareStore: IocContainer.get<FindCareStoreType>(IocTypes.FindCareStore),
    eobListStore: IocContainer.get<EOBListStoreType>(IocTypes.EOBListStore),
    storageStore: IocContainer.get<StorageStoreType>(IocTypes.StorageStore),
    userStore: IocContainer.get<UserStoreType>(IocTypes.UserStore),
    errorsStore: IocContainer.get<ErrorsStoreType>(IocTypes.ErrorsStore),
    errorStoreCommon: IocContainer.get<ErrorStoreCommonType>(IocTypes.ErrorStore),
    conditionsStore: IocContainer.get<ConditionsStoreType>(IocTypes.ConditionsStore),
    payerStore: IocContainer.get<PayerStoreCommonType>(IocTypes.PayerStore),
    medicationRequestStore: IocContainer.get<MedicationRequestStoreType>(IocTypes.MedicationRequestStore),
    AllergiesStore: IocContainer.get<AllergiesStoreType>(IocTypes.AllergiesStore),
    EncountersStore: IocContainer.get<EncountersStoreType>(IocTypes.EncountersStore),
    implantableDeviceStore: IocContainer.get<ImplantableDeviceStoreType>(IocTypes.ImplantableDeviceStore),
    proceduresStore: IocContainer.get<ProceduresStoreType>(IocTypes.ProceduresStore),
    immunizationsStore: IocContainer.get<ImmunizationsStoreType>(IocTypes.ImmunizationsStore),
    whoAmIStore: IocContainer.get<WhoAmIStoreType>(IocTypes.WhoAmIStore),
    delegateStore: IocContainer.get<DelegateStoreType>(IocTypes.DelegateStore),
    labObservationStore: IocContainer.get<LabObservationStoreType>(IocTypes.LabObservationStore),
    clinicalsOverviewStore: IocContainer.get<ClinicalsOverviewStoreType>(IocTypes.ClinicalsOverviewStore)
  };

  return stores;
};

export interface Stores {
  enrollmentStore: EnrollmentStoreType;
  userStore: UserStoreType;
  authStore: AuthStoreType;
  routesStore: RoutesStoreType;
  themeStore: ThemeStoreType;
  imageStore: ImageStoreType;
  storageStore: StorageStoreType;
  notificationModalStore: NotificationModalStoreType;
  appConfigStore: AppConfigStoreType;
  payerDocumentsStore: PayerDocumentsStoreType;
  eobListStore: EOBListStoreType;
  linkedServicesStore: LinkedServicesListStoreType;
  payerToPayerStore: PayerToPayerStoreType;
  findCareStore: FindCareStoreType;
  responsiveStore: ResponsiveStoreType;
  errorsStore: ErrorsStoreType;
  errorStoreCommon: ErrorStoreCommonType;
  payerStore: PayerStoreCommonType;
  medicationRequestStore: MedicationRequestStoreType;
  conditionsStore: ConditionsStoreType;
  AllergiesStore: AllergiesStoreType;
  EncountersStore: EncountersStoreType;
  implantableDeviceStore: ImplantableDeviceStoreType;
  proceduresStore: ProceduresStoreType;
  immunizationsStore: ImmunizationsStoreType;
  whoAmIStore: WhoAmIStoreType;
  delegateStore: DelegateStoreType;
  labObservationStore: LabObservationStoreType;
  clinicalsOverviewStore: ClinicalsOverviewStoreType;
}

const defaultValue = {} as any;
export const StoresContext = createContext<Stores>(defaultValue);

export default () => createStores();

export { StoreRequestStatus, EnrollmentStoreType, EnrollmentSteps, EnrollmentOrigin, EnrollmentType, PersonalSecretIdentifier, ImageState };
export type { EnrollmentContext, ThemeStoreHandler, LogoType, Image, PayerItem, Request_Record };
