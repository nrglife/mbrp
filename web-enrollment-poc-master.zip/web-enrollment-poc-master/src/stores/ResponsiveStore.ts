import { injectable } from 'inversify';
import debounce from 'lodash/debounce';
import { observable, action, decorate } from 'mobx';

const tabletScreenSizeThreshold = 991;
const mobileScreenSizeThreshold = 767;
@injectable()
class ResponsiveStore {
  public isTablet: boolean;
  public isMobile: boolean;
  public innerWidth: number;
  public removeScrollbar: boolean;

  constructor() {
    this.isTablet = window.innerWidth <= tabletScreenSizeThreshold;
    this.isMobile = window.innerWidth <= mobileScreenSizeThreshold;
    this.innerWidth = window.innerWidth;
    this.removeScrollbar = false;
    window.addEventListener('resize', this.checkSize.bind(this));
  }

  private checkSize() {
    this.setIsTablet.bind(this)(window.innerWidth <= tabletScreenSizeThreshold);
    this.setIsMobile.bind(this)(window.innerWidth <= mobileScreenSizeThreshold);
    this.setInnerWidthDebounce.bind(this)();
  }

  private setInnerWidthDebounce = debounce(() => {
    this.setInnerWidth.bind(this)(window.innerWidth);
  }, 100);

  public setIsTablet(flag: boolean) {
    this.isTablet = flag;
  }

  public setIsMobile(flag: boolean) {
    this.isMobile = flag;
  }

  public setInnerWidth(innerWidth: number): any {
    this.innerWidth = innerWidth;
  }

  public setRemoveScrollbar(flag: boolean) {
    this.removeScrollbar = flag;
  }
}

decorate(ResponsiveStore, {
  isTablet: observable,
  isMobile: observable,
  innerWidth: observable,
  removeScrollbar: observable,

  setIsTablet: action,
  setIsMobile: action,
  setInnerWidth: action,
  setRemoveScrollbar: action
});

export { ResponsiveStore as ResponsiveStoreType };
