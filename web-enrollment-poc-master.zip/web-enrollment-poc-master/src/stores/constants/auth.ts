export enum AUTH_DOMAINS {
  development = 'https://sso-test.changehealthcare.com',
  qa = 'https://sso-test.changehealthcare.com',
  testing = 'https://sso-test.changehealthcare.com',
  cert = 'https://sso-cert.changehealthcare.com',
  production = 'https://sso.changehealthcare.com'
}

export type CIAM_CONFIG = {
  RESPONSE_TYPE: string;
  IMPLICIT_REDIRECT_URI: string;
  IMPLICIT_SILENT_REDIRECT_URI: string;
  CODEFLOW_REDIRECT_URI: string;
  SCOPE: string;
  URL: string;
  SERVER: string;
  LOGOUT_URI: string;
  CMDBID: string;
};

export type CIAM_AUTH_REQUEST_CONFIG = {
  client_id: string;
  response_type: string;
  redirect_uri: string;
  scope: string;
  nonce?: string;
};

export const DEFAULT_CONFIG: CIAM_CONFIG = {
  RESPONSE_TYPE: 'token id_token',
  IMPLICIT_REDIRECT_URI: `http://localhost:5020/auth`,
  IMPLICIT_SILENT_REDIRECT_URI: `http://localhost:5020/auth`,
  CODEFLOW_REDIRECT_URI: `${(window as any)?.env?.REACT_APP_SERVER_URL}/authCodeFlow?apikey=CIAM-${(window as any)?.env?.REACT_APP_CIAM_CLIENT_ID}`,
  SCOPE: 'profile openid',
  URL: `${AUTH_DOMAINS[(window as any)?.env?.REACT_APP_ENV ? (window as any)?.env?.REACT_APP_ENV : 'development']}/as/authorization.oauth2`,
  SERVER: `${AUTH_DOMAINS[(window as any)?.env?.REACT_APP_ENV ? (window as any)?.env?.REACT_APP_ENV : 'development']}/ext/sso`,
  LOGOUT_URI: `${AUTH_DOMAINS[(window as any)?.env?.REACT_APP_ENV ? (window as any)?.env?.REACT_APP_ENV : 'development']}/idp/startSLO.ping`,
  CMDBID: '2276'
};

export const POSSIBLE_RANDOM_STRING = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
