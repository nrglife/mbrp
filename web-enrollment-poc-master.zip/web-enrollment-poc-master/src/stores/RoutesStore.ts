import { observable, action, computed, decorate } from 'mobx';
import { injectable } from 'inversify';
import { StoreRequestStatus } from 'stores';
import { PayerStoreFeatures } from '@healthcareapp/connected-health-common-services/dist/stores/PayerStore';

export enum screens {
  landing = 'landing',
  consent = 'consent',
  eobs = 'eobs',
  eobDetails = 'eobDetails',
  findCare = 'findcare',
  help = 'help',
  contactUs = 'contactUs',
  profileAndSettings = 'profileAndSettings',
  overview = 'overview',
  linkedServices = 'linkedServices',
  linkedServicesFindApps = 'linkedServicesFindApps',
  linkedServicesRequests = 'linkedServicesRequests',
  linkedServicesRequestsDetails = 'linkedServicesRequestsDetails',
  home = 'home',
  appointments = 'appointments',
  healthProfile = 'healthProfile',
  clinicalsOverview = 'clinicalsOverview',
  medications = 'medications',
  problemsAndConditions = 'problemsAndConditions',
  allergiesAndIntolerances = 'allergiesAndIntolerances',
  medicalImplants = 'medicalImplants',
  procedures = 'procedures',
  labObservations = 'labObservations',
  visits = 'visits',
  vaccinations = 'vaccinations',
  careTeam = 'careTeam'
}

export enum payerConfigOptions {
  featuresToHide = 'featuresToHide'
}

export enum RouteName {
  any = 'any',
  landing = 'landing',
  //auth: string;
  //login: string;
  consent = 'consent',
  /// home page redirects
  home = 'home',
  findCare = 'findCare',
  findCareServices = 'findCareServices',
  findCareSpecialties = 'findCareSpecialties',
  findCarePractitioners = 'findCarePractitioners',
  findCareOrganizations = 'findCareOrganizations',
  eobs = 'eobs',
  eobDetails = 'eobDetails',
  appointments = 'appointments',
  healthProfile = 'healthProfile',
  clinicalsOverview = 'clinicalsOverview',
  medications = 'medications',
  problemsAndConditions = 'problemsAndConditions',
  allergiesAndIntolerances = 'allergiesAndIntolerances',
  allergiesAndIntolerancesDetails = 'allergiesAndIntolerancesDetails',
  medicalImplants = 'medicalImplants',
  procedures = 'procedures',
  visits = 'visits',
  vaccinations = 'vaccinations',
  labObservations = 'labObservations',
  careTeam = 'careTeam',
  linkedServices = 'linkedServices',
  linkedServicesFindApps = 'linkedServicesFindApps',
  linkedServicesDetails = 'linkedServicesDetails',
  linkedServicesRequests = 'linkedServicesRequests',
  linkedServicesRequestsDetails = 'linkedServicesRequestsDetails',
  profileAndSettings = 'profileAndSettings',
  profileAndSettingsOverview = 'profileAndSettingsOverview',
  overview = 'overview',
  help = 'help',
  helpContactUs = 'HelpContactUs',
  contactUs = 'contactUs'
}

interface IRoute {
  path: string;
  feature: PayerStoreFeatures;
}

type RoutesMap = {
  [key in RouteName]: IRoute;
};

//needs to be the same as the last path / of the page with lowercase
export const mobileRoutesPageNames = {
  findcare: 'Find Care',
  eobs: 'Benefits Summary',
  eobdetails: 'Explanation of Benefits',
  appointments: 'Appointments',
  healthprofile: 'Health Profile',
  medications: 'Medications',
  problemsandconditions: 'Problems & Conditions',
  allergiesandintolerances: 'Allergies & Intolerances',
  allergiesAndIntolerancesDetails: 'Allergies & Intolerances',
  visits: 'Visit Details',
  medicalimplants: 'Medical Implants',
  procedures: 'Procedures',
  labobservations: 'Lab Observations',
  vaccinations: 'Vaccinations',
  careteam: 'Care Team',
  linkedservices: 'Linked Services',
  connectedapps: 'Find Apps',
  p2p: 'Request & Send',
  profileandsettings: 'Profile & Settings',
  help: 'Help',
  overview: 'Overview',
  contactus: 'Contact Us',
  clinicalsOverview: 'Overview'
};
@injectable()
class RoutesStore {
  //public routePaths: RoutesMap;
  public payer: string | null;
  public status: StoreRequestStatus;

  constructor() {
    this.payer = null;
    this.status = StoreRequestStatus.Idle;
  }

  public getPath(name: RouteName) {
    return this.payerRoutes[name].path;
  }

  public getFeature(name: RouteName) {
    return this.payerRoutes[name].feature;
  }

  // Setting the payer name from the landing URL to be part of the baseUrl to all constructerd URL routes.
  setPayerName(payer: string) {
    if (payer && payer.length > 0) {
      this.payer = payer;
      this.status = StoreRequestStatus.Loaded;
    }
    else{
      this.setNoPayerName();
    }
  }

  setNoPayerName() {
    this.payer = null;
    this.status = StoreRequestStatus.Error;
  }

  get payerRoutes(): RoutesMap {
    return {
      any: { path: `*`, feature: PayerStoreFeatures.Other },
      landing: { path: this.payer ? `/${this.payer}/landing` : '', feature: PayerStoreFeatures.Other },
      consent: { path: this.payer ? `/${this.payer}/consent` : '', feature: PayerStoreFeatures.Other },
      /// home page redirects
      home: { path: this.payer ? `/${this.payer}` : '', feature: PayerStoreFeatures.Other },
      findCare: { path: this.payer ? `/${this.payer}/FindCare` : '', feature: PayerStoreFeatures.FindCare },
      findCareServices: { path: this.payer ? `/${this.payer}/FindCare/Services` : '', feature: PayerStoreFeatures.FindCare },
      findCareSpecialties: { path: this.payer ? `/${this.payer}/FindCare/Specialties` : '', feature: PayerStoreFeatures.FindCare },
      findCarePractitioners: { path: this.payer ? `/${this.payer}/FindCare/Practitioners` : '', feature: PayerStoreFeatures.FindCare },
      findCareOrganizations: { path: this.payer ? `/${this.payer}/FindCare/Organizations` : '', feature: PayerStoreFeatures.FindCare },
      eobs: { path: this.payer ? `/${this.payer}/EOBs` : '', feature: PayerStoreFeatures.EOBs },
      eobDetails: { path: this.payer ? `/${this.payer}/EOBs/EOBDetails/:eobId` : '', feature: PayerStoreFeatures.EOBs },
      appointments: { path: this.payer ? `/${this.payer}/Appointments` : '', feature: PayerStoreFeatures.Other },
      healthProfile: { path: this.payer ? `/${this.payer}/HealthProfile` : '', feature: PayerStoreFeatures.HealthProfile },
      clinicalsOverview: { path: this.payer ? `/${this.payer}/HealthProfile/Overview` : '', feature: PayerStoreFeatures.HealthProfile },
      medications: { path: this.payer ? `/${this.payer}/HealthProfile/Medications` : '', feature: PayerStoreFeatures.HealthProfile },
      medicalImplants: { path: this.payer ? `/${this.payer}/HealthProfile/MedicalImplants` : '', feature: PayerStoreFeatures.HealthProfile },
      procedures: { path: this.payer ? `/${this.payer}/HealthProfile/Procedures` : '', feature: PayerStoreFeatures.HealthProfile },
      problemsAndConditions: { path: this.payer ? `/${this.payer}/HealthProfile/ProblemsAndConditions` : '', feature: PayerStoreFeatures.HealthProfile },
      allergiesAndIntolerances: { path: this.payer ? `/${this.payer}/HealthProfile/AllergiesAndIntolerances` : '', feature: PayerStoreFeatures.HealthProfile },
      allergiesAndIntolerancesDetails: { path: this.payer ? `/${this.payer}/HealthProfile/AllergiesAndIntolerances/Details/:id` : '', feature: PayerStoreFeatures.HealthProfile },
      visits: { path: this.payer ? `/${this.payer}/HealthProfile/Visits` : '', feature: PayerStoreFeatures.HealthProfile },
      vaccinations: { path: this.payer ? `/${this.payer}/HealthProfile/Vaccinations` : '', feature: PayerStoreFeatures.HealthProfile },
      careTeam: { path: this.payer ? `/${this.payer}/CareTeam` : '', feature: PayerStoreFeatures.Other },
      linkedServices: { path: this.payer ? `/${this.payer}/LinkedServices` : '', feature: PayerStoreFeatures.LinkedServices },
      linkedServicesFindApps: { path: this.payer ? `/${this.payer}/LinkedServices/ConnectedApps` : '', feature: PayerStoreFeatures.LinkedServices },
      linkedServicesDetails: { path: this.payer ? `/${this.payer}/LinkedServices/ConnectedApps/ServiceDetails/:serviceId` : '', feature: PayerStoreFeatures.LinkedServices },
      linkedServicesRequests: { path: this.payer ? `/${this.payer}/LinkedServices/P2P` : '', feature: PayerStoreFeatures.LinkedServicesRequests },
      linkedServicesRequestsDetails: { path: this.payer ? `/${this.payer}/LinkedServices/P2P/Payer/:payerId` : '', feature: PayerStoreFeatures.LinkedServicesRequests },
      profileAndSettings: { path: this.payer ? `/${this.payer}/ProfileAndSettings` : '', feature: PayerStoreFeatures.Profile },
      profileAndSettingsOverview: { path: this.payer ? `/${this.payer}/ProfileAndSettings/Overview` : '', feature: PayerStoreFeatures.Profile },
      labObservations: { path: this.payer ? `/${this.payer}/HealthProfile/labObservations` : '', feature: PayerStoreFeatures.HealthProfile },

      help: { path: this.payer ? `/${this.payer}/Help` : '', feature: PayerStoreFeatures.Help },
      HelpContactUs: { path: this.payer ? `/${this.payer}/Help/ContactUs` : '', feature: PayerStoreFeatures.Help },
      contactUs: { path: this.payer ? `/${this.payer}/Help/ContactUs` : '', feature: PayerStoreFeatures.Help },
      overview: { path: this.payer ? `/${this.payer}/ProfileAndSettings/Overview` : '', feature: PayerStoreFeatures.Profile }
    };
    // return this.routePaths;
  }
}

decorate(RoutesStore, {
  payerRoutes: computed,
  setPayerName: action,
  setNoPayerName: action,
  payer: observable,
  status: observable
});

export { RoutesStore, RoutesStore as RoutesStoreType };
