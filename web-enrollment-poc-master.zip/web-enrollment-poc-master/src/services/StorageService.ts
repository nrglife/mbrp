import instance, { WebStorageManager } from '../utils/webstorage-manager';
import { injectable } from 'inversify';
import { IStorageService } from '@healthcareapp/connected-health-common-services';

@injectable()
export class StorageService implements IStorageService {
  private storage: WebStorageManager = instance;

  public getValueByKey(key: string) {
    return this.storage.getValue(key);
  }

  public setItem(key: string, value: any) {
    this.storage.add(key, value);
  }

  public removeItemByKey(key: string) {
    this.storage.remove(key);
  }
}
