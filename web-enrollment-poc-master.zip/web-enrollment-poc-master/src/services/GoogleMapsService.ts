import { useState, useEffect } from 'react';

export const googleAutocomplete = async text =>
  new Promise((resolve, reject) => {
    //For more info on places api - https://developers.google.com/maps/documentation/javascript/reference/places-autocomplete-service
    if (!text) {
      return reject('Need valid text input');
    }

    // for use in things like GatsbyJS where the html is generated first
    if (window == null) {
      return reject('Need valid window object');
    }

    if (!(window as any)?.google?.maps?.places) {
      return reject('places script wasnt loaded to the web site');
    }

    try {
      //for more info - https://developers.google.com/maps/documentation/javascript/reference/places-autocomplete-service#AutocompletionRequest
      new (window as any).google.maps.places.AutocompleteService().getPlacePredictions({ input: text, componentRestrictions: { country: ['us', 'pr', 'vi', 'gu', 'mp'] } }, resolve);
    } catch (e) {
      reject(e);
    }
  });

export const googleFindPlaceFromQuery = async query =>
  new Promise((resolve, reject) => {
    if (!query) {
      return reject('Need a valid query string');
    }

    if (window == null) {
      return reject('Need valid window object');
    }

    if (!(window as any)?.google?.maps?.places) {
      return reject('places script wasnt loaded to the web site');
    }

    try {
      //create dummy map obj for the getDetails api request
      const map = new (window as any).google.maps.Map(document.createElement('div'));
      //for more info - https://developers.google.com/maps/documentation/javascript/places#place_details_requests
      new (window as any).google.maps.places.PlacesService(map).findPlaceFromQuery({ fields: ['ALL'], query }, resolve);
    } catch (e) {
      reject(e);
    }
  });

export const googlePlaceDetailsByID = async id =>
  new Promise((resolve, reject) => {
    //For more info on places api - place details- https://developers.google.com/maps/documentation/javascript/places#place_details
    if (!id) {
      return reject('Need valid id input');
    }

    // for use in things like GatsbyJS where the html is generated first
    if (window == null) {
      return reject('Need valid window object');
    }

    if (!(window as any)?.google?.maps?.places) {
      return reject('places script wasnt loaded to the web site');
    }

    try {
      //create dummy map obj for the getDetails api request
      const map = new (window as any).google.maps.Map(document.createElement('div'));
      //for more info - https://developers.google.com/maps/documentation/javascript/places#place_details_requests
      new (window as any).google.maps.places.PlacesService(map).getDetails({ placeId: id, fields: ['name', 'formatted_address', 'geometry'] }, resolve);
    } catch (e) {
      reject(e);
    }
  });

export const getAddressFromLocation = async (latitude, longitude) =>
  new Promise((resolve, reject) => {
    if (!latitude || !longitude) {
      return reject('Needs valid latitude and longitude values');
    }

    // for use in things like GatsbyJS where the html is generated first
    if (window == null) {
      return reject('Need valid window object');
    }

    if (!(window as any)?.google?.maps?.places) {
      return reject('places script wasnt loaded to the web site');
    }

    try {
      const geocoder = new (window as any).google.maps.Geocoder();
      const location = new (window as any).google.maps.LatLng(latitude, longitude);
      geocoder.geocode({ location: location }, (results, status) => {
        if (status === 'OK') {
          if (results[0]) {
            resolve(results[0]);
          } else {
            reject('No results found');
          }
        } else {
          reject('Geocoder failed due to: ' + status);
        }
      });
    } catch (e) {
      reject(e);
    }
  });

export const loadGooglePlacesApiScript = async (timeout = 10000) =>
  new Promise((resolve, reject) => {
    resolve(true);
  });

// export const loadGooglePlacesApiScript = async (timeout = 10000) =>
//   new Promise((resolve, reject) => {
//     //for more info about dynamic loading the Maps JavaScript API - https://developers.google.com/maps/documentation/javascript/overview#Dynamic
//     // Create the script tag, set the appropriate attributes
//     if (!(window as any).finishLoadingPlacesApi) {
//       (window as any).finishLoadingPlacesApi = async () => {
//         (window as any).PlacesApiLoaded = true;
//         resolve(true);
//       };

//       !(window as any)?.env?.REACT_APP_GOOGLE_GEOLOCATION_API && reject('Google api key not found');

//       const googlePlacesApiScriptID = 'googlePlacesApiScriptID';
//       const script = document.createElement('script');
//       //To add more languages for the api - https://developers.google.com/maps/faq#languagesupport
//       const languages = 'en';
//       script.src = `https://maps.googleapis.com/maps/api/js?key=${(window as any)?.env?.REACT_APP_GOOGLE_GEOLOCATION_API}&libraries=places&callback=finishLoadingPlacesApi&language=${languages}`;
//       script.async = true;
//       script.id = googlePlacesApiScriptID;

//       // Append the 'script' element to 'head'
//       const isScriptExist = document.getElementById(googlePlacesApiScriptID);
//       !isScriptExist && document.head.appendChild(script);
//     } else {
//       if ((window as any).PlacesApiLoaded) {
//         resolve(true);
//       } else {
//         const newTimeout = timeout ? timeout - 100 : 10000;
//         if (newTimeout <= 0) {
//           reject('Loading timeout');
//         } else {
//           setTimeout(() => {
//             resolve(loadGooglePlacesApiScript(newTimeout));
//           }, 100);
//         }
//       }
//     }
//   });

export const useGooglePlacesLoaded = () => {
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  useEffect(() => {
    loadGooglePlacesApiScript()
      .then(loaded => loaded && setIsLoaded(true))
      .catch(e => {
        console.log(e);
        !isLoaded && setIsLoaded(true);
      });
  }, []);

  return [isLoaded];
};

export const initFormattedAddress = (address: string): string => {
  return !address ? '' : address.replace(', USA', '');
};
