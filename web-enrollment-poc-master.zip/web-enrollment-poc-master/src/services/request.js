import 'whatwg-fetch';
import merge from 'deepmerge';
import { getTokenValuesForHeaders } from 'auth-management';

/**
 * Parses the JSON returned by a network request
 *
 * @param  {object} response A response from a network request
 *
 * @return {object}          The parsed JSON from the request
 */
function parseJSON(response) {
  if (response.status === 204 || response.status === 205) {
    return null;
  }
  return response.json();
}

/**
 * Checks if a network request came back fine, and throws an error if not
 *
 * @param  {object} response   A response from a network request
 *
 * @return {object|undefined} Returns either the response, or throws an error
 */
function checkStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response;
  }

  const error = new Error(response.statusText);
  error.response = response;
  throw error;
}

/**
 * Authorization header
 */
function mergeOptions(options, includeIdentity) {
  const { tokenType, accessToken, idToken } = getTokenValuesForHeaders();
  const standardOptions = {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `${tokenType} ${accessToken}`,
    },
  };
  if (includeIdentity) {
    standardOptions.headers.Identity = idToken;
  }
  // Object.assign() doesn't handle deep merge
  const finalOptions = merge.all([{}, standardOptions, options]);
  return finalOptions;
}

function stringify(params) {
  return Object.keys(params)
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`)
    .join('&');
}

/**
 * Requests a URL, returning a promise
 *
 * @param  {string} url       The URL we want to request
 * @param  {object} [options] The options we want to pass to "fetch"
 *
 * @return {object}           The response data
 */
export default function request(
  url,
  options = {},
  params = null,
  includeIdentity = true,
) {
  let uri = url;
  if (params) {
    uri = `${uri}?${stringify(params)}`;
  }
  return fetch(uri, mergeOptions(options, includeIdentity))
    .then(checkStatus)
    .then(parseJSON);
}
