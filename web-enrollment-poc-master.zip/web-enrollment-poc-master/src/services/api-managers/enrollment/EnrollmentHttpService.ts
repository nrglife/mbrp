import { IocContainer, IocTypes, EnrollmentStoreType } from '../../../inversify.config';
import { handleFetchError } from '../../../pages/enrollment/utils';
import { HTTPErrorHandler } from '../..';

export const EnrollmentHttpService = async (httpReq: Function, navigateUponSuccess: Function, uponFailure: HTTPErrorHandler, withPageLoader: boolean = true, handleLockedError: boolean = false) => {
  const enrollmentStore = IocContainer.get<EnrollmentStoreType>(IocTypes.EnrollmentStore);

  try {
    withPageLoader && enrollmentStore.setIsLoading(true);

    const response = await httpReq();
    if (response?.data?.success) return navigateUponSuccess(response.data);
    handleFetchError(response.data, uponFailure, handleLockedError);
  } catch (error) {
    error && handleFetchError((error as any)?.responseData, uponFailure, handleLockedError);
  } finally {
    withPageLoader && enrollmentStore.setIsLoading(false);
  }
};
