export const DefaultApiConfig = {
  errorHandler: null,
  precallHandler: null,
  successHandler: null,
  headers: {}
};

export const fillDefaultConfig = <T>(apiConfig: T):T & typeof DefaultApiConfig =>  {return { ...DefaultApiConfig, ...apiConfig}};
