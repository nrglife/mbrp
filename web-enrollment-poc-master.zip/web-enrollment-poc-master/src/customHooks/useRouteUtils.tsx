/** @jsxImportSource @emotion/core */

import { Redirect, Route, RouteChildrenProps, RouteComponentProps, RouteProps, Switch } from 'react-router';
import { RouteName } from 'stores/RoutesStore';
import NotFoundPageComponent from 'pages/404/not-found-page.component';
import { useStores } from 'stores/useStores';

export interface BuildRouteParams extends RouteProps {
  key: string;
  name: RouteName;
  component?: React.ComponentType<RouteComponentProps<any>> | React.ComponentType<any>;
  render?: (props: RouteComponentProps<any>) => React.ReactNode;
  children?: ((props: RouteChildrenProps<any>) => React.ReactNode) | React.ReactNode;
  exact?: boolean;
}

export const useRouteUtils = () => {
  const { routesStore, payerStore, delegateStore } = useStores();
  const buildRoute = ({ children, name, render, component, key, exact }: BuildRouteParams) => {
    if (!payerStore.isRouteAllowed(routesStore.payerRoutes[name].feature)) {
      return null;
    }

    return (
      <Route key={key} path={routesStore.payerRoutes[name].path} component={component} render={render} exact={exact}>
        {children}
      </Route>
    );
  };

  return {
    getPath: (name: RouteName) => {
      return routesStore.getPath(name);
    },
    isRouteAllowed: (name: RouteName) => {
      if (!delegateStore.selectedDelegateIsMember && name.includes(RouteName.linkedServices)) {
        return false;
      }
      return payerStore.isRouteAllowed(routesStore.getFeature(name));
    },
    buildSwitch: (routes: BuildRouteParams[], errorPage: boolean, redirectFrom?: RouteName) => {
      let redirectOrder: RouteName[] = [];
      let routeEntries = routes.map(route => {
        if (payerStore.isRouteAllowed(routesStore.getFeature(route.name))) {
          redirectOrder.push(route.name);
          return buildRoute(route);
        }
        return null;
      });

      return (
        <Switch>
          {routeEntries}
          {redirectFrom && redirectOrder.length && (
            <Route key={'navigation-home-page'} path={routesStore.getPath(redirectFrom)} exact render={() => <Redirect key={'navigation-redirect'} to={routesStore.getPath(redirectOrder[0])} />} />
          )}
          {errorPage && <Route key={'page-not-found'} path={'*'} children={<NotFoundPageComponent isBranded={true} showBackLink={true} showErrorCode={true} />}></Route>}
        </Switch>
      );
    }
    // buildRoute: buildRoute
  };
};
