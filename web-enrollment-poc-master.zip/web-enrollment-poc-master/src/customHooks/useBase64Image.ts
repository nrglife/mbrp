import { useCallback, useEffect, useState } from 'react';

type IImage = any | ((value: any) => void);
type IRatio = any | ((value: any) => void);
type IScaledDimension = any | ((value: any) => void);

/**
 * Converts a given base64 dataurl string into an HTMLImageElement.
 * Also returns a scaled width and height based on given maxWidth and maxHeight parameters
 *
 * @param {string} dataUrl A data url built from a base64 image string
 * @param {string} maxWidth The maximum allowed width of the image
 * @param {string} maxHeight The maximum allowed height of the image
 */
const useBase64Image = ({ dataUrl, maxWidth, maxHeight }) => {
  const [image, setImage] = useState<IImage>();
  const [ratio, setRatio] = useState<IRatio>();
  const [scaledWidth, setScaledWidth] = useState<IScaledDimension>();
  const [scaledHeight, setScaledHeight] = useState<IScaledDimension>();

  const setScaledValues = useCallback((img) => {
    const ar : number = Math.min(maxWidth / img.width, maxHeight / img.height);
    setRatio(ar);
    setScaledWidth(img.width * ar);
    setScaledHeight(img.height * ar);
  }, [maxHeight, maxWidth]);

  useEffect(() => {
    const img = new Image();

    img.onload = () => {
      setScaledValues(img);
      setImage(img);
    };

    img.src = dataUrl;
  }, [dataUrl, setScaledValues]);

  useEffect(() => {
    if (!image) return;

    setScaledValues(image);
  }, [setScaledValues, image]);

  return {
    image,
    ratio,
    scaledWidth,
    scaledHeight,
  };
};

export default useBase64Image;
