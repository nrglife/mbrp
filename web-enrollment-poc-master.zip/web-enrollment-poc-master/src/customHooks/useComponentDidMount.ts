import { useEffect } from 'react';


export const useComponentDidMount = (didMountEffect: () => unknown) => {
    useEffect(() => {
        didMountEffect();
    }, []);
};