import { useEffect, useState } from 'react';
import { useMobileDetect } from './useMobileDetect';

const MOBILE_MAX_WIDTH = 1220;

export const useIsScreenInMobile = () => {
  const [isMobile, setISMobile] = useState<boolean>(false);
  const detectMobile = useMobileDetect();

  useEffect(() => {
    const handleResize = () => setISMobile((window.innerWidth <= MOBILE_MAX_WIDTH && !detectMobile.isDesktop()) || detectMobile.isMobile());

    window.addEventListener('resize', handleResize);

    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [isMobile, detectMobile]);

  return isMobile;
};
