import { useRef, useEffect } from 'react';


export const useComponentDidUpdate = (didUpdateEffect: () => unknown, dependencies: any[] = []) => {
    const hasMounted = useRef<boolean>(false);
    useEffect(() => {
        if (!hasMounted.current) {
            hasMounted.current = true;
            return;
        }
        didUpdateEffect();
    }, [...dependencies, didUpdateEffect]);
};