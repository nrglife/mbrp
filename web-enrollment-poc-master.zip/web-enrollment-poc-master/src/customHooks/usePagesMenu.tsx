import { useEffect, useState } from 'react';
import { useStores } from '../stores/useStores';
import { RouteName, screens } from 'stores/RoutesStore';
import { LinkType } from 'components/general/nav-links-menu/nav-links-menu.component';
import { IntlConfig } from 'react-intl';
import { Route, Switch } from 'react-router-dom';
import { ReactComponent as FindCareIcon } from 'assets/icons/findcare-search.svg';
import { ReactComponent as BillsPaymentsIcon } from 'assets/icons/large.svg';
import { ReactComponent as HealthProfileIcon } from 'assets/icons/heart.svg';
import { ReactComponent as CareCalendarIcon } from '../../../assets/icons/calendar.svg';
import { ReactComponent as HospiceIcon } from '../../../assets/icons/heart.svg';
import { ReactComponent as MedicationGenericIcon } from '../../../assets/icons/medication-generic.svg';
import { ReactComponent as ProviderIcon } from '../../../assets/icons/provider-new.svg';
import { ReactComponent as LinkedServicesIcon } from 'assets/icons/linked-services.svg';
import { ReactComponent as PersonIcon } from 'assets/icons/user.svg';
import { ReactComponent as HelpIcon } from 'assets/icons/help-icon.svg';

export const usePagesMenu = () => {
  const { routesStore, appConfigStore, payerStore } = useStores();
  const [pagesMenu, setPagesMenu] = useState<{
    primaryLinks: LinkType[];
    profileAndSettingsLinks: LinkType[];
    linkedServicesLinks: LinkType[];
    helpLinks: LinkType[];
    healthProfileLinks: LinkType[];
    [key: string]: LinkType[];
  }>({
    primaryLinks: [],
    profileAndSettingsLinks: [],
    linkedServicesLinks: [],
    healthProfileLinks: [],
    helpLinks: []
  });

  useEffect(() => {
    const profileAndSettingsLinks: LinkType[] = [{ name: screens.overview, to: RouteName.overview, linkText: 'Overview', disable: false, parent: screens.profileAndSettings }];

    const linkedServicesLinks: LinkType[] = [
      { name: screens.linkedServicesFindApps, to: RouteName.linkedServicesFindApps, linkText: 'Find Connected Apps', disable: false, parent: screens.linkedServices },
      { name: screens.linkedServicesRequests, to: RouteName.linkedServicesRequests, linkText: 'Request & Send Health Records', disable: false, parent: screens.linkedServices }
    ];

    const helpLinks: LinkType[] = [{ name: screens.contactUs, to: RouteName.contactUs, linkText: 'Contact Us', disable: false, parent: screens.help }];

    const healthProfileLinks: LinkType[] = [
      { name: screens.clinicalsOverview, to: RouteName.clinicalsOverview, linkText: 'Overview', disable: false, parent: screens.healthProfile },
      { name: screens.allergiesAndIntolerances, to: RouteName.allergiesAndIntolerances, linkText: 'Allergies & Intolerances', disable: false, parent: screens.healthProfile },
      { name: screens.labObservations, to: RouteName.labObservations, linkText: 'Lab Observations', disable: false, parent: screens.healthProfile },
      { name: screens.medicalImplants, to: RouteName.medicalImplants, linkText: 'Medical Implants', disable: false, parent: screens.healthProfile },
      { name: screens.medications, to: RouteName.medications, linkText: 'Medications', disable: false, parent: screens.healthProfile },
      { name: screens.problemsAndConditions, to: RouteName.problemsAndConditions, linkText: 'Problems & Conditions', disable: false, parent: screens.healthProfile },
      { name: screens.procedures, to: RouteName.procedures, linkText: 'Procedures', disable: false, parent: screens.healthProfile },
      { name: screens.vaccinations, to: RouteName.vaccinations, linkText: 'Vaccinations', disable: false, parent: screens.healthProfile },
      { name: screens.visits, to: RouteName.visits, linkText: 'Visit Details', disable: false, parent: screens.healthProfile }
    ];

    const primaryLinks: LinkType[] = [
      {
        name: screens.findCare,
        to: RouteName.findCare,
        linkText: 'Find Care',
        icon: <FindCareIcon />,
        disable: false,
        parent: null
      },
      {
        name: screens.eobs,
        to: RouteName.eobs,
        linkText: 'Benefits Summary',
        icon: <BillsPaymentsIcon />,
        disable: false,
        parent: null
      },
      {
        name: screens.healthProfile,
        to: RouteName.healthProfile,
        linkText: 'Health Profile',
        icon: <HealthProfileIcon />,
        disable: false,

        parent: null
      },
      {
        name: screens.profileAndSettings,
        to: RouteName.profileAndSettings,
        linkText: 'Profile & Settings',
        icon: <PersonIcon />,
        disable: false,
        parent: null
      },
      { name: screens.linkedServices, to: RouteName.linkedServicesFindApps, linkText: 'Linked Services', icon: <LinkedServicesIcon />, disable: false, parent: null },
      { name: screens.help, to: RouteName.help, linkText: 'Help', icon: <HelpIcon />, disable: false, parent: null },
      //Profile & Settings sub links
      ...profileAndSettingsLinks,
      //Linked Services sub links
      ...linkedServicesLinks,
      //Help sub links
      ...helpLinks,
      //Health Profile sub links
      ...healthProfileLinks
    ];

    setPagesMenu({ primaryLinks, profileAndSettingsLinks, linkedServicesLinks, helpLinks, healthProfileLinks });
  }, [routesStore.payerRoutes]);

  return pagesMenu;
};
