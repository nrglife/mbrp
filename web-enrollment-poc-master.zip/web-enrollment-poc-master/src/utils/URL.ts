import { hashResponse } from '../stores/AuthStore';

export function parseParms(str: string) {
  var pieces = str.split('&'),
    data = {},
    i,
    parts;
  // process each query pair
  for (i = 0; i < pieces.length; i++) {
    parts = pieces[i].split('=');
    if (parts.length < 2) {
      parts.push('');
    }
    data[decodeURIComponent(parts[0])] = decodeURIComponent(parts[1]);
  }
  return data;
}

export const urldecode = (text: string) => decodeURIComponent(text.replace(/\+/g, ' '));

export const parseUrlHash = (hashParam: string, excludeKey?: string): hashResponse | null  => {
  let response: hashResponse | null = null;
  const hash = hashParam.split('#')[1];
  if (hash) {
    response = {};
    // String will be formatted key=value&key=value&
    // Transforming to JS object
    response = hash.split('&').reduce((accumulator, item) => {
      const [key, value] = item.split('=');
      if (key !== excludeKey) {
        accumulator[key] = urldecode(value);
      }
      return accumulator;
    }, {});
  }

  return response;
};
