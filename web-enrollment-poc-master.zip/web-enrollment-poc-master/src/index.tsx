import ReactDOM from 'react-dom';
import { configure } from 'mobx';
import 'reflect-metadata';

import * as serviceWorker from 'serviceWorker';

import { AppRoot } from 'AppRoot';

// Import i18n messages
//import { translationMessages } from 'i18n';


import 'custom_fonts.scss';
import 'styles/base-settings';

// When the strict mode is enabled and it enforces globally that state mutations are only allowed inside actions.
configure({ enforceActions: 'observed' });

const MOUNT_NODE = document.getElementById('root');

ReactDOM.render(<AppRoot messages={{}} />, MOUNT_NODE);
// const render = messages => ReactDOM.render(<AppRoot messages={messages} />, MOUNT_NODE);

// if (module.hot) {
//   // Hot reloadable React components and translation json files
//   // modules.hot.accept does not accept dynamic dependencies,
//   // have to be constants at compile-time
//   module.hot.accept(['./i18n'], () => {
//     ReactDOM.unmountComponentAtNode(MOUNT_NODE as Element);
//     render(translationMessages);
//   });
// }

// // Chunked polyfill for browsers without Intl support
// if (!window.Intl) {
//   new Promise(resolve => {
//     resolve(import('intl'));
//   })
//     .then(() => Promise.all([import('intl/locale-data/jsonp/en.js')]))
//     .then(() => render(translationMessages))
//     .catch(err => {
//       throw err;
//     });
// } else {
//   render(translationMessages);
// }

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
