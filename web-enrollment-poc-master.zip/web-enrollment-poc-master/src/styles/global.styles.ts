export const globalStyles = {
  COLOR: {
    /* colors */
    /* grey */
    paleGrey: '#f5f7f7',
    coolGrey: '#9ba1a9',
    brownGrey: '#979797',
    steelGrey: '#747e86',
    steelGreyTwo: ' #767e86',
    steelGreyThree: '#777d85',
    battleshipGrey: '#6d767e',
    brownishGrey: '#666666',
    slateGrey: '#656c73',
    slateGreyEight: '#616a79',
    greyishBrown: '#4a4a4a',
    charcoalGrey: '#364750',
    charcoalGreyTwo: '#35434c',
    charcoalGreyThree: '#364750',
    charcoalGreyFour: '#36474f',
    charcoalGreyFive: '#37474f',
    charcoalGreySix: '#646b75',
    charcoalGreySeven: '#5D5D5D',
    charcoalGreyEight: '#383838',
    veryLightPink60: 'rgba(216,216,216,0.6)',
    blueyGreyTwo: '#aac0c5',
    lightGrey: '#dfdfdf',
    baseNeutral5: '#F0F3F8',
    baseNeutral10: '#EAEEF4',
    baseNeutral15: '#DEE4EC',

    /* blue */
    veryLightBlueTwo: '#d9f3ff',
    veryLightBlue: '#e1edf1',
    iceBlue: '#f0f4f5',
    sky: '#82d8ff',
    azure: '#24b3f6',
    azureTwo: ' #009ee8',
    tealBlue: '#007bb4',
    waterBlue: '#1188c1',
    darkIndigo: '#0f0f59',
    nightBlue: '#0d0555',
    // TODO: oreng: check with dana about the name of the color
    blueGrey: '#626d8a',
    darkBlueGrey: '#183734',
    lightBlueGrey: '#c5d6dc',
    darkGreyBlue: '#2f6264',
    mediumBlue: '#2a6265',
    sea: '#2d958f',
    linkBlue: '#007db2',
    ocean: '#007a8e',
    torquiz: '#28837e',
    dark: '#1f3634',

    /* green */
    bluishGreen: '#0ea274',
    grassyGreen: '#44ad00',
    darkGrassGreen: '#358600',
    darkGreen: '#133735',
    /* red */
    veryLightPink: '#efefef',
    veryLightPinkTwo: '#d8d8d8',
    veryLightPinkThree: '#cccccc',
    veryLightPinkFour: '#d9d9d9',
    veryLightPinkFive: '#e6e6e6',
    redPink: '#f42a4d',
    darkCoral: '#d63e3e',
    rustyRed: '#bf1616',
    /* orange */
    apricot: '#ffbe69',
    wheat: '#f8ca7b',
    /* purple */
    amethyst: '#933ed7',

    white: '#ffffff',
    black: '#333333',
    blackTwo: '#262626',
    blackThree: '#121212',
    black15: 'rgba(0, 0, 0, 0.15)',

    pale: '#f2eee3'
  },
  STYLES: {
    ellipsis: {
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    },
    boxShadow: {
      boxShadow: `0 0.2rem 0.4rem 0 rgba(0, 0, 0, 0.2), 0 0.2rem 0.6rem 0 rgba(0, 0, 0, 0.15)`
    },
    horizontalScroll: {
      '::-webkit-scrollbar': {
        width: '.5rem',
        height: '.5rem'
      },
      '::-webkit-scrollbar-track': {
        borderRadius: '5px'
      },
      '::-webkit-scrollbar-thumb': {
        borderRadius: '5px'
      }
    }
  },
  /* spacing */
  m_size: '1.6rem',
  l_size: '3.2rem',
  xl_size: '4.8rem'
};

export const applyOpacity = (color: string, opacity: number) => {
  if (typeof color !== 'string' || color.length !== 7) return color;

  if (opacity < 0) opacity = 0;
  else if (opacity > 1) opacity = 1;
  opacity = Math.round(opacity * 255);

  return color + opacity.toString(16).toUpperCase().padStart(2, '0');
};
