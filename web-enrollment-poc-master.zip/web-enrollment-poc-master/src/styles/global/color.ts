export const COLOR = {
  ContentPrimary: '#262626',
  ContentSecondary: '#656C73',
  ContentPlaceholder: '#9D9D9D',
  ContentDisabled: '#C3C5CD'
};
