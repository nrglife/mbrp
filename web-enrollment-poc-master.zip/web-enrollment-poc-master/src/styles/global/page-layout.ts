import { css } from '@emotion/core';
// import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';
import { fontStyle, COLOR } from 'styles/global';

// Page
const pageContainer = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  backgroundColor: 'white',
  marginBottom: '3rem'
});

// Content
const contentContainer = css({
  display: 'flex',
  maxWidth: '100rem',
  alignItems: 'left',
  flexDirection: 'column',
  background: 'white',
  margin: 0,
  padding: '0 min(4.75rem, 4%)'
});
const contentContainerTablet = css({
  padding: '0 min(3rem, 3%)'
});
const contentContainerMobile = css({
  margin: 0,
  padding: '0 min(2rem,4%) 0 min(2rem,4%)'
});

const contentContainerResponsive = (isTablet: boolean, isMobile: boolean) => {
  return [contentContainer, isTablet && contentContainerTablet, isMobile && contentContainerMobile];
};

// Header
const headerTitle = [
  fontStyle.XL,
  css({
    display: 'flex',
    alignItems: 'center',
    color: globalStyles.COLOR.black,
    // color: COLOR.ContentPrimary,
    marginTop: '2.2rem',
    marginBottom: '0.5rem'
  })
];

const headerSubtitle = [
  fontStyle.Small,
  css({
    color: globalStyles.COLOR.black,
    // color: COLOR.ContentSecondary,
    marginBottom: '2.2rem'
  })
];

const headerSubtitleMobile = css({
  marginTop: '1.5rem',
  maxWidth: '100%',
  paddingLeft: '0'
});

// Section

const sectionTitle = [
  fontStyle.MediumBold,
  css({
    color: COLOR.ContentPrimary,
    marginBottom: '0.5em'
  })
];

const sectionText = [
  fontStyle.MediumBold,
  css({
    color: COLOR.ContentPrimary,
  })
];

const sectionParagraph = [
  fontStyle.Medium,
  css({
    color: COLOR.ContentPrimary,
    marginBottom: '0.75em'
  })
];

// Export
export const pageLayout = {
  pageContainer,
  contentContainerResponsive,
  content: {
    contentContainer,
    contentContainerTablet,
    contentContainerMobile
  },
  header: {
    headerTitle,
    headerSubtitle,
    headerSubtitleMobile
  },
  section: {
    sectionTitle,
    sectionText,
    sectionParagraph
  },
  devider: css({
    borderBottom: `1px solid ${globalStyles.COLOR.baseNeutral15}`
  })
};
