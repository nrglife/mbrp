import { css } from '@emotion/core';

export const fontStyle = {
  XXSmall: css({ fontSize: '1rem', lineHeight: '150%', fontWeight: 'normal' }),
  XSmall: css({ fontSize: '1.1rem', lineHeight: '150%', fontWeight: 'normal' }),
  XSmallBold: css({ fontSize: '1.1rem', lineHeight: '150%', fontWeight: 'bold' }),
  Small: css({ fontSize: '1.4rem', lineHeight: '150%', fontWeight: 'normal' }), // uicl8: 1.3rem
  SmallBold: css({ fontSize: '1.4rem', lineHeight: '150%', fontWeight: 'bold' }), // uicl8: 1.3rem
  Medium: css({ fontSize: '1.6rem', lineHeight: '150%', fontWeight: 'normal' }),
  MediumBold: css({ fontSize: '1.6rem', lineHeight: '150%', fontWeight: 'bold' }),
  Large: css({ fontSize: '2rem', lineHeight: '140%', fontWeight: 'normal' }),
  LargeBold: css({ fontSize: '2rem', lineHeight: '140%', fontWeight: 'bold' }),
  XL: css({ fontSize: '3rem', lineHeight: '140%', fontWeight: 'normal' }) // uicl8: 2.4rem
};
