import { COLOR } from './color';
import { fontStyle } from './font';
import { general } from './general';
import { pageLayout } from './page-layout';

export { COLOR, fontStyle };
export { general };
export { pageLayout };

const Style = {
  COLOR,
  fontStyle,
  general,
  pageLayout
};

export default Style;
