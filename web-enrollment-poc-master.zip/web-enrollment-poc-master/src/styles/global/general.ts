import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
// import { globalStyles } from 'styles/global.styles';
// import { fontStyle, COLOR } from 'styles/global';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none',
    cursor: 'pointer'
  });

// Export
export const general = {
  href
};
