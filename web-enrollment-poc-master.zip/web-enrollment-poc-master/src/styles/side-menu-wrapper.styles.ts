import { css } from '@emotion/core';
import { globalStyles } from './global.styles';
import { Preferences } from '../stores/ThemeStore';

const leftMainMenu = (theme: Preferences) =>
  css({
    width: '20%',
    maxWidth: '19.9rem',
    marginRight: '2.7rem',
    display: 'flex',
    color: theme.colors.backgroundDark.published,
    flexDirection: 'column'
  });

const pagesContainer = css({
  display: 'flex',
  flexDirection: 'column',
  position: 'relative',
  borderLeft: `1px solid ${globalStyles.COLOR.lightGrey}`
});

const linkColor = (theme: Preferences) =>
  css({
    color: theme.colors.actionDark.published
  });

const linkWrapperStyles = css({
  marginTop: '1.6rem'
});

export const styles = {
  leftMainMenu,
  pagesContainer,
  linkColor,
  linkWrapperStyles
};
