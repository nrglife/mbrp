
const general = `.label {
  display: block;
  margin - bottom: 10px;
}
`

export default general;