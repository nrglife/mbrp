import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { FindCareSearchOptionsListComponent as FindCareSearchOptionsList, PREDEFINED_SEARCH_OPTIONS } from 'components/findcare/findcare-search-options-list';
import BrowsingAreaComponent from 'components/findcare/browsing-area/find-care-browsing-area-filter.compontet';
//styles
import * as styles from './find-care-page.styles';

import { useStores } from 'stores/useStores';
import { SearchOptions } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import FindCareMapAreaComponent from 'components/findcare/map-area/findcare-map-area.compontet';
import FindCareResultDetails from 'components/findcare/practitioner-details/findcare-result-details.component';
import { RouteName } from 'stores/RoutesStore';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';

interface FindCarePageProps {}

const FindCarePage: FC<FindCarePageProps> = ({}) => {
  const { findCareStore } = useStores();
  const { buildSwitch } = useRouteUtils();
  const match = useRouteMatch();
  const switchConfig: BuildRouteParams[] = [
    {
      key: 'find-care-categories-general',
      name: RouteName.findCare,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.All} categoriesList={PREDEFINED_SEARCH_OPTIONS} />,
      exact: true
    },
    {
      key: 'find-care-categories-specialties',
      name: RouteName.findCareSpecialties,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.Specialties} categoriesList={findCareStore.currentSpecialtiesList} />,
      exact: true
    },
    { key: 'find-care-categories-specialties-results', name: RouteName.findCareSpecialties, children: <FindCareSearchOptionsList searchCategory={SearchOptions.SpecialtiesResults} /> },
    {
      key: 'find-care-categories-services',
      name: RouteName.findCareServices,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.Services} categoriesList={findCareStore.currentServicesList} />,
      exact: true
    },
    {
      key: 'find-care-categories-services-results',
      name: RouteName.findCareServices,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.ServicesResults} />
    },
    {
      key: 'find-care-categories-practitioners',
      name: RouteName.findCarePractitioners,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.Practitioners} />
    },
    {
      key: 'find-care-categories-organizations',
      name: RouteName.findCareOrganizations,
      children: <FindCareSearchOptionsList searchCategory={SearchOptions.Organizations} />,
      exact: true
    }
  ];

  const getSpecificList = () => {
    return (
      <>
        {buildSwitch(switchConfig, true)}
        <FindCareSearchOptionsList isPageNotFoundError={true} searchCategory={SearchOptions.Practitioners} />
      </>
    );
  };

  const getMainPageArea = () => {
    if (
      (findCareStore.searchType === SearchOptions.ServicesResults ||
        findCareStore.searchType === SearchOptions.SpecialtiesResults ||
        findCareStore.searchType === SearchOptions.Organizations ||
        findCareStore.searchType === SearchOptions.Practitioners) &&
      findCareStore.selected
    ) {
      return <FindCareResultDetails />;
    } else {
      return (
        <div css={styles.MapComponent}>
          <FindCareMapAreaComponent />
        </div>
      );
    }
  };

  return (
    <div css={styles.container}>
      <div css={styles.dataContainer}>
        <div css={[styles.findCareOptionsContainerStyle]}>
          <div css={styles.findcareTitleContainer}>
            <div css={styles.findcareMainTitle}>Find Care</div>
          </div>
          <BrowsingAreaComponent />

          {getSpecificList()}
        </div>
        {getMainPageArea()}
      </div>
    </div>
  );
};

export default observer(FindCarePage);
