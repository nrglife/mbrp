/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const container = css({ display: 'flex', flex: 1, flexDirection: 'row', padding: '1rem' });
export const dataContainer = css({ display: 'flex', flex: 1, alignItems: 'left', alignContent: 'left' });

export const findCareOptionsContainerStyle = css({
  display: 'flex',
  flex: '1 1 325px',
  flexFlow: 'column nowrap',
  marginRight: '1rem',
  maxWidth: '32.5rem',
  minWidth: '32.5rem',
  overflowY: 'scroll'
});

export const findcareTitleContainer = css({ padding: '1.8rem 0 0 2.8rem', backgroundColor: 'white' });
export const findcareMainTitle = css({ fontSize: '2.4rem', lineHeight: '3.4rem', fontcolor: globalStyles.COLOR.charcoalGreyTwo });
export const eobsSecondaryTitle = css({ marginTop: '1rem', fontSize: '1.4rem', lineHeight: '1.43' });

export const eobsTableContainerStyle = css({ display: 'flex', flexFlow: 'column nowrap', flex: 1, maxWidth: '900px', marginRight: 'auto' });

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const EOBsPage = css({
  width: '67.6rem',
  paddingLeft: '7.5rem',
  paddingTop: '2.9rem'
});

export const emptyEOBListContainer = css({
  display: 'flex',
  flex: '1 0 auto',
  maxWidth: '900px',
  marginRight: 'auto',
  marginLeft: 'auto',
  justifyContent: 'center',
  marginTop: '269px',
  padding: '0 20px'
});

export const MapComponent = css({
  minWidth: '32.5rem',
  width: '100%'
})