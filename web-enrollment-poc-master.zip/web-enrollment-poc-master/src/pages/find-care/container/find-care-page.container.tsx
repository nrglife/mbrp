import { FC, Fragment, useEffect, useState } from 'react';
import { useRouteMatch } from 'react-router-dom';

import FindCarePage from 'pages/find-care/components/find-care-page.component';

//developed
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';
import { IocContainer, IocTypes, ApiError, ProviderDirectoryServicesApiType } from 'inversify.config';
import { SearchOptions, Location, LocationSelectType } from '@healthcareapp/connected-health-common-services/dist/stores/findcare/FindCareStore';
import { googleFindPlaceFromQuery, useGooglePlacesLoaded, initFormattedAddress } from 'services/GoogleMapsService';
import Loader from 'components/general/loader/loader.component';

const useFindCarePageContainerBehavior = () => {
  const { findCareStore, userStore, appConfigStore, whoAmIStore } = useStores();
  const providerDirectoryServicesApi = IocContainer.get<ProviderDirectoryServicesApiType>(IocTypes.ProviderDirectoryServicesApi);
  const [isGooglePlacesLoaded] = useGooglePlacesLoaded();
  const [initializeDone, setInitializeDone] = useState(false);

  const setResultError = err => {
    findCareStore.setIsLoading(false);
    findCareStore.setError(true, err.statusCode);
  };

  const setSingleSourceResults = response => {
    if (response.status === 200) {
      findCareStore.setResults(response.data);
      findCareStore.setError(false);
      findCareStore.setIsLoading(false);
    } else {
      if (response.status !== 200) throw new ApiError(response.status ? response.status : 500, response.statusText ? response.statusText : 'Internal error');
    }
  };

  const getUnifiedResults = (query: string = '') => {
    Promise.all([providerDirectoryServicesApi.getPractitionerRole({ query: query }), providerDirectoryServicesApi.getOrganizationAffiliation({ query: query })])
      .then(response => {
        if (response[0].status === 200 && response[1].status === 200) {
          findCareStore.setResults(response[0].data);
          findCareStore.setResults(response[1].data, false);

          findCareStore.setError(false);
          findCareStore.setIsLoading(false);
        } else {
          if (response[0].status !== 200) throw new ApiError(response[0].status ? response[0].status : 500, response[0].statusText ? response[0].statusText : 'Internal error');
          if (response[1].status !== 200) throw new ApiError(response[1].status ? response[1].status : 500, response[1].statusText ? response[1].statusText : 'Internal error');
        }
      })
      .catch((err: ApiError) => {
        setResultError(err);
      });
  };

  const getResults = () => {
    findCareStore.setIsLoading(true);
    findCareStore.clearResults();

    switch (findCareStore.searchType) {
      case SearchOptions.SpecialtiesResults:
        getUnifiedResults(findCareStore.selectedSpecialty ? 'specialty=' + findCareStore.selectedSpecialty.code : '');
        break;
      case SearchOptions.ServicesResults:
        const query = findCareStore.selectedService ? `_contained=${true}&service.service-category=${findCareStore.selectedService.code}` : '';
        getUnifiedResults(query);
        break;
      case SearchOptions.Practitioners:
        providerDirectoryServicesApi
          .getPractitionerRole()
          .then(response => {
            if (response.status === 200) {
              setSingleSourceResults(response);
            } else {
              if (response.status !== 200) throw new ApiError(response.status ? response.status : 500, response.statusText ? response.statusText : 'Internal error');
            }
          })
          .catch((err: ApiError) => {
            setResultError(err);
          });

        break;
      case SearchOptions.Organizations:
        providerDirectoryServicesApi
          .getOrganizationAffiliation()
          .then(response => {
            setSingleSourceResults(response);
          })
          .catch((err: ApiError) => {
            setResultError(err);
          });
        break;
      default:
        findCareStore.setIsLoading(false);
        break;
    }
  };

  const trySetHomeLocation = async () => {
    if (!findCareStore.homeLocation && whoAmIStore.basicInfo?.address) {
      try {
        const { line1, city, state, zip } = whoAmIStore.basicInfo?.address;
        const addressQuery = [line1, city, state, zip].join(' ');
        const homeLocations: any = await googleFindPlaceFromQuery(addressQuery);
        if (homeLocations && homeLocations.length > 0) {
          const homeLocation: Location = {
            formatted_address: initFormattedAddress(homeLocations[0].formatted_address),
            latitude: homeLocations[0].geometry.location.lat(),
            longitude: homeLocations[0].geometry.location.lng(),
            locationSelectType: LocationSelectType.Home,
            placeId: homeLocations[0].place_id
          };
          findCareStore.setHomeLocation(homeLocation);
        }
      } catch (error) {
        console.error('error', error);
      }
    }
    setInitializeDone(true);
  };

  useEffect(() => {
    if (
      (findCareStore.searchType === SearchOptions.ServicesResults ||
        findCareStore.searchType === SearchOptions.SpecialtiesResults ||
        findCareStore.searchType === SearchOptions.Organizations ||
        findCareStore.searchType === SearchOptions.Practitioners) &&
      findCareStore.selectedLocation
    ) {
      getResults();
    }
  }, [findCareStore.searchType, findCareStore.selectedLocation, findCareStore.searchRadius]);

  useEffect(() => () => findCareStore.resetStore(), [findCareStore]);

  useEffect(() => {
    if (isGooglePlacesLoaded && !whoAmIStore.basicInfoLoading) {
      trySetHomeLocation();
    }
  }, [isGooglePlacesLoaded, whoAmIStore.basicInfoLoading]);

  useEffect(() => {
    findCareStore.setFilterResultsByLocation(appConfigStore.currentConfig.filterFindCareByLocation);
  }, []);
  return {
    initializeDone: initializeDone
  };
};

interface IFindCarePageContainer {}
export const FindCarePageContainer: FC<IFindCarePageContainer> = observer(() => {
  const { initializeDone } = useFindCarePageContainerBehavior();
  const { themeStore } = useStores();

  let match = useRouteMatch();

  return (
    <Fragment>
      <Loader loading={!initializeDone} color={themeStore.currentTheme.colors.actionMedium.published} />
      {initializeDone && <FindCarePage />}
    </Fragment>
  );
});
