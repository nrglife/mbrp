import { FC, useCallback, useEffect, useMemo } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { RouteComponentProps } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useEnrollment } from '../enrollment/useEnrollment';
import { useStores } from '../../stores/useStores';
import useBase64Image from '../../customHooks/useBase64Image';
import PoweredByCHC from '../../components/powered-by-chc/powered-by-chc.component';
import SignInWithCHC from '../../components/sign-in-with-chc/sign-in-with-chc.component';
import { ReactComponent as CHCLogo } from 'assets/icons/chc-logo.svg';
import SkeletonLoader from 'components/general/skeleton-loader/skeleton-loader.component';
import { styles } from './landing-page.styles';
import ContactUs from 'components/contact-us/contact-us.component';

import appStoreBadgeIcon from '../../assets/icons/app_store_badge.png';
import googlePlayBadgeIcon from '../../assets/icons/google_play_badge.png';
import { useAlertModal } from 'components/alert-modal/use-alert-modal';
import moment from 'moment';
import { EnrollmentOrigin } from '@healthcareapp/connected-health-common-services';
import { AppPreferences } from '@healthcareapp/connected-health-common-services/dist/stores/AppConfigStore';
import { ImageState } from 'stores';

interface LandingPageProps extends RouteComponentProps {
  isEnrolled: boolean | null;
}

export const dateIsValid = (startDate: Date, endDate: Date): boolean => {
  if (startDate && moment(startDate).isValid()) {
    //if start day is after today return false
    if (moment(startDate).isAfter()) {
      return false;
    }
  }

  //if end day is before today return false
  if (endDate && moment(endDate).isValid()) {
    if (moment(endDate).isBefore()) {
      return false;
    }
  }

  return true;
};

export const showEntryMessage = (appConfing: AppPreferences) => {
  return appConfing?.appMessage && appConfing.appMessage.showMessage && dateIsValid(appConfing?.appMessage.startDate, appConfing?.appMessage.endDate);
};

// 'this is a text. hello world!' -> 'This is a text. Hello world!'
export const capitalizeText = input => {
  input = input === undefined || input === null ? '' : input;
  return input.toString().replace(/(^|\. *)([a-z])/g, function (match, separator, char) {
    return separator + char.toUpperCase();
  });
};

// 'this is a text. hello world!' -> 'This Is A Text. Hello world!'
export const capitalizeWords = input => {
  input = input === undefined || input === null ? '' : input;
  return input.replace(/(^\w{1})|(\s+\w{1})/g, letter => letter.toUpperCase());
};

// 'this is a text. hello world!' -> 'THIS IS A TEXT. HELLO WORLD!'
export const upperCaseText = input => {
  input = input === undefined || input === null ? '' : input;
  return input.toUpperCase();
};

const LandingPage: FC<LandingPageProps> = props => {
  const { EnrollmentModal, setEnrollmentVisibility, initEnrollment, ContactUsModal, setContactUsVisibility } = useEnrollment();
  const { AlertModal, setAlertModalVisibility } = useAlertModal();

  const { payerDocumentsStore, imageStore, themeStore, responsiveStore, enrollmentStore, payerStore, appConfigStore } = useStores();
  const { image: darkLogo, scaledWidth, scaledHeight } = useBase64Image({ dataUrl: imageStore.logos.dark.data, maxWidth: 250, maxHeight: 200 });

  useEffect(() => {
    (async () => {
      if (showEntryMessage(appConfigStore.currentConfig)) {
        setAlertModalVisibility({
          isVisible: true,
          title: capitalizeWords(appConfigStore.currentConfig.appMessage.title),
          isTitleBold: true,
          text: capitalizeText(appConfigStore.currentConfig.appMessage.message),
          buttonText: upperCaseText(appConfigStore.currentConfig.appMessage.closeButtonText),
          showCloseButton: appConfigStore.currentConfig.appMessage.showCloseButton
        });
      }
    })();
  }, [appConfigStore.currentConfig]);

  const openContactUsModal = () => {
    setContactUsVisibility(true);
  };

  const showCopyrightStatement = useMemo(() => payerStore.payer?.copyrightStatement && payerStore.payer.copyrightStatement.trim() !== '', [payerStore.payer]);

  return (
    <div css={styles.landingPage(themeStore.currentTheme)}>
      <AlertModal></AlertModal>
      <div
        css={[
          styles.backgroundContainer(imageStore.logos.landing),
          responsiveStore.isTablet && styles.backgroundContainerTabletView,
          responsiveStore.isMobile && styles.backgroundContainerMobileView
        ]}>
        <SkeletonLoader isLoading={imageStore.logos?.landing?.state !== ImageState.Loaded} style={{ position: 'absolute', top: 0, left: 0 }} withFadeOut />
        <div css={styles.contentContainer}>
          {darkLogo != null ? <img src={darkLogo.src} width={scaledWidth} height={scaledHeight} alt="" /> : null}

          {!!payerDocumentsStore.docs.landing.published && <div css={styles.p1} dangerouslySetInnerHTML={{ __html: payerDocumentsStore.docs.landing.published }} />}

          <div css={styles.btnsContainer}>
            <SignInWithCHC />
            <div css={[styles.enrollBtn]} onClick={() => initEnrollment(EnrollmentOrigin.LandingPageUnified)}>
              ENROLL
            </div>
          </div>
          {responsiveStore.isMobile && (
            <div css={styles.appBadgesContainer}>
              <a href="https://rebrand.ly/ch_ios">
                <img src={appStoreBadgeIcon} css={[styles.appBadgeIcon, styles.firstAppBadgeIcon]} alt="App Store Badge" />
              </a>
              <a href="https://rebrand.ly/ch_android">
                <img src={googlePlayBadgeIcon} css={styles.appBadgeIcon} alt="Google Play Badge" />
              </a>
            </div>
          )}
          <div css={[styles.p2, payerStore?.primaryEmail || payerStore?.primaryPhone ? styles.borderBottom : {}]}>
            Keep Your Electronic Health Information Secure: Take caution when sharing your personal health data with external parties. To learn more visit&nbsp;
            <a href="https://www.hhs.gov/hipaa" css={styles.href(themeStore.currentTheme)} target="_blank">
              www.hhs.gov/hipaa
            </a>
          </div>
          <div css={styles.bottomContentContainer}>
            <div css={styles.titleSmall}>
              <ContactUs onClick={openContactUsModal} containerStyle={{ display: 'inline' }} />
            </div>
          </div>
        </div>
      </div>

      <div css={[styles.bottomSection, responsiveStore.isMobile && styles.bottomSectionMobileMode]}>
        <div css={[styles.copyrightStatementContainer, responsiveStore.isMobile && styles.copyrightStatementContainerMobileMode]}>
          <div>{(showCopyrightStatement && payerStore?.payer?.copyrightStatement) || 'Copyright Ⓒ 2022. All Rights Reserved'}</div>
        </div>

        <PoweredByCHC containerStyle={styles.poweredByCHCContainer} contentTxt="Connected Health is powered by" contentStyle={styles.poweredByCHCContentStyle} showLogoImg={false}>
          <CHCLogo css={styles.chcLogo} />
        </PoweredByCHC>
      </div>
      <EnrollmentModal />
      <ContactUsModal />
    </div>
  );
};

export default observer(LandingPage);
