/** @jsxImportSource @emotion/core */
import { css, jsx, keyframes } from '@emotion/core';
//consts
import { globalStyles } from '../../styles/global.styles';
import { Preferences } from '../../stores/ThemeStore';
import { Image } from 'stores';

const landingPage = (theme: Preferences) =>
  css({
    minHeight: '100%',
    display: 'flex',

    flexDirection: 'column',
    color: theme.colors.backgroundDark.published,
    backgroundColor: theme.colors.backgroundDark.published
  });

const backgroundContainer = (bg: Image) =>
  css({
    backgroundImage: `url(${bg.data})`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    backgroundPosition: 'center',

    paddingTop: '9.5rem',
    paddingLeft: '9.5rem',
    marginTop: '2rem',
    marginBottom: '2rem',
    position: 'relative'
  });

const backgroundContainerTabletView = css({
  paddingLeft: '.5rem',
  paddingRight: '.5rem',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center'
});

const backgroundContainerMobileView = css({
  // backgroundSize: 'contain',
  // backgroundPosition: 'top'
});

const contentContainer = css({
  marginBottom: '2rem',
  width: '47.5rem',
  maxWidth: '100%',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  background: 'white',
  padding: '2rem 3rem',
  borderRadius: '.3rem',
  boxShadow: '0 1px 5px 0 rgba(0, 0, 0, 0.12)',
  border: 'solid 1px rgba(55, 71, 79, 0.2)',
  position: 'relative'
});

const logo = css({
  width: '21.5rem',
  height: '6.5rem',
  marginBottom: '4.4rem'
});

const p1 = css({
  color: globalStyles.COLOR.charcoalGrey,
  fontSize: '1.6rem',
  lineHeight: '2.2rem',
  marginTop: '2rem',
  fontWeight: 400
});

const btnsContainer = css({
  margin: '2.7rem 0',
  alignItems: 'center',
  display: 'flex',
  flexDirection: 'column'
});

const appBadgesContainer = css({
  width: '100%',
  marginTop: '4rem',
  marginBottom: '2.5rem'
});

const appBadgeIcon = css({
  maxWidth: '48%'
});

const firstAppBadgeIcon = css({
  marginRight: '2%'
});

const enrollBtn = css({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '15.8rem',
  height: '3rem',
  color: globalStyles.COLOR.charcoalGrey,
  border: `solid .1rem ${globalStyles.COLOR.charcoalGrey}`,
  borderRadius: '.3rem',
  fontSize: '1.6rem',
  fontWeight: 'bold',
  letterSpacing: '0.5px',
  marginTop: '1rem',
  '&:hover': {
    transition: 'all .3s',
    cursor: 'pointer',
    transform: 'scale(1.05)'
  }
});

const p2 = css({
  color: globalStyles.COLOR.slateGrey,
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  letterSpacing: 0,
  paddingBottom: '3.9rem',
  marginBottom: '1.9rem'
});

const borderBottom = css({
  borderBottom: '.1rem solid #e6e6e6'
});

const bottomContentContainer = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'column'
});

const titleSmall = css({
  color: globalStyles.COLOR.battleshipGrey,
  fontSize: '1.4rem',
  textAlign: 'center'
});

const spacing = css({ marginBottom: '1.2rem', fontSize: '1.4rem', fontWeight: 400 });

const separator = css({ marginBottom: '1.2rem' });

const href = (theme: Preferences) => css({ color: theme.colors.backgroundDark.published, cursor: 'pointer' });

const bottomSection = css({ color: 'white', fontSize: '1.4rem', margin: '0 1.8rem', marginBottom: '5rem', display: 'flex', flexWrap: 'wrap-reverse', justifyContent: 'space-between' });
const bottomSectionNoCopyrightStatement = css({ justifyContent: 'flex-end' });
const bottomSectionMobileMode = css({ justifyContent: 'center' });
const copyrightStatementContainer = css({ alignItems: 'center', display: 'flex', minWidth: '30rem' });
const copyrightStatementContainerMobileMode = css({ width: '100%', marginTop: '1rem', justifyContent: 'center' });
const poweredByCHCContainer = css({ color: 'white', margin: '0', width: 'auto' });
const poweredByCHCContentStyle = css({ marginRight: '1.5rem' });
const chcLogo = css({ marginTop: '.2rem' });

export const styles = {
  landingPage,
  backgroundContainer,
  backgroundContainerTabletView,
  backgroundContainerMobileView,
  contentContainer,
  logo,
  p1,
  btnsContainer,
  appBadgesContainer,
  firstAppBadgeIcon,
  appBadgeIcon,
  enrollBtn,
  p2,
  bottomContentContainer,
  titleSmall,
  spacing,
  separator,
  href,
  borderBottom,
  bottomSection,
  bottomSectionNoCopyrightStatement,
  bottomSectionMobileMode,
  copyrightStatementContainer,
  copyrightStatementContainerMobileMode,
  poweredByCHCContainer,
  poweredByCHCContentStyle,
  chcLogo
};
