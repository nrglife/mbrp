/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
//consts
import { globalStyles } from '../../styles/global.styles';

export const mainContainer = css({
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  color: 'black',
  flexDirection: 'column',
  backgroundColor: 'white',
  flex: '1 1 200px',
  justifyContent: 'space-between'
});

export const container = css({ marginTop: '10%', display: 'flex', flexFlow: 'row wrap', justifyContent: 'center', padding: '0 15px' });

export const iconStyle = css({ color: '#37474F', width: '100%' });

export const titleTextStyle = css({ color: '#37474F', fontSize: '4.3rem', fontWeight: 'bold', lineHeight: 0.81, letterSpacing: '-0.22px', textAlign: 'center', marginTop: '83px', width: '100%' });

export const titleTextStyleMobile = css({
  color: '#37474F',
  fontSize: '3.8rem',
  fontWeight: 'bold',
  lineHeight: 1.1,
  letterSpacing: '-0.22px',
  textAlign: 'center',
  marginTop: '83px',
  width: '100%'
});

export const descriptionTextStyle = css({ color: '#37474F', fontSize: '2.6rem', fontWeight: 400, lineHeight: 1.35, letterSpacing: '-0.13px', textAlign: 'center', marginTop: '27px', width: '100%' });

export const linkTextStyle = css({
  marginTop: '84px',
  display: 'inline-block',
  textAlign: 'center',
  cursor: 'pointer',
  fontSize: '2.6rem',
  fontWeight: 'bold',
  lineHeight: 1.35,
  letterSpacing: '-0.13px',
  color: '#37474F'
});

export const errorCodeTextStyle = css({
  fontSize: '1.2rem',
  fontWeight: 400,
  lineHeight: '1.33',
  color: globalStyles.COLOR.battleshipGrey,
  marginBottom: '23px'
});
