import { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { ReactComponent as NotFoundIcon } from 'assets/icons/not-found-page-icon.svg';
import ErrorCode from 'components/error-code/error-code.component';
//style
import * as styles from './not-found-page.styles';
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';
import { RouteName } from 'stores/RoutesStore';
import { useRouteUtils } from 'customHooks/useRouteUtils';

interface INotFoundPage {
  showBackLink?: boolean;
  isBranded?: boolean;
  showErrorCode?: boolean;
  backLinkText?: string;
  backLinkReturnUrl?: string;
}

const NotFoundPage: FC<INotFoundPage> = ({ isBranded = false, showBackLink = false, showErrorCode = false, backLinkText = 'Back to home page', backLinkReturnUrl }) => {
  const { routesStore, themeStore, responsiveStore } = useStores();
  const { getPath } = useRouteUtils();

  return (
    <div css={[styles.mainContainer, isBranded ? { backgroundColor: themeStore.currentTheme.colors.backgroundMedium.published } : undefined]}>
      <div css={styles.container}>
        <NotFoundIcon css={styles.iconStyle} />
        <h1 css={!responsiveStore.isMobile ? styles.titleTextStyle : styles.titleTextStyleMobile}>Sorry, we couldn’t find this page</h1>
        <p css={styles.descriptionTextStyle}>You may have mistyped the address or the page may have moved</p>
        {showBackLink ? (
          <a css={styles.linkTextStyle} href={backLinkReturnUrl ? backLinkReturnUrl : getPath(RouteName.home)}>
            {backLinkText}
          </a>
        ) : null}
      </div>
      <ErrorCode componentStyle={styles.errorCodeTextStyle} />
    </div>
  );
};

export default observer(NotFoundPage);
