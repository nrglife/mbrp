import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { ReactComponent as ComputerIcon } from 'assets/icons/remove-from-queue.svg';

import * as styles from './no-mobile-support.styles';
import { useStores } from 'stores/useStores';
import { observer } from 'mobx-react';
import { ImageState } from 'stores';

interface INoMobileSupportComponent {}
export const NoMobileSupportComponent: FC<INoMobileSupportComponent> = observer(props => {
  const { themeStore, imageStore } = useStores();
  return (
    <div css={styles.mainContainer(themeStore.currentTheme)}>
      <div css={styles.container}>
        <div>
          <ComputerIcon css={styles.iconStyle} />
          <h1 css={styles.titleTextStyle}>Use a desktop computer</h1>
          <p css={styles.descriptionTextStyle}>Mobile access is not currently supported for Connected Health. Please try on a desktop computer.</p>
        </div>
        {imageStore.logos?.light.state === ImageState.Loaded && <img src={imageStore.logos.light.data} css={styles.logoStyle} alt="" />}
      </div>
    </div>
  );
});
