/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const mainContainer = (theme: Preferences) => {
  const isBackgroundDefaultWhite = '#ffffff' === theme.colors.actionDark.published || 'white' === theme.colors.actionDark.published || 'rgb(255,255,255)' === theme.colors.actionDark.published;

  return css({
    backgroundColor: theme.colors.actionDark.published,
    display: 'flex',
    flexFlow: 'row nowrap',
    height: '100%',
    justifyContent: 'center',
    padding: '0 36px',
    paddingBottom: '10%',
    flex: '1 0 300px',
    color: isBackgroundDefaultWhite ? globalStyles.COLOR.charcoalGrey : globalStyles.COLOR.white
  });
};

export const container = css({
  display: 'flex',
  flexFlow: 'column nowrap',
  alignItems: 'center',
  justifyContent: 'space-between',
  minWidth: '247px',
  maxWidth: '800px'
});

export const iconStyle = css({
  marginTop: '17.71%',
  width: '100%',
  height: '50px',
  '@media (min-width: 600px)': {
    height: '79px'
  }
});

export const titleTextStyle = css({
  fontSize: '1.8rem',
  fontWeight: 'bold',
  lineHeight: 1.2,
  textAlign: 'center',
  marginTop: '30px',
  '@media (min-width: 600px)': {
    fontSize: '4.3rem'
  }
});

export const descriptionTextStyle = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: 1.29,
  textAlign: 'center',
  marginTop: '30px',
  '@media (min-width: 600px)': {
    fontSize: '2.6rem',
    marginTop: '27px'
  }
});

export const logoStyle = css({
  width: '84px',
  height: 'auto',
  '@media (min-width: 600px)': {
    width: '130px'
  }
});
