import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { styles } from './appointments-page.styles';

interface AppointmentsProps {}

const AppointmentsPage: FC<AppointmentsProps> = () => {
  return (
    <div css={styles.AppointmentsPage}>
      <h1>Appointments Page</h1>
    </div>
  );
};

export default AppointmentsPage;
