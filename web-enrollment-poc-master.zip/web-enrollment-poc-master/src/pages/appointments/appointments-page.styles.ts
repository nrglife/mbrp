/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const AppointmentsPage = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: 'black'
});

export const styles = {
  AppointmentsPage
};
