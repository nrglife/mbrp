import { globalStyles } from '../../styles/global.styles';
import { css } from '@emotion/core';
import { Preferences } from '../../stores/ThemeStore';

const consentSectionStyle = (theme: Preferences) =>
  css({
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: theme.colors.backgroundMedium.published,
    padding: '10.7rem 2rem 8.6rem 2rem'
  });

const consentSectionStyleTablet = css({
  padding: '4rem'
});

const consentSectionStyleMobile = css({
  padding: '0'
});

const consentContainerStyle = css({
  background: 'white',
  padding: '2rem 1rem 5rem',
  maxWidth: '69.4rem',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  borderRadius: '5px'
});

const mainContainer = css({
  padding: '0 10%'
});

const mainContainerTablet = css({
  padding: '0 7%'
});

const mainContainerMobile = css({
  padding: '0 3.5%'
});

const p = css({
  color: globalStyles.COLOR.greyishBrown,
  fontSize: '1.4rem',
  marginBottom: '2.5rem',
  fontWeight: 400
});

const lineHeight = css({
  lineHeight: '2.4rem'
});

const pTitle = css({
  color: globalStyles.COLOR.greyishBrown,
  fontWeight: 'bold'
});

const hr = css({
  borderTop: `1px solid ${globalStyles.COLOR.veryLightPink}`,
  marginBottom: '1.5rem',
  marginTop: '2.5rem'
});

const checkBoxText = css({
  fontSize: '1.6rem',
  lineHeight: '2rem'
});

const checkBoxContainer = css({
  display: 'flex',
  alignItems: 'flex-start',
  marginTop: '2.9rem',
  marginBottom: '3.6rem'
});

const checkBox = css({
  minWidth: '2.2rem',
  minHeight: '2.2rem',
  backgroundColor: globalStyles.COLOR.tealBlue,
  marginRight: '0.9rem'
});

const checkBoxTablet = css({
  minWidth: '1.85rem',
  minHeight: '1.85rem',
  backgroundColor: globalStyles.COLOR.tealBlue,
  marginRight: '0.9rem'
});

const checkBoxMobile = css({
  minWidth: '1.7rem',
  minHeight: '1.7rem',
  backgroundColor: globalStyles.COLOR.tealBlue,
  marginRight: '0.7rem'
});

const btnContainer = css({
  width: '100%',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  padding: '0 3rem',
  position: 'relative'
});

const btnStyle = css({
  maxWidth: '30.7rem'
});

const printIconBottom = css({
  right: '0',
  position: 'absolute'
});

const printIconBottomMobile = css({
  marginTop: '12rem',
});

const upperBoxShadow = css({
  webkitBoxShadow: '0px -3px 5px 0px rgba(0,0,0,0.1)',
  mozBoxShadow: '0px -3px 5px 0px rgba(0,0,0,0.1)',
  boxShadow: '0px -4px 3px -2px rgba(0,0,0,0.1)'
});

const href = css({
  color: globalStyles.COLOR.azure,
  textDecoration: 'none'
});

const hrefTermsAndPrivacyPolicy = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

const print = (theme: Preferences) =>
  css({
    fontSize: '1.4rem',
    lineHeight: '2rem',
    fontWeight: 500,
    color: theme.colors.actionMedium.published,
    textDecoration: 'none',
    cursor: 'pointer',
    paddingLeft: '0.8rem',
    paddingBottom: '10px'
  });

const printIcon = css({
  color: globalStyles.COLOR.greyishBrown,
  cursor: 'pointer',
  verticalAlign: 'middle'
});

const printContainer = css({
  textAlign: 'right',
  paddingTop: '2rem',
  paddingBottom: '3.2rem'
});

const contractTextDiv = css({
  wordBreak: 'break-word'
});

const errorContainer = css({
  padding: '0rem 2rem 0.5rem'
});

const errorMessage = css({
  color: globalStyles.COLOR.darkCoral,
  fontSize: '1.6rem',
  fontWeight: 400
});

const styles = {
  consentSectionStyle,
  consentSectionStyleMobile,
  consentSectionStyleTablet,
  consentContainerStyle,
  mainContainer,
  mainContainerTablet,
  mainContainerMobile,
  pTitle,
  p,
  lineHeight,
  hr,
  checkBoxText,
  checkBoxContainer,
  checkBox,
  checkBoxTablet,
  checkBoxMobile,
  btnContainer,
  btnStyle,
  printIconBottom,
  printIconBottomMobile,
  upperBoxShadow,
  href,
  hrefTermsAndPrivacyPolicy,
  print,
  printIcon,
  printContainer,
  contractTextDiv,
  errorContainer,
  errorMessage
};

export default styles;
