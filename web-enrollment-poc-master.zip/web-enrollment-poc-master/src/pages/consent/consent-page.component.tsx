import { FC, useState, useEffect } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { observer } from 'mobx-react';
import { Base64 } from 'js-base64';
import isBase64 from 'is-base64';
import utf8 from 'utf8';
import { useHistory } from 'react-router-dom';
//developed
import { useStores } from 'stores/useStores';
import Button from 'components/general/button/button.component';
import { ReactComponent as PrintIcon } from '../../assets/icons/print.svg';
//styles
import styles from './consent-page.styles';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import ActivityTracker from '../../components/user-inactivity/user-inactivity.component';
import { IocContainer, IocTypes, ConsentApiType } from 'inversify.config';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
interface ConsentPageProps {
  onCloseModal?: () => void;
}

const ConsentPage: FC<ConsentPageProps> = ({ onCloseModal }) => {
  //consts
  const { userStore, themeStore, responsiveStore, authStore, storageStore } = useStores();
  const { getPath } = useRouteUtils();
  const consentApi = IocContainer.get<ConsentApiType>(IocTypes.ConsentApi);

  const mainTitle: string = `Please review and agree to our Terms & Conditions`;

  const checkBoxText = {
    iHaveReviewed: 'I have reviewed and agree to be bound by the ',
    termsAndConditions: 'Terms & Conditions',
    and: ' and ',
    privacyPolicy: 'Privacy Policy.'
  };

  const termsAndConditionsChangeHealthcareUrl = 'https://www.​changehealthcare.​com/terms-of-use/health-app';
  const privacyPolicyChangeHealthcareUrl = 'https://www.changehealthcare.com/privacy-notice/health-app';
  const btnText: string = 'next';

  //state vars
  const [isButtonDisabled, setIsButtonDisabled] = useState<boolean>(true);
  const [isConsentError, setIsConsentError] = useState<boolean>(false);
  const [isConsentHTMLValid, setIsConsentHTMLValid] = useState<boolean>(true);

  let history = useHistory();

  const uponNotificationModalClose = () => {
    if (!userStore.contractId || !isConsentHTMLValid || isConsentError) {
      authStore.logout();
    }
  };

  const { NotificationModal, setNotificationModalVisibility } = useNotificationModal({ onClose: uponNotificationModalClose, onButtonClickHandler: uponNotificationModalClose });

  const postConsent = async (isConsent: boolean) => {
    try {
      userStore.setIsLoading(true);

      const dataToSend = {
        contractId: userStore.contractId,
        consentFlag: isConsent
      };

      const response = await consentApi.postConsent({ consentData: dataToSend });

      if (response.data?.success) {
        userStore.updateUserTokenConsent(true);
        storageStore.setItem('useSessionData', true);
        window.location.href = storageStore.getValueByKey('targetLocation');
      } else {
        setIsConsentError(true);
        setNotificationModalVisibility(true, 'Something went wrong', 'Please try again.');
      }
    } catch (error) {
      setIsConsentError(true);
      setNotificationModalVisibility(true, 'Something went wrong', 'Please try again.');
    } finally {
      userStore.setIsLoading(false);
    }
  };

  // get the html from the api
  useEffect(() => {
    const getHtmlContract = async () => {
      try {
        userStore.setIsLoading(true);

        const response = await consentApi.getContract({});
        if (response.data?.success) {
          const { contractId, contractText } = response.data;
          const contractDecoded = contractText && isBase64(contractText) ? utf8.decode(Base64.decode(contractText)) : null;
          if (!contractId || !contractDecoded) {
            setIsConsentHTMLValid(false);
            setNotificationModalVisibility(true, 'Something went wrong', 'Please try again.');
          }
          userStore.setContractId(contractId);
          userStore.setContractHtml(contractDecoded);
        } else {
          setNotificationModalVisibility(true, 'Something went wrong', 'Please try again.');
        }
      } catch (error) {
        setNotificationModalVisibility(true, 'Something went wrong', 'Please try again.');
      } finally {
        userStore.setIsLoading(false);
      }
    };

    getHtmlContract();
  }, []);

  const onClick = () => {
    //at this stage we only allow to consent
    setIsConsentError(false);
    postConsent(true);
  };

  const onCheckBoxChange = () => {
    setIsConsentError(false);
    setIsButtonDisabled(!isButtonDisabled);
  };

  return (
    <div>
      <ActivityTracker />
      {userStore.contractId && (
        <div
          css={[styles.consentSectionStyle(themeStore.currentTheme), responsiveStore.isTablet ? (responsiveStore.isMobile ? styles.consentSectionStyleMobile : styles.consentSectionStyleTablet) : {}]}>
          <div css={styles.consentContainerStyle}>
            <div css={[styles.mainContainer, responsiveStore.isTablet ? (responsiveStore.isMobile ? styles.mainContainerMobile : styles.mainContainerTablet) : {}]}>
              {userStore.contractHtml && (
                <div>
                  <div css={styles.printContainer}>
                    <PrintIcon onClick={() => window.print()} css={styles.printIcon} />
                    <a onClick={() => window.print()} css={[styles.print(themeStore.currentTheme)]} target="_blank">
                      {'Print'}
                    </a>
                  </div>
                  <div css={styles.contractTextDiv} dangerouslySetInnerHTML={{ __html: userStore.contractHtml ?? '' }}></div>
                </div>
              )}
              <hr css={[styles.hr]} />

              <div css={[styles.checkBoxContainer]}>
                <input
                  type="checkbox"
                  css={[styles.checkBox, responsiveStore.isTablet ? (responsiveStore.isMobile ? styles.checkBoxMobile : styles.checkBoxTablet) : {}]}
                  onChange={onCheckBoxChange}
                />
                <div css={[styles.checkBoxText]}>
                  {checkBoxText.iHaveReviewed}
                  <a css={styles.hrefTermsAndPrivacyPolicy(themeStore.currentTheme)} href={`${termsAndConditionsChangeHealthcareUrl}`} target="_blank" rel="noopener noreferrer">
                    {checkBoxText.termsAndConditions}
                  </a>
                  {checkBoxText.and}
                  <a css={styles.hrefTermsAndPrivacyPolicy(themeStore.currentTheme)} href={`${privacyPolicyChangeHealthcareUrl}`} target="_blank" rel="noopener noreferrer">
                    {checkBoxText.privacyPolicy}
                  </a>
                </div>
              </div>

              <div css={styles.btnContainer}>
                <Button buttonStyle={styles.btnStyle} text={btnText.toUpperCase()} onClick={onClick} isButtonDisabled={isButtonDisabled} />
              </div>
            </div>
          </div>
        </div>
      )}
      <NotificationModal />
    </div>
  );
};

export default observer(ConsentPage);
