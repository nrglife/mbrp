import { useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

import { useStores } from 'stores/useStores';
import { useLocation } from 'react-router-dom';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import { useHistory } from 'react-router-dom';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';

export const DelegateError = () => {
  const { storageStore, authStore, userStore } = useStores();
  const { getPath } = useRouteUtils();
  const { t } = useTranslation('translation');

  const redirectToHome = () => {
    window.location.href = getOrigin() + getPath(RouteName.home);
  };

  const logOut = () => {
    userStore.currentUser && authStore.logout();
  };

  const getOrigin = () => {
    const origin = window.location.origin;
    const urlStart = (window as any)?.env?.REACT_APP_SERVER_URL?.split(':')[0];
    return origin && origin.startsWith(urlStart) ? origin : null;
  };

  const cachedTheme = storageStore.getValueByKey('theme') ? JSON.parse(storageStore.getValueByKey('theme')) : null;

  let notificationModalConfig = {
    onClose: logOut,
    customTheme: cachedTheme,
    buttonText: t(LocaleKeys.errors.try_again_button),
    onButtonClickHandler: redirectToHome,
    disableClose: userStore.currentUser ? false : true
    //  onSecondButtonClickHandler: userStore.currentUser ? logOut : undefined,
    //  secondButtonText: userStore.currentUser ? 'Log out' : undefined
  };

  const { NotificationModal, setNotificationModalVisibility } = useNotificationModal(notificationModalConfig);

  useEffect(() => {
    setNotificationModalVisibility(true, t(LocaleKeys.errors.something_went_wrong), t(LocaleKeys.errors.unable_to_get_account_information));
  }, []);

  return <NotificationModal />;
};
