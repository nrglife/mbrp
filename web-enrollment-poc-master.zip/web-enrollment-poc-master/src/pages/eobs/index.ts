export { EOBsPageContainer } from './container/eobs-page.container';
