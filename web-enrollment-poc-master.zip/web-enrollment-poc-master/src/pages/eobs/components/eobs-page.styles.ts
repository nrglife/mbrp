/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

export const container = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column'
});
export const dataContainer = css({
  display: 'flex',
  flex: 1,
  padding: '0 11px'
});

export const errorDataContainer = css({
  display: 'flex',
  flex: 1
});

export const dataContainerMobile = css({ padding: '0' });

export const eobsListContainerStyle = css({
  width: '25%',
  display: 'flex',
  flexDirection: 'column',
  marginTop: '2.2rem',
  maxWidth: '32.5rem',
  minWidth: '20rem'
});

export const eobsListContainerMobile = css({
  width: '100%',
  maxWidth: '100%'
});

export const eobsTitleContainer = css({ marginTop: '2.4rem', marginLeft: '4rem' });
export const eobsTitleContainerMobile = css({ marginTop: '.5rem', marginLeft: '2.8rem', marginRight: '1.5rem' });
export const eobsMainTitle = css({ fontSize: '3rem', lineHeight: '0.83' });
export const eobsSecondaryTitle = css({ marginTop: '1rem', fontSize: '1.4rem', lineHeight: '1.43' });
