import { FC, useEffect, useState } from 'react';
//third party
import { useParams } from 'react-router-dom';
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
//developed
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useStores } from '../../../stores/useStores';
import EobsTableSection from '../../../components/eobs/eobs-table-section';
import Loader from 'components/general/loader/loader.component';
import { Error } from 'components/error';
import { ReactComponent as EmptyEOBListIcon } from '../../../assets/icons/empty-eob-list-thin.svg';
import { globalStyles } from 'styles/global.styles';

interface EOBsDetailsMobileProps {}

const EOBsDetailsMobile: FC<EOBsDetailsMobileProps> = () => {
  const { t } = useTranslation();
  const { eobListStore } = useStores();
  const { eobId = null } = useParams<any>();
  const [show, setShow] = useState(false);
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    try {
      setIsError(false);
      //get eob data from store according to url id
      const eobForDetailsPage = eobListStore.eobs.filter(e => e.id.trim() === eobId)[0];
      //check if the selected current eob is the one we get the data from store according to url id - if not set this url one
      !!eobForDetailsPage && eobListStore.selected?.id !== eobForDetailsPage.id && eobListStore.setSelectedEOB(eobForDetailsPage);
      //if the id of the url not pointing to existing eob reset selected eob and show error message
      if (!eobForDetailsPage) {
        setIsError(true);
        eobListStore.setSelectedEOB(null);
      }
    } catch (error) {
      console.log(error);
    }
    setShow(true);
  }, [eobListStore.selected]);

  if (isError) {
    // return <Error errorText={t(LocaleKeys.errors.no_eobs_to_show_yet)} Image={EmptyEOBListIcon}></Error>;
    return <Error errorText={"EOB’s data doesn't exists"} Image={EmptyEOBListIcon}></Error>;
  }

  return show ? <EobsTableSection /> : <Loader loading={true} color={globalStyles.COLOR.slateGrey} backgroundColor={'transparent'} position={'centered'} />;
};

export default observer(EOBsDetailsMobile);
