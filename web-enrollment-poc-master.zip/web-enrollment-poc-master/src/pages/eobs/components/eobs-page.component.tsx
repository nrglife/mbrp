import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import EOBsTableSection from '../../../components/eobs/eobs-table-section';
import { Error } from 'components/error';
import { EobListComponent as EobList } from 'components/eobs/eob-list';
import { useStores } from '../../../stores/useStores';
//styles
import * as styles from './eobs-page.styles';
import { failureSource, LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { ReactComponent as ClockIcon } from 'assets/icons/clock.svg';
import { ReactComponent as NoContentIcon } from 'assets/icons/no-content-icon.svg';
import { useTranslation } from 'react-i18next';

interface EOBsPageProps {
  isError?: null | boolean;
}

const EOBsPage: FC<EOBsPageProps> = ({ isError = false }) => {
  const { responsiveStore, eobListStore, delegateStore } = useStores();
  const { t } = useTranslation('translation');

  return (
    <div css={styles.container}>
      <div css={[styles.eobsTitleContainer, responsiveStore.isMobile && styles.eobsTitleContainerMobile]}>
        {!responsiveStore.isMobile && <div css={styles.eobsMainTitle}>{t(LocaleKeys.screens.EOBs.benefits_summary_title)}</div>}
        {!isError && <div css={styles.eobsSecondaryTitle}>{t(LocaleKeys.screens.EOBs.page_header_subtitle_text)}</div>}
      </div>
      <>
        {!isError ? (
          <div css={[styles.dataContainer, responsiveStore.isMobile && styles.dataContainerMobile]}>
            {/* HealthCosts and EobList container */}
            {eobListStore.eobs && eobListStore.eobs.length > 0 ? (
              <>
                <div css={[styles.eobsListContainerStyle, responsiveStore.isMobile && styles.eobsListContainerMobile]}>
                  {/* <HealthCosts /> */}
                  <EobList list={eobListStore.eobs || []} />
                </div>
                {/* eobs table section container */}
                {!responsiveStore.isMobile && <EOBsTableSection />}
              </>
            ) : (
              <div css={[styles.errorDataContainer]}>
                <Error
                  errorText={delegateStore.isMemberConsentIn12HoursRange ? t(LocaleKeys.errors.data_still_loading) : t(LocaleKeys.errors.no_eobs_to_show_yet)}
                  Image={delegateStore.isMemberConsentIn12HoursRange ? ClockIcon : NoContentIcon}
                  ignoreNextPage={false}
                />
              </div>
            )}
          </div>
        ) : (
          <Error errorSource={failureSource.EOB_Get} ignoreNextPage={false} />
        )}
      </>
    </div>
  );
};

export default observer(EOBsPage);
