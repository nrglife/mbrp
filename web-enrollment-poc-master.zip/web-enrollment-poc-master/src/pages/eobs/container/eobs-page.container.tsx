import { FC, Fragment, useEffect, useState } from 'react';
//third party
import { Route, Switch, Redirect, useParams } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import EOBsPage from 'pages/eobs/components/eobs-page.component';
import Loader from 'components/general/loader/loader.component';
import EobsTableSection from 'components/eobs/eobs-table-section';
import NotFoundPage from 'pages/404/not-found-page.component';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import EOBsDetailsMobile from '../components/eob-detail-mobile';

const useEOBsPageContainerBehavior = () => {
  const { eobListStore, delegateStore, responsiveStore } = useStores();
  const [show, setShow] = useState(true);

  useEffect(() => {
    setShow(true);
    const initEOBS = async () => {
      try {
        await eobListStore.fetchData({});
        !eobListStore.selected && eobListStore.eobs.length > 0 && !responsiveStore.isMobile && eobListStore.setSelectedEOB(eobListStore.eobs[0]);
      } catch (error) {
        console.log(error);
      }
      setShow(false);
    };
    initEOBS();
  }, [eobListStore, delegateStore.selectedDelegateId]);

  useEffect(() => () => eobListStore.resetStore(), [eobListStore]);

  return { isError: eobListStore.initialReqStatus == ReqStatus.ERROR, showLoader: show };
};

interface IEOBsPageContainer {}
export const EOBsPageContainer: FC<IEOBsPageContainer> = observer(() => {
  const { isError, showLoader } = useEOBsPageContainerBehavior();
  const { themeStore, eobListStore, responsiveStore } = useStores();
  const { buildSwitch } = useRouteUtils();

  const switchConfig: BuildRouteParams[] = [{ key: 'navigation-eobs-page-general', name: RouteName.eobs, children: <EOBsPage isError={isError} />, exact: true }];
  if (responsiveStore.isMobile) {
    switchConfig.push({
      key: 'navigation-eob-info-page',
      name: RouteName.eobDetails,
      children: <EOBsDetailsMobile />,
      exact: true
    });
  }

  const getEobsPages = () => buildSwitch(switchConfig, true);

  return (
    <Fragment>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={eobListStore.initialReqStatus == ReqStatus.IDE || eobListStore.initialReqStatus == ReqStatus.LOADING || showLoader}
        backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published}
      />
      {eobListStore.initialReqStatus != ReqStatus.IDE && eobListStore.initialReqStatus != ReqStatus.LOADING && !showLoader && getEobsPages()}
    </Fragment>
  );
});
