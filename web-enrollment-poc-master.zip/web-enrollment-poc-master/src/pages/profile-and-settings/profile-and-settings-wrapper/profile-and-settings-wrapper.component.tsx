import { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//third party
import { Route, Switch, Redirect, useRouteMatch } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../stores/useStores';
import { usePagesMenu } from '../../../customHooks/usePagesMenu';
import PageLayout from '../../../components/page-layout/page-layout.component';
import NavLinksMenu from '../../../components/general/nav-links-menu/nav-links-menu.component';
import ProfileAndSettingsOverview from '../profile-and-settings-overview/profile-and-settings-overview.component';
import NotFoundPage from 'pages/404/not-found-page.component';
//consts
import { styles } from '../../../styles/side-menu-wrapper.styles';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';

interface ProfileAndSettingsWrapperProps {}

const ProfileAndSettingsWrapper: FC<ProfileAndSettingsWrapperProps> = () => {
  const { themeStore, responsiveStore } = useStores();
  const pagesMenu = usePagesMenu();
  const { buildSwitch, getPath } = useRouteUtils();

  const switchConfig: BuildRouteParams[] = [
    {
      key: 'navigation-profile-and-settings',
      name: RouteName.profileAndSettings,
      exact: true,
      render: () => <Redirect to={{ pathname: getPath(RouteName.profileAndSettingsOverview) }} />
    },
    { key: 'navigation-profile-and-settings-overview', exact: true, name: RouteName.profileAndSettingsOverview, component: ProfileAndSettingsOverview },
  ];

  //all the links in the menue of Profile And Settings page
  const profileAndSettingsMenu = (
    <Fragment>
      <div css={styles.linkWrapperStyles}>{<NavLinksMenu links={pagesMenu.profileAndSettingsLinks} linkStyle={styles.linkColor(themeStore.currentTheme)} addAsPrimary={true} />}</div>
    </Fragment>
  );

  const profileAndSettingsRoutes = (
    <Fragment>
      {/* All the pages in Profile And Settings page * */}
      {buildSwitch(switchConfig, true)}
    </Fragment>
  );

  return (
    <PageLayout
      // left={responsiveStore.isTablet ? null : profileAndSettingsMenu}
      // leftStyle={styles.leftMainMenu(themeStore.currentTheme)}
      center={profileAndSettingsRoutes}
      centerStyle={styles.pagesContainer}
    />
  );
};

export default observer(ProfileAndSettingsWrapper);
