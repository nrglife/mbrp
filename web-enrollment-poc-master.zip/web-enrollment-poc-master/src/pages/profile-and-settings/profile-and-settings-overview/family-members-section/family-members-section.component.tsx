import React, { FC } from 'react';
//third party
import { observer } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//developed
import { useStores } from 'stores/useStores';
//common
import { isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
//assets
import { ReactComponent as AvatarFamilyMemberIcon } from '../../../../assets/icons/avatar-familyMember.svg';
//styles
import * as styles from '../profile-and-settings-overview.styles';

interface FamilyMembersSectionProps {}

const FamilyMembersSection: FC<FamilyMembersSectionProps> = () => {
  const { whoAmIStore, responsiveStore, themeStore } = useStores();
  const { t } = useTranslation();
  const ageText = t(LocaleKeys.screens.Settings.age);
  const monthsText = t(LocaleKeys.screens.Settings.months);
  const monthText = t(LocaleKeys.screens.Settings.months);
  const daysText = t(LocaleKeys.screens.Settings.days);
  const dayText = t(LocaleKeys.screens.Settings.day);
  const getStringAge = (birthday: string) => {
    if (!isValidDate(birthday)) return null;

    let ageInYears = moment().diff(moment(birthday, 'YYYY-MM-DD'), 'years');
    if (ageInYears >= 1) return `${ageText} ${ageInYears}`;
    //for years not need to add 'years' title
    else {
      let ageInMonths = moment().diff(moment(birthday, 'YYYY-MM-DD'), 'months');
      if (ageInMonths >= 2) return `${ageText} ${ageInMonths} ${monthsText}`;
      // oreng: I know is not logical to put >= cause we need just =, but otherwise is not work :-(
      else if (ageInMonths >= 1) return `${ageText} ${ageInMonths} ${monthText}`;
      else {
        let ageInDays = moment().diff(moment(birthday, 'YYYY-MM-DD'), 'days');
        if (ageInDays >= 2) return `${ageText} ${ageInDays} ${daysText}`;
        // oreng: I know is not logical to put >= cause we need just =, but otherwise is not work :-(
        else if (ageInDays >= 1) return `${ageText} ${ageInDays} ${dayText}`;
      }
    }
  };

  return (
    <div css={[styles.membersContainer, responsiveStore.isMobile && styles.membersMobileStyle]}>
      {whoAmIStore.basicInfo?.dependents && whoAmIStore.basicInfo?.dependents?.length > 0 && (
        <div css={[styles.TitleRectangle(themeStore.currentTheme), styles.titleRectangleMarginTop]}>
          <p css={styles.SectionTitle}>{t(LocaleKeys.screens.Settings.familyMembers)}</p>
        </div>
      )}
      {whoAmIStore.basicInfo?.dependents?.map((dependent, i) => (
        <div css={styles.memberItem} key={i}>
          <div css={styles.familyMemberRectangle}>
            <div css={styles.avatarFamilyMemberContainer}>
              <AvatarFamilyMemberIcon style={{ color: themeStore.currentTheme.colors.backgroundDark.published }} />
            </div>
            <div css={styles.memberContainer}>
              <p css={styles.memberName}>{dependent.dependentFullName}</p>
              {dependent.dependentBirthDate && <p css={styles.memberAge}>{getStringAge(dependent.dependentBirthDate)}</p>}
            </div>
          </div>
          {i + 1 !== whoAmIStore.basicInfo?.dependents?.length && <div css={styles.memberRectangleSeparator} />}
        </div>
      ))}
    </div>
  );
};

export default observer(FamilyMembersSection);
