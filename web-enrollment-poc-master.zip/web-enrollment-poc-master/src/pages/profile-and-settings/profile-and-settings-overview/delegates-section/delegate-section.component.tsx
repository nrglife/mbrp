import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { useStores } from 'stores/useStores';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { ReactComponent as AvatarFamilyMemberIcon } from '../../../../assets/icons/avatar-familyMember.svg';
import * as styles from '../profile-and-settings-overview.styles';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface DelegationSectionProps {}

const DelegationSection: FC<DelegationSectionProps> = () => {
  const { whoAmIStore, responsiveStore, themeStore } = useStores();
  const { t } = useTranslation();
  return (
    <div css={[styles.membersContainer, responsiveStore.isMobile && styles.membersMobileStyle]}>
      {whoAmIStore.activeDelegatesForMember && whoAmIStore.activeDelegatesForMember?.length > 0 && (
        <div css={styles.TitleRectangle(themeStore.currentTheme)}>
          <p css={styles.SectionTitle}>{t(LocaleKeys.screens.Settings.yourDelegates)}</p>
          <p css={styles.SectionSubtitle}>{t(LocaleKeys.screens.Settings.delegatesSectionHeader)}</p>
        </div>
      )}
      {whoAmIStore.activeDelegatesForMember?.map((delegate, i) => (
        <div css={styles.memberItem} key={i}>
          <div css={styles.delegateRectangle}>
            <div css={styles.avatarFamilyMemberContainer}>
              <AvatarFamilyMemberIcon style={{ color: themeStore.currentTheme.colors.backgroundDark.published }} />
            </div>
            <div css={styles.memberContainer}>
              {delegate.fullName && <p css={styles.memberName}>{delegate.fullName}</p>}
              {delegate.emailAddress && <p css={styles.memberEmail}>{delegate.emailAddress}</p>}
              <div css={styles.memberRange}>
                {delegate.periodStartDateTime && (
                  <p css={[styles.memberRangeItem, responsiveStore.isMobile && styles.memberRangeItemMobile]}>{`${t(LocaleKeys.screens.Settings.start)}: ${delegate.periodStartDateTime}`}</p>
                )}
                {delegate.periodEndDateTime && (
                  <p css={[styles.memberRangeItem, responsiveStore.isMobile && styles.memberRangeItemMobile]}>{`${t(LocaleKeys.screens.Settings.end)}: ${delegate.periodEndDateTime}`}</p>
                )}
              </div>
            </div>
          </div>
          {i + 1 !== whoAmIStore.activeDelegatesForMember?.length && <div css={styles.memberRectangleSeparator} />}
        </div>
      ))}
    </div>
  );
};

export default observer(DelegationSection);
