import React, { FC, Fragment, useEffect, useState } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
//developed
import { useStores } from 'stores/useStores';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import Loader from 'components/general/loader/loader.component';
import { Error } from 'components/error';
import InlineWarning from 'components/general/inline-warning/inline-warning.component';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import FamilyMembersSection from './family-members-section/family-members-section.component';
import DelegationSection from './delegates-section/delegate-section.component';
//styles
import * as styles from './profile-and-settings-overview.styles';
//assets
import { ReactComponent as AvatarProfileIcon } from '../../../assets/icons/avatar-profile.svg';
//common
import { failureSource, LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface ProfileAndSettingsOverviewProps {
  isError?: null | boolean;
}

const ProfileAndSettingsOverview: FC<ProfileAndSettingsOverviewProps> = ({ isError = false }) => {
  //consts
  const { userStore, themeStore, routesStore, responsiveStore, whoAmIStore, delegateStore } = useStores();
  const [initializationDone, setInitializationDone] = useState(false);
  const { getPath } = useRouteUtils();
  const { t } = useTranslation();
  const errorMessage = t(LocaleKeys.errors.some_records_not_available);

  useEffect(() => {
    whoAmIStore.loadBasicInfo();
    whoAmIStore.loadDelegatesForMember();
    setInitializationDone(true);
  }, [delegateStore.selectedDelegateId]);

  if (whoAmIStore.basicInfoError) {
    return <Error errorSource={failureSource.Whoami_Get_Basic} />;
  }
  let userBirthDate = whoAmIStore.basicInfo?.birth_date ? whoAmIStore.basicInfo?.birth_date : '';
  let userGender = whoAmIStore.basicInfo?.gender ? whoAmIStore.basicInfo?.gender : '';
  let dobGenderLabel = userBirthDate !== '' && userGender !== '' ? userBirthDate + ' | ' + userGender : userBirthDate !== '' ? userBirthDate : userGender;

  return (
    <Fragment>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={!initializationDone || !!userStore.isLoading || !!whoAmIStore.basicInfoLoading || !!whoAmIStore.delegatesForMemberLoading}
        backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published}
      />
      {whoAmIStore.basicInfo && (
        <div css={[styles.profileAndSettingsOverviewPage, responsiveStore.isTablet && styles.profileAndSettingsOverviewPageTabletMode]}>
          {!responsiveStore.isMobile && <div css={[styles.overviewTitle, responsiveStore.isTablet && styles.overviewTitleTopMargin]}>{t(LocaleKeys.screens.Settings.titleOverview)}</div>}
          <div css={styles.warningText}>
            <div>{whoAmIStore.delegatesForMemberError && <InlineWarning text={errorMessage} />}</div>
          </div>
          <div css={[styles.whiteRectangle, responsiveStore.isMobile && styles.whiteRectangleMobileStyle]}>
            <div css={[styles.personalInfoContent, responsiveStore.isMobile && styles.personalInfoContentMobileStyle]}>
              <div css={styles.avatarContainer}>
                {whoAmIStore.basicInfo?.avatar?.url ? (
                  <div css={[styles.avatarImg, { backgroundImage: `${whoAmIStore.basicInfo?.avatar?.url}` }]} />
                ) : (
                  <AvatarProfileIcon style={{ color: themeStore.currentTheme.colors.backgroundDark.published }} />
                )}
              </div>
              <div css={styles.contactContainer}>
                <h1 css={styles.contactName}>{whoAmIStore.basicInfo.full_name}</h1>
                {whoAmIStore.basicInfoError ? null : (
                  <div>
                    <p css={styles.contactBirthday}>{dobGenderLabel}</p>
                    <p css={styles.contactAddress}>
                      {whoAmIStore.basicInfo?.address?.line1}
                      <br />
                      {whoAmIStore.basicInfo?.address?.city ? `${whoAmIStore.basicInfo?.address?.city}, ` : ''}
                      {whoAmIStore.basicInfo?.address?.state} {whoAmIStore.basicInfo?.address?.zip}
                      <br />
                      {whoAmIStore.basicInfo?.phone_number}
                    </p>
                    <p css={styles.contactEmail}>{whoAmIStore.basicInfo?.email}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          <FamilyMembersSection />
          {whoAmIStore.delegatesForMember && <DelegationSection />}

          <div css={styles.personalInfoContainer}>
            <p css={[styles.personalInfoText, responsiveStore.isMobile && styles.personalInfoTextMobile]}>
              {t(LocaleKeys.screens.Settings.toMakeChangesPlease)}{' '}
              <NavLink to={`${getPath(RouteName.help)}/ContactUs`} css={styles.href(themeStore.currentTheme)}>
                {t(LocaleKeys.errors.contact_us_lowercase)}
              </NavLink>
              .
            </p>
          </div>
        </div>
      )}
    </Fragment>
  );
};

export default observer(ProfileAndSettingsOverview);
