/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const profileAndSettingsOverviewPage = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  maxWidth: '81.6rem',
  padding: '3.3rem 6.9rem'
});

export const profileAndSettingsOverviewPageTabletMode = css({
  maxWidth: '100%',
  padding: '0',
  alignItems: 'center'
});

export const overviewTitle = css({
  width: '100%',
  maxWidth: '70rem',
  fontSize: '3rem',
  lineHeight: '3.4rem',
  color: globalStyles.COLOR.charcoalGrey
});

export const warningText = css({ paddingTop: '1rem', paddingBottom: '1.5rem', width: '100%', maxWidth: '70rem' });

export const overviewTitleTopMargin = css({ marginTop: '3.3rem' });

export const overviewText = css({
  paddingTop: '1.2rem',
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  color: globalStyles.COLOR.charcoalGreyThree
});

export const whiteRectangle = css({
  maxWidth: '70rem',
  width: '100%',
  backgroundColor: globalStyles.COLOR.white,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  padding: '3rem 4rem'
});

export const whiteRectangleMobileStyle = css({
  padding: '2rem',
  gridColumnGap: '.5rem',
  maxWidth: '100%'
});

export const personalInfoContent = css({
  display: 'grid',
  gridTemplateColumns: '9rem auto',
  gridColumnGap: '5.5rem'
});

export const personalInfoContentMobileStyle = css({
  gridColumnGap: '1rem'
});

export const membersContainer = css({
  width: '100%',
  maxWidth: '70rem'
});

export const membersMobileStyle = css({
  maxWidth: '100%'
});

export const memberItem = css({
  backgroundColor: globalStyles.COLOR.white
});

export const familyMemberRectangle = css({
  height: '7.1rem',
  backgroundColor: globalStyles.COLOR.white
});

export const delegateRectangle = css({
  display: 'flex',
  paddingBottom: '1.9rem',
  backgroundColor: globalStyles.COLOR.white
});

export const memberRectangleSeparator = css({
  height: '0.1rem',
  backgroundColor: 'rgba(60, 60, 67, 0.29)',
  marginLeft: '1.6rem'
});

export const TitleRectangle = (theme: Preferences) =>
  css({
    minHeight: '7.9rem',
    backgroundColor: theme.colors.backgroundLight.published,
    paddingLeft: '3.1rem',
    paddingTop: '1.7rem',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  });

export const titleRectangleMarginTop = css({
  marginTop: '3rem'
});

export const SectionTitle = (theme: Preferences) =>
  css({
    fontSize: '1.6rem',
    lineHeight: '2rem'
  });

export const SectionSubtitle = (theme: Preferences) =>
  css({
    fontSize: '1.4rem',
    lineHeight: '1.8rem',
    color: globalStyles.COLOR.slateGrey
  });

export const avatarContainer = css({
  display: 'flex',
  maxWidth: '100%'
});

export const avatarFamilyMemberContainer = css({
  paddingLeft: '3.1rem',
  paddingTop: '2.2rem',
  float: 'left'
});

export const avatarImg = css({
  opacity: '1',
  backgroundRepeat: 'no-repeat',
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  maxWidth: '10rem',
  maxHeight: '10rem',
  borderRadius: '50%',
  border: `white .4rem solid`
});

export const familyMemberAvatarImg = css({
  opacity: '1',
  backgroundRepeat: 'no-repeat',
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  width: '3.6rem',
  height: '3.6rem',
  borderRadius: '50%',
  border: `white .4rem solid`
});

export const contactContainer = css({});

export const memberContainer = css({
  paddingLeft: '1.9rem',
  paddingTop: '2.2rem',
  float: 'left'
});

export const contactName = css({
  fontSize: '2rem',
  fontWeight: 400,
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const memberName = css({
  fontSize: '1.6rem',
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const memberEmail = css({
  fontSize: '1.2rem',
  lineHeight: '1.4rem',
  color: globalStyles.COLOR.blackTwo
});

export const contactBirthday = css({
  fontSize: '1.4rem',
  fontWeight: 400,
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const memberRange = css({
  marginTop: '2rem',
  display: 'flex'
});

export const memberRangeItem = css({
  fontSize: '1.2rem',
  lineHeight: '1.4rem',
  marginRight: '4.4rem',
  color: globalStyles.COLOR.blackTwo
});

export const memberRangeItemMobile = css({
  marginRight: '1.4rem'
});

export const memberAge = css({
  marginTop: '0.2rem',
  fontSize: '1.2rem',
  lineHeight: '1.2rem',
  color: globalStyles.COLOR.black
});

export const contactAddress = css({
  paddingTop: '1rem',
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const contactEmail = css({
  paddingTop: '.3rem',
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const personalInfoContainer = css({
  paddingLeft: '1.9rem'
});

export const personalInfoTitle = css({
  paddingTop: '3.4rem',
  fontWeight: 400,
  fontSize: '1.6rem',
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo
});

export const personalInfoText = css({
  paddingTop: '3rem',
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  marginBottom: '4rem',
  color: globalStyles.COLOR.charcoalGreyFour
});

export const personalInfoTextMobile = css({
  marginBottom: '9rem'
});
