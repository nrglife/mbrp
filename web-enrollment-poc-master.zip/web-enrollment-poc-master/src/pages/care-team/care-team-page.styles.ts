/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const careTeamPage = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: 'black'
});

export const styles = {
  careTeamPage
};
