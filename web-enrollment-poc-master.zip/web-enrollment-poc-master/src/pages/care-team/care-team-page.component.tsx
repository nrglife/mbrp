import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { styles } from './care-team-page.styles';

interface CareTeamPageProps {}

const CareTeamPage: FC<CareTeamPageProps> = () => {
  return (
    <div css={styles.careTeamPage}>
      <h1>Care Team Page</h1>
    </div>
  );
};

export default CareTeamPage;
