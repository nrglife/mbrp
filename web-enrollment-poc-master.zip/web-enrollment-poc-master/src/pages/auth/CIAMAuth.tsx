import { useEffect, FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { RouteComponentProps, useHistory } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { IocContainer, IocTypes, EnrollmentApiType, ConsentApiType, DataServicesApiType } from 'inversify.config';
import { parseUrlHash } from '../../utils/URL';
import { useStores } from '../../stores/useStores';
import { hashResponse } from '../../stores/AuthStore';
import { AuthErrors } from '.';
import Loader from 'components/general/loader/loader.component';
//styles
import { globalStyles } from 'styles/global.styles';
import i18n from 'i18n';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { failureSource, ErrorCode_CIAM, ErrorCode_Enrollment_Get_Enrollment, ErrorCode_TC_Get_Consent } from '@healthcareapp/connected-health-common-services';
import { error } from 'console';
import { useTranslation } from 'react-i18next';

interface CIAMAuthProps extends RouteComponentProps {}

const ENROLLED_STATUS = 'Enrolled';

export const CIAMAuth: FC<CIAMAuthProps> = observer(({ location }) => {
  const { storageStore, userStore, authStore, errorStoreCommon, delegateStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);
  const consentApi = IocContainer.get<ConsentApiType>(IocTypes.ConsentApi);
  const dataServicesApi = IocContainer.get<DataServicesApiType>(IocTypes.DataServicesApi);

  const history = useHistory();

  const { t } = useTranslation('translation');

  const navigateToError = (
    title: string | null,
    text: string,
    errorType: AuthErrors,
    redirectCustomerShortName: string = '',
    errorSource: failureSource | null = null,
    errorCode: number | null = null
  ) => {
    if (errorSource) errorStoreCommon.setError(errorSource, errorCode, false);
    history.replace('/error', { error: { title, text, errorType, redirectCustomerShortName } });
  };

  const navigateToAuth = () => history.replace('/auth');

  const navigateToAppRouter = () => {
    storageStore.setItem('useSessionData', true);
    window.location.href = storageStore.getValueByKey('targetLocation');
  };

  const getConsent = async (hashParams: hashResponse) => {
    try {
      const response = await consentApi.getConsent({ callScopeAuthToken: hashParams?.access_token });

      if (response?.data.success && response.data?.data.consentFlag === true) {
        userStore.setUserToken({ isEnrolled: true, isConsent: true, consentDate: response.data?.data?.consentedAt, hashResponse: hashParams });
        navigateToAppRouter(); // Navigate home
      } else if (response?.data.success) {
        userStore.setUserToken({ isEnrolled: true, isConsent: false, hashResponse: hashParams });
        navigateToAppRouter(); // Navigate to T&C page
      } else {
        userStore.setUserToken({ isEnrolled: true, isConsent: null, hashResponse: hashParams });
        navigateToError(i18n.t(LocaleKeys.errors.something_went_wrong), i18n.t(LocaleKeys.errors.please_try_again), AuthErrors.NotAuthorized, undefined);
      }
    } catch (error: any) {
      hashParams && userStore.setUserToken({ isEnrolled: true, isConsent: null, hashResponse: hashParams });
      //some general error on Get Consent
      navigateToError(
        i18n.t(LocaleKeys.errors.something_went_wrong),
        i18n.t(LocaleKeys.errors.please_try_again),
        AuthErrors.NotAuthorized,
        undefined,
        failureSource.TC_Get_Consent,
        error?.statusCode ?? ErrorCode_TC_Get_Consent.GENERAL
      ); //450 - Consent General Error
    }
  };

  const getEnrollment = async (httpReq: Function, access_token: string | undefined, hashParams: hashResponse) => {
    try {
      const response = await httpReq();
      const responseData = response?.data;

      if (responseData?.success && responseData?.data?.enrollmentStatus === ENROLLED_STATUS) {
        let currentPayerId = storageStore.getValueByKey('payerId');
        if (currentPayerId && responseData?.data?.customerId && Array.isArray(responseData?.data?.customerId) && responseData?.data?.customerId.indexOf(currentPayerId) !== -1) {
          getConsent(hashParams);
        } else {
          //find the first customerId that return a valid short_name
          let redirectCustomerFullName: string | undefined = '';
          let redirectCustomerShortName: string | undefined = '';
          for (let customerId of responseData?.data?.customerId || []) {
            //TODO: check why in case of failure in getPayerConfigByPayerIdReturnNull it's crash and not return null
            let responsePayerConfig: any = null;
            try {
              responsePayerConfig = await dataServicesApi.getPayerConfigByPayerIdReturnNull({ payerId: customerId });
            } catch (e) {
              responsePayerConfig = null;
            }
            redirectCustomerFullName = responsePayerConfig?.data?.customer_name;
            redirectCustomerShortName = responsePayerConfig?.data?.short_name;
            if (!!redirectCustomerShortName) break;
          }
          if (redirectCustomerShortName)
            //Registered to different payer
            navigateToError(
              null,
              i18n.t(LocaleKeys.errors.login_different_payer_redirect, { payerName: redirectCustomerFullName ?? redirectCustomerShortName }),
              AuthErrors.RedirectToDifferentPayer,
              redirectCustomerShortName,
              failureSource.Enrollment_Get_Enrollment,
              ErrorCode_Enrollment_Get_Enrollment.DIFFERENT_PAYER //451 - Registered to different payer
            );
          //Enrolled but we didn't found payer (maybe Not Authorized)
          else
            navigateToError(
              i18n.t(LocaleKeys.errors.login_different_payer),
              i18n.t(LocaleKeys.errors.contact_support),
              AuthErrors.NotAuthorized,
              undefined,
              failureSource.Enrollment_Get_Enrollment,
              ErrorCode_Enrollment_Get_Enrollment.PAYER_NOT_FOUND
            ); //452 - Enrolled but we didn't found payer (maybe Not Authorized)
        }
      } else if (responseData?.success) {
        userStore.setUserToken({ isEnrolled: false, isConsent: null, hashResponse: hashParams });
        //User is not Enrolled
        navigateToError(
          i18n.t(LocaleKeys.errors.login_user_not_enrolled_2),
          i18n.t(LocaleKeys.errors.please_enroll),
          AuthErrors.NotAuthorized,
          undefined,
          failureSource.Enrollment_Get_Enrollment,
          ErrorCode_Enrollment_Get_Enrollment.NOT_ENROLLED
        ); //453 - User is not Enrolled
      } else {
        userStore.setUserToken({ isEnrolled: null, isConsent: null, hashResponse: hashParams });
        navigateToError(i18n.t(LocaleKeys.errors.something_went_wrong), i18n.t(LocaleKeys.errors.please_try_again), AuthErrors.NotAuthorized, undefined);
      }
    } catch (error: any) {
      userStore.setUserToken({ isEnrolled: null, isConsent: null, hashResponse: hashParams });
      //some general error on Get Enrollment
      navigateToError(
        i18n.t(LocaleKeys.errors.something_went_wrong),
        i18n.t(LocaleKeys.errors.please_try_again),
        AuthErrors.NotAuthorized,
        undefined,
        failureSource.Enrollment_Get_Enrollment,
        error?.statusCode ?? ErrorCode_Enrollment_Get_Enrollment.GENERAL
      ); //450 - Get Enrollment General Error
    }
  };

  useEffect(() => {
    // extract previously intended target location

    // check that we have a hash and are not in an iframe

    if (window.top === window.self) {
      delegateStore.clearStoredDelegateIndex();
      const accessTokenCookie = authStore.getAndDeleteAccessTokenCookie();
      const hashParams = accessTokenCookie ? accessTokenCookie : parseUrlHash(location.hash, 'expires_in');

      //Go to error in hash Params not valid
      if (!hashParams || hashParams.error) {
        //CIAM with no hashParams
        navigateToError(
          i18n.t(LocaleKeys.errors.something_went_wrong),
          i18n.t(LocaleKeys.errors.please_try_again),
          AuthErrors.NotAuthorized,
          undefined,
          failureSource.CIAM,
          ErrorCode_CIAM.NO_HASHPARAMS
        );
        return;
      }

      //Go to error in Hash Authenticated  not valid
      let hashAuthenticatedResponse = authStore.isHashAuthenticated(hashParams);
      if (hashAuthenticatedResponse.errorSource || hashAuthenticatedResponse.errorCode) {
        navigateToError(
          i18n.t(LocaleKeys.errors.something_went_wrong),
          i18n.t(LocaleKeys.errors.please_try_again),
          AuthErrors.NotAuthorized,
          undefined,
          hashAuthenticatedResponse.errorSource,
          hashAuthenticatedResponse.errorCode
        );
        return;
      }

      // yay we're secure, maybe store other things like user, navigate somewhere
      // GET /enrollment
      navigateToAuth();
      getEnrollment(async () => await enrollmentApi.getEnrollment({ callScopeAuthToken: hashParams?.access_token }), hashParams?.access_token, hashParams);
    }
  }, []);

  return <Loader loading={true} color={globalStyles.COLOR.slateGrey} backgroundColor={globalStyles.COLOR.white} position={'global'} />;
});
