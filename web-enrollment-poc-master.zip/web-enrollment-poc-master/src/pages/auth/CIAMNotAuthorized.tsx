import { useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

import { useStores } from 'stores/useStores';
import { useLocation } from 'react-router-dom';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import { AuthErrors } from '.';

export const CIAMNotAuthorized = () => {
  const { storageStore, authStore } = useStores();
  const location = useLocation<{ error: { title: string; text: string; errorType: AuthErrors; redirectCustomerShortName: string } }>();

  const getOrigin = () => {
    const origin = window.location.origin;
    const urlStart = (window as any)?.env?.REACT_APP_SERVER_URL?.split(':')[0];
    return origin && origin.startsWith(urlStart) ? origin : null;
  };

  const getTargetLocation = () => {
    const targetLocation = storageStore.getValueByKey('targetLocation');
    const urlStart = (window as any)?.env?.REACT_APP_SERVER_URL?.split(':')[0];
    return targetLocation && targetLocation.startsWith(urlStart) ? targetLocation : null;
  };

  const redirectToDifferentPayerHome = () => {
    storageStore.setItem('useSessionData', false);
    let targetLocation = getTargetLocation() ?? getOrigin();
    targetLocation = targetLocation?.toLowerCase();
    const payerShortName = storageStore.getValueByKey('payerShortName')?.toLowerCase();
    let redirectCustomerShortName = location.state?.error?.redirectCustomerShortName?.toLowerCase();
    if (redirectCustomerShortName) {
    let urlObj = new URL(targetLocation);
      if (payerShortName && urlObj?.pathname?.includes(payerShortName)) {
        targetLocation = `${urlObj?.origin}${urlObj?.pathname?.replaceAll(payerShortName, redirectCustomerShortName)}`;
      }
      else {
        targetLocation = `${urlObj?.origin}/${redirectCustomerShortName}`;
      }
    }
    authStore.removePayerStorageKeys();
    window.location.href = targetLocation;
  };

  const redirectToHome = () => {
    //WITHOUT LOGOUT
    storageStore.setItem('useSessionData', true);
    const targetLocation = getTargetLocation();
    window.location.href = targetLocation ? targetLocation : getOrigin();
  };

  const logOutAndRedirectToHome = () => {
    authStore.logout();
  };

  const cachedTheme = storageStore.getValueByKey('theme') ? JSON.parse(storageStore.getValueByKey('theme')) : null;

  let notificationModalConfig = {};

  if (!!location.state?.error) {
    switch (location.state?.error.errorType) {
      case AuthErrors.NotAuthorized: {
        notificationModalConfig = {
          onClose: logOutAndRedirectToHome,
          customTheme: cachedTheme,
          buttonText: 'OK',
          onButtonClickHandler: logOutAndRedirectToHome
        };
        break;
      }
      case AuthErrors.RedirectToDifferentPayer: {
        notificationModalConfig = {
          onClose: redirectToHome,
          customTheme: cachedTheme,
          buttonText: 'GO NOW',
          onButtonClickHandler: redirectToDifferentPayerHome
        };

        //Auto redirect Timer.
        setTimeout(() => {
          redirectToDifferentPayerHome();
        }, parseInt((window as any)?.env?.REACT_APP_REDIRECT_TO_LOGIN_TIME_OUT || '5000'));
        break;
      }
      default: {
        notificationModalConfig = {
          onClose: logOutAndRedirectToHome,
          customTheme: cachedTheme,
          buttonText: 'OK',
          onButtonClickHandler: logOutAndRedirectToHome
        };
        break;
      }
    }
  }
  const { NotificationModal, setNotificationModalVisibility } = useNotificationModal(notificationModalConfig);

  useEffect(() => {
    if (location?.state?.error) {
      setNotificationModalVisibility(!!location?.state?.error, location?.state?.error.title, location.state?.error.text);
    }
  }, []);

  if (!location?.state?.error) {
    redirectToHome();
    return null;
  }

  return <NotificationModal />;
};
