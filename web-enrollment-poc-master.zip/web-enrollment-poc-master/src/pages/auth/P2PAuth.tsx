import { useEffect, FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { RouteComponentProps } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { IocContainer, IocTypes, EnrollmentApiType, ConsentApiType, DataServicesApiType } from 'inversify.config';
import { useStores } from '../../stores/useStores';
import { hashResponse } from '../../stores/AuthStore';
import { AuthErrors } from '.';
import Loader from 'components/general/loader/loader.component';
//styles
import { globalStyles } from 'styles/global.styles';
import i18n from 'i18n';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useTranslation } from 'react-i18next';

interface P2PAuthProps extends RouteComponentProps {}

export const P2PAuth: FC<P2PAuthProps> = observer(({ location }) => {
  const { storageStore } = useStores();

  // const { t } = useTranslation('translation');

  useEffect(() => {
    if (window.top === window.self) {
      const p2pTargetLocation = storageStore.getValueByKey('p2pTargetLocation');
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      const code = urlParams.get('code');
      window.location.href = p2pTargetLocation + `?p2pcode=${code}`;
    }
  }, []);

  return <Loader loading={true} color={globalStyles.COLOR.slateGrey} backgroundColor={globalStyles.COLOR.white} position={'global'} />;
});
