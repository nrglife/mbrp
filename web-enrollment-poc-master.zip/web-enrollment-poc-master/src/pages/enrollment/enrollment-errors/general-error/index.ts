import GeneralErrorContainer from './container/general-error.container';
export { GeneralErrorContainer as default };
