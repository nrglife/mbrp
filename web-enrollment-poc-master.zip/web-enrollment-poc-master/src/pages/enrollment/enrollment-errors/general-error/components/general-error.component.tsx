import { FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { ReactComponent as ErrorIcon } from '../../../../../assets/icons/x-icons.svg';
import EnrollmentPagesWrapper from '../../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import * as styles from './general-error.styles';
import { Preferences as IPreferences } from '../../../../../stores/ThemeStore';
import { useStores } from '../../../../../stores/useStores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export interface GeneralErrorProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  onContactUsClickHandler: () => void;
  isButtonDisabled: boolean;
  actionButtonText?: string;
  linkText?: string;
  theme: IPreferences;
}

export const GeneralError: FC<GeneralErrorProps> = ({ onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, theme, linkText }) => {
  const { appConfigStore } = useStores();
  const { t, i18n } = useTranslation('translation');

  const ContactUs = (
    <p css={[styles.textStyle, { marginTop: '26px' }]}>
      {`${t(LocaleKeys.errors.if_problem_persists)} `}
      <a onClick={onContactUsClickHandler} css={styles.linkTextStyle(theme)} rel="noopener noreferrer">
        {t(LocaleKeys.errors.contact_us_lowercase)}
      </a>
      .
    </p>
  );

  return (
    <EnrollmentPagesWrapper
      title={t(LocaleKeys.errors.something_went_wrong)}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={actionButtonText}
      linkText={linkText}
      withQuestionBtn={false}>
      <div css={styles.container}>
        <div css={styles.xSign}>
          <ErrorIcon />
        </div>
        <p css={styles.textStyle}>{t(LocaleKeys.errors.enrollment_process_failed_try_again)}</p>
        {ContactUs}
      </div>
    </EnrollmentPagesWrapper>
  );
};
