//third party
import { css } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';
import { Preferences } from '../../../../../stores/ThemeStore';

export const container = css({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  paddingBottom: '5rem',
  maxWidth: '47rem',
  margin: '0 auto'
});

export const xSign = css({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginTop: '58px',

  alignSelf: 'center'
});

export const textStyle = css({
  minHeight: '44px',
  fontSize: '18px',
  fontWeight: 'normal',
  fontStretch: 'normal',
  fontStyle: 'normal',
  lineHeight: 1.22,
  letterSpacing: 'normal',
  color: globalStyles.COLOR.black,
  marginTop: '41px'
});

export const emailPartsContainer = css({ 
  display: 'flex', 
  flexWrap: 'wrap' 
});

export const linkTextStyle = (currentTheme: Preferences) =>
  css({
    color: currentTheme.colors.actionMedium.published,
    textDecoration: 'none',
    cursor: 'pointer'
  });

export const phoneTextStyle = css({
  textDecoration: 'none'
});
