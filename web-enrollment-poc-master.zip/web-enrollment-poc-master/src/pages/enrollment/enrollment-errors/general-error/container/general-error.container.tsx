import { FC } from 'react';
import * as React from 'react';
import { GeneralError } from '../components/general-error.component';
import { useStores } from '../../../../../stores/useStores';
import { observer } from 'mobx-react';
import { EnrollmentSteps } from '../../../../../stores';

export interface GeneralErrorContainerProps {}

const useGeneralErrorContainerBehavior = () => {
  const { enrollmentStore, routesStore, themeStore } = useStores();
  const isButtonDisabled: boolean | undefined = false;
  const actionButtonText = 'TRY AGAIN';
  const linkText = 'CLOSE';

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event.preventDefault();
    onSubmitEnterHandler();
  };

  const onSubmitEnterHandler = () => {
    enrollmentStore.setStep(EnrollmentSteps.InvitationCode);
    console.log('go to first enrollment screen');
  };

  const onContactUsClickHandler = () => {
    enrollmentStore.setContactUsVisibility(true);
  };

  return { onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, linkText, routesStore, themeStore };
};

const GeneralErrorContainer: FC<GeneralErrorContainerProps> = observer(props => {
  const { onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, routesStore, themeStore, linkText } = useGeneralErrorContainerBehavior();
  return (
    <GeneralError
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      onContactUsClickHandler={onContactUsClickHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={actionButtonText}
      linkText={linkText}
      theme={themeStore.currentTheme}
    />
  );
});

export default GeneralErrorContainer;
