import { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { ReactComponent as ErrorIcon } from '../../../../assets/icons/x-icons.svg';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import * as styles from './wrong-payer-error.styles';
import { useStores } from '../../../../stores/useStores';
import { useTranslation } from 'react-i18next';

export interface WrongPayerErrorProps {}

const WrongPayerError: FC<WrongPayerErrorProps> = ({}) => {
  const { enrollmentStore } = useStores();
  const { t, i18n } = useTranslation('translation');

  const closeModal = () => enrollmentStore.setModalVisibility(false);
  const actionButtonText = 'OK';
  const errorDescription = t(LocaleKeys.errors.enrollment_invalid_invitation_code);

  return (
    <EnrollmentPagesWrapper
      title={t(LocaleKeys.errors.something_went_wrong)}
      onSubmitHandler={closeModal}
      onSubmitEnterHandler={closeModal}
      actionButtonText={actionButtonText}
      btnStyle={styles.btnStyle}
      withQuestionBtn={enrollmentStore.enrollmentContext.isLandingPage}
      >
      <div css={styles.container}>
        <div css={styles.xSign}>
          <ErrorIcon />
        </div>
        <p css={styles.textStyle}>{errorDescription}</p>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default WrongPayerError;
