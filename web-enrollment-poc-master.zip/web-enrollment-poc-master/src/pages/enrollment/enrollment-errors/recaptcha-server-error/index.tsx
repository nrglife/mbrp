import { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

import * as styles from './recaptcha-server-error.styles';
import { useStores } from '../../../../stores/useStores';
import { HTTP_STATUS_CODES } from 'services';
import { useTranslation } from 'react-i18next';

export interface RecaptchaServerErrorProps {}

// TODO: oreng: think maybe we can union RecaptchaServerError & RecaptchaClientError
const RecaptchaServerError: FC<RecaptchaServerErrorProps> = ({}) => {
  const { enrollmentStore } = useStores();
  const { t, i18n } = useTranslation('translation');

  const closeModal = () => enrollmentStore.setModalVisibility(false);
  const actionButtonText = 'CLOSE';
  const errorDescription = t(LocaleKeys.errors.please_try_again);

  return (
    <EnrollmentPagesWrapper
      title={t(LocaleKeys.errors.something_went_wrong)}
      onSubmitHandler={closeModal}
      onSubmitEnterHandler={closeModal}
      actionButtonText={actionButtonText}
      btnStyle={styles.btnStyle}
      isError={true}>
      <div css={styles.container}>
        <p css={styles.textStyle}>{errorDescription}</p>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default RecaptchaServerError;
