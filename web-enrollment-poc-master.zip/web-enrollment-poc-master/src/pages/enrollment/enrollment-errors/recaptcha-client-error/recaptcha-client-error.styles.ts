//third party
import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

export const container = css({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  paddingBottom: '4.5rem'
});

export const textStyle = css({
  textAlign: 'center',
  alignSelf: 'center',
  maxWidth: '54.4rem',
  fontSize: '1.8rem',
  fontWeight: 'normal',
  fontStretch: 'normal',
  fontStyle: 'normal',
  lineHeight: 1.22,
  letterSpacing: 'normal',
  color: globalStyles.COLOR.black,
  marginTop: '4.1rem'
});

export const btnStyle = css({ width: '20.5rem' });
