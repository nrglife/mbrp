import { css } from '@emotion/core';
import { globalStyles } from '../../styles/global.styles';

export const payerContainer = css({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: '8%'
});

export const payerTitle = css({
  textDecoration: 'underline',
  fontSize: '2.0rem',
  color: globalStyles.COLOR.tealBlue,
  lineHeight: '35px',
  letterSpacing: '-0.13px',
  textAlign: 'center',
  marginBottom: '5%'
});

export const mainTitleStyle = color =>
  css({
    fontSize: '2.4rem',
    color: color,
    //lineHeight: '35px',
    letterSpacing: '0',
    textAlign: 'center',
    fontWeight: 600
  });

export const errorMessage = css({
  fontSize: '1.8rem',
  fontWeight: 'normal',
  fontStretch: 'normal',
  fontStyle: 'normal',
  lineHeight: '2.2rem',
  letterSpacing: '0',
  color: globalStyles.COLOR.darkCoral
});

export const modalContainer = css({
  minWidth: '500px',
  minHeight: '100px',
  display: 'flex',
  flexDirection: 'column'
});

export const actionButtons = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%'
});

export const link = themecolor =>
  css({
    color: themecolor,
    textDecoration: 'none',
    fontSize: '1.6rem',
    fontWeight: 'bold',
    fontStretch: 'normal',
    fontStyle: 'normal',
    lineHeight: 'normal',
    letterSpacing: '0.62px',
    textAlign: 'center',
    marginTop: '20px',
    '&:hover': {
      transition: 'all .3s',
      cursor: 'pointer',
      transform: 'scale(1.05)'
    }
  });

export const contactContainer = css({
  flexDirection: 'row',
  marginTop: '2rem',
  color: globalStyles.COLOR.slateGrey
});

export const contactUs = themecolor =>
  css({
    color: themecolor,
    cursor: 'pointer',
    marginLeft: '.5rem'
  });

export const modalHeader = css({ justifySelf: 'flex-start', padding: '10px 20px' });

export const modalContent = css({ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, marginTop: '20px' });

export const textInputItem = css({ fontSize: '1.1rem', fontWeight: 'bold', color: globalStyles.COLOR.charcoalGrey });

export { globalStyles };
