import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

export const container = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'column',
  alignItems: 'center',
  color: globalStyles.COLOR.black
});

export const content = css({
  fontSize: '1.8rem',
  lineHeight: '28px',
  textAlign: 'center'
});

export const checkFilledIcon = css({
  color: globalStyles.COLOR.darkGrassGreen,
  width: '2.5rem',
  height: '2.5rem'
});

export const requirements = css({
  marginTop: '2rem'
});

export const input = css({
  width: '25.1rem',
  height: '3rem',
  fontSize: '1.5rem',
  textAlign: 'left',
  //transition: 'all 0.3s ease-in-out',
  padding: '0 0.2rem',
  //marginRight: 5, // defaults to px
  border: 'none',
  borderBottom: '1px solid rgba(0,0,0,0.2)',
  borderRadius: 'unset',

  '&:focus': {
    borderBottom: '1px  solid #333333'
  }
});

export const inputError = css({
  borderBottom: '2px solid rgba(255,0,0,0.25)',
  color: globalStyles.COLOR.darkCoral,

  '&:focus': {
    borderBottom: `2px solid ${globalStyles.COLOR.darkCoral}`,
    transition: 'all 0.3s ease-in-out'
  }
});

export const confirmPasswordContainer = css({
  margin: '1rem 0 5.5rem 0',
  maxWidth: '100%',
  width: '35rem',
  div: {
    position: 'relative',
    flex: 1,
    flexDirection: 'row',
    display: 'flex',
    input: {
      maxWidth: '100%',
      width: '100%',
      paddingRight: '25px'
    },
    i: {
      position: 'absolute',
      right: '0'
    }
  }
});

export const passwordContainer = css({
  margin: '3.5rem 0 1.5rem 0',
  maxWidth: '100%',
  width: '35rem',
  div: {
    position: 'relative',
    flex: 1,
    flexDirection: 'row',
    display: 'flex',
    input: {
      maxWidth: '100%',
      width: '100%',
      paddingRight: '25px'
    },
    i: {
      position: 'absolute',
      right: '0'
    }
  }
});

export const errorMessage = css({
  paddingTop: '2.9rem',
  paddingBottom: '1rem'
});

export const warningIcon = css({
  color: globalStyles.COLOR.redPink,
  width: '2.5rem',
  height: '2.5rem'
});
