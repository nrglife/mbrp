import { FC, useRef, useEffect, useCallback } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

//developed
import { EnrollmentStoreType, EnrollmentContext } from 'stores';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { Errors } from '../modules/models/error';
import useMaskPassword from '../modules/hooks/password/useMaskPassword';
import { ReactComponent as CheckFilledIcon } from 'assets/icons/check-filled.svg';
import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';
//styles
import * as enrollmentGlobalStyles from '../../enrollment-page.styles';
import * as styles from './create-password.styles';

interface CreatePasswordProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  isButtonDisabled?: boolean | undefined;
  errors: Errors;
  onPasswordChange: (password: string) => void;
  onConfirmPasswordChange: (password: string) => void;
  password: string;
  confirmPassword: string;
  store: EnrollmentStoreType;
  enrollmentContext: EnrollmentContext;
}

const getErrorMessage = (errors: Errors) => [errors.matchError.message, errors.onSubmitError.message].join(' ');

const Indicator = ({ isError = false, display = false }) => {
  return display ? (
    isError ? (
      <i>
        <WarningTriangle css={[styles.warningIcon]} />
      </i>
    ) : (
      <i>
        <CheckFilledIcon css={styles.checkFilledIcon} />
      </i>
    )
  ) : null;
};

const ErrorMessage = ({ isError = false, display = false, message = '' }) => {
  return display ? isError ? <p css={[enrollmentGlobalStyles.errorMessage, { fontSize: '1.4rem' }]}>{message}</p> : null : null;
};

const errorStyle = (isError: boolean | undefined, display = false) => {
  return display ? (isError ? styles.inputError : undefined) : undefined;
};

// TODO: will improve when have time
const resetValue = (reset: boolean, value: string) => (reset ? '' : value);

const CreatePassword: FC<CreatePasswordProps> = ({
  store,
  password,
  confirmPassword,
  onPasswordChange,
  onConfirmPasswordChange,
  errors,
  onSubmitHandler,
  onSubmitEnterHandler,
  isButtonDisabled = false,
  enrollmentContext
}) => {
  const passwordRef = useRef<HTMLInputElement>(null);
  const confirmPasswordRef = useRef<HTMLInputElement>(null);

  const [, maskPassword, onMaskPasswordChange] = useMaskPassword({ callback: value => onPasswordChange(value || '') });
  const [, maskConfirmPassword, onMaskConfirmPasswordChange] = useMaskPassword({ callback: value => onConfirmPasswordChange(value || '') });

  const { t } = useTranslation('translation');
  const { CreatePassword: CreatePasswordLocalKeys } = LocaleKeys.components.Enrollment;

  const whatTo = t(CreatePasswordLocalKeys.DescriptionWhatTo); // 'Create a unique password that will be used for signing into Connected Health.'
  const requirements = t(CreatePasswordLocalKeys.DescriptionRequirements); //'Minimum 8 characters, both upper and lower case letters, at least one number, and one special character.'

  useEffect(() => {
    passwordRef.current && passwordRef.current.focus();
  }, []);

  // TODO: will improve when have time
  const displayIndicator = useCallback(() => {
    const isAllowed = !errors.matchError.isError && !errors.onSubmitError.isApiError;
    return isAllowed;
  }, [errors.matchError, errors.onSubmitError]);

  return (
    <EnrollmentPagesWrapper
      title={t(CreatePasswordLocalKeys.Title)} // 'Email confirmed, let’s create a password'
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={t(CreatePasswordLocalKeys.ButtonSavePassword)} // 'SAVE PASSWORD'
      isError={errors.onSubmitError.isApiError}
      withQuestionBtn={enrollmentContext.isLandingPage}>
      <div css={styles.container}>
        <div css={styles.errorMessage}>
          <p css={enrollmentGlobalStyles.errorMessage}>{getErrorMessage(errors)}</p>
        </div>
        <p id="what-to-do" css={styles.content}>
          {whatTo} {requirements}
        </p>
        <div css={styles.passwordContainer}>
          <div>
            <input
              autoComplete="off"
              ref={passwordRef}
              value={resetValue(password.length === 0, maskPassword)}
              id="password"
              name="password"
              placeholder={t(CreatePasswordLocalKeys.NewPassword)}  // 'New password'
              onChange={onMaskPasswordChange}
              maxLength={100}
              css={[styles.input, errorStyle(errors.password.isError, password.length >= 3)]}
            />
            {displayIndicator() && <Indicator isError={errors.password.isError} display={password.length >= 3} />}
          </div>
          <div css={{ height: '1.4rem' }}>
            <ErrorMessage isError={errors.password.isError} message={errors.password.message} display={password.length >= 3}></ErrorMessage>
          </div>
        </div>
        <div css={styles.confirmPasswordContainer}>
          <div>
            <input
              autoComplete="off"
              ref={confirmPasswordRef}
              value={resetValue(confirmPassword.length === 0, maskConfirmPassword)}
              id="confirm-password"
              name="confirm-password"
              placeholder={t(CreatePasswordLocalKeys.ConfirmNewPassword)}   // 'Confirm new password'
              onChange={onMaskConfirmPasswordChange}
              maxLength={100}
              css={[styles.input, errorStyle(errors.confirmPassword.isError, confirmPassword.length >= 3)]}
            />
            {displayIndicator() && <Indicator isError={errors.confirmPassword.isError} display={confirmPassword.length >= 3} />}
          </div>
          <div css={{ height: '1.4rem' }}>
            <ErrorMessage isError={errors.confirmPassword.isError} message={errors.confirmPassword.message} display={confirmPassword.length >= 3}></ErrorMessage>
          </div>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default observer(CreatePassword);
