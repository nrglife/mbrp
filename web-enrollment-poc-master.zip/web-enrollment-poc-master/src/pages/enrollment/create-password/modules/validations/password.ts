import isEmpty from 'lodash/isEmpty';
import { Error, Errors, errorFactory } from '../models/error';
import Access from '../../modules/models/access';
import messages from '../messages/password';
import getPasswordMessages from '../messages/password';

/**
 * Minimum eight characters, at least one uppercase letter,
 * one lowercase letter, one number and one special character:
 */
// const passwordRegex = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$/
// const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,100}$/;
// const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[~!@#$%^&*()-_=+{}|;:,.<>/?])[A-Za-z\d~!@#$%^&*()-_=+{}|;:,.<>/?]{8,100}$/;

export const validateRegex = (password: string) => passwordRegex.test(password);

export interface Validation {
  execute: (password: string) => Error;
}

const empty = (next?: Validation): Validation => {
  let nextHandler: Validation | undefined = next;

  const execute = (password: string): Error => {
    if (isEmpty(password)) return errorFactory({isError: true, message: getPasswordMessages().empty});
    return (nextHandler && nextHandler.execute(password)) || errorFactory({});
  };

  return { execute };
};

const isValid = (next?: Validation): Validation => {
  let nextHandler: Validation | undefined = next;

  const execute = (password: string): Error => {
    if (!validateRegex(password)) return errorFactory({isError: true, message: getPasswordMessages().invalid});
    return (nextHandler && nextHandler.execute(password)) || errorFactory({});
  };

  return { execute };
};

export interface AccessValidation {
  execute: (access: Access) => Error;
}

const matchPassword = (next?: AccessValidation): AccessValidation => {
  let nextHandler: AccessValidation | undefined = next;

  const execute = (access: Access): Error => {
    if (!(access.password === access.confirmPassword)) return errorFactory({isError: true, message: getPasswordMessages().unmatched});
    return (nextHandler && nextHandler.execute(access)) || errorFactory({});
  };

  return { execute };
};

const validateAll = (access: Access): Errors => {
  let errors: Errors = { password: errorFactory({}), confirmPassword: errorFactory({}), onSubmitError: errorFactory({}), matchError: errorFactory({}) };

  Object.entries(access).forEach(([key, value]) => {
    errors[key] = empty(isValid()).execute(value) || errorFactory({});
  });

  errors['matchError'] = matchPassword().execute(access);

  return errors;
};

const validate = (password: string): Error => empty(isValid()).execute(password) || errorFactory({});

export default { validate, messages, matchPassword, validateAll };
