import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import i18n from 'i18n';
// TODO: ask product and member portal team for appropriate message and standard

export default function getPasswordMessages() {
  return {
    invalid: i18n.t(LocaleKeys.errors.password_invalid),
    empty: i18n.t(LocaleKeys.errors.password_invalid),
    unmatched: i18n.t(LocaleKeys.errors.password_unmatched),
    wentWrong: i18n.t(LocaleKeys.errors.something_wrong_try_again)
  };
}
