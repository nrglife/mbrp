
import { selectNewInput } from './password-type';

export function getDisplayValue(inputValue: string, cursorPos, mask: string): string {
	return inputValue
		.split('')
		.map((c, index) => (index === cursorPos.current - 1 ? c : mask))
		.join('');
}

export function getOriginalValue(inputValue: string, cursorPos, mask: string, value: string) {
	return inputValue.replace(selectNewInput(cursorPos.current, mask), (match, _, offset) => {
		if (!offset && cursorPos.current) {
			return value.substr(0, match.length);
		}

		return value.substr(-match.length);
	});
}
