import { ChangeEvent } from 'react';

import type from '../../utils/literal-type';
import { Error as CustomError } from '../../models/error';

export const selectNewInput = (cursorPos: number, mask: string): RegExp => {
  if (cursorPos) {
    return new RegExp(`(^\\${mask}{1,${cursorPos}})|(\\${mask}+)`, 'g');
  }

  return new RegExp(`(\\${mask}+)`, 'g');
};

export const maskMode = type.literally({
  lastChar: 'lastChar',
  delayed: 'delayed'
});

export type mode = 'lastChar' | 'delayed';

export type HTMLTextInputElement = HTMLInputElement | HTMLTextAreaElement;

export type NextValueString = string & { kind: 'nextValue' };

export type Props<T extends HTMLTextInputElement> = {
  /** Masking symbol. **'•'** by default */
  readonly mask?: string;
  /** Delay while entered symbol is visible in milliseconds. **1000** by default */
  readonly delay?: number;
  /** Custom onChange handler. Accepts two arguments: real input value, the original event, and the error. */
  readonly callback?: (newValue?: string, origin?: ChangeEvent<T>, error?: CustomError) => void;
  /** Mode. `lastChar`: only last char to be visible. `delayed`: input is only hidden after time elapsed. */
  readonly mode?: mode;
  /** Throw error when enable */
  readonly isThrowError?: boolean;
};

export type UseMaskPasswordProps<T extends HTMLTextInputElement> = Props<T>;

export const state = {
  config: {
    mask: '•',
    delay: 1000,
    mode: maskMode.lastChar,
    isThrowError: false
  } as Props<HTMLTextInputElement>,
  init: {
    value: '',
    maskValue: '',
    futureMaskValue: ''
  }
};

export const defaults: Props<HTMLTextInputElement> = state.config;

export type Settings<T extends HTMLTextInputElement> = Required<Pick<Props<T>, keyof typeof defaults>> & Props<T>;

export type UseMaskReturn<T extends HTMLTextInputElement> = [string, string, (e: ChangeEvent<T>) => NextValueString, (value: string) => void];
