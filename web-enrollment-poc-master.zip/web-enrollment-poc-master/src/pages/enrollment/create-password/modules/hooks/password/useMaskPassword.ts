import { useState, ChangeEvent, useMemo, useRef, useEffect, useCallback } from 'react';

import { errorFactory } from '../../models/error';
import maskMessage from '../password/messages/mask';
import { HTMLTextInputElement, UseMaskPasswordProps, defaults, UseMaskReturn, Settings, state, NextValueString, maskMode } from '../password/password-type';
import { getDisplayValue, getOriginalValue } from './password';

export default <T extends HTMLTextInputElement>(props?: UseMaskPasswordProps<T>): UseMaskReturn<T> => {
  const { mask, delay, mode, callback } = useMemo(() => ({ ...defaults, ...props } as Settings<T>), [props]);

  if (mask.length !== 1) {
    callback(undefined, undefined, errorFactory({ isError: true, message: maskMessage.invalidLength }));

    if (!state.config.isThrowError) return [state.init.value, state.init.maskValue, (e: ChangeEvent<T>) => '' as NextValueString, (value: string) => {}];

    if (state.config.isThrowError) throw new Error(maskMessage.invalidLength);
  }

  const timer = useRef<number | undefined>();
  const cursorPos = useRef<number>(0);
  const inputRef = useRef<T | null>(null);

  const [value, setValue] = useState(state.init.value);
  const [maskValue, setMaskValue] = useState(state.init.maskValue);
  const [futureMaskValue, setFutureMaskValue] = useState(state.init.futureMaskValue);

  const onChange = useCallback(
    (e: ChangeEvent<T>): NextValueString => {
      inputRef.current = e.target;

      cursorPos.current = inputRef?.current?.selectionEnd || 0;
      const inputValue = inputRef?.current?.value || '';

      // This is going to be the new original value (unmasked)
      const newValue = getOriginalValue(inputValue, cursorPos, mask, value);

      let newDisplay = '';

      // Mask the value leaving the last character entered intact
      if (mode === maskMode.lastChar) {
        newDisplay = getDisplayValue(inputValue, cursorPos, mask);
      } else {
        // Keep entered value as is until timer hides everything
        newDisplay = inputValue;
      }

      setValue(newValue);
      setMaskValue(newDisplay);
      setFutureMaskValue(new Array(inputValue.length + 1).join(mask));

      if (typeof callback === 'function') {
        callback(newValue, e);
      }

      return newValue as NextValueString;
    },
    [mask, mode, callback, value]
  );

  // Restore cursor position once presentation has changed
  useEffect(() => {
    inputRef.current?.setSelectionRange(cursorPos.current, cursorPos.current);
  }, [maskValue, inputRef, cursorPos]);

  // Set futurePresentation as presentation after the timeout
  useEffect(() => {
    if (maskValue !== futureMaskValue && futureMaskValue) {
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setMaskValue(futureMaskValue), delay) as unknown as number;
    }

    return () => clearTimeout(timer.current);
  }, [timer, maskValue, futureMaskValue, delay]);

  const resetValue = (value: string) => setValue(() => value);

  return [value, maskValue, onChange, resetValue];
};
