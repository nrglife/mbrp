export default {
  invalidLength: 'mask should be a character or a symbol'
};
