import { IHTTP_ERROR } from 'services';

/**
 * TODO: in the case of password creation,
 * these two properties won't have to be in this, will improve once have time
 * isApiError?: boolean;
  * isError?: boolean;
 */
export interface Error {
  isApiError?: boolean;
  isError?: boolean;
  message: string;
  error?: IHTTP_ERROR;
}

export interface Errors {
  password: Error;
  confirmPassword: Error;
  onSubmitError: Error;
  matchError: Error;
}

export const errorFactory = ({ isError = false, isApiError = false, message = '' }): Error => ({ isError, isApiError, message });

export const errorApiFactory = (props: Error): Error => {
  const result = { ...props, isApiError: true };
  return result;
};
