interface Access {
	password: string;
	confirmPassword: string;
}

export default Access;
