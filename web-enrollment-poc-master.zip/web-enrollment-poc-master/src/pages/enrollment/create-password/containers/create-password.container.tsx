import { FC, useReducer } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';

//developed
import { IocContainer, IocTypes, EnrollmentApiType } from 'inversify.config';
import { EnrollmentSteps } from '../../../../stores';
import CreatePassword from '../components/create-password.component';
import { useStores } from '../../../../stores/useStores';
// import { Error, Errors, errorFactory, errorApiFactory } from '../modules/models/error';
import { Error as CustomError, Errors, errorFactory, errorApiFactory } from '../modules/models/error';
import { IHTTP_ERROR, HTTP_STATUS_CODES } from 'services';
import { EnrollmentHttpService } from 'services';
import validation from '../modules/validations/password';
import type from '../modules/utils/literal-type';
import getPasswordMessages from '../modules/messages/password';

interface CreatePasswordContainerProps {}

interface State {
  password: string;
  confirmPassword: string;
  errors: Errors;
}

const errorsInitialState = { password: errorFactory({}), confirmPassword: errorFactory({}), onSubmitError: errorFactory({}), matchError: errorFactory({}) };

const initialState: State = {
  password: '',
  confirmPassword: '',
  errors: errorsInitialState
};

const actions = type.literally({
  setPassword: 'SET_PASSWORD',
  setPasswordError: 'SET_PASSWORD_ERROR',
  setPasswordFilled: 'SET_PASSWORD_FILLED',
  setConfirmPassword: 'SET_CONFIRM_PASSWORD',
  setConfirmPasswordError: 'SET_CONFIRM_PASSWORD_ERROR',
  setSubmitPassword: 'SET_SUBMIT_PASSWORD',
  setSubmitPasswordError: 'SET_SUBMIT_PASSWORD_ERROR',
  setMatchPasswordError: 'SET_MATCH_PASSWORD_ERROR',
  setBothPasswordError: 'SET_BOTH_PASSWORD_ERROR'
});

type ActionTypes =
  | 'SET_SUBMIT_PASSWORD'
  | 'SET_SUBMIT_PASSWORD_ERROR'
  | 'SET_CONFIRM_PASSWORD'
  | 'SET_CONFIRM_PASSWORD_ERROR'
  | 'SET_PASSWORD'
  | 'SET_PASSWORD_ERROR'
  | 'SET_PASSWORD_FILLED'
  | 'SET_RESEND_LINK_LOADING'
  | 'SET_MATCH_PASSWORD_ERROR'
  | 'SET_BOTH_PASSWORD_ERROR';

type Action = { type: ActionTypes; payload?: any };

const password = (state: State, error: CustomError) => ({ ...errorsInitialState, confirmPassword: state.errors.confirmPassword, password: error });

const confirmPassword = (state: State, error: CustomError) => ({ ...errorsInitialState, password: state.errors.password, confirmPassword: error });

const submitPassword = (error: CustomError) => {
  const result = { ...errorsInitialState, onSubmitError: error };
  return result;
};

const matchPassword = (state: State, error: CustomError) => ({
  ...errorsInitialState,
  confirmPassword: { ...state.errors.confirmPassword, isError: error.isError },
  password: { ...state.errors.password, isError: error.isError },
  matchError: error
});

const validatePassword = (password: CustomError, confirmPassword: CustomError): Errors => ({
  ...errorsInitialState,
  password,
  confirmPassword
});

const reducer = (state: State = initialState, action: Action): State => {
  const { type, payload } = action;
  switch (type) {
    case actions.setPassword:
      return { ...state, errors: password(state, payload.error), password: payload.password };
    case actions.setPasswordError:
      return { ...state, errors: password(state, errorFactory(payload)) };
    case actions.setConfirmPassword:
      return { ...state, errors: confirmPassword(state, payload.error), confirmPassword: payload.password };
    case actions.setConfirmPasswordError:
      return { ...state, errors: confirmPassword(state, errorFactory(payload)) };
    case actions.setSubmitPassword:
      return { ...state, errors: submitPassword(errorFactory({})), confirmPassword: payload };
    case actions.setSubmitPasswordError:
      const error = errorApiFactory(payload.error);
      const errors = submitPassword(error);
      return { ...state, errors: errors, password: payload.password, confirmPassword: payload.confirmPassword };
    case actions.setMatchPasswordError:
      return { ...state, errors: matchPassword(state, errorFactory(payload)) };
    case actions.setBothPasswordError:
      return { ...state, errors: payload.errors, password: payload.password, confirmPassword: payload.confirmPassword };
    default:
      return state;
  }
};

const useEnrollmentBehavior = () => {
  const { enrollmentStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);

  const [{ errors, password, confirmPassword }, dispatch] = useReducer(reducer, initialState);

  const isButtonDisabled =
    password.length === 0 || confirmPassword.length === 0 || (!errors.matchError.isError && (errors.password.isError || errors.confirmPassword.isError)) || errors.onSubmitError.isError;

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event.preventDefault();
    onSubmitEnterHandler();
  };

  const validateAll = async () => {
    const [pwd, cPwd, match] = await Promise.all([validation.validate(password), validation.validate(confirmPassword), validation.matchPassword().execute({ password, confirmPassword })]);

    const errors: Errors = validatePassword(pwd, cPwd);
    dispatch({ type: actions.setBothPasswordError, payload: { errors, confirmPassword, password } });

    if (!pwd.isError && !cPwd.isError) dispatch({ type: actions.setMatchPasswordError, payload: { ...match, error: { statusCode: 0 } } });
  };

  const onSubmitEnterHandler = () => {
    const { invitationCode = '', userId = '' } = enrollmentStore || {};

    const validate = validation.validateAll({ password, confirmPassword });

    // send validation states
    validateAll();
    // preventing submission of the password
    if (validate.confirmPassword.isError || validate.password.isError || validate.matchError.isError) {
      return;
    }

    EnrollmentHttpService(
      async () => await enrollmentApi.postPassword({ code: invitationCode, password: password, userId: userId }),
      () => enrollmentStore.setStep(EnrollmentSteps.Enrolled),
      ({ statusCode }: IHTTP_ERROR) => {
        switch (statusCode) {
          case HTTP_STATUS_CODES.BAD_REQUEST:
            const error = errorApiFactory({ message: getPasswordMessages().wentWrong, error: { statusCode } });
            dispatch({ type: actions.setSubmitPasswordError, payload: { error, password: '', confirmPassword: '' } });
            break;
          default:
            return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
        }
      },
      true
    );
  };

  const onPasswordChange = async (value: string) => {
    // should the validation just to be for only this password?
    if (errors.matchError.isError) {
      const [pwd, cPwd] = await Promise.all([validation.validate(value), validation.validate(confirmPassword)]);
      const errors: Errors = validatePassword(pwd, cPwd);
      dispatch({ type: actions.setBothPasswordError, payload: { errors, confirmPassword, password: value } });
    } else {
      const error = validation.validate(value);
      dispatch({ type: actions.setPassword, payload: { password: value, error } });
    }
  };

  const onConfirmPasswordChange = async (value: string) => {
    if (errors.matchError.isError) {
      const [pwd, cPwd] = await Promise.all([validation.validate(password), validation.validate(value)]);
      const errors: Errors = validatePassword(pwd, cPwd);
      dispatch({ type: actions.setBothPasswordError, payload: { errors, password, confirmPassword: value } });
    } else {
      const error = validation.validate(value);
      dispatch({ type: actions.setConfirmPassword, payload: { password: value, error } });
    }
  };

  return { onSubmitHandler, onSubmitEnterHandler, isButtonDisabled, onPasswordChange, onConfirmPasswordChange, errors, password, confirmPassword };
};

const CreatePasswordContainer: FC<CreatePasswordContainerProps> = props => {
  const { enrollmentStore } = useStores();
  const { onSubmitHandler, onSubmitEnterHandler, isButtonDisabled, onPasswordChange, onConfirmPasswordChange, errors, password, confirmPassword } = useEnrollmentBehavior();

  return (
    <CreatePassword
      store={enrollmentStore}
      errors={errors}
      onPasswordChange={onPasswordChange}
      onConfirmPasswordChange={onConfirmPasswordChange}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      password={password}
      confirmPassword={confirmPassword}
      enrollmentContext={enrollmentStore.enrollmentContext}
    />
  );
};

export default observer(CreatePasswordContainer);
