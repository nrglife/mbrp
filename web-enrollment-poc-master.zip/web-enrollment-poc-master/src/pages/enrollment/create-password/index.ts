import CreatePassword from './containers/create-password.container';

export { CreatePassword as default };