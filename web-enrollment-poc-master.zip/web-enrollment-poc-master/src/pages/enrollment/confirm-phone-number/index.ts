import ConfirmPhoneNumberContainer from './containers/confirm-phone-number.container';

export { ConfirmPhoneNumberContainer as default };
