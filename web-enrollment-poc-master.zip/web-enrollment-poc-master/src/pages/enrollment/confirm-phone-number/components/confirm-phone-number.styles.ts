/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const contentContainer = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'column',
  alignItems: 'center',
  paddingTop: '2.3rem',
  color: globalStyles.COLOR.black
});

export const content = css({
  fontSize: '1.8rem',
  lineHeight: '28px',
  maxWidth: '47.5rem',
  textAlign: 'center'
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const userPhoneNumber = css({
  textAlign: 'center'
});

export const modalContent = css({
  margin: '2rem'
});

export const checkboxesContainer = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flexStart',
  justifyContent: 'center',
  marginBottom: '3rem',
  marginTop: '.5rem'
});

export const width475 = css({
  maxWidth: '47.5rem',
  width: '100%',
});

export const checkboxesContainerTitle = css({
  fontSize: '1.4rem',
  lineHeight: '2.1rem',
  fontWeight: 'bold',
  marginTop: '1.8rem'
});

export const checkboxContainer = css({
  color: globalStyles.COLOR.greyishBrown,
  marginTop: '1.5rem'
});

export const checkbox = css({
  width: '1.8rem',
  height: '1.8rem',
  marginRight: '1rem',
  backgroundColor: 'white',
  borderRadius: '50%',
  verticalAlign: 'middle',
  border: `1px solid ${globalStyles.COLOR.greyishBrown}`,
  WebkitAppearance: 'none',
  outline: 'none',
  cursor: 'pointer',

  '&:checked': { border: `.7rem solid ${globalStyles.COLOR.tealBlue}` }
});

export const checkboxDisabled = css({
  border: `1px solid ${globalStyles.COLOR.lightGrey}`,
  cursor: 'wait',

  '&:checked': { border: `.7rem solid ${globalStyles.COLOR.lightGrey}` }
});

export const appSupportPhoneNumberMsgContainer = css({
  maxWidth: '26.5rem',
  marginBottom: '2rem',
  fontSize: '1.3rem',
  lineHeight: '1.5rem',
  color: globalStyles.COLOR.charcoalGreyFive,
  marginLeft: '2.5rem',

  '@media (max-width: 400px)': {
    marginLeft: '4.5rem'
  },

  '@media (max-width: 380px)': {
    marginLeft: '5rem'
  },

  '@media (max-width: 320px)': {
    marginLeft: '2.5rem'
  }
});

export const radioLabelDescription = css({
  fontSize: '1.3rem',
  lineHeight: '1.5rem',
  color: globalStyles.COLOR.charcoalGreyFive,
  marginLeft: '3rem',
});

export const appSupportPhoneNumberLink = (theme: Preferences) =>
  css({
    marginLeft: '.5rem',
    textDecoration: 'none',
    color: theme.colors.actionMedium.published
  });

//SMS Send Styles
export const resendLoaderContainer = css({
  display: 'flex',
  justifyContent: 'left'
});

export const disableLink = css({
  display: 'flex',
  justifyContent: 'left',
  color: globalStyles.COLOR.greyishBrown,
  fontStyle: 'italic',
  alignItems: 'center'
});

export const resendLink = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    display: 'flex',
    justifyContent: 'left',
    '&:hover': {
      transition: 'all .3s',
      cursor: 'pointer',
      position: 'relative',
      top: '-1px'
    }
  });

export const verificationContainer = css({
  textAlign: 'left',
  marginBottom: '2rem'
});

export const formDescription = css({
  fontSize: '1.8rem',
  color: globalStyles.COLOR.black,
  lineHeight: '2.2rem',
  width: '100%',
  margin: '1rem 0',
  maxWidth: '46rem'
});

export const expiresTimeLabel = css({
  marginTop: '0.8rem',
  fontSize: '1.4rem',
  color: '#37474f',
  alignSelf: 'flex-start'
});

export const noticeLabel = css({
  marginTop: '0.8rem',
  fontSize: '1.15rem',
  color: globalStyles.COLOR.coolGrey,
  alignSelf: 'flex-start'
});

export const smallFont = css({
  fontSize: '1.4rem'
});

export const boldFont = css({
  fontWeight: 'bold'
});
