import { useState, FC, useEffect } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import ClipLoader from 'react-spinners/ClipLoader';
import { observer } from 'mobx-react';
import { useStores } from '../../../../stores/useStores';
import { EnrollmentContext } from 'stores';
//developed
import OtpInput from 'components/general/OTP';
import EnrollmentPagesWrapper from 'pages/enrollment/enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
//styles
import * as styles from './confirm-phone-number.styles';
import { ReactComponent as CheckFilledIcon } from 'assets/icons/check-filled.svg';
import * as enrollmentGlobalStyles from 'pages/enrollment/enrollment-page.styles';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { SendCodeMethod } from '@healthcareapp/connected-health-common-services/dist/stores/EnrollmentStore';

interface ConfirmPhoneNumberProps {
  userName: string;
  userPhoneLastDigits: string | string[];
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  onChangeSelectedPhoneNumber: Function;
  selectedSendMethod: SendCodeMethod;
  //TODO: oreng: check if we really not gonna use payerName & payerWebsite and delete them
  payerName: string;
  payerWebsite: string;
  //SMS Send Vars
  isResendLinkLoading: boolean;
  resendHandler: any;
  invitationCodeFormat: string;
  isErrorPhoneNumber: boolean;
  isErrorVerificationCode: boolean;
  onOTPChange: any;
  setCodeFullFilled: any;
  isButtonDisabled: boolean;
  remainingAttempts: number;
  enrollmentContext: EnrollmentContext;
}
const resendWaitSeconds = { 1: 10, 2: 60, 3: 3 * 60 };

const ConfirmPhoneNumber: FC<ConfirmPhoneNumberProps> = ({
  userName,
  userPhoneLastDigits,
  onSubmitHandler,
  onSubmitEnterHandler,
  onChangeSelectedPhoneNumber,
  selectedSendMethod,
  isResendLinkLoading,
  resendHandler,
  invitationCodeFormat,
  isErrorPhoneNumber,
  isErrorVerificationCode,
  onOTPChange,
  setCodeFullFilled,
  isButtonDisabled,
  remainingAttempts,
  enrollmentContext
}) => {
  const [disableLink, setDisableLink] = useState(false);
  const [resendPressNumber, setResendPressNumber] = useState(1);
  const [disableLinkTimeoutId, setDisableLinkTimeoutId] = useState<NodeJS.Timeout | null>(null);
  const { t } = useTranslation('translation');
  const { ConfirmPhoneNumber: ConfirmPhoneNumberLocalKeys } = LocaleKeys.components.Enrollment;

  //in case the phone number is single, we want it as a list
  if (!Array.isArray(userPhoneLastDigits))
    userPhoneLastDigits = [userPhoneLastDigits];

  const upperText = t(ConfirmPhoneNumberLocalKeys.ConfirmIdentityCode); // `To confirm your identity, we’ll send a unique code to your mobile number. This code expires in 10 minutes.`;
  const { themeStore, appConfigStore, enrollmentStore } = useStores();

  const appSupportPhoneNumberMsg = t(ConfirmPhoneNumberLocalKeys.NoSmsPleaseCall); // 'If you cannot receive SMS at this number please call'
  const appSupportPhoneNumber =
    appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers &&
    appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers.length > 0 &&
    appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers.filter(number => number && number !== '')[0];

  const onResendPress = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    //disable resend link for the amount of needed time
    const waitMilliSeconds = resendWaitSeconds[resendPressNumber] ? resendWaitSeconds[resendPressNumber] * 1000 : 3 * 60 * 1000;
    setDisableLink(true);
    setResendPressNumber(resendPressNumber + 1);

    const timeoutId = setTimeout(() => {
      //enable the option to use resend link only if this is at the most the x time press (depened on resenedWaitSeconed obj)
      setDisableLink(false);
    }, waitMilliSeconds);

    //clear old Timeout
    disableLinkTimeoutId && clearTimeout(disableLinkTimeoutId);
    //set new Timeout to clear next press or at component unmount
    setDisableLinkTimeoutId(timeoutId);
    //do the resend action got from the props of the component
    resendHandler(event);
  };

  useEffect(() => {
    return () => {
      //clear old Timeout at component unmount
      disableLinkTimeoutId && clearTimeout(disableLinkTimeoutId);
    };
  }, [disableLinkTimeoutId]);

  let title = t(ConfirmPhoneNumberLocalKeys.TitleUnified); // "Let's confirm your identity";

  if (!enrollmentContext.isLandingPageUnified) {
    if (!enrollmentContext.isDelegate) {
      // Member flow
      title = t(ConfirmPhoneNumberLocalKeys.TitleMember, { userName: userName && userName?.toLowerCase() !== 'unknown' ? ' ' + userName : '' }); // `Hi{{ userName }}, we found your account`
    } else {
      // Delegate flow
      title = t(ConfirmPhoneNumberLocalKeys.TitleDelegate); // "Let's confirm your identity";
    }
  }

  let codeSentMessage = '';
  switch (selectedSendMethod) {
    case SendCodeMethod.SMS: {
      codeSentMessage = t(ConfirmPhoneNumberLocalKeys.VerificationCodeSent);//"Verification code sent"
      break;
    }
    case SendCodeMethod.Voice: {
      codeSentMessage = t(ConfirmPhoneNumberLocalKeys.CallComing);//"Call is coming, stand by";
      break;
    }
  }

  return (
    <EnrollmentPagesWrapper
      title={title}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isWrapperAutoFocus={false}
      isButtonDisabled={isButtonDisabled}
      withCiamBtn={!enrollmentContext.isLandingPageUnified && !enrollmentContext.isDelegate}
      withQuestionBtn={enrollmentContext.isLandingPage}
      isError={isErrorPhoneNumber || isErrorVerificationCode}>
      <div css={styles.contentContainer}>
        {(isErrorPhoneNumber || isErrorVerificationCode) && (
          <div css={[enrollmentGlobalStyles.errorMessage, { textAlign: 'center', whiteSpace: 'pre-wrap', marginBottom: '2.2rem', fontsize: '1.8rem' }]}>
            {t(LocaleKeys.errors.something_wrong_try_again)}
            <div css={!!remainingAttempts && remainingAttempts < 3 ? styles.boldFont : {}}>
              {remainingAttempts > 0 ? t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainingAttempts, s: remainingAttempts > 1 ? 's' : '' }) : ``}
            </div>
          </div>
        )}

        <div css={styles.width475}>
          <p css={styles.content}>{upperText}</p>
          <div>
            <p css={styles.checkboxesContainerTitle}>Send code to:</p>
            <div css={styles.checkboxesContainer}>
              {userPhoneLastDigits.map((phone, i) => (
                <div key={phone} css={[styles.checkboxContainer, i === 0 ? { marginTop: '0rem' } : {}]}>
                  <input
                    autoFocus={i === 0}
                    type="radio"
                    css={[styles.checkbox, disableLink && styles.checkboxDisabled]}
                    id={phone}
                    name="userSelectedPhoneNumber"
                    value={phone}
                    defaultChecked={i === 0}
                    onClick={() => { onChangeSelectedPhoneNumber(phone) }}
                    disabled={disableLink}
                  />
                  <label css={[styles.content, styles.userPhoneNumber]}>{`(***) ***-${phone}`}</label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <p css={styles.checkboxesContainerTitle}>Send code via:</p>
            <div css={styles.checkboxesContainer}>
              <div key={SendCodeMethod.SMS} css={[styles.checkboxContainer, { marginTop: '0rem' }]}>
                <input
                  autoFocus={true}
                  type="radio"
                  css={[styles.checkbox, disableLink && styles.checkboxDisabled]}
                  id={SendCodeMethod.SMS}
                  name="userSelectedSendMethod"
                  value={SendCodeMethod.SMS}
                  defaultChecked={true}
                  onClick={() => enrollmentStore.setSelectedSendMethod(SendCodeMethod.Voice)}
                  disabled={disableLink}
                />
                <label css={[styles.content, styles.userPhoneNumber]}>{t(ConfirmPhoneNumberLocalKeys.TextMessage)}</label>  {/* Text Message */}
                <div css={[styles.radioLabelDescription]}>
                  <span>{t(ConfirmPhoneNumberLocalKeys.DataRatesMayApply)}</span> {/* Message and data rates may apply. */}
                  {appSupportPhoneNumber && <>
                    <span>{appSupportPhoneNumberMsg}</span>
                    <a href={`tel:${appSupportPhoneNumber}`} css={styles.appSupportPhoneNumberLink(themeStore.currentTheme)}>
                      {appSupportPhoneNumber}
                    </a>
                    <span>.</span>
                  </>}
                </div>

              </div>
              <div key={SendCodeMethod.Voice} css={[styles.checkboxContainer]}>
                <input
                  autoFocus={true}
                  type="radio"
                  css={[styles.checkbox, disableLink && styles.checkboxDisabled]}
                  id={SendCodeMethod.Voice}
                  name="userSelectedSendMethod"
                  value={SendCodeMethod.Voice}
                  onClick={() => enrollmentStore.setSelectedSendMethod(SendCodeMethod.Voice)}
                  disabled={disableLink}
                />
                <label css={[styles.content, styles.userPhoneNumber]}>{t(ConfirmPhoneNumberLocalKeys.VoiceCall)}</label>  {/* Voice Call */}
                <div css={[styles.radioLabelDescription]}>{t(ConfirmPhoneNumberLocalKeys.SelectReceiveAnAutomated)}</div> {/* Select this option to receive an automated phone call with your confirmation code. Be prepared to write the code down. */}
              </div>
            </div>
          </div>

          <div>
            <div css={{ marginBottom: '3.5rem' }}>
              {isResendLinkLoading ? (
                <div css={[styles.resendLoaderContainer, { alignSelf: 'flex-start' }]}>
                  <ClipLoader size="20px" color={'#498DFF'} />
                </div>
              ) : (
                <div css={[disableLink ? styles.disableLink : styles.resendLink(themeStore.currentTheme), { alignSelf: 'flex-start' }]} onClick={disableLink ? () => { } : onResendPress}>
                  {disableLink && (
                    <div css={{ marginRight: '.4rem' }}>
                      <CheckFilledIcon css={{ width: '2rem', height: '2rem' }} />
                    </div>
                  )}
                  {disableLink ? <div>{codeSentMessage}</div> : <div>{resendPressNumber === 1 ? 'Send' : 'Resend'} code</div>}
                </div>
              )}
            </div>
            <div css={[styles.verificationContainer, (!(resendPressNumber > 1) || isErrorPhoneNumber) && { opacity: 0, pointerEvents: 'none' }]}>
              <p css={styles.formDescription}>{t(ConfirmPhoneNumberLocalKeys.EnterCodeBelow)}</p> {/* 'Enter the code below:' */}
              <div
                css={{
                  flex: 1,
                  alignItems: 'center',
                  flexDirection: 'column',
                  justifyContent: 'left',
                  display: 'flex',
                  flexGrow: 1,
                  alignContent: 'left'
                }}>
                <OtpInput format={invitationCodeFormat} hasErrored={isErrorVerificationCode} autoFocus={false} onChange={onOTPChange} setCodeFullFilled={setCodeFullFilled} />
                <p css={[enrollmentGlobalStyles.errorMessage, styles.smallFont, { alignSelf: 'flex-start', marginTop: '0.8rem' }]}>
                  {isErrorVerificationCode ? t(LocaleKeys.errors.wrong_verification_code) : ' '}
                </p>
                <div css={styles.expiresTimeLabel}>{t(ConfirmPhoneNumberLocalKeys.ExpiresIn)}</div> {/* 'Expires in 10 minutes' */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default observer(ConfirmPhoneNumber);
