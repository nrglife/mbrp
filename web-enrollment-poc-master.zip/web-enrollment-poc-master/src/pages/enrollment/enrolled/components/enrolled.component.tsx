import { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import * as styles from './enrolled.styles';
import { EnrollmentContext } from 'stores';
import { formatDate, isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';

interface EnrolledProps {
  email: string | null;
  delegatorName?: string;
  onDelegateDoneHandler: () => void;
  enrollmentContext: EnrollmentContext;
}

export const Enrolled: FC<EnrolledProps> = ({ email, delegatorName, onDelegateDoneHandler, enrollmentContext }) => {
  const { t } = useTranslation('translation');
  const { Enrolled: EnrolledLocalKeys } = LocaleKeys.components.Enrollment;

  let title = t(EnrolledLocalKeys.TitleUnified); // 'Sign in to get started';

  if (!enrollmentContext.isLandingPageUnified) {
    if (!enrollmentContext.isDelegate) {
      // Member flow
      title = t(EnrolledLocalKeys.TitleMember); // 'Welcome to Connected Health.'
    } else if (enrollmentContext.isLandingPage) {
      // Delegate flow - landing page
      title = t(EnrolledLocalKeys.TitleDelegateLandingPage); // "Sign in to get started",
    } else {
      // Delegate flow - add new button
      title = t(EnrolledLocalKeys.TitleDelegateAddButton); // 'Delegate account linked'
    }
  }

  const getOneYearFromNow = () => {
    const date = new Date();
    date.setFullYear(date.getFullYear() + 1);
    return formatDate(date.toISOString());
  };

  return (
    <EnrollmentPagesWrapper
      title={title}
      withCiamBtn={!enrollmentContext.isDelegate}
      withCiamLinkText={false}
      withQuestionBtn={false}
      onSubmitHandler={enrollmentContext.isDelegate ? onDelegateDoneHandler : undefined}
      actionButtonText={
        enrollmentContext.isLandingPage
          ? t(EnrolledLocalKeys.ButtonContinue) // 'CONTINUE'
          : t(EnrolledLocalKeys.ButtonDone) // 'DONE'
      }>
      <div css={styles.container}>
        {enrollmentContext.isLandingPage ? (
          <>
            <p css={styles.textStyle}>
              {
                t(EnrolledLocalKeys.DescriptionLandingPageSetupComplete) // Your account setup is complete.
              }
            </p>
            {email && (
              <p css={styles.textStyle}>
                {
                  t(EnrolledLocalKeys.DescriptionLandingPageNextStep) // The next step is to sign in with the email you just used for verification:
                }
                <br />
                <br />
                <b css={styles.bold}>{email}</b>
              </p>
            )}
          </>
        ) : (
          // Not landing page (Add delegate button)
          <>
            <p css={styles.textStyle}>
              {
                // `You are now a delegate{{forDelegatorName}} on Connected Health. This access will expire in one year on {{oneYearDate}}.`
                t(EnrolledLocalKeys.DescriptionAddButtonYouAreDelegate, { forDelegatorName: delegatorName && ' for ' + delegatorName, oneYearDate: getOneYearFromNow() })
              }
            </p>
            <br />
            <br />
            <p css={styles.textStyle}>
              {
                t(EnrolledLocalKeys.DescriptionAddButtonChangeView) // To change your view select from the available members in the menu of the top right of the screen.
              }
            </p>
          </>
        )}
      </div>
    </EnrollmentPagesWrapper>
  );
};
