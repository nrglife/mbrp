import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

export const container = css({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  marginBottom: '3.0rem',
  paddingTop: '4.5rem',
});

export const textStyle = css({
  // maxWidth: '350px',
  minHeight: '44px',
  fontSize: '1.8rem',
  fontWeight: 'normal',
  fontStretch: 'normal',
  fontStyle: 'normal',
  lineHeight: 1.22,
  letterSpacing: 'normal',
  color: globalStyles.COLOR.black,
  textAlign: 'center'
});


export const bold = css({
  fontWeight: 'bold'
});
