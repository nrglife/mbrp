export { EnrolledContainer as default } from './containers/enrolled.container';
