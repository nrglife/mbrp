import { FC } from 'react';
import { useStores } from 'stores/useStores';
import { Enrolled } from '../components/enrolled.component';

interface EnrolledContainerProps {}

export const EnrolledContainer: FC<EnrolledContainerProps> = props => {
  const { enrollmentStore, userStore } = useStores();

  const email = enrollmentStore.selectedEmail;
  const delegatorName = enrollmentStore.enrollmentContext.isDelegate ? enrollmentStore.userCredentials?.firstname : undefined;

  const onDelegateDoneHandler = () => {
    enrollmentStore.setModalVisibility(false);
  };

  return <Enrolled email={email} delegatorName={delegatorName} onDelegateDoneHandler={onDelegateDoneHandler} enrollmentContext={enrollmentStore.enrollmentContext} />;
};
