import { FC } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';
import { useStores } from '../../../../stores/useStores';
import { ContactUsComponent } from '../components/contact-us.component';

interface ContactUsContainerProps {}

const useContactUSContainerBehavior = () => {
  const { enrollmentStore } = useStores();
  const mainTitle = 'Contact Us';
  const closeButtonText = enrollmentStore.showModal == true ? 'BACK TO ENROLLMENT' : 'CLOSE';
  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    onSubmitEnterHandler();
  };

  const onSubmitEnterHandler = () => {
    enrollmentStore.setContactUsVisibility(false);
  };
  return { mainTitle, onSubmitHandler, onSubmitEnterHandler, closeButtonText };
};

const ContactUsContainer: FC<ContactUsContainerProps> = props => {
  const { mainTitle, closeButtonText, onSubmitHandler, onSubmitEnterHandler } = useContactUSContainerBehavior();
  return <ContactUsComponent mainTitle={mainTitle} actionButtonText={closeButtonText} onSubmitHandler={onSubmitHandler} onSubmitEnterHandler={onSubmitEnterHandler} />;
};

export default observer(ContactUsContainer);
