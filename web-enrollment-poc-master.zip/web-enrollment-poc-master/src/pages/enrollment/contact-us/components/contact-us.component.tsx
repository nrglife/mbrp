import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import EnrollmentPagesWrapper from 'pages/enrollment/enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import * as styles from './contact-us.styles';
import { observer } from 'mobx-react';
import { useStores } from 'stores/useStores';
import PayerContactDetails from '../../../../components/contact-details/payer-contact-details';
import AppContactDetails from '../../../../components/contact-details/app-contact-details';

interface IContactUsComponent {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  mainTitle: string;
  actionButtonText: string;
}

export const ContactUsComponent: FC<IContactUsComponent> = observer(({ onSubmitEnterHandler, onSubmitHandler, mainTitle, actionButtonText }) => {
  const { responsiveStore, appConfigStore, payerStore } = useStores();

  let technicalAppSupportDisplay = !!(appConfigStore?.phone?.trim() || appConfigStore?.email?.trim())
    && !!appConfigStore?.currentConfig?.appSupportVisible;

  let insuranceSupportDisplay = !!(payerStore?.primaryPhone?.trim() || payerStore?.primaryEmail?.trim() || payerStore?.payer?.address?.trim())
    && !!appConfigStore?.currentConfig?.insuranceSupportVisible;

  let isEmptyContactUs = !technicalAppSupportDisplay && !insuranceSupportDisplay;
  let isWholeContactUs = technicalAppSupportDisplay && insuranceSupportDisplay;

  return (
    <EnrollmentPagesWrapper title={mainTitle} actionButtonText={actionButtonText} onSubmitHandler={onSubmitHandler} onSubmitEnterHandler={onSubmitEnterHandler} withQuestionBtn={false}>
      <div css={[styles.contactMainContainer, responsiveStore.isMobile && { padding: '3rem 0' }]}>
        {!isEmptyContactUs && <>
          {technicalAppSupportDisplay && <div>
            {insuranceSupportDisplay && <h1 css={styles.scondaryTitle}>{'Technical & App Issues'}</h1>}
            <div css={[styles.detailsContainer]}>
              <AppContactDetails isReduceView={!insuranceSupportDisplay} />
            </div>
          </div>}
          {isWholeContactUs && <div css={styles.contactUsSeparator} />}
          {insuranceSupportDisplay && <div>
            {technicalAppSupportDisplay && <h1 css={styles.scondaryTitle}>{'Insurance, Billing & Benefits'}</h1>}
            <div css={[styles.detailsContainer]}>
              <PayerContactDetails isReduceView={!technicalAppSupportDisplay} />
            </div>
          </div>}
        </>}
        {isEmptyContactUs &&
          <p css={styles.emptyContactUs}>{`Call the number on your ${payerStore?.payerName} card.`}</p>
        }
      </div>
    </EnrollmentPagesWrapper>
  );
});
