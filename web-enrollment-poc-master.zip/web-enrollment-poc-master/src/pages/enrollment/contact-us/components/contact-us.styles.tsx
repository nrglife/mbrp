/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const contactMainContainer = css({
  display: 'flex',
  flexDirection: 'column',
  padding: '6rem 4rem 4.6rem 4rem'
});

export const contactContainer = css({
  display: 'flex',
  height: '100%',
  flexDirection: 'column',  
});

export const xSign = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '58px'
});

export const text = css({
  fontSize: '1.8rem',
  fontWeight: 400,
  fontStretch: 'normal',
  lineHeight: 1.22,
  color: globalStyles.COLOR.black
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });



export const scondaryTitle = css({
  fontSize: '2.6rem',
  fontWeight: 600,
  color: globalStyles.COLOR.charcoalGreyTwo,
  //height: '3.4rem'
});

export const emptyContactUs = css({
  fontSize: '1.6rem',
  lineHeight: '2.0rem',
  color: globalStyles.COLOR.blackTwo,
  whiteSpace: 'pre-wrap',
  margin: 'auto',
  paddingBottom: '5rem'
});

export const contactUsSeparator = css({
  height: '0.1rem',
  backgroundColor: globalStyles.COLOR.veryLightPinkThree,
  margin: '2rem 0'
});

export const detailsContainer = css({
  paddingTop: '1.2rem',
  float: 'left'
});

export const payerDetails = css({
  marginBottom: '4.6rem'
});

export const spaceBetweenLinesStyle = css({ marginTop: '1.5em' });
