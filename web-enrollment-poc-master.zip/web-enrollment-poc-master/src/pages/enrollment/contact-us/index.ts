import ContactUsContainer from './container/contact-us.container';

export { ContactUsContainer as default };
