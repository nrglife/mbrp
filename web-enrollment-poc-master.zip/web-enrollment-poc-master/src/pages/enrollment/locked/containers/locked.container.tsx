import { FC } from 'react';
import * as React from 'react';
import Locked from '../components/locked.component';
import { observer } from 'mobx-react';
import { useStores } from '../../../../stores/useStores';
import { EnrollmentSteps } from 'stores';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface LockedContainerProps {}

const useLockedContainerBehavior = () => {
  const { routesStore, enrollmentStore, themeStore, payerStore } = useStores();
  const { t } = useTranslation('translation');

  const mainTitle = t(LocaleKeys.errors.invitation_code_locked);
  const description = t(LocaleKeys.errors.enrollment_invitation_code_locked);

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    onSubmitEnterHandler();
  };

  const onSubmitEnterHandler = () => {
    enrollmentStore.setModalVisibility(false);
  };

  const onContactUsClickHandler = () => {
    enrollmentStore.setContactUsVisibility(true);
  };

  return { mainTitle, description, routesStore, onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, themeStore, payerStore };
};

const LockedContainer: FC<LockedContainerProps> = props => {
  const { mainTitle, description, routesStore, onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, themeStore, payerStore } = useLockedContainerBehavior();
  return (
    <Locked
      mainTitle={mainTitle}
      description={description}
      payer={payerStore.payer}
      theme={themeStore.currentTheme}
      onContactUsClickHandler={onContactUsClickHandler}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
    />
  );
};

export default observer(LockedContainer);
