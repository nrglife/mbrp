import LockedContainer from './containers/locked.container';

export { LockedContainer as default };
