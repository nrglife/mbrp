import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

import { Preferences } from '../../../../stores/ThemeStore';

export const lockedMainContainer = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  flex: 1
});

export const lockedContainer = css({
  display: 'flex',
  height: '100%',

  flexDirection: 'column',
  padding: '0 5rem'
});

export const xSign = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '58px'
});

export const text = css({
  fontSize: '1.8rem',
  fontWeight: 'normal',
  fontStretch: 'normal',
  lineHeight: 1.56,
  color: globalStyles.COLOR.greyishBrown,
  marginTop: '41px'
});

export const callTo = (theme: Preferences) =>
  css({
    margin: 'auto 0 auto',
    padding: '3rem 0.5rem',
    color: theme.colors.actionMedium.published
  });

export const linkTextStyle = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none',
    cursor: 'pointer'
  });
