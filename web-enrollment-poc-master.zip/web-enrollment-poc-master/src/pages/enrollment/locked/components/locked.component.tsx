import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { ReactComponent as ErrorIcon } from '../../../../assets/icons/x-icons.svg';
import * as styles from './locked.styles';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { Preferences } from '../../../../stores/ThemeStore';
import { uppercaseFirstLetter } from '@healthcareapp/connected-health-common-services/dist/utilities/string';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { useTranslation } from 'react-i18next';
import { IPayer } from '@healthcareapp/connected-health-common-services/dist/stores/PayerStore';

interface LockedProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  onContactUsClickHandler: () => void;
  mainTitle: string;
  description: string;
  payer: IPayer | null;
  theme: Preferences;
}

const Locked: FC<LockedProps> = ({ mainTitle, description, payer, theme, onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler }) => {
  const { t, i18n } = useTranslation('translation');
  const payerLink = (
    <a onClick={onContactUsClickHandler} css={styles.linkTextStyle(theme)}>
      {t(LocaleKeys.errors.contact_payer_name, { payerName: payer?.fullName || uppercaseFirstLetter(payer?.shortName) || t(LocaleKeys.errors.us) })}
    </a>
  );

  return (
    <EnrollmentPagesWrapper title={mainTitle} actionButtonText="CLOSE" onSubmitHandler={onSubmitHandler} onSubmitEnterHandler={onSubmitEnterHandler} withQuestionBtn={false}>
      <div css={styles.lockedMainContainer}>
        <div css={styles.lockedContainer}>
          <div css={styles.xSign}>
            <ErrorIcon />
          </div>
          <p css={styles.text}>{`${description}`}</p>
          <p css={[styles.text, { marginTop: '48px', marginBottom: '60px' }]}>{payerLink} for help.</p>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default Locked;
