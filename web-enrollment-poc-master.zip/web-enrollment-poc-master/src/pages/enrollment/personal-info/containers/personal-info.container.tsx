import { useEffect } from 'react';

//CommonServices
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';

import PersonalInfo from '../components/personal-info.component';
import { FC } from 'react';
import { useStores } from '../../../../stores/useStores';
import { observer } from 'mobx-react';
import { EnrollmentSteps } from 'stores';

interface PersonalInfoContainerProps {}

const PersonalInfoContainer: FC<PersonalInfoContainerProps> = props => {
  const { enrollmentStore } = useStores();
  useEffect(() => {
    const timeoutId = enrollmentStore.registerEnrollmentTimeout(() => {
      console.log('TIMEOUT from personal info screen: ', timeoutId);
      enrollmentStore.clearAllRegisteredTimeouts();
      enrollmentStore.setContactUsVisibility(false);
      enrollmentStore.setStep(EnrollmentSteps.Timeout);
    }, minutesToMilliseconds((window as any)?.env?.REACT_APP_ENROLLMENT_GLOBAL_TIME_OUT_IN_MINUTES));
  }, [enrollmentStore]);

  return <PersonalInfo store={enrollmentStore} enrollmentContext={enrollmentStore.enrollmentContext} />;
};

export default observer(PersonalInfoContainer);
