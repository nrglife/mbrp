//CommonServices
import { isValidDate } from '@healthcareapp/connected-health-common-services/dist/utilities/dates';

import { FC, useRef, useEffect, useReducer, useCallback } from 'react';
import * as React from 'react';
import moment from 'moment';
import { observer } from 'mobx-react';
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import { IocContainer, IocTypes, EnrollmentApiType } from 'inversify.config';
import OtpInput from '../../../../components/general/OTP';
import { IHTTP_ERROR } from '../../../../services';
import { EnrollmentStoreType, EnrollmentSteps, EnrollmentContext, PersonalSecretIdentifier } from 'stores';
import { EnrollmentHttpService } from '../../../../services';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { upperCase } from "utils/string";

//styles
import * as enrollmentGlobalStyles from '../../enrollment-page.styles';
import * as styles from './personal-info.styles';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import { useStores } from '../../../../stores/useStores';
import {} from 'stores';

interface PersonalInfoProps {
  store: EnrollmentStoreType;
  enrollmentContext: EnrollmentContext;
}

interface State {
  zipCodeValue: string;
  birthdayValue: string;
  identityValue: string;
  isBirthdayDateError: boolean;
  isError: boolean;
}

const initialState: State = {
  zipCodeValue: '',
  birthdayValue: '',
  identityValue: '',
  isBirthdayDateError: false,
  isError: false
};

type ActionTypes = 'SET_ZIP_CODE' | 'SET_BIRTHDAY_DATE' | 'SET_IDENTITY' | 'SET_ERROR' | 'SET_INVALID_DATE_ERROR';
type Action = { type: ActionTypes; payload?: any };

const reducer = (state: State = initialState, action: Action): State => {
  const { type, payload } = action;
  switch (type) {
    case 'SET_ZIP_CODE':
      return { ...state, isError: false, zipCodeValue: payload };
    case 'SET_BIRTHDAY_DATE':
      return { ...state, isError: false, isBirthdayDateError: false, birthdayValue: payload };
    case 'SET_IDENTITY':
      return { ...state, isError: false, identityValue: payload };
    case 'SET_INVALID_DATE_ERROR':
      return { ...state, isBirthdayDateError: payload };
    case 'SET_ERROR':
      return { ...state, isError: payload };
  }
};

const PersonalInfo: FC<PersonalInfoProps> = ({ store, enrollmentContext }) => {
  const zipCodeRef = useRef<OtpInput>(null);
  const birthdayRef = useRef<OtpInput>(null);
  const ssnRef = useRef<OtpInput>(null);
  const secretRef = useRef<HTMLInputElement>(null);
  const inputsFullfillment = useRef(Array(3).fill(false));

  const [{ zipCodeValue, birthdayValue, identityValue, isBirthdayDateError, isError }, dispatch] = useReducer(reducer, initialState);

  const { enrollmentStore, appConfigStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);

  useEffect(() => {
    secretRef.current && secretRef.current.focus();
  }, []);

  const isFormValid = useCallback(() => {
    let isValid = true;
    const date = moment(birthdayValue, 'MMDDYYYY');
    if (!identityValue || !zipCodeValue || !date.isValid()) {
      dispatch({ type: 'SET_INVALID_DATE_ERROR', payload: !date.isValid() });
      isValid = false;
    }
    return isValid;
  }, [identityValue, birthdayValue, zipCodeValue]);

  const onSubmitEnterHandler = useCallback(() => {
    if (!isFormValid) return;

    const dataToSend = {
      ssn: enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.ssn ? identityValue : '',
      secret: enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.secret ? identityValue : '',
      dateOfBirth: moment(birthdayValue, 'MMDDYYYY').format('YYYY-MM-DD').toString(),
      postalcode: zipCodeValue
    };

    EnrollmentHttpService(
      async () => await enrollmentApi.postPersonalInfo({ code: store.invitationCode, data: dataToSend }),
      response => {
        const { data } = response;
        enrollmentStore.setUserCredentials({ ...data });

        const noUserPhone =
          !data.phone || (data.phone && Array.isArray(data.phone) && data.phone.length === 0) || (data.phone && Array.isArray(data.phone) && !data.phone.filter(number => number && number !== '')[0]);
        const appSupportPhoneNumber =
          appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers &&
          appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers.length > 0 &&
          appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers.filter(number => number && number !== '')[0];
        //in case there is not any phone numbers to show and no customer support number
        if (noUserPhone && !appSupportPhoneNumber) return store.setStep(EnrollmentSteps.GeneralError);
        //in case there is not any phone numbers but customer support number exist
        if (noUserPhone) return store.setStep(EnrollmentSteps.NoUserPhone);
        //all the required data exist, continue to the next step in the enrolment flow
        store.setStep(EnrollmentSteps.ConfirmPhoneNumber);
      },
      (error: IHTTP_ERROR) => {
        /*
            potential errors this screen should handle:
            case HTTP_STATUS_CODES.BAD_REQUEST: (400)
          */
        dispatch({ type: 'SET_ERROR', payload: true });
      }
    );
  }, [identityValue, birthdayValue, zipCodeValue, enrollmentStore, isFormValid, store]);

  const onSubmitHandler = useCallback(
    async (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
      event?.preventDefault();
      if (!isFormValid) return;

      onSubmitEnterHandler();
    },
    [isFormValid, onSubmitEnterHandler]
  );

  const onSSNChanged = useCallback(
    (otp: string, isDone: boolean) => {
      dispatch({ type: 'SET_IDENTITY', payload: otp });
      inputsFullfillment.current[0] = isDone;
      if (!inputsFullfillment.current[1]) {
        birthdayRef.current && birthdayRef.current.setFocus();
      } else if (!inputsFullfillment.current[2]) {
        zipCodeRef.current && zipCodeRef.current.setFocus();
      }
    },
    [dispatch]
  );

  const onSecretChanged = useCallback(
    (value: string) => {
      inputsFullfillment.current[0] = value !== '' ? true : false;

      dispatch({ type: 'SET_IDENTITY', payload: value });
    },
    [dispatch]
  );

  const onBirthdayChanged = useCallback(
    (otp: string, isDone: boolean) => {
      const todayDate = new Date(moment(Date.now()).format('YYYY-MM-DD')).getTime();
      const isValidDOB = isDone && isValidDate(otp, ['MMDDYYYY']) && new Date(moment(otp, 'MMDDYYYY').format('YYYY-MM-DD')).getTime() < todayDate;

      isBirthdayDateError && dispatch({ type: 'SET_INVALID_DATE_ERROR', payload: false });
      dispatch({ type: 'SET_BIRTHDAY_DATE', payload: otp });
      inputsFullfillment.current[1] = isDone;

      if (!inputsFullfillment.current[2]) zipCodeRef.current && zipCodeRef.current.setFocus();
      if (isDone && !isValidDOB) dispatch({ type: 'SET_INVALID_DATE_ERROR', payload: true });
    },
    [dispatch, isBirthdayDateError]
  );

  const onZipCodeChanged = useCallback(
    (otp: string, isDone: boolean) => {
      dispatch({ type: 'SET_ZIP_CODE', payload: otp });
      inputsFullfillment.current[2] = isDone;
      if (!inputsFullfillment.current[0]) {
        if (enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.ssn) {
          ssnRef.current && ssnRef.current.setFocus();
        } else if (enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.secret) {
          secretRef.current && secretRef.current.focus();
        }
      }
    },
    [dispatch, enrollmentStore.userSecretMetadata]
  );

  const isButtonDisabled = () => isError || isBirthdayDateError || !inputsFullfillment.current || !inputsFullfillment.current[0] || !inputsFullfillment.current[1] || !inputsFullfillment.current[2];
  const { t } = useTranslation('translation');
  const { PersonalInfo: PersonalInfoLocalKeys } = LocaleKeys.components.Enrollment;

  let title = t(PersonalInfoLocalKeys.TitleLandingUnified); // 'Confirm personal information';
  let description = t(PersonalInfoLocalKeys.DescriptionUnified); // "In order to protect personal information we need to ask you a few security questions."
  let ssnFormLabel = upperCase(t(PersonalInfoLocalKeys.SsnLabelUnified)); // "LAST 4 DIGITS OF SSN"
  let birthdayFormLabel = upperCase(t(PersonalInfoLocalKeys.BirthdayUnified)); // "BIRTHDAY"
  let zipCodeFormLabel = upperCase(t(PersonalInfoLocalKeys.ZipCodeUnified)); // 'ZIP CODE'

  if (!enrollmentContext.isLandingPageUnified) {
    if (!enrollmentContext.isDelegate) {
      // Member flow
      title = t(PersonalInfoLocalKeys.TitleMember); // "Let’s confirm your personal information"
      description = t(PersonalInfoLocalKeys.DescriptionMember); // 'In order to protect your personal information we need to ask you a few security questions.'
      ssnFormLabel = upperCase(t(PersonalInfoLocalKeys.SsnLabelMember)); //'LAST 4 DIGITS OF SSN'
      birthdayFormLabel = upperCase(t(PersonalInfoLocalKeys.BirthdayMember)); // 'YOUR BIRTHDAY'
      zipCodeFormLabel = upperCase(t(PersonalInfoLocalKeys.ZipCodeMember)); // 'YOUR ZIP CODE'
    } else {
      // Delegate flow
      title = t(PersonalInfoLocalKeys.TitleDelegate); // "Confirm delegator's personal information"
      description = t(PersonalInfoLocalKeys.DescriptionDelegate); // 'In order to protect personal information we need to ask you a few security questions. Please enter the info for the delegator below.';
      ssnFormLabel = upperCase(t(PersonalInfoLocalKeys.SsnLabelDelegate)); // "LAST 4 DIGITS OF DELEGATOR'S SSN"
      birthdayFormLabel = upperCase(t(PersonalInfoLocalKeys.BirthdayDelegate)); // `DELEGATOR'S BIRTHDAY`;
      zipCodeFormLabel = upperCase(t(PersonalInfoLocalKeys.ZipCodeDelegate)); // `DELEGATOR'S ZIP CODE`;
    }
  }

  return (
    <EnrollmentPagesWrapper
      title={title}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isWrapperAutoFocus={false}
      isButtonDisabled={isButtonDisabled()}
      isError={isError}
      withCiamBtn={!enrollmentContext.isLandingPageUnified && !enrollmentContext.isDelegate}
      withQuestionBtn={enrollmentContext.isLandingPage}>
      <div css={styles.formGroupContainerStyle}>
        <div css={{ minHeight: '2.4rem', padding: '1rem' }}>
          <p css={enrollmentGlobalStyles.errorMessage}>
            {isError ? (
              <div css={[enrollmentGlobalStyles.errorMessage, { textAlign: 'center', whiteSpace: 'pre-wrap', marginBottom: '2.2rem', fontsize: '1.8rem' }]}>
                {t(LocaleKeys.errors.personal_info_misinformation)}
                <br />
                {store.remainingAttempts > 0 && (
                  <span css={[enrollmentGlobalStyles.errorMessage, store.remainingAttempts < 3 ? { fontWeight: 'bold' } : undefined]}>
                    {t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: store.remainingAttempts, s: store.remainingAttempts > 1 ? 's' : '' })}
                  </span>
                )}
              </div>
            ) : (
              ' '
            )}
          </p>
          <p css={styles.personalInfoContentDescription}>{description}</p>
          {enrollmentContext.isLandingPageUnified && (
            <p css={styles.personalInfoContentDescription}>
              <span css={styles.personalInfoUnified}>{t(PersonalInfoLocalKeys.DescriptionUnifiedDelegate1)}</span> {/* "If you are enrolling as a delegate," */}
              {t(PersonalInfoLocalKeys.DescriptionUnifiedDelegate2)} {/* please enter the info for the delegator below. */}
            </p>
          )}
        </div>

        <div css={[styles.formGroupContainerStyle]}>
          {enrollmentStore.userSecretMetadata?.personalIdentifier === PersonalSecretIdentifier.ssn ? (
            <div css={styles.formGroupStyle}>
              <label className={'label'} css={[enrollmentGlobalStyles.textInputItem]}>
                {ssnFormLabel}
              </label>
              <OtpInput format={'####'} hasErrored={isError} autoFocus={true} ref={ssnRef} onChange={onSSNChanged} />
            </div>
          ) : (
            <div css={styles.formGroupStyle}>
              <label className={'label'} css={[enrollmentGlobalStyles.textInputItem]}>
                {enrollmentStore.userSecretMetadata?.secretDisplayName?.toUpperCase()}
              </label>

              <input
                ref={secretRef!}
                value={identityValue}
                onChange={event => onSecretChanged(event.target.value)}
                maxLength={40}
                css={[styles.secretInputStyle, isError ? styles.secretErrorStyle : undefined]}
              />
            </div>
          )}
          <div css={styles.formGroupStyle}>
            {isBirthdayDateError && <p css={[enrollmentGlobalStyles.errorMessage, styles.redColor, { fontSize: '1.2rem' }]}>{t(LocaleKeys.errors.this_is_not_valid_date)}</p>}
            <label className={'label'} css={[enrollmentGlobalStyles.textInputItem]}>
              {birthdayFormLabel}
            </label>
            <OtpInput format={'mm/dd/yyyy'} hasErrored={isError || isBirthdayDateError} onChange={onBirthdayChanged} ref={birthdayRef} inputStyle={styles.inputStyleForMobile} />
          </div>
          <div css={[styles.formGroupStyle]}>
            <label className={'label'} css={[enrollmentGlobalStyles.textInputItem]}>
              {zipCodeFormLabel}
            </label>
            {/* TODO: oreng good example for ref use, maybe use like that instead of enter press for btn */}
            <OtpInput format={'#####'} hasErrored={isError} onChange={onZipCodeChanged} ref={zipCodeRef} inputStyle={styles.inputStyleForMobile} />
          </div>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default observer(PersonalInfo);
