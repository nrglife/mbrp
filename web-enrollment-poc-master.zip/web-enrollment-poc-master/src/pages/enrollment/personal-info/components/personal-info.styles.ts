import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

export const formContainer = css({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  margin: '0 auto'
});

export const formGroupContainerStyle = css({
  width: '100%',
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'column',
  padding: '0 0.3rem'
});

export const personalInfoContentDescription = css({
  fontSize: '1.8rem',
  color: globalStyles.COLOR.black,
  lineHeight: '28px',
  paddingTop: '3rem',
  textAlign: 'center'
});

export const personalInfoUnified = css({
  fontWeight: 'bold'
});

export const formGroupStyle = css({
  margin: '3.5rem 0',
  width: '100%',
  maxWidth: '35rem',
  '@media (max-width: 450px)': {
    maxWidth: '28rem'
  }
});

export const redColor = css({
  color: globalStyles.COLOR.darkCoral
});

export const secretErrorStyle = css({
  borderBottom: '2px solid rgba(255,0,0,0.25)',
  color: globalStyles.COLOR.darkCoral,

  '&:focus': {
    borderBottom: `2px solid ${globalStyles.COLOR.darkCoral}`,
    transition: 'all 0.3s ease-in-out'
  }
});

export const inputStyleForMobile = css({
  '@media (max-width: 450px)': {
    width: '2.3rem',
    height: '2.3rem'
  }
});

export const secretInputStyle = css({
  width: '100%',
  height: '3rem',
  fontSize: '2rem',
  textAlign: 'left',
  //transition: 'all 0.3s ease-in-out',
  padding: '0 0.2rem',
  //marginRight: 5, // defaults to px
  border: 'none',
  borderBottom: '1px solid rgba(0,0,0,0.2)',
  borderRadius: 'unset',

  '&:focus': {
    borderBottom: '1px  solid #333333'
    //transition: 'all 0.3s ease-in-out'
  }
  // '&:disabled': {
  //   backgroundColor: 'transparent'
  // }
});
