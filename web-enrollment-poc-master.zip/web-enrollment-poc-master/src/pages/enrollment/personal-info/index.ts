import PersonalInfoContainer from './containers/personal-info.container';

export { PersonalInfoContainer as default };
