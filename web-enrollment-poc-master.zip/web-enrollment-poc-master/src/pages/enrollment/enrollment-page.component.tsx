import { FC, Fragment } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../stores/useStores';
import Modal from 'components/general/modal/modal.component';
import EnrollmentSteps from 'components/enrollment-page/enrollment-steps/enrollment-steps.component';
import LoaderComponent from 'components/general/loader/loader.component';
//styles
import * as styles from './enrollment-page.styles';
import { globalStyles } from 'styles/global.styles';

interface EnrollmentPageProps {}

const Loader = observer(() => {
  const { enrollmentStore } = useStores();
  return <LoaderComponent loading={!!enrollmentStore.isLoading} position="global" color="white" backgroundColor={'rgba(0, 0, 0, 0.6)'} />;
});



const EnrollmentPage: FC<EnrollmentPageProps> = props => {
  return (
    <Fragment>
      <EnrollmentSteps />
      <Loader />
    </Fragment>
  );
};

export default EnrollmentPage;
