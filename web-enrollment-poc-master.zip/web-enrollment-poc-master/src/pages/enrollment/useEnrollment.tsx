import Modal from 'components/general/modal/modal.component';
import EnrollmentPage from './enrollment-page.component';
import { useStores } from '../../stores/useStores';
import { EnrollmentOrigin, EnrollmentType } from 'stores';
import { observer } from 'mobx-react';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { useTranslation } from 'react-i18next';
import ContactUsContainer from 'pages/enrollment/contact-us';


const defaultStyle = {
  padding: '0 0',
  flex: 1,
  width: '100%',
  height: '100%',
  flexDirection: 'column',
  overflow: 'auto',
  display: 'flex',
  borderRadius: '2px'
};

export const useEnrollment = () => {
  const { enrollmentStore, responsiveStore, errorStoreCommon } = useStores();

  const modalStyle = responsiveStore.isMobile ? defaultStyle : { ...defaultStyle, height: 'auto', maxWidth: '694px', maxHeight: '820px', minHeight: '407px' };

  const EnrollmentModal = observer(() => (
    <Modal modalStyle={modalStyle} open={enrollmentStore.showModal} onModalClose={() => setEnrollmentVisibility(false)} overlayStyle={{ padding: 0 }} closeButtonStyle={{ display: 'none' }} center>
      <div style={{ position: 'relative', overflow: 'auto' }}>
        <div style={{ position: 'absolute', width: '100%', textAlign: 'right', paddingTop: '5px', paddingRight: '5px' }}>
          <CloseIcon style={{ cursor: 'pointer' }} onClick={() => setEnrollmentVisibility(false)} />
        </div>
        <EnrollmentPage />
      </div>
    </Modal>
  ));

  const ContactUsModal = observer(() => (
    <Modal modalStyle={modalStyle} open={enrollmentStore.showContactUsModal} onModalClose={() => {}} overlayStyle={{ padding: 0 }} closeButtonStyle={{ display: 'none' }} center>
      <div style={{ position: 'relative', overflow: 'auto' }}>
        <div style={{ position: 'absolute', width: '100%', textAlign: 'right', paddingTop: '5px', paddingRight: '5px' }}>
          {!enrollmentStore.showModal && (
            <CloseIcon
              style={{ cursor: 'pointer' }}
              onClick={() => {
                setContactUsVisibility(false);
              }}
            />
          )}
        </div>
        <ContactUsContainer />
      </div>
    </Modal>
  ));

  const setContactUsVisibility = (isVisible: boolean) => {
    enrollmentStore.setContactUsVisibility(isVisible);
  };

  const setEnrollmentVisibility = (isVisible: boolean) => {
    enrollmentStore.setModalVisibility(isVisible);
    errorStoreCommon.clearAllErrors();
  };

  const initEnrollment = (enrollmentOrigin: EnrollmentOrigin) => {
    enrollmentStore.setEnrollmentOrigin(enrollmentOrigin);
    enrollmentStore.setModalVisibility(true);
    errorStoreCommon.clearAllErrors();
  };

  return { EnrollmentModal, ContactUsModal, initEnrollment, setEnrollmentVisibility, setContactUsVisibility };
};
