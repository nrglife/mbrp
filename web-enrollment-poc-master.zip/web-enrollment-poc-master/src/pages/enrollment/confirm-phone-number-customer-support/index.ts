import ConfirmPhoneNumberCustomerSupportContainer from './containers/confirm-phone-number-customer-support.container';

export { ConfirmPhoneNumberCustomerSupportContainer as default };
