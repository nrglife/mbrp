/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const contentContainer = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'column',
  alignItems: 'center',
  paddingTop: '2.3rem',
  color: globalStyles.COLOR.black
});

export const content = css({
  fontSize: '1.8rem',
  lineHeight: '28px',
  maxWidth: '47.5rem',
  width: '100%',
  marginBottom: '3.5rem'
});

export const appSupportPhoneLink = (theme: Preferences) =>
  css({
    textDecoration: 'none',
    color: theme.colors.actionMedium.published,
    cursor: 'pointer'
  });

//SMS Send Styles
export const resendLoaderContainer = css({
  display: 'flex',
  justifyContent: 'left'
});

export const resendLink = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'underline',
    cursor: 'pointer'
  });

export const verificationContainer = css({
  textAlign: 'left',
  maxWidth: '47.5rem',
  width: '100%',
  marginBottom: '2rem'
});

export const formDescription = css({
  fontSize: '1.8rem',
  color: globalStyles.COLOR.black,
  lineHeight: '2.2rem',
  width: '100%',
  margin: '1rem 0',
  maxWidth: '46rem'
});

export const expiresTimeLabel = css({
  marginTop: '0.8rem',
  fontSize: '1.4rem',
  color: '#37474f',
  alignSelf: 'flex-start'
});

export const smallFont = css({
  fontSize: '1.4rem'
});

export const boldFont = css({
  fontWeight: 'bold'
});
