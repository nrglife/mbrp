import { useState, FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import ClipLoader from 'react-spinners/ClipLoader';
import { observer } from 'mobx-react';
import { useStores } from '../../../../stores/useStores';
//developed
import OtpInput from '../../../../components/general/OTP';
import EnrollmentPagesWrapper from '../../../../pages/enrollment/enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
//styles
import * as styles from './confirm-phone-number-customer-support.styles';
import * as enrollmentGlobalStyles from '../../../../pages/enrollment/enrollment-page.styles';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface ConfirmPhoneNumberCustomerSupportProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;

  //TODO: check if we really not gonna use payerName & payerWebsite and delete them
  payerName: string;
  payerWebsite: string;
  //SMS Send Vars
  isResendLinkLoading: boolean;
  sendHandler: any;
  invitationCodeFormat: string;
  isErrorPhoneNumber: boolean;
  isErrorVerificationCode: boolean;
  onOTPChange: any;
  setCodeFullFilled: any;
  isButtonDisabled: boolean;
  remainingAttempts: number;
}

const ConfirmPhoneNumberCustomerSupport: FC<ConfirmPhoneNumberCustomerSupportProps> = ({
  onSubmitHandler,
  onSubmitEnterHandler,
  isResendLinkLoading,
  sendHandler,
  invitationCodeFormat,
  isErrorPhoneNumber,
  isErrorVerificationCode,
  onOTPChange,
  setCodeFullFilled,
  isButtonDisabled,
  remainingAttempts
}) => {
  const [sendCodeWasPressed, setSendCodeWasPressed] = useState(false);
  const { t, i18n } = useTranslation('translation');

  const pageTitle = t(LocaleKeys.errors.contact_customer_support);
  const upperText = t(LocaleKeys.errors.we_dont_heve_phone_number);
  const { themeStore, appConfigStore } = useStores();

  const appSupportPhoneNumber = appConfigStore.currentConfig.appSupportDetails.appSupportPhoneNumbers.filter(number => number && number !== '')[0];

  const onSendPress = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    !sendCodeWasPressed && setSendCodeWasPressed(true);
    sendHandler(event);
  };

  return (
    <EnrollmentPagesWrapper
    title={pageTitle}
    onSubmitHandler={onSubmitHandler}
    onSubmitEnterHandler={onSubmitEnterHandler}
    isWrapperAutoFocus={false}
    isButtonDisabled={isButtonDisabled}
    isError={isErrorPhoneNumber || isErrorVerificationCode}>
      <div css={styles.contentContainer}>
        {(isErrorPhoneNumber || isErrorVerificationCode) && (
          <div css={[enrollmentGlobalStyles.errorMessage, { textAlign: 'center', whiteSpace: 'pre-wrap', marginBottom: '2.2rem', fontsize: '1.8rem' }]}>
            {t(LocaleKeys.errors.something_wrong_try_again)}
            <div css={!!remainingAttempts && remainingAttempts < 3 ? styles.boldFont : {}}>
              {remainingAttempts > 0 ? t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: remainingAttempts, s: remainingAttempts > 1 ? 's' : '' }) : ``}
            </div>
          </div>
        )}
        <div css={styles.content}>{upperText}</div>
        <div css={[styles.content, { display: 'flex' }]}>
          <span style={{ marginRight: '.5rem' }}>{'1.'}</span>
          <div>
            {'Please call customer support at '}
            <a href={`tel:${appSupportPhoneNumber}`} css={styles.appSupportPhoneLink(themeStore.currentTheme)}>
              {appSupportPhoneNumber}
            </a>
            <span>{'.'}</span>
          </div>
        </div>
        <div css={[styles.content, { display: 'flex' }]}>
          <span style={{ marginRight: '.5rem' }}>{'2.'}</span>
          <div style={{ maxWidth: '44rem' }}>
            {'When prompted by the agent you’ll be asked to '}
            {isResendLinkLoading ? (
              <div css={[styles.resendLoaderContainer, { alignSelf: 'flex-start' }]}>
                <ClipLoader size="20px" color={'#498DFF'} />
              </div>
            ) : (
              <div css={{ display: 'inline' }}>
                <span css={[styles.resendLink(themeStore.currentTheme)]} onClick={onSendPress}>
                  {'request a code'}
                </span>
                <span>{'.'}</span>
              </div>
            )}
          </div>
        </div>

        <div css={[styles.verificationContainer, (!sendCodeWasPressed || isErrorPhoneNumber) && { opacity: 0, pointerEvents: 'none' }]}>
          <p css={styles.formDescription}>{'3. Enter the code below:'}</p>
          <div
            css={{
              flex: 1,
              alignItems: 'center',
              flexDirection: 'column',
              justifyContent: 'left',
              display: 'flex',
              flexGrow: 1,
              alignContent: 'left'
            }}>
            <OtpInput format={invitationCodeFormat} hasErrored={isErrorVerificationCode} autoFocus={false} onChange={onOTPChange} setCodeFullFilled={setCodeFullFilled} />
            <p css={[enrollmentGlobalStyles.errorMessage, styles.smallFont, { alignSelf: 'flex-start', marginTop: '0.8rem' }]}>
              {isErrorVerificationCode ? t(LocaleKeys.errors.wrong_verification_code) : ' '}
            </p>
            <div css={styles.expiresTimeLabel}>{'Expires in 10 minutes'}</div>
          </div>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default observer(ConfirmPhoneNumberCustomerSupport);
