import { FC, useCallback, useMemo, useReducer } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { observer } from 'mobx-react';
//CommonServices
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';

//developed
import { IocContainer, IocTypes, EnrollmentApiType } from 'inversify.config';
import { useStores } from '../../../../stores/useStores';
import { EnrollmentSteps } from '../../../../stores';
import { IHTTP_ERROR, EnrollmentHttpService } from '../../../../services';
import ConfirmPhoneNumberCustomerSupport from '../components/confirm-phone-number-customer-support.component';
import { uppercaseFirstLetter } from '@healthcareapp/connected-health-common-services/dist/utilities/string';
import { EncountersStore } from '@healthcareapp/connected-health-common-services';

interface ConfirmPhoneNumberCustomerSupportContainerProps {}

const useConfirmPhoneNumberCustomerSupportContainerBehavior = () => {
  const { enrollmentStore, appConfigStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);

  //consts
  const { invitationCode = '' } = enrollmentStore || {};
  const resetConfirmSMSTimeOut = () => {
    //clear previous time out
    enrollmentStore.clearAllRegisteredTimeouts();
    //set new time out
    const timeoutId = enrollmentStore.registerEnrollmentTimeout(() => {
      console.log('TIMEOUT from confirm SMS screen: ', timeoutId);
      enrollmentStore.clearTimeout(timeoutId);
      enrollmentStore.setContactUsVisibility(false);
      enrollmentStore.setStep(EnrollmentSteps.Timeout);
    }, minutesToMilliseconds((window as any)?.env?.REACT_APP_ENROLLMENT_SMS_CODE_TIME_OUT_IN_MINUTES));
    return timeoutId;
  };

  interface State {
    invitationCodeFormat: string;
    smsCode: string;
    isErrorPhoneNumber: boolean;
    isErrorVerificationCode: boolean;
    isSmsCodeFilled: boolean;
    isResendLinkLoading: boolean;
  }
  const initialState: State = {
    invitationCodeFormat: '######',
    smsCode: '',
    isErrorPhoneNumber: false,
    isErrorVerificationCode: false,
    isSmsCodeFilled: false,
    isResendLinkLoading: false
  };

  type ActionTypes = 'SET_SMS_CODE' | 'SET_ERROR_PHONE_NUMBER' | 'SET_ERROR_VERIFICATION_CODE' | 'SET_SMS_CODE_FIILED' | 'SET_RESEND_LINK_LOADING';
  type Action = { type: ActionTypes; payload?: any };

  const reducer = (state: State = initialState, action: Action): State => {
    const { type, payload } = action;
    switch (type) {
      case 'SET_SMS_CODE':
        return { ...state, isErrorPhoneNumber: false, isErrorVerificationCode: false, smsCode: payload };
      case 'SET_SMS_CODE_FIILED':
        return { ...state, isErrorPhoneNumber: false, isErrorVerificationCode: false, isSmsCodeFilled: payload };
      case 'SET_ERROR_PHONE_NUMBER':
        return { ...state, isErrorPhoneNumber: payload };
      case 'SET_ERROR_VERIFICATION_CODE':
        return { ...state, isErrorVerificationCode: payload };
      case 'SET_RESEND_LINK_LOADING':
        return { ...state, isResendLinkLoading: payload };
    }
  };

  const [{ smsCode, isErrorPhoneNumber, isErrorVerificationCode, isResendLinkLoading, isSmsCodeFilled, invitationCodeFormat }, dispatch] = useReducer(reducer, initialState);

  const onOTPChange = useCallback((otp: string): void => dispatch({ type: 'SET_SMS_CODE', payload: otp }), [dispatch]);

  const onSubmitEnterHandler = useCallback(() => {
    EnrollmentHttpService(
      async () => await enrollmentApi.postOtpPassCode({ code: invitationCode, passCode: smsCode }),
      response => {
        const { data = [] } = response;
        enrollmentStore.setEmails(data);
        enrollmentStore.setStep(EnrollmentSteps.EmailVerification);
      },
      (error: IHTTP_ERROR) => {
        /*
            potential errors this screen should handle:
            case HTTP_STATUS_CODES.BAD_REQUEST: (400)
          */
        dispatch({ type: 'SET_ERROR_VERIFICATION_CODE', payload: true });
      }
    );
  }, [smsCode, invitationCode]);

  const onSubmitHandler = useCallback(
    async (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
      event?.preventDefault();
      onSubmitEnterHandler();
    },
    [smsCode, invitationCode]
  );

  const sendHandler = useCallback(
    async (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
      event.preventDefault();

      dispatch({ type: 'SET_ERROR_PHONE_NUMBER', payload: false });
      dispatch({ type: 'SET_ERROR_VERIFICATION_CODE', payload: false });
      dispatch({ type: 'SET_RESEND_LINK_LOADING', payload: true });

      const phone = 'XXXX';
      const channel = 'sms';//TODO: check it

      await EnrollmentHttpService(
        async () => await enrollmentApi.postRequestOtpCode({ code: invitationCode, phoneNumber: phone, channel: channel }),
        () => {
          //TODO: change the message
          console.log('sms resend successfully');
          console.log('reset confirm sms time out');
          resetConfirmSMSTimeOut();
        },
        (error: IHTTP_ERROR) => {
          /*
            potential errors this screen should handle:
            case HTTP_STATUS_CODES.BAD_REQUEST: (400)
          */

          dispatch({ type: 'SET_ERROR_PHONE_NUMBER', payload: true });
          //return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
        },
        false
      );

      dispatch({ type: 'SET_RESEND_LINK_LOADING', payload: false });
    },
    [dispatch, invitationCode]
  );

  const setCodeFullFilled = useCallback((isFullFilled: boolean) => dispatch({ type: 'SET_SMS_CODE_FIILED', payload: isFullFilled }), [dispatch]);

  const isButtonDisabled = useMemo(() => !smsCode || isErrorPhoneNumber || !isSmsCodeFilled, [smsCode, isErrorPhoneNumber, isSmsCodeFilled]);

  return {
    onSubmitHandler,
    onSubmitEnterHandler,
    //SMS Send Vars
    isResendLinkLoading,
    sendHandler,
    invitationCodeFormat,
    isErrorPhoneNumber,
    isErrorVerificationCode,
    onOTPChange,
    setCodeFullFilled,
    isButtonDisabled,
    enrollmentStore
  };
};

const ConfirmPhoneNumberCustomerSupportContainer: FC<ConfirmPhoneNumberCustomerSupportContainerProps> = props => {
  const {
    onSubmitHandler,
    onSubmitEnterHandler,
    //SMS Send Vars
    isResendLinkLoading,
    sendHandler,
    invitationCodeFormat,
    isErrorPhoneNumber,
    isErrorVerificationCode,
    onOTPChange,
    setCodeFullFilled,
    isButtonDisabled,
    enrollmentStore
  } = useConfirmPhoneNumberCustomerSupportContainerBehavior();

  const { routesStore, payerStore } = useStores();
  const payerName = payerStore.payer?.fullName || uppercaseFirstLetter(payerStore.payer?.shortName) || '';
  const payerWebsite = payerStore?.payer?.url ?? '';

  return (
    <ConfirmPhoneNumberCustomerSupport
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      payerName={payerName}
      payerWebsite={payerWebsite}
      //SMS Send Vars
      isResendLinkLoading={isResendLinkLoading}
      sendHandler={sendHandler}
      invitationCodeFormat={invitationCodeFormat}
      isErrorPhoneNumber={isErrorPhoneNumber}
      isErrorVerificationCode={isErrorVerificationCode}
      onOTPChange={onOTPChange}
      setCodeFullFilled={setCodeFullFilled}
      isButtonDisabled={isButtonDisabled}
      remainingAttempts={enrollmentStore.remainingAttempts}
    />
  );
};

export default observer(ConfirmPhoneNumberCustomerSupportContainer);
