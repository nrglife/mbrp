import InvitationCodeContainer from './containers/invitation-code.container';

export { InvitationCodeContainer as default };
