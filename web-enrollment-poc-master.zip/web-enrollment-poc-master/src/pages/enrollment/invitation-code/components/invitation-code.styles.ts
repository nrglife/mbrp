import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const invitationCodeContentInvitationCodeElement = css({
  display: 'flex',
  flexGrow: 1,
  flexDirection: 'column',
  justifyContent: 'left',
  alignItems: 'center',
  alignContent: 'left',
  paddingTop: '3.3rem'
});

export const invitationCodeContentDescription = css({
  fontSize: '1.8rem',
  color: globalStyles.COLOR.black,
  lineHeight: '28px',
  paddingTop: '3rem',
  textAlign: 'center'
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none',
    cursor: 'pointer'
  });

export const invitationCodeContentInvitationCode = css({
  marginTop: '10px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  paddingBottom: '0.7rem'
});

export const invitationCodeContentActionButtons = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '31.3rem'
});

export const redColor = css({
  color: '#d63e3e'
});

export const errorMessageStyle = css({
  minHeight: 14,
  color: '#d63e3e',
  marginBottom: 25,
  fontSize: '1.8rem'
});
