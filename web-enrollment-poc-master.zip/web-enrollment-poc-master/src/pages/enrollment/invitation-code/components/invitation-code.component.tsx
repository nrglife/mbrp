import { FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
//developed
import OtpInput from '../../../../components/general/OTP';
import { EnrollmentContext } from 'stores';
import { upperCase } from 'utils/string';

//styles
import * as enrollmentGlobalStyles from '../../enrollment-page.styles';
import * as styles from './invitation-code.styles';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface InvitationCodeProps {
  onOTPChange: Function;
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  linkText?: string;
  linkTo?: string;
  setCodeFullFilled: Function;
  errorMessage: string;
  isExpired: boolean;
  isButtonDisabled: boolean;
  payerFullName: string;
  payerWebSite: string;
  enrollmentContext: EnrollmentContext;
}

const invitationCodeFormat = '######';
const InvitationCode: FC<InvitationCodeProps> = ({
  onOTPChange,
  onSubmitHandler,
  onSubmitEnterHandler,
  setCodeFullFilled,
  errorMessage,
  isExpired,
  isButtonDisabled,
  linkText,
  linkTo,
  payerFullName,
  payerWebSite,
  enrollmentContext
}) => {
  const { t } = useTranslation('translation');
  const { InvitationCode: InvitationCodeLocalKeys } = LocaleKeys.components.Enrollment;

  let title = t(InvitationCodeLocalKeys.TitleUnified); //'Welcome to Connected Health'
  let description = t(InvitationCodeLocalKeys.DescriptionUnified1); // + // Please enter your invitation code.
  let description2 = t(InvitationCodeLocalKeys.DescriptionUnified2); // You should have received this by email or mail.",

  if (!enrollmentContext.isLandingPageUnified) {
    if (enrollmentContext.isLandingPage) {
      title = t(InvitationCodeLocalKeys.TitleLandingPage); // "Welcome to Connected Health"
      description = t(InvitationCodeLocalKeys.DescriptionLandingPage); // "Please enter your invitation code. You should have received this by email or mail.",
      description2 = '';
    } else {
      title = t(InvitationCodeLocalKeys.TitleAddButton); //  'Add a New Delegate Account '
      description = t(InvitationCodeLocalKeys.DescriptionAddButton); // "Please enter your authorization code. You should have received this by email or mail."
      description2 = '';
    }
  }

  return (
    <EnrollmentPagesWrapper
      title={title}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      isWrapperAutoFocus={false}
      linkText={linkText}
      linkTo={linkTo}
      isError={errorMessage ? true : false}
      withCiamBtn={enrollmentContext.isLandingPage}
      withQuestionBtn={enrollmentContext.isLandingPage}>
      <div css={{ paddingBottom: '4.6rem', maxWidth: '51.5rem', margin: '0 auto' }}>
        <div css={{ paddingTop: '2.9rem' }}>
          <p css={enrollmentGlobalStyles.errorMessage}>{errorMessage}</p>
        </div>

        <p css={styles.invitationCodeContentDescription}>
          {description}
          {description2 && description2 !== '' && (
            <>
              <br /> {description2}
            </>
          )}
        </p>
        <div css={styles.invitationCodeContentInvitationCodeElement}>
          <div>
            <label className={'label'} css={enrollmentGlobalStyles.textInputItem}>
              {upperCase(t(InvitationCodeLocalKeys.InvitationCodeLabel))}
            </label>
            <div css={styles.invitationCodeContentInvitationCode}>
              <OtpInput format={invitationCodeFormat} hasErrored={errorMessage != null && errorMessage !== ''} autoFocus={true} onChange={onOTPChange} setCodeFullFilled={setCodeFullFilled} />
            </div>
            {isExpired && <p css={[enrollmentGlobalStyles.errorMessage, { fontSize: '1.4rem' }]}>{t(LocaleKeys.errors.invitation_screen_not_valid_code)}</p>}
          </div>
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default InvitationCode;
