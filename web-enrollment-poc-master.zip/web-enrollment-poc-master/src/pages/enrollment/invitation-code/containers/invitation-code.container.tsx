import { useState, FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { IocContainer, IocTypes, EnrollmentApiType } from 'inversify.config';
import { IHTTP_ERROR, HTTP_STATUS_CODES } from '../../../../services';
import { useStores } from '../../../../stores/useStores';
import { EnrollmentSteps } from 'stores';
import { EnrollmentHttpService } from '../../../../services';
//styles
import InvitationCode from '../components/invitation-code.component';
import { uppercaseFirstLetter } from '@healthcareapp/connected-health-common-services/dist/utilities/string';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

// Mobile-1790 - Remove ReCaptcha for MVP6 release
// import ReCAPTCHA from 'react-google-recaptcha';
// const recaptchaRef = React.createRef<ReCAPTCHA>();

const useInvitationCodeBehaviour = () => {
  const { enrollmentStore, errorStoreCommon, payerStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);

  const [invitationCode, setInvitationCode] = useState<string>('');
  const [isError, setIsError] = useState<IHTTP_ERROR | null>(null);

  const [isInvitationCodeFullFilled, setIsInvitationCodeFullFilled] = useState<boolean>(false);

  const onOTPChange = (otp: string): void => {
    setInvitationCode(otp);
    // reset errors only once
    isError && setIsError(null);
    isError && errorStoreCommon.clearAllErrors();
  };

  const payerName = payerStore?.payer?.fullName || uppercaseFirstLetter(payerStore?.payer?.shortName);

  const onSubmitEnterHandler = () => {
    EnrollmentHttpService(
      async () => await enrollmentApi.getInvitationCode({ code: invitationCode }),
      response => {
        const { data } = response;
        enrollmentStore.setUserSecretMetadata({ ...data });

        // if origin is add delegate button, enrollment type must be of a delegate and not a member
        if (!enrollmentStore.enrollmentContext.isLandingPage && !enrollmentStore.enrollmentContext.isDelegate) {
          enrollmentStore.setStep(EnrollmentSteps.WrongPayerError);
        } else if ((data.customerId && data.customerId === payerStore?.payer?.guid) || enrollmentStore.enrollmentContext.isDelegate) {
          enrollmentStore.setInvitationCode(invitationCode);
          enrollmentStore.setStep(EnrollmentSteps.PersonalInfo);
        } else if (data.customerId && payerStore?.payer?.guid && data.customerId !== payerStore.payer.guid) {
          enrollmentStore.setStep(EnrollmentSteps.WrongPayerError);
        } else {
          enrollmentStore.setStep(EnrollmentSteps.GeneralError);
        }
      },
      (error: IHTTP_ERROR) => {
        /*
          potential errors this screen should handle:
          case HTTP_STATUS_CODES.NOT_FOUND: (404)
          case HTTP_STATUS_CODES.INVALID_LOCKED: (422)
          case HTTP_STATUS_CODES.BAD_REQUEST: (400)
        */

        setIsError(error);
      },
      true,
      true
    );
  };

  const onSubmitHandler = async (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event?.preventDefault();
    onSubmitEnterHandler();
  };

  const onReCAPTCHAClientErrorHandler = () => {
    enrollmentStore.setStep(EnrollmentSteps.RecaptchaClientError);
  };

  const onReCAPTCHAServerErrorHandler = () => {
    enrollmentStore.setStep(EnrollmentSteps.RecaptchaServerError);
  };

  const setCodeFullFilled = (isFullFilled: boolean) => setIsInvitationCodeFullFilled(isFullFilled);

  const isButtonDisabled = !invitationCode || isError != null || !isInvitationCodeFullFilled;

  return { onOTPChange, onSubmitHandler, onReCAPTCHAClientErrorHandler, onSubmitEnterHandler, setCodeFullFilled, isError, isButtonDisabled, payerName };
};

interface InvitationCodeContainerProps {}

const InvitationCodeContainer: FC<InvitationCodeContainerProps> = props => {
  const { onOTPChange, onSubmitHandler, onReCAPTCHAClientErrorHandler, onSubmitEnterHandler, setCodeFullFilled, isError, isButtonDisabled } = useInvitationCodeBehaviour();

  const { payerStore, enrollmentStore } = useStores();
  const { t, i18n } = useTranslation('translation');

  let errorMessage = '';
  if (isError != null) {
    errorMessage = t(LocaleKeys.errors.invitation_screen_not_valid_code);
    if (isError?.statusCode === HTTP_STATUS_CODES.INVALID_LOCKED) errorMessage = t(LocaleKeys.errors.invitation_screen_code_locked);
  }

  const isExpired = isError?.statusCode === HTTP_STATUS_CODES.INVALID_LOCKED;

  return (
    <InvitationCode
      onOTPChange={onOTPChange}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      setCodeFullFilled={setCodeFullFilled}
      errorMessage={errorMessage}
      isExpired={isExpired}
      isButtonDisabled={isButtonDisabled}
      payerFullName={payerStore?.payer?.fullName || uppercaseFirstLetter(payerStore?.payer?.shortName) || ''}
      payerWebSite={payerStore?.payer?.url ?? ''}
      enrollmentContext={enrollmentStore.enrollmentContext}
    />
  );
  // Mobile-1790 - Remove ReCaptcha for MVP6 release
  // return (
  //   <>
  //     <InvitationCode
  //       onOTPChange={onOTPChange}
  //       onSubmitHandler={onSubmitHandler}
  //       onSubmitEnterHandler={onSubmitEnterHandler}
  //       setCodeFullFilled={setCodeFullFilled}
  //       errorMessage={errorMessage}
  //       isExpired={isExpired}
  //       isButtonDisabled={isButtonDisabled}
  //       payerFullName={payerStore.currentPayer?.fullName || uppercaseFirstLetter(payerStore.currentPayer?.) || ''}
  //       payerWebSite={payerStore?.currentPayer?.url ?? ''}
  //     />
  //     <ReCAPTCHA sitekey={(window as any)?.env?.REACT_APP_RECAPTCHA_SITE_KEY} size="invisible" ref={recaptchaRef} onErrored={onReCAPTCHAClientErrorHandler} />
  //   </>
  //);
};

export default observer(InvitationCodeContainer);
