import { css } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';

export const titleContainerStyle = css({
  height: '13.3rem',
  width: '100%',
  flex: 1,
  flexDirection: 'column',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  '@media (max-width: 1000px)': {
    padding: '0 1.5rem'
  }
});

export const actionButtonsAllignment = css({
  display: 'flex',
  flexGrow: 1,
  flexDirection: 'column',
  justifyContent: 'left',
  alignItems: 'center',
  alignContent: 'left'
  //margin: '5rem 0'
});

export const itemsAllignmentContentContent = css({
  display: 'flex',
  flexGrow: 1,
  flexDirection: 'column',
  justifyContent: 'space-between',
  alignItems: 'center',
  alignContent: 'center',
  backgroundColor: 'white'
  //height: '44.1rem'
});

export const childrenContainer = css({
  width: '100%',
  padding: '0 5.9rem',
  '@media (max-width: 1300px)': {
    padding: '0 3rem'
  }
});

export const btnStyle = css({
  //marginBottom: '2.5rem'
});

export const ciamBtnHader = css({
  textDecoration: 'none',
  fontSize: '1.6rem',
  fontStretch: 'normal',
  fontStyle: 'normal',
  lineHeight: 'normal',
  letterSpacing: '0.62px',
  textAlign: 'center',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'normal',
  marginTop: '2rem',
  marginBottom: '1rem'
});

export const lnkStyle = css({
  backgroundColor: 'transparent'
});

export const enrollmentWrapperContainerStyle = css({
  flex: 1,
  paddingBottom: '6rem',
  flexDirection: 'column',
  justifyContent: 'space-between',
  overflow: 'auto'
});

export const errorNumber = css({
  fontSize: '1.2rem',
  color: globalStyles.COLOR.battleshipGrey,
  marginTop: '2rem'
});
