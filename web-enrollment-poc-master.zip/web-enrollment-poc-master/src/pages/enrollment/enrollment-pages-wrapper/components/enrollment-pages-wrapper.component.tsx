import { useRef, FC } from 'react';
import * as React from 'react';
import { useComponentDidMount } from '../../../../customHooks';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, SerializedStyles } from '@emotion/core';
import { Link } from 'react-router-dom';
//developed
import Button from '../../../../components/general/button/button.component';
import SignInWithCHC from '../../../../components/sign-in-with-chc/sign-in-with-chc.component';
import { useStores } from '../../../../stores/useStores';

//styles
import * as enrollmentGlobalStyles from '../../enrollment-page.styles';
import * as styles from './enrollment-pages-wrapper.styles';
import ContactUs from 'components/contact-us/contact-us.component';
import ErrorCode from 'components/error-code/error-code.component';
import { EnrollmentSteps } from 'stores';

interface EnrollmentPagesWrapperProps {
  onSubmitHandler?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler?: () => void;
  isButtonDisabled?: boolean;
  isWrapperAutoFocus?: boolean;
  title: string;
  actionButtonText?: string;
  linkText?: string;
  linkTo?: string;
  withCiamBtn?: boolean;
  withCiamLinkText?: boolean;
  withQuestionBtn?: boolean;
  isError?: boolean;
  btnStyle?: SerializedStyles | undefined;
}

const CLOSE_MODAL = 'CLOSE';
const ciamBtnText = 'Are you already enrolled?';
const ENTER = 13;

const EnrollmentPagesWrapper: FC<EnrollmentPagesWrapperProps> = ({
  title,
  onSubmitHandler = null,
  onSubmitEnterHandler = null,
  isButtonDisabled = false,
  isWrapperAutoFocus = true,
  children,
  actionButtonText = 'NEXT',
  linkText = '',
  linkTo = '',
  withCiamBtn = false,
  withQuestionBtn = true,
  withCiamLinkText = true,
  isError = false,
  btnStyle
}) => {
  const { enrollmentStore, themeStore, errorStoreCommon } = useStores();
  const enrollmentWrapperContainer = useRef<HTMLDivElement>(null);

  const OnCloseModal = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event.preventDefault();
    enrollmentStore.setModalVisibility(false);
  };

  const handleOnKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER || e.key === 'Enter') {
      e.preventDefault();
      !isButtonDisabled && onSubmitEnterHandler && onSubmitEnterHandler();
    }
  };

  //run this when component first mounts (for autoFocus and avoiding logic duplication)
  useComponentDidMount(() => {
    if (isWrapperAutoFocus) {
      enrollmentWrapperContainer?.current?.focus();
    }
  });

  return (
    <div css={styles.enrollmentWrapperContainerStyle} ref={enrollmentWrapperContainer} tabIndex={0} onKeyDown={handleOnKeyDown}>
      {title && (
        <div css={[{ backgroundColor: themeStore.currentTheme.colors.backgroundMedium.published }, styles.titleContainerStyle]}>
          <h1 css={[enrollmentGlobalStyles.mainTitleStyle(themeStore.currentTheme.colors.actionDark.published)]}>{title}</h1>
        </div>
      )}
      <div css={styles.itemsAllignmentContentContent}>
        <div css={styles.childrenContainer}>{children}</div>
        <div css={[enrollmentGlobalStyles.actionButtons]}>
          {onSubmitHandler && (
            <React.Fragment>
              <div css={[{ textAlign: 'center', width: '31.3rem' }]}>
                <Button buttonStyle={{ ...styles.btnStyle, ...btnStyle }} text={actionButtonText} onClick={onSubmitHandler} isButtonDisabled={isButtonDisabled} />
              </div>
            </React.Fragment>
          )}

          {withCiamBtn && (
            <div css={styles.itemsAllignmentContentContent}>
              {withCiamLinkText && <div css={[styles.ciamBtnHader]}>{ciamBtnText}</div>}
              <SignInWithCHC />
            </div>
          )}
          {linkText !== '' && (
            <div css={styles.itemsAllignmentContentContent}>
              {linkText === CLOSE_MODAL && <Button buttonStyle={styles.lnkStyle} text={linkText} onClick={OnCloseModal} />}
              {linkTo !== '' && linkText !== '' && linkText !== CLOSE_MODAL && (
                <Link css={enrollmentGlobalStyles.link} to={linkTo}>
                  {linkText}
                </Link>
              )}
            </div>
          )}
          {withQuestionBtn && (
            <ContactUs />
          )}

        </div>
        {(isError ||
          enrollmentStore.step == EnrollmentSteps.AlreadyEnrolled ||
          enrollmentStore.step == EnrollmentSteps.GeneralError ||
          enrollmentStore.step == EnrollmentSteps.MissingInfo ||
          enrollmentStore.step == EnrollmentSteps.Locked) && <ErrorCode />}
      </div>
    </div>
  );
};

export default EnrollmentPagesWrapper;
