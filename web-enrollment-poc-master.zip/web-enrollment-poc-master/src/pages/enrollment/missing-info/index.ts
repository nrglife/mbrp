export { MissingInfoContainer as default } from './container/missing-info.container';
