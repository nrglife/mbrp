import { FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { ReactComponent as ErrorIcon } from '../../../../assets/icons/x-icons.svg';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import * as styles from './missing-info.styles';
import { Preferences as IPreferences } from '../../../../stores/ThemeStore';
import { uppercaseFirstLetter } from '@healthcareapp/connected-health-common-services/dist/utilities/string';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import { Trans, useTranslation } from 'react-i18next';
import { IPayer } from '@healthcareapp/connected-health-common-services/dist/stores/PayerStore';

export interface MissingInfoProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  onContactUsClickHandler: () => void;
  isButtonDisabled: boolean;
  actionButtonText?: string;
  payer: IPayer | null;
  theme: IPreferences;
}

export const MissingInfo: FC<MissingInfoProps> = ({ onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, payer, theme }) => {
  const { t, i18n } = useTranslation('translation');
  return (
    <EnrollmentPagesWrapper
      title={t(LocaleKeys.errors.contact_payer_name, { payerName: payer?.fullName || uppercaseFirstLetter(payer?.shortName) })}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={actionButtonText}
      withQuestionBtn={false}>
      <div css={styles.container}>
        <div css={styles.xSign}>
          <ErrorIcon />
        </div>
        <p css={styles.textStyle}>{t(LocaleKeys.errors.we_found_your_account)}</p>
        <p css={[styles.textStyle, { marginTop: '21px', marginBottom: '50px' }]}>
          <Trans
            t={t}
            i18nKey={LocaleKeys.errors.contact_payer_to_complete_details}
            values={{ payer: payer?.fullName || uppercaseFirstLetter(payer?.shortName) || 'us' }}
            components={[<a css={styles.linkTextStyle(theme)} onClick={onContactUsClickHandler} />]}
          />
        </p>
      </div>
    </EnrollmentPagesWrapper>
  );
};
