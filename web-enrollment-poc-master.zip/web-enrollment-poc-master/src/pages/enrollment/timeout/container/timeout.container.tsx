import { FC } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';
import { useStores } from '../../../../stores/useStores';
import { TimeoutComponent } from '../components/timeout.component';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface TimeoutContainerProps {}

const useTimeoutContainerBehavior = () => {
  const { enrollmentStore, appConfigStore } = useStores();
  const { t } = useTranslation('translation');

  const mainTitle = t(LocaleKeys.errors.enrollment_timed_out);
  const description = [t(LocaleKeys.errors.enrollment_timed_out_2), t(LocaleKeys.errors.please_try_again)];

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    onSubmitEnterHandler();
  };

  const onSubmitEnterHandler = () => {
    enrollmentStore.clearAllRegisteredTimeouts();
    enrollmentStore.setModalVisibility(false);
    appConfigStore.loadConfig();
  };

  return { mainTitle, description, onSubmitHandler, onSubmitEnterHandler };
};

const TimeoutContainer: FC<TimeoutContainerProps> = props => {
  const { mainTitle, description, onSubmitHandler, onSubmitEnterHandler } = useTimeoutContainerBehavior();
  return <TimeoutComponent mainTitle={mainTitle} description={description} onSubmitHandler={onSubmitHandler} onSubmitEnterHandler={onSubmitEnterHandler} />;
};

export default observer(TimeoutContainer);
