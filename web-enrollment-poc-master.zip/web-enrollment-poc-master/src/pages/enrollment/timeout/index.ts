import TimeoutContainer from './container/timeout.container';

export { TimeoutContainer as default };
