import { FC } from 'react';
import * as React from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { ReactComponent as ErrorIcon } from 'assets/icons/x-icons.svg';
import EnrollmentPagesWrapper from 'pages/enrollment/enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import * as styles from './timeout.styles';
import { observer } from 'mobx-react';
import { Description } from './description.component';

interface ITimeoutComponent {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  mainTitle: string;
  description: string | string[];
}

const Icon = props => (
  <div css={styles.xSign}>
    <ErrorIcon />
  </div>
);

export const TimeoutComponent: FC<ITimeoutComponent> = observer(({ onSubmitEnterHandler, onSubmitHandler, mainTitle, description }) => (
  <EnrollmentPagesWrapper title={mainTitle} actionButtonText="OK" onSubmitHandler={onSubmitHandler} onSubmitEnterHandler={onSubmitEnterHandler}>
    <div css={styles.timeoutMainContainer}>
      <div css={styles.timeoutContainer}>
        <Icon />
        <Description descriptionText={description} />
      </div>
    </div>
  </EnrollmentPagesWrapper>
));
