import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import * as styles from './timeout.styles';

interface IDescriptionProps {
  descriptionText: string | string[];
}

export const Description: FC<IDescriptionProps> = ({ descriptionText = '' }) => {
  if (!descriptionText) {
    return null;
  }

  let description: string | JSX.Element[] | null = null;
  if (descriptionText.constructor === String) {
    description = descriptionText;
  }

  if (descriptionText.constructor === Array) {
    description = descriptionText.map((item, index) => (
      <p css={[styles.text, index === descriptionText.length - 1 ? styles.spaceBetweenLinesStyle : undefined]} key={index}>
        {item}
      </p>
    ));
  }

  return <div css={{ marginTop: '41px', marginBottom: '104px' }}>{description}</div>;
};
