/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const timeoutMainContainer = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  flex: 1
});

export const timeoutContainer = css({
  display: 'flex',
  height: '100%',
  flexDirection: 'column',
  padding: '0 5rem'
});

export const xSign = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '58px'
});

export const text = css({
  fontSize: '1.8rem',
  fontWeight: 400,
  fontStretch: 'normal',
  lineHeight: 1.22,
  color: globalStyles.COLOR.black
});

export const spaceBetweenLinesStyle = css({ marginTop: '1.5em' });
