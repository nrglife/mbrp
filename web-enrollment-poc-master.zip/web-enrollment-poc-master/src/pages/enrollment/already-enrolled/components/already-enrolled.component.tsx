import { FC } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import { ReactComponent as ErrorIcon } from '../../../../assets/icons/x-icons.svg';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';

import * as styles from './already-enrolled.styles';
import { Preferences as IPreferences } from '../../../../stores/ThemeStore';
import { Trans, useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export interface AlreadyEnrolledProps {
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  onContactUsClickHandler: () => void;
  isButtonDisabled: boolean;
  actionButtonText?: string;
  theme: IPreferences;
}

export const AlreadyEnrolled: FC<AlreadyEnrolledProps> = ({ onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, theme }) => {
  const { t, i18n } = useTranslation('translation');

  return (
    <EnrollmentPagesWrapper
      title={t(LocaleKeys.errors.something_went_wrong)}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={actionButtonText}
      withQuestionBtn={false}>
      <div css={styles.container}>
        <div css={styles.xSign}>
          <ErrorIcon />
        </div>
        <p css={styles.textStyle}>{t(LocaleKeys.errors.account_already_enrolled)}</p>
        <p css={[styles.textStyle, { marginTop: '0', marginBottom: '50px' }]}>
          <Trans t={t} i18nKey={LocaleKeys.errors.try_to_sign_in} components={[<a css={styles.linkTextStyle(theme)} onClick={onContactUsClickHandler} />]} />
        </p>
      </div>
    </EnrollmentPagesWrapper>
  );
};
