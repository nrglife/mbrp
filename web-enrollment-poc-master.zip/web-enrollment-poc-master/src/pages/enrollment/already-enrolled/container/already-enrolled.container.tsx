import { FC } from 'react';
import * as React from 'react';
import { AlreadyEnrolled } from '../components/already-enrolled.component';
import { useStores } from '../../../../stores/useStores';
import { observer } from 'mobx-react';
import { EnrollmentSteps } from 'stores';

export interface AlreadyEnrolledContainerProps {}

const useAlreadyEnrolledContainerBehavior = () => {
  const { enrollmentStore, routesStore, themeStore } = useStores();
  const isButtonDisabled: boolean | undefined = false;
  const actionButtonText = 'CLOSE';

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event.preventDefault();
    onSubmitEnterHandler();
  };

  const onSubmitEnterHandler = () => {
    console.log('close the modal and reset the enrollment process');
    enrollmentStore.setModalVisibility(false);
  };

  const onContactUsClickHandler = () => {
    enrollmentStore.setContactUsVisibility(true);
  };

  return { onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, routesStore, themeStore };
};

export const AlreadyEnrolledContainer: FC<AlreadyEnrolledContainerProps> = observer(props => {
  const { onSubmitHandler, onSubmitEnterHandler, onContactUsClickHandler, isButtonDisabled, actionButtonText, routesStore, themeStore } = useAlreadyEnrolledContainerBehavior();
  return (
    <AlreadyEnrolled
      onSubmitHandler={onSubmitHandler}
      onContactUsClickHandler={onContactUsClickHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      actionButtonText={actionButtonText}
      theme={themeStore.currentTheme}
    />
  );
});
