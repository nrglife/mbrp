export { AlreadyEnrolledContainer as default } from './container/already-enrolled.container';
