import { IocContainer, IocTypes, EnrollmentStoreType } from './../../inversify.config';
import { EnrollmentSteps } from '../../stores';
import { HTTP_STATUS_CODES, HTTPErrorHandler } from '../../services';

import i18n from './../../i18n';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

const handleGeneralErrorRecievedFromServer = (statusCode: HTTP_STATUS_CODES, errorMessage = '') => {
  const enrollmentStore = IocContainer.get<EnrollmentStoreType>(IocTypes.EnrollmentStore);
  let logErrorMessage = '';
  let customToastErrorMessage = i18n.t(LocaleKeys.errors.oops_something_is_wrong);
  switch (statusCode) {
    case HTTP_STATUS_CODES.UNAUTHORIZED:
      logErrorMessage = `NOT AUTHORIZED.`;
      customToastErrorMessage = i18n.t(LocaleKeys.errors.try_again_later);
      break;
    case HTTP_STATUS_CODES.CONFLICT:
      logErrorMessage = i18n.t(LocaleKeys.errors.conflict_request);
      break;
    case HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS:
      logErrorMessage = i18n.t(LocaleKeys.errors.requests_exceeded);
      break;
    case HTTP_STATUS_CODES.SERVER_ERROR:
      logErrorMessage = i18n.t(LocaleKeys.errors.could_not_reach_server);
      break;
    default:
      logErrorMessage = `UNHANDLED`;
  }

  return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
};

export const handleFetchError = (response: any, uponFailure: HTTPErrorHandler, handleLockedError: boolean = false) => {
  const enrollmentStore = IocContainer.get<EnrollmentStoreType>(IocTypes.EnrollmentStore);
  const { meta = {} } = response || {};
  const { remoteRequest = {} } = meta || {};
  const { status = HTTP_STATUS_CODES.NOT_FOUND } = remoteRequest || {};
  const { meta: innerMeta = {} } = remoteRequest || {};
  const { attemptCount = 0, attemptMax = 0 } = innerMeta || {};
  //check max attemepts
  if (attemptCount !== 0 && attemptMax !== 0 && attemptMax - attemptCount <= 0) return enrollmentStore.setStep(EnrollmentSteps.Locked);
  //if not max attemepts - set at the store current attempts if exist
  !isNaN(attemptCount) && !isNaN(attemptMax) && enrollmentStore.setAttemptsNumber({ attemptCount, attemptMax });
  //check error code
  switch (status) {
    // if  INVALID_LOCKED navigate to LOCK screen.
    case HTTP_STATUS_CODES.INVALID_LOCKED:
      return handleLockedError ? uponFailure({ statusCode: status }) : enrollmentStore.setStep(EnrollmentSteps.Locked);
    case HTTP_STATUS_CODES.ALREADY_ENROLLED:
      return enrollmentStore.setStep(EnrollmentSteps.AlreadyEnrolled);
    // errors handled in UI
    case HTTP_STATUS_CODES.MISSING_INFO:
      return enrollmentStore.setStep(EnrollmentSteps.MissingInfo);
    case HTTP_STATUS_CODES.BAD_REQUEST:
      return uponFailure && uponFailure({ statusCode: status });
    // handle by displaying the error in a toast
    case HTTP_STATUS_CODES.UNAUTHORIZED:
    case HTTP_STATUS_CODES.CONFLICT:
    case HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS:
    case HTTP_STATUS_CODES.SERVER_ERROR:
      return handleGeneralErrorRecievedFromServer(status);
    //special cases
    case HTTP_STATUS_CODES.NOT_FOUND:
      return enrollmentStore.step === EnrollmentSteps.InvitationCode ? uponFailure && uponFailure({ statusCode: status }) : handleGeneralErrorRecievedFromServer(status);
    case HTTP_STATUS_CODES.ALREADY_IN_USE:
      return enrollmentStore.step === EnrollmentSteps.EmailVerification ? uponFailure && uponFailure({ statusCode: status, meta: innerMeta }) : handleGeneralErrorRecievedFromServer(status);

    default:
      handleGeneralErrorRecievedFromServer(status);
      break;
  }
};
