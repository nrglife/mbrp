import { FC, useCallback, useState, useEffect, useRef } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import debounce from 'lodash/debounce';

//developed
import ResendCode from '../resend-code/resend-code.component';
import { Error } from '../../modules/models/error';

//styles
import * as styles from './radio-last-input.styles';
import * as enrollmentGlobalStyles from '../../../enrollment-page.styles';

interface RadioLastInputProps extends React.HTMLProps<HTMLInputElement> {
  emails: string[];
  placeholder?: string;
  onSelected?: (email: string) => void;
  inputDelay?: number;
  remainingAttempts: number;
  error: Error;
  isResendLinkLoading: boolean;
  onResendHandler: any;
  onResendHandlerError: any;
}

const RadioLastInput: FC<RadioLastInputProps> = ({ emails, onSelected, inputDelay = 500, remainingAttempts, error, isResendLinkLoading, onResendHandler, onResendHandlerError }) => {
  const emailRef = useRef<HTMLInputElement>(null);

  const [email, setEmail] = useState('');
  const [enteredEmail, setEnteredEmail] = useState('');
  const [isEnteredEmail, setIsEnteredEmail] = useState(false);

  const onChangeDelay = useCallback(
    debounce((email: string, isMounted: boolean) => {
      if (isMounted && isEnteredEmail) {
        onSelected && onSelected(email);
        setEmail(email);
      }
    }, inputDelay),
    [enteredEmail]
  );

  /**
   * Set on initial load a first email
   */
  useEffect(() => {
    let isMounted = true;
    if (emails.length > 0) {
      onSelected && onSelected(emails[0]);
      if (isMounted) setEmail(emails[0]);

      if (emails.length === 1 && emailRef.current) {
        emailRef.current.focus();
      }
    }
    return () => {
      onChangeDelay.cancel();
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let isMounted = true;
    onChangeDelay(enteredEmail, isMounted);

    // Cancel the debounce on useEffect cleanup.
    return () => {
      onChangeDelay.cancel();
      isMounted = false;
    };
  }, [enteredEmail, onChangeDelay]);

  const onChangeEnterEmailHandler = (email: string) => {
    setIsEnteredEmail(true);
    setEnteredEmail(email);
  };

  const onClickPreEmailHandler = (email: string) => {
    onSelected && onSelected(email);
    setEmail(email);
    setIsEnteredEmail(false);
  };

  const onCheckEnterEmail = () => {
    setIsEnteredEmail(true);

    if (emailRef.current) {
      setEmail(emailRef.current.value);
      emailRef.current.focus();
    }
  };

  const onClickEnterEmail = () => {
    if (!isEnteredEmail) {
      setIsEnteredEmail(true);
      if (emailRef.current) setEmail(emailRef.current.value);
    }
  };

  return (
    <React.Fragment>
      <div css={styles.checkboxesContainer}>
        {emails.map((email, i) => (
          <div key={email} css={[styles.checkboxContainer]}>
            <input
              autoFocus={i === 0}
              type="radio"
              css={[styles.checkbox]}
              id={`email-${i.toString()}`}
              name="email"
              value={email}
              defaultChecked={i === 0}
              onClick={() => onClickPreEmailHandler(email)}
            />
            <label css={[styles.content, styles.email]} title={email}>
              {email}
            </label>
          </div>
        ))}
        <div key={'input-email'} css={[styles.inputType, styles.checkboxContainer]}>
          {emails.length > 0 && (
            <input autoFocus={false} type="radio" css={[styles.checkbox]} id="input-email" name="email" checked={isEnteredEmail} onClick={onCheckEnterEmail} onChange={onCheckEnterEmail} />
          )}
          <div css={styles.formGroupStyle}>
            <input
              placeholder="Enter a new email"
              type="email"
              ref={emailRef}
              value={enteredEmail}
              onChange={event => onChangeEnterEmailHandler(event.target.value)}
              maxLength={40}
              onClick={onClickEnterEmail}
              css={[styles.emailInput, error.isError ? styles.emailInputError : undefined]}
            />
            {error.isError && <p css={[enrollmentGlobalStyles.errorMessage, { fontSize: '1.4rem' }]}>{error.message}</p>}
          </div>
        </div>
        <ResendCode
          email={email}
          remainingAttempts={remainingAttempts}
          isResendLinkLoading={isResendLinkLoading}
          error={error}
          onResendHandler={onResendHandler}
          onResendHandlerError={onResendHandlerError}
        />
      </div>
    </React.Fragment>
  );
};

export default RadioLastInput;
