/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';

export const content = css({
  fontSize: '1.8rem',
  lineHeight: '28px'
});

export const email = css({
  ...globalStyles.STYLES.ellipsis,
  textAlign: 'center',
  maxWidth: '28rem'
});

export const checkboxesContainer = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-start',
  justifyContent: 'center'
});

export const checkboxesContainerTitle = css({
  fontStyle: 'italic',
  fontSize: '1.8rem',
  lineHeight: '1.22px'
});

export const checkboxContainer = css({
  color: globalStyles.COLOR.greyishBrown,
  marginTop: '1.5rem',
  display: 'flex',
  alignItems: 'center'
});

export const checkbox = css({
  width: '1.8rem',
  height: '1.8rem',
  marginRight: '1rem',
  backgroundColor: 'white',
  borderRadius: '50%',
  verticalAlign: 'middle',
  border: `1px solid ${globalStyles.COLOR.greyishBrown}`,
  WebkitAppearance: 'none',
  outline: 'none',
  cursor: 'pointer',

  '&:checked': { border: `.7rem solid ${globalStyles.COLOR.tealBlue}` }
});

export const inputType = css({
  display: 'flex'
});

export const emailInput = css({
  width: '25.1rem',
  height: '3rem',
  fontSize: '1.8rem',
  textAlign: 'left',
  //transition: 'all 0.3s ease-in-out',
  padding: '0 0.2rem',
  //marginRight: 5, // defaults to px
  border: 'none',
  borderBottom: '1px solid rgba(0,0,0,0.2)',
  borderRadius: 'unset',

  '&:focus': {
    borderBottom: '1px  solid #333333'
    //transition: 'all 0.3s ease-in-out'
  }
  // '&:disabled': {
  //   backgroundColor: 'transparent'
  // }
});

export const emailInputError = css({
  borderBottom: '2px solid rgba(255,0,0,0.25)',
  color: globalStyles.COLOR.darkCoral,

  '&:focus': {
    borderBottom: `2px solid ${globalStyles.COLOR.darkCoral}`,
    transition: 'all 0.3s ease-in-out'
  }
});

export const formGroupStyle = css({
  maxWidth: '35rem'
});
