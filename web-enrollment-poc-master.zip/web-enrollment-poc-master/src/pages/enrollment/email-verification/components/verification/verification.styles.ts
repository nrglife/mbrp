import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';

export const container = css({
  display: 'flex',
  flexGrow: 1,
  flexDirection: 'column',
  justifyContent: 'left',
  alignItems: 'left',
  alignContent: 'left',
  paddingTop: '3.3rem'
});

export const content = css({
  marginTop: '10px',
  display: 'flex',
  justifyContent: 'left',
  alignItems: 'left',
  paddingBottom: '0.7rem'
});

export const label = css({
  fontSize: '1.5rem',
  color: '#37474f',
  textAlign: 'left'
});

export const enterCodeHeader = css({
  fontSize: '1.8rem',
  lineHeight: '28px',
  color: globalStyles.COLOR.black
});

export const expiresIn60Minutes = css({
  fontSize: '1.3rem',
  color: '#37474f'
});
