import { FC, useEffect, useState } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

//developed
import { HTTP_STATUS_CODES } from 'services';
import OtpInput from 'components/general/OTP';
import { Error } from '../../modules/models/error';

//styles
import * as enrollmentGlobalStyles from 'pages/enrollment/enrollment-page.styles';
import * as styles from './verification.styles';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface VerificationProps {
  error: Error;
  codeFormat: string;
  onOTPChange: any;
  setCodeFullFilled: any;
  enterCodeHeader: string;
  email: string | null;
}

const Verification: FC<VerificationProps> = ({ email, error, codeFormat, onOTPChange, setCodeFullFilled, enterCodeHeader }) => {
  const expiresIn60Mins = 'Expires in 60 minutes ';
  const { t, i18n } = useTranslation('translation');

  const [value, setValue] = useState('');

  useEffect(() => {
    let isMounted = true;
    if (isMounted && error.isApiError && error.error?.statusCode === HTTP_STATUS_CODES.ALREADY_IN_USE) {
      setValue('');
    }
    return () => {
      isMounted = false;
    };
  }, [error]);

  const hasError = error.isError || (error.isApiError && error.error?.statusCode === HTTP_STATUS_CODES.BAD_REQUEST);

  const onChange = (value: string) => {
    onOTPChange(value);
    setValue(value);
  };

  return (
    <div css={styles.container}>
      <div css={styles.label}>
        <label css={[styles.label, styles.enterCodeHeader]}>{enterCodeHeader}</label>
        <div css={styles.content}>
          <OtpInput format={codeFormat} hasErrored={hasError} onChange={onChange} setCodeFullFilled={setCodeFullFilled} value={value} />
        </div>
        {(error.isError || (error.isApiError && error.error?.statusCode === HTTP_STATUS_CODES.BAD_REQUEST)) && (
          <p css={[enrollmentGlobalStyles.errorMessage, { fontSize: '1.4rem' }]}>{t(LocaleKeys.errors.wrong_code)}</p>
        )}
        <div css={styles.expiresIn60Minutes}>{expiresIn60Mins}</div>
      </div>
    </div>
  );
};

export default Verification;
