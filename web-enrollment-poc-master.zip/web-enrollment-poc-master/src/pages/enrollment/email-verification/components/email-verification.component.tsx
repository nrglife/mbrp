import { FC } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//developed
import { EnrollmentStoreType, EnrollmentContext } from 'stores';
import EnrollmentPagesWrapper from '../../enrollment-pages-wrapper/components/enrollment-pages-wrapper.component';
import RadioLastInput from './radio-last-input/radio-last-input.component';
import Verification from './verification/verification.component';
import { Error, Errors } from '../modules/models/error';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

//styles
import * as enrollmentGlobalStyles from '../../enrollment-page.styles';
import * as styles from './email-verification.styles';

interface EmailVerificationProps {
  userName: string | null;
  onSubmitHandler: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  onSubmitEnterHandler: () => void;
  isButtonDisabled?: boolean;
  resetEmailVerificationTimeOut?: Function;
  emails: string[];
  codeFormat: string | '';
  onOTPChange: (otp: string) => void;
  setCodeFullFilled: (isFullFilled: boolean) => void;
  onResendHandler: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
  isResendLinkLoading?: boolean | undefined;
  remainingAttempts: number;
  onSelectedEmail: (email: string) => void;
  errors: Errors;
  email: string | null;
  onResendHandlerError: (error: Error) => void;
  store: EnrollmentStoreType;
  showEmailOTPSection?: boolean;
  enrollmentContext: EnrollmentContext;
}

const getErrorMessage = (errors: Errors) => {
  // TODO: oreg: check if the first step is needed
  if (errors.emailCode.isApiError && errors.emailAddress.isApiError)
    return [(errors.emailCode.isApiError && errors.emailCode.message) || '', (errors.emailAddress.isApiError && errors.emailAddress.message) || ''].join('');
  else if (errors.emailCode.isApiError) return errors.emailCode.message;
  else if (errors.emailAddress.isApiError) return errors.emailAddress.message;
  else return '';
};
const codeLabel = 'Enter the code below:';

const EmailVerification: FC<EmailVerificationProps> = ({
  store,
  emails,
  userName,
  onSubmitHandler,
  onSubmitEnterHandler,
  isButtonDisabled = false,
  resetEmailVerificationTimeOut = null,
  codeFormat = '',
  onOTPChange = (otp: string) => {},
  setCodeFullFilled = (isFullFilled: boolean) => {},
  onResendHandler = (() => {})(),
  isResendLinkLoading = false,
  remainingAttempts,
  onSelectedEmail = (email: string) => {},
  errors,
  email,
  onResendHandlerError = (error: Error) => {},
  showEmailOTPSection = true,
  enrollmentContext
}) => {
  const { t } = useTranslation('translation');
  const { EmailVerification: EmailVerificationLocalKeys } = LocaleKeys.components.Enrollment;

  const title = t(EmailVerificationLocalKeys.Title, { userName: userName && ` ${userName}` }); // `Hi{{userName}}, we’ve confirmed your identity`;
  let descriptionWhatToDo = t(EmailVerificationLocalKeys.DescriptionWhatToDoUnified); // 'To sign you in securely, we need to confirm your email. This will also be your username for signing into Connected Health.'

  if (!enrollmentContext.isLandingPageUnified) {
    if (enrollmentContext.isLandingPage) {
      // Landing page
      descriptionWhatToDo = t(EmailVerificationLocalKeys.DescriptionWhatToDoLandingPage); // 'To sign you in securely, we need to confirm your email. This will also be your username for signing into Connected Health.'
    } else {
      // Add new delegate button
      descriptionWhatToDo = t(EmailVerificationLocalKeys.DescriptionWhatToDoAddButton); // 'We need to confirm your email.';
    }
  }

  const descriptionRequirements = !(emails && emails.length > 1)
    ? t(EmailVerificationLocalKeys.DescriptionRequirements1email) // 'We’ll send a unique code to this address:'
    : t(EmailVerificationLocalKeys.DescriptionRequirementsManyEmails); // 'Select one of these emails and we’ll send unique code:';

  const description = `${descriptionWhatToDo} ${descriptionRequirements}`;

  return (
    <EnrollmentPagesWrapper
      title={title}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      isWrapperAutoFocus={false}
      withQuestionBtn={enrollmentContext.isLandingPage}
      actionButtonText={t(EmailVerificationLocalKeys.ButtonNext)} // "NEXT"
      isError={errors.emailAddress.isApiError || errors.emailCode.isApiError}>
      <div css={styles.container}>
        <div css={styles.errorMessage}>
          <p css={enrollmentGlobalStyles.errorMessage}>{getErrorMessage(errors)}</p>
        </div>
        <p id="what-to-do" css={styles.content}>
          {description}
        </p>
        <div css={styles.optionsContainer}>
          <RadioLastInput
            emails={emails}
            remainingAttempts={remainingAttempts}
            onSelected={onSelectedEmail}
            error={errors.emailAddress}
            onResendHandler={onResendHandler}
            isResendLinkLoading={isResendLinkLoading}
            onResendHandlerError={onResendHandlerError}
          />
        </div>
        <div css={[styles.verificationContainer, !showEmailOTPSection && { opacity: 0, pointerEvents: 'none' }]}>
          <Verification email={email} error={errors.emailCode} codeFormat={codeFormat} onOTPChange={onOTPChange} setCodeFullFilled={setCodeFullFilled} enterCodeHeader={codeLabel} />
        </div>
      </div>
    </EnrollmentPagesWrapper>
  );
};

export default observer(EmailVerification);
