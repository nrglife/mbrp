import { useState, FC, useEffect } from 'react';
import * as React from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';
import ClipLoader from 'react-spinners/ClipLoader';

//developed
import { Error } from '../../modules/models/error';
import validation from '../../modules/validations/email';

//styles
import * as enrollmentGlobalStyles from 'pages/enrollment/enrollment-page.styles';
import * as styles from './resend-code.styles';
import { ReactComponent as CheckFilledIcon } from 'assets/icons/check-filled.svg';
import { useStores } from '../../../../../stores/useStores';

interface ResendCodeProps {
  error: Error;
  remainingAttempts: number;
  onResendHandler: any;
  isResendLinkLoading: boolean;
  email: string;
  onResendHandlerError: any;
}

const ResendCode: FC<ResendCodeProps> = ({ email, error, remainingAttempts, onResendHandler, isResendLinkLoading, onResendHandlerError }) => {
  const [disableLink, setDisableLink] = useState(false);
  const [resendPressNumber, setResendPressNumber] = useState(1);
  const { themeStore } = useStores();
  const [disableLinkTimeoutId, setDisableLinkTimeoutId] = useState<NodeJS.Timeout | null>(null);

  const resendWaitSeconds = { 1: 10, 2: 60, 3: 3 * 60 };

  const onResendPress = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    //disable resend link for the amount of needed time
    const waitMilliseconds = resendWaitSeconds[resendPressNumber] ? resendWaitSeconds[resendPressNumber] * 1000 : 3 * 60 * 1000;
    setDisableLink(true);

    const timeoutId = setTimeout(() => {
      //enable the option to use resend link only if this is at the most the x time press (depened on resenedWaitSeconed obj)
      setDisableLink(false);
      setResendPressNumber(resendPressNumber + 1);
    }, waitMilliseconds);

    //clear old Timeout
    disableLinkTimeoutId && clearTimeout(disableLinkTimeoutId);
    //set new Timeout to clear next press or at component unmount
    setDisableLinkTimeoutId(timeoutId);
    //do the resend action got from the props of the component
    onResendHandler(event);
  };

  useEffect(() => {
    return () => {
      //clear old Timeout at component unmount
      disableLinkTimeoutId && clearTimeout(disableLinkTimeoutId);
    };
  }, [disableLinkTimeoutId]);

  const sendLabel = (error: Error, pressNumber: number) => {
    // TODO: does invalid email will be counted as invalid attempt
    // means resendPressNumber will add 1
    // errors.emailAddress.isError
    return pressNumber > 1 ? 'Resend code' : 'Send code';
  };

  const isCodeSent = (isDisable: boolean, error: Error) => (error.isError ? false : isDisable);

  const validateEmail = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    // it must not go through when no email address set
    // TODO: should I throw an error when no email address,
    // question to member portal team how it should be handle
    const validations = validation.combined(email);

    if (validations.isError) onResendHandlerError(validations);
    else onResendPress(event);
  };

  return (
    <div css={styles.container}>
      <div style={{ marginBottom: '.5rem' }}>
        {!!remainingAttempts && (
          <p css={[enrollmentGlobalStyles.errorMessage, styles.smallFont, !!remainingAttempts && remainingAttempts < 3 ? styles.boldFont : {}]}>
            {error.isError ? `You have ${remainingAttempts} attempts remaining` : ' '}
          </p>
        )}
      </div>
      {isResendLinkLoading ? (
        <div css={styles.resendLoaderContainer}>
          <ClipLoader size="20px" color={'#498DFF'} />
        </div>
      ) : (
        <div
          css={!error.isApiError && isCodeSent(disableLink, error) ? styles.disableLink : styles.resendLink(themeStore.currentTheme)}
          onClick={error.isError || isCodeSent(disableLink, error) ? () => {} : validateEmail}>
          {!error.isApiError && isCodeSent(disableLink, error) && (
            <div css={{ marginRight: '.4rem' }}>
              <CheckFilledIcon css={styles.checkFilledIcon} />
            </div>
          )}
          {!error.isApiError && isCodeSent(disableLink, error) ? <div id="code-sent">Code Sent</div> : <div id="send-code-label">{sendLabel(error, resendPressNumber)}</div>}
        </div>
      )}
    </div>
  );
};

export default ResendCode;
