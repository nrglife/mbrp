import { css } from '@emotion/core';
import { globalStyles } from '../../../../../styles/global.styles';
import { Preferences } from '../../../../../stores/ThemeStore';

export const container = css({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  width: '100%;'
});

export const smallFont = css({
  fontSize: '1.4rem'
});

export const boldFont = css({
  fontWeight: 'bold'
});

export const resendLink = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    marginTop: '2rem',
    display: 'flex',
    justifyContent: 'left',
    '&:hover': {
      transition: 'all .3s',
      cursor: 'pointer',
      position: 'relative',
      top: '-1px'
    }
  });

export const disableLink = css({
  marginTop: '2rem',
  display: 'flex',
  justifyContent: 'left',
  color: globalStyles.COLOR.greyishBrown,
  fontStyle: 'italic',
  alignItems: 'center'
});

export const resendLoaderContainer = css({
  display: 'flex',
  justifyContent: 'left',
  paddingTop: '2.8rem'
});

export const checkFilledIcon = css({
  width: '2rem',
  height: '2rem'
});
