/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../../styles/global.styles';
import { Preferences } from '../../../../stores/ThemeStore';

export const container = css({
  display: 'flex',
  width: '100%',
  flexDirection: 'column',
  alignItems: 'center',
  color: globalStyles.COLOR.black,
  maxWidth: '50.5rem',
  margin: '0 auto'
});

export const content = css({
  fontSize: '1.8rem',
  lineHeight: '28px',
  textAlign: 'center',
  marginBottom: '1rem'
});

export const requirements = css({
  marginTop: '2rem'
});

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const email = css({
  textAlign: 'center'
});

export const modalContent = css({
  margin: '2rem'
});

export const checkboxesContainer = css({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: '3rem',
  marginTop: '.5rem'
});

export const checkboxesContainerTitle = css({
  fontStyle: 'italic',
  fontSize: '1.8rem',
  lineHeight: '1.22px'
});

export const checkboxContainer = css({
  color: globalStyles.COLOR.greyishBrown,
  marginTop: '1.5rem'
});

export const checkbox = css({
  width: '1.8rem',
  height: '1.8rem',
  marginRight: '1rem',
  backgroundColor: 'white',
  borderRadius: '50%',
  verticalAlign: 'middle',
  border: `1px solid ${globalStyles.COLOR.greyishBrown}`,
  WebkitAppearance: 'none',
  outline: 'none',
  cursor: 'pointer',

  '&:checked': { border: `.7rem solid ${globalStyles.COLOR.tealBlue}` }
});

export const errorMessage = css({
  paddingTop: '2.9rem',
  whiteSpace: 'pre-wrap',
  paddingBottom: '1rem',
  textAlign: 'center'
});

export const optionsContainer = css({ textAlign: 'left', width: '31.3rem' });

export const verificationContainer = css({ textAlign: 'left', width: '31.3rem', marginBottom: '2rem' });
