/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

const container = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  textarea: { resize: 'none' }
});

export { container };
