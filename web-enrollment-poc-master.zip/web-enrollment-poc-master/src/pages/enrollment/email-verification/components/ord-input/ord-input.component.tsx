import { FC } from 'react';
import * as React from 'react';

/** @jsxImportSource @emotion/core */
import { jsx } from '@emotion/core';

//styles
import * as styles from './ord-input.styles';

type InputElement = HTMLInputElement | HTMLTextAreaElement;
type InputChangeEvent = React.ChangeEvent<InputElement>;

interface TextFieldProps {
  name?: string;
  label?: string | null;
  maxLength?: number;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  autoFocus?: boolean;
  type?: 'email' | 'password' | 'text';
  textarea?: boolean;
  disabled?: boolean | false;
}

const OrdInput: FC<TextFieldProps> = ({ name, label, textarea = false, disabled = false, onChange, maxLength = 20, ...rest }: TextFieldProps) => {
  const InputElement = textarea ? 'textarea' : 'input';
  // TODO: nice if debounce can be implemented here
  return (
    <div css={[styles.container]}>
      {label && <label htmlFor={name}>{label}</label>}
      <InputElement
        type="text"
        aria-label="label"
        aria-required="true"
        maxLength={maxLength}
        id={name}
        data-id={name}
        disabled={disabled}
        onChange={({ target: { value } }: InputChangeEvent) => onChange(value)}
        {...rest}></InputElement>
    </div>
  );
};

export default OrdInput;
