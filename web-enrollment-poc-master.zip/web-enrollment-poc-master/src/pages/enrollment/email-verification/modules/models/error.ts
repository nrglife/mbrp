import { IHTTP_ERROR } from 'services';

export interface Error {
  isApiError?: boolean;
  isError?: boolean;
  // TODO: oreng: try to change it instead of any to ReactElement or ReactNode
  message: string | any;
  error?: IHTTP_ERROR;
}

export interface Errors {
  emailCode: Error;
  emailAddress: Error;
}

export const errorFactory = ({ isError = false, isApiError = false, message = '' }): Error => ({ isError, isApiError, message });

export const errorApiFactory = (props: Error): Error => {
  const result = { ...props, isApiError: true };
  return result;
};