import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import ContactUsWithCHC from 'components/contact-us/contact-us.component';
import SignInWithCHC from 'components/sign-in-with-chc/sign-in-with-chc.component';
import i18n from 'i18n';

export default function getEmailCodeMessage() {
  return {
    attempts: (count: number) =>
      i18n.t(LocaleKeys.errors.something_wrong_try_again) + (count > 0 ? '\n' + i18n.t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: count, s: count > 1 ? 's' : '' }) : ``),
    alreadyInUse: (email: string | null, metaCode: number) => {
      if (metaCode === 1902)
        return (
          <div>
            {i18n.t(LocaleKeys.errors.email_already_in_use, { email: email })}
            <br />
            {i18n.t(LocaleKeys.errors.select_another_email_part_1) + ' '}
            <ContactUsWithCHC
              ignoreDefaultContainerStyle={true}
              containerStyle={{ display: 'inline' }}
              ignoreDefaultTextStyle={true}
              textStyle={{ textDecoration: 'underline', cursor: 'pointer' }}
              contactUsPrefixText={''}
              contactUsText={i18n.t(LocaleKeys.errors.contact_us_lowercase)}
              contactUsPostText={''}
            />
            {' ' + i18n.t(LocaleKeys.errors.select_another_email_part_2)}
          </div>
        );
      else
        return (
          <div>
            {i18n.t(LocaleKeys.errors.email_already_registered, { email: email })} {i18n.t(LocaleKeys.errors.try_signing_in_part_1) + ' '}
            <SignInWithCHC
              text={i18n.t(LocaleKeys.errors.signing_in)}
              showLogoImg={false}
              ignoreDefaultContainerStyle={true}
              containerStyle={{ display: 'inline' }}
              ignoreDefaultTextStyle={true}
              textStyle={{ textDecoration: 'underline', cursor: 'pointer' }}
            />
            {' ' + i18n.t(LocaleKeys.errors.try_signing_in_part_2)}
          </div>
        );
    },
    invalid: i18n.t(LocaleKeys.errors.this_is_not_valid_verification),
    userId: i18n.t(LocaleKeys.errors.unable_find_user_verification_code)
  };
}
