import { LocaleKeys } from '@healthcareapp/connected-health-common-services';
import i18n from 'i18n';

// TODO: ask product and member portal team for appropriate message and standard
export default function getEmailAdressMessages() {
  return {
    attempts: (count: number) =>
      i18n.t(LocaleKeys.errors.something_wrong_try_again) + (count > 0 ? '\n' + i18n.t(LocaleKeys.errors.you_have_more_attempt, { remainintAttempts: count, s: count > 1 ? 's' : '' }) : ``),
    invalid: i18n.t(LocaleKeys.errors.enter_vallid_email),
    empty: i18n.t(LocaleKeys.errors.enter_vallid_email)
  };
}
