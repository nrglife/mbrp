import isEmpty from 'lodash/isEmpty';
import { Error, errorFactory } from '../models/error';
import getEmailAdressMessages from '../messages/email-address';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const isValid = (email: string) => {
  return emailRegex.test(email);
};

export interface Validation {
  execute: (email: string) => Error;
}

const empty = (next?: Validation): Validation => {
  let nextHandler: Validation | undefined = next;

  const execute = (email: string): Error => {
    if (isEmpty(email)) return errorFactory({isError: true, message: getEmailAdressMessages().empty});
    return (nextHandler && nextHandler.execute(email)) || errorFactory({});
  };

  return { execute };
};

const validUnmasked = (next?: Validation): Validation => {
  let nextHandler: Validation | undefined = next;

  const execute = (email: string): Error => {
    if (email.indexOf('*') === -1 && !isValid(email)) return errorFactory({ isError: true, message: getEmailAdressMessages().invalid});
    return (nextHandler && nextHandler.execute(email)) || errorFactory({});
  };

  return { execute };
};

const combined = (email: string): Error => empty(validUnmasked()).execute(email) || errorFactory({});

export default { combined, empty, validUnmasked };
