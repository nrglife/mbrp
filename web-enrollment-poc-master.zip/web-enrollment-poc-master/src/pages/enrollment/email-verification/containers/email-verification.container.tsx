import { FC, useEffect, useReducer, useMemo, useState } from 'react';
import * as React from 'react';
import { observer } from 'mobx-react';

//CommonServices
import { minutesToMilliseconds } from '@healthcareapp/connected-health-common-services/dist/utilities/time';

//developed
import { IocContainer, IocTypes, EnrollmentApiType } from 'inversify.config';
import { EnrollmentSteps } from '../../../../stores';
import EmailVerification from '../components/email-verification.component';
import { useStores } from '../../../../stores/useStores';
import { IHTTP_ERROR, HTTP_STATUS_CODES } from 'services';
import { EnrollmentHttpService } from 'services';
import { Error, Errors, errorApiFactory, errorFactory } from '../modules/models/error';
import email from '../modules/validations/email';
import getEmailCodeMessage from '../modules/messages/email-code';
import type from '../modules/utils/literal-type';
import getEmailAdressMessages from '../modules/messages/email-address';
import i18n from 'i18n';

interface EmailVerificationContainerProps {}

interface State {
  emailCodeFormat: string;
  emailCode: string;
  isEmailCodeFilled: boolean;
  isResendLinkLoading: boolean;
  errors: Errors;
}

const errorsInitialState = { emailCode: errorFactory({}), emailAddress: errorFactory({}) };

const initialState: State = {
  emailCodeFormat: '######',
  emailCode: '',
  isEmailCodeFilled: false,
  isResendLinkLoading: false,
  errors: errorsInitialState
};

const actions = type.literally({
  setEmailCode: 'SET_EMAIL_CODE',
  setEmailCodeError: 'SET_EMAIL_CODE_ERROR',
  setEmailCodeFilled: 'SET_EMAIL_CODE_FILLED',
  setResendLink: 'SET_RESEND_LINK_LOADING',
  setEmailAddress: 'SET_EMAIL_ADDRESS',
  setEmailAddressError: 'SET_EMAIL_ADDRESS_ERROR'
});

type ActionTypes = 'SET_EMAIL_ADDRESS' | 'SET_EMAIL_ADDRESS_ERROR' | 'SET_EMAIL_CODE' | 'SET_EMAIL_CODE_ERROR' | 'SET_EMAIL_CODE_FILLED' | 'SET_RESEND_LINK_LOADING';
type Action = { type: ActionTypes; payload?: any };

const emailCode = (state: State, error: Error) => ({ emailAddress: errorFactory({}), emailCode: error });

const emailAddress = (state: State, error: Error) => ({ emailCode: state.errors.emailCode, emailAddress: error });

const reducer = (state: State = initialState, action: Action): State => {
  const { type, payload } = action;
  switch (type) {
    case actions.setEmailCode:
      return { ...state, errors: emailCode(state, payload.error), emailCode: payload.otp };
    case actions.setEmailCodeFilled:
      return { ...state, isEmailCodeFilled: payload };
    case actions.setEmailCodeError:
      return { ...state, errors: emailCode(state, payload) };
    case actions.setResendLink:
      return { ...state, isResendLinkLoading: payload };
    case actions.setEmailAddress:
      return { ...state, errors: emailAddress(state, errorFactory({})) };
    case actions.setEmailAddressError:
      return { ...state, errors: emailAddress(state, payload) };
    default:
      return state;
  }
};

const useEnrollmentBehavior = () => {
  const { enrollmentStore, whoAmIStore, payerStore } = useStores();
  const enrollmentApi = IocContainer.get<EnrollmentApiType>(IocTypes.EnrollmentApi);

  //consts
  const { userCredentials } = enrollmentStore || {};
  const { firstname: userCredentialsFirstName = null } = userCredentials || {};
  const [{ errors, emailCode, isResendLinkLoading, isEmailCodeFilled, emailCodeFormat }, dispatch] = useReducer(reducer, initialState);
  const [showEmailOTPSection, setShowEmailOTPSection] = useState(false);

  // Finding the user name
  // For default enrollment (member type) taking firstname from the enrollment post response.
  // For delegate enrollment from landing page (user is not signed in) taking name from the Delegate person data from enrollment API response.
  // For delegate enrollment when the user is signed in (not landing page), taking name from user store.
  const enrollingUserName = !enrollmentStore.enrollmentContext.isDelegate
    ? userCredentialsFirstName
    : enrollmentStore.enrollmentContext.isLandingPage
    ? enrollmentStore.delegateData.name
    : whoAmIStore.basicInfo?.full_name;

  //setting timeout for email verification screen
  useEffect(() => {
    resetEmailVerificationTimeOut();
    return () => {
      //clear previous time out
      enrollmentStore.clearAllRegisteredTimeouts();
      //set back to previous global time out
      resetEmailVerificationTimeOut((window as any)?.env?.REACT_APP_ENROLLMENT_GLOBAL_TIME_OUT_IN_MINUTES);
    };
  }, []);

  const resetEmailVerificationTimeOut = (timeOutInMinutes: string | null = null) => {
    //clear previous time out
    enrollmentStore.clearAllRegisteredTimeouts();
    //set new time out
    const timeoutId = enrollmentStore.registerEnrollmentTimeout(() => {
      console.log('TIMEOUT from Email Verification screen: ', timeoutId);
      enrollmentStore.clearTimeout(timeoutId);
      enrollmentStore.setContactUsVisibility(false);
      enrollmentStore.setStep(EnrollmentSteps.Timeout);
    }, minutesToMilliseconds(timeOutInMinutes ? timeOutInMinutes : (window as any)?.env?.REACT_APP_ENROLLMENT_EMAIL_CODE_TIME_OUT_IN_MINUTES));
    return timeoutId;
  };

  const onSubmitHandler = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    event.preventDefault();
    onSubmitEnterHandler();
  };

  /**
   * Verify entered email verification code
   */
  const onSubmitEnterHandler = () => {
    const { invitationCode = '' } = enrollmentStore || {};
    const federatedId = payerStore.payer?.federatedId || '';
    const isFederated = federatedId !== '';
    const idp = isFederated ? '' : 'CIAM';

    EnrollmentHttpService(
      async () => await enrollmentApi.postOtpEmailPassCode({ code: invitationCode, passCode: emailCode, idp: idp, ciamFederationId: federatedId, token: '' }),
      response => {
        const { userId = '' } = response?.data || '';
        if (response.status === HTTP_STATUS_CODES.CREATED && isFederated) {
          // success 201 - Successful user creation
          // User is federated, no need for CIAM password creation.
          enrollmentStore.setStep(EnrollmentSteps.Enrolled);
        } else if (response.status === HTTP_STATUS_CODES.CREATED && userId && userId.length > 0) {
          // success 201 - Successful user creation, user isnt federated, need to set CIAM password for the new user.
          enrollmentStore.setUserId(userId);
          enrollmentStore.setStep(EnrollmentSteps.CreatePassword);
        } else if (response.status === HTTP_STATUS_CODES.SUCCESS) {
          // success 200 - User was already exist in CIAM but not in member portal (IHDP),
          // No password needed, and user was linked to enrollment accout.
          enrollmentStore.setStep(EnrollmentSteps.Enrolled);
        }
        //must have a user id for creating password - error
        else {
          dispatch({ type: actions.setEmailCodeError, payload: errorApiFactory({ message: getEmailCodeMessage().userId }) });
          return;
        }
      },
      ({ statusCode, meta }: IHTTP_ERROR) => {
        switch (statusCode) {
          case HTTP_STATUS_CODES.NOT_FOUND:
            return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
          case HTTP_STATUS_CODES.BAD_REQUEST:
            const badRequest = getEmailCodeMessage().attempts(enrollmentStore.remainingAttempts);
            const badRequestError = errorApiFactory({ message: badRequest, error: { statusCode } });
            dispatch({ type: actions.setEmailCodeError, payload: badRequestError });
            break;
          case HTTP_STATUS_CODES.ALREADY_IN_USE:
            const alreadyInUse = getEmailCodeMessage().alreadyInUse(enrollmentStore.selectedEmail, meta?.code);
            const alreadyInUseError = errorApiFactory({ message: alreadyInUse, error: { statusCode } });
            showEmailOTPSection && setShowEmailOTPSection(false);
            dispatch({ type: actions.setEmailCodeError, payload: alreadyInUseError });
            break;
          default:
            return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
        }
      },
      true
    );
  };
  /**
   * Send code to selected email address
   */
  const onResendHandler = () => {
    const { invitationCode = '', selectedEmail = '' } = enrollmentStore || {};

    const validate = email.combined(selectedEmail || '');
    if (validate.isError) {
      dispatch({ type: actions.setEmailAddressError, payload: errorFactory({ message: validate.message }) });
      return;
    }

    EnrollmentHttpService(
      async () => await enrollmentApi.postRequestOtpEmailCode({ code: invitationCode, email: selectedEmail || '' }),
      () => {
        // email verification code will be valid within 60 minutes
        resetEmailVerificationTimeOut();
        dispatch({ type: actions.setEmailAddress });
        !showEmailOTPSection && setShowEmailOTPSection(true);
      },
      ({ statusCode }: IHTTP_ERROR) => {
        switch (statusCode) {
          case HTTP_STATUS_CODES.BAD_REQUEST:
            const badRequest = getEmailAdressMessages().attempts(enrollmentStore.remainingAttempts);
            dispatch({ type: actions.setEmailAddressError, payload: errorApiFactory({ message: badRequest, error: { statusCode } }) });
            break;
          default:
            return enrollmentStore.setStep(EnrollmentSteps.GeneralError);
        }
      },
      true
    );
  };

  const onOTPChange = (otp: string): void => {
    const error = (otp.length === 0 && errors.emailCode.error?.statusCode === HTTP_STATUS_CODES.ALREADY_IN_USE && errors.emailCode) || errorFactory({});
    dispatch({ type: actions.setEmailCode, payload: { otp, error: error } });
  };

  const setCodeFullFilled = (isFullFilled: boolean) => {
    dispatch({ type: actions.setEmailCodeFilled, payload: isFullFilled });
  };

  const isButtonDisabled = useMemo(
    () => !emailCode || !!errors.emailAddress.isError || !!errors.emailCode.isApiError || !!errors.emailCode.isError || !isEmailCodeFilled,
    [emailCode, errors, isEmailCodeFilled]
  );

  const setSelectedEmail = (email: string) => {
    dispatch({ type: actions.setEmailAddress });
    enrollmentStore.setSelectedEmail(email);
  };

  const onResendHandlerError = (error: Error) => {
    dispatch({ type: actions.setEmailAddressError, payload: errorFactory({ isError: true, message: error.message }) });
  };

  return {
    userName: enrollingUserName,
    onSubmitHandler,
    onSubmitEnterHandler,
    isButtonDisabled,
    resetEmailVerificationTimeOut,
    onOTPChange,
    emailCodeFormat,
    errors,
    isResendLinkLoading,
    onResendHandler,
    setCodeFullFilled,
    email: enrollmentStore.selectedEmail,
    onSelectedEmail: setSelectedEmail,
    onResendHandlerError,
    showEmailOTPSection
  };
};

const EmailVerificationContainer: FC<EmailVerificationContainerProps> = props => {
  const { enrollmentStore, userStore, whoAmIStore } = useStores();

  let emails: string[] = [];

  if (enrollmentStore.enrollmentContext.isLandingPage || !enrollmentStore.enrollmentContext.isDelegate) {
    emails = enrollmentStore.emails;
  } else if (userStore.user?.email) {
    emails = [userStore.user.email];
  } else if (whoAmIStore.basicInfo?.email) {
    emails = [whoAmIStore.basicInfo.email];
  }

  const {
    userName,
    onSubmitHandler,
    onSubmitEnterHandler,
    isButtonDisabled,
    errors,
    resetEmailVerificationTimeOut,
    onOTPChange,
    setCodeFullFilled,
    isResendLinkLoading,
    onResendHandler,
    onSelectedEmail,
    email,
    onResendHandlerError,
    showEmailOTPSection
  } = useEnrollmentBehavior();

  return (
    <EmailVerification
      store={enrollmentStore}
      userName={userName}
      onSubmitHandler={onSubmitHandler}
      onSubmitEnterHandler={onSubmitEnterHandler}
      isButtonDisabled={isButtonDisabled}
      resetEmailVerificationTimeOut={resetEmailVerificationTimeOut}
      email={email}
      emails={emails}
      errors={errors}
      codeFormat={'######'}
      remainingAttempts={enrollmentStore.remainingAttempts}
      onOTPChange={onOTPChange}
      setCodeFullFilled={setCodeFullFilled}
      onResendHandler={onResendHandler}
      isResendLinkLoading={isResendLinkLoading}
      onSelectedEmail={onSelectedEmail}
      onResendHandlerError={onResendHandlerError}
      showEmailOTPSection={showEmailOTPSection}
      enrollmentContext={enrollmentStore.enrollmentContext}
    />
  );
};

export default observer(EmailVerificationContainer);
