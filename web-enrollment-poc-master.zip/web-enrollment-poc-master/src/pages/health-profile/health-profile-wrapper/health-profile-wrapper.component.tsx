import React, { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//third party
import { Route, Switch, Redirect, useRouteMatch } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../stores/useStores';
import { usePagesMenu } from '../../../customHooks/usePagesMenu';
import PageLayout from '../../../components/page-layout/page-layout.component';
import NavLinksMenu from '../../../components/general/nav-links-menu/nav-links-menu.component';

import NotFoundPage from 'pages/404/not-found-page.component';

import { styles } from '../../../styles/side-menu-wrapper.styles';
import { HealthProfileMedicationsPageContainer } from '../components/health-profile-medications/container/health-profile-medications-page.container';
import { HealthProfileConditionsPageContainer } from '../components/health-profile-conditions/container/health-profile-conditions-page-container';
import { HealthProfileAllergiesPageContainer } from '../components/health-profile-allergies/container/health-profile-allergies-page.container';
import { HealthProfileMedicalImplantsPageContainer } from '../components/health-profile-medical-implants/container/health-profile-medical-implants-page.container';
import { HealthProfileProceduresPageContainer } from '../components/health-profile-procedures/container/health-profile-procedures-page.container';
import { HealthProfileVisitsPageContainer } from '../components/health-profile-visits/container/health-profile-visits-page.container';
import { HealthProfileVaccinationsPageContainer } from '../components/health-profile-vaccinations/container/health-profile-vaccinations-page.container';
import { RouteName } from 'stores/RoutesStore';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import healthProfileAllergiesDetailsPageComponent from '../components/health-profile-allergies/details/components/health-profile-allergies-details-page.component';
import { HealthProfileLabObservationsContainer } from '../components/health-profile-labObservesion/container/health-profile-lab-observations.container';
import { HealthProfileOverviewPageContainer } from '../components/health-profile-overview/container/health-profile-overview-page.container';

interface HealthProfileWrapperProps {}

const HealthProfileWrapper: FC<HealthProfileWrapperProps> = () => {
  const { themeStore, responsiveStore } = useStores();
  const pagesMenu = usePagesMenu();
  //get the path to this route
  let match = useRouteMatch();

  const { buildSwitch, getPath } = useRouteUtils();
  //get the path to this route

  const switchConfig: BuildRouteParams[] = [ 
    { key: 'navigation-health-profile', name: RouteName.healthProfile, exact: true, render: () => <Redirect to={{ pathname: getPath(RouteName.clinicalsOverview) }} /> },
    { key: 'navigation-health-profile-overview', exact: true, name: RouteName.clinicalsOverview, component: HealthProfileOverviewPageContainer },
    { key: 'navigation-health-profile-medications', exact: true, name: RouteName.medications, component: HealthProfileMedicationsPageContainer },
    { key: 'navigation-health-profile-conditions', exact: true, name: RouteName.problemsAndConditions, component: HealthProfileConditionsPageContainer },
    { key: 'navigation-health-profile-allergies', exact: false, name: RouteName.allergiesAndIntolerances, component: HealthProfileAllergiesPageContainer },
    { key: 'navigation-health-profile-observations', exact: false, name: RouteName.labObservations, component: HealthProfileLabObservationsContainer },
    { key: 'navigation-health-medical-implants', exact: true, name: RouteName.medicalImplants, component: HealthProfileMedicalImplantsPageContainer },
    { key: 'navigation-health-profile-medications', exact: true, name: RouteName.medications, component: HealthProfileMedicationsPageContainer },
    { key: 'navigation-health-profile-conditions', exact: true, name: RouteName.problemsAndConditions, component: HealthProfileConditionsPageContainer },
    { key: 'navigation-health-profile-procedures', exact: true, name: RouteName.procedures, component: HealthProfileProceduresPageContainer },
    { key: 'navigation-health-profile-vaccinations', exact: false, name: RouteName.vaccinations, component: HealthProfileVaccinationsPageContainer },
    { key: 'navigation-health-profile-visits', exact: false, name: RouteName.visits, component: HealthProfileVisitsPageContainer }
    //{ key: 'navigation-health-profile-allergies-details', exact: true, name: RouteName.allergiesAndIntolerancesDetails, component: healthProfileAllergiesDetailsPageComponent }
  ];

  //all the links in the menu of Profile And Settings page
  const healthProfileMenu = (
    <Fragment>
      <div css={styles.linkWrapperStyles}>{<NavLinksMenu links={pagesMenu.healthProfileLinks} linkStyle={styles.linkColor(themeStore.currentTheme)} addAsPrimary={true} />}</div>
    </Fragment>
  );

  const healthProfileRoutes = (
    <Fragment>
      {/* All the pages in Health Profile page * */}
      {buildSwitch(switchConfig, true)}
    </Fragment>
  );

  return (
    <PageLayout left={responsiveStore.isTablet ? null : healthProfileMenu} leftStyle={styles.leftMainMenu(themeStore.currentTheme)} center={healthProfileRoutes} centerStyle={styles.pagesContainer} />
  );
};

export default observer(HealthProfileWrapper);
