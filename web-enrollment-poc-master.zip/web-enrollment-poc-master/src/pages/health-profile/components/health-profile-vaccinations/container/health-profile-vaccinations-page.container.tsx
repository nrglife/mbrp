import { FC, useEffect } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import HealthProfileBasePage from '../../health-profile-base.component';

//styles
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useVaccinationsPageContainerBehavior = () => {
  const { immunizationsStore } = useStores();

  useEffect(() => {
    immunizationsStore.fetchData({});
  }, [immunizationsStore]);

  useEffect(() => () => immunizationsStore.resetStore(), [immunizationsStore]);

  return {
    isLoading: immunizationsStore.initialReqStatus === ReqStatus.IDE || immunizationsStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => immunizationsStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: immunizationsStore.nextPageKey !== null,
    loadingNextPage: immunizationsStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: immunizationsStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 2,
    healthProfileData: immunizationsStore.getUIData(),
    getNextPage: () => immunizationsStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface HealthProfileVaccinationsPageContainerProps {}
export const HealthProfileVaccinationsPageContainer: FC<HealthProfileVaccinationsPageContainerProps> = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useVaccinationsPageContainerBehavior();

  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
