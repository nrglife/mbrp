import { FC, useEffect } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import HealthProfileBasePage from '../../health-profile-base.component';

//styles
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useProceduresPageContainerBehavior = () => {
  const { proceduresStore } = useStores();

  useEffect(() => {
    proceduresStore.fetchData({});
  }, [proceduresStore]);

  useEffect(() => () => proceduresStore.resetStore(), [proceduresStore]);

  return {
    isLoading: proceduresStore.initialReqStatus === ReqStatus.IDE || proceduresStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => proceduresStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: proceduresStore.nextPageKey !== null,
    loadingNextPage: proceduresStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: proceduresStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 2,
    healthProfileData: proceduresStore.getUIData(),
    getNextPage: () => proceduresStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface HealthProfileProceduresPageContainerProps {}
export const HealthProfileProceduresPageContainer: FC<HealthProfileProceduresPageContainerProps> = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useProceduresPageContainerBehavior();
  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
