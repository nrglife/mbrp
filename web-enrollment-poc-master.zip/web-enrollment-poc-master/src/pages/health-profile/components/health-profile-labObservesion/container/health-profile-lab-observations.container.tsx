import { FC, Fragment, useEffect, useState } from 'react';
//third party
import { Route, Switch, Redirect } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import HealthProfileBasePage from '../../health-profile-base.component';

//styles
import { globalStyles } from '../../../../../styles/global.styles';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useMedicationRequestPageContainerBehavior = () => {
  const { labObservationStore } = useStores();

  useEffect(() => {
    labObservationStore.fetchData({});
  }, [labObservationStore]);

  useEffect(() => () => labObservationStore.resetStore(), [labObservationStore]);

  return {
    isLoading: labObservationStore.initialReqStatus == ReqStatus.IDE || labObservationStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => labObservationStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: labObservationStore.nextPageKey !== null,
    loadingNextPage: labObservationStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: labObservationStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 2,
    healthProfileData: labObservationStore.getUIData(),
    getNextPage: () => labObservationStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface IHealthProfileMedicationsPageContainer {}
export const HealthProfileLabObservationsContainer: FC<IHealthProfileMedicationsPageContainer> = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useMedicationRequestPageContainerBehavior();
  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
