import React, { FC, Fragment } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';

import InfiniteScroll from 'react-infinite-scroller';
//developed
import { useStores } from 'stores/useStores';

import HealthProfileItemComponent from 'components/clinicals/health-profile-item/health-profile-item.component';
import HealthProfileGroupedItemsHeader from 'components/clinicals/health-profile-grouped-items-header/health-profile-grouped-items-header.component';
import InlineLoader from 'components/clinicals/next-page-inline-loader/next-page-inline-loader.component';

//styles
import * as styles from './styles';
import { Error } from 'components/error';

import HealthProfileTryAgainComponent from 'components/general/try-again/try-again.component';
import { DisplayableHealthProfileData, DisplayableHealthProfileItem, NoDataType } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import { failureSource } from '@healthcareapp/connected-health-common-services';
import Loader from '../../../components/general/loader/loader.component';
import InlineWarning from 'components/general/inline-warning/inline-warning.component';
import { toJS } from 'mobx';
import { ReactComponent as WarningThin } from 'assets/icons/warning-thin.svg';
import { ReactComponent as ClockIcon } from 'assets/icons/clock.svg';
import { ReactComponent as NoContentIcon } from 'assets/icons/no-content-icon.svg';

interface HealthProfileBasePageProps {
  hasMore: boolean | null;
  loadingNextPage: boolean | null;
  apiErrorNextPage: boolean | null;
  healthProfileData: DisplayableHealthProfileData;
  loadMore: () => void;
  getNextPage: (numOfRetries: number) => {};
  isLoading: boolean;
  maxItemsInRow: number;
  onSelect?: (item: DisplayableHealthProfileItem) => void;
}

const HealthProfileBasePage: FC<HealthProfileBasePageProps> = ({
  loadMore = null,
  hasMore = false,
  loadingNextPage,
  apiErrorNextPage,
  getNextPage,
  healthProfileData,
  isLoading,
  onSelect,
  maxItemsInRow
}) => {
  const { responsiveStore, themeStore } = useStores();

  const getNoContentImage = (type: NoDataType) => {
    switch (type) {
      case NoDataType.error:
        return WarningThin;
      case NoDataType.not_completed:
        return ClockIcon;
      case NoDataType.empty:
        return NoContentIcon;
      default:
        return null;
    }
  };

  return (
    <Fragment>
      <Loader color={themeStore.currentTheme.colors.actionMedium.published} position={'centered'} loading={isLoading} backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published} />
      <div css={[styles.healthProfileMainPage, styles.PaddingHorizontal, { overflow: 'auto' }, responsiveStore.isMobile && styles.healthProfileMainPageMobile]} id="scrollableDiv">
        {!responsiveStore.isMobile && <div css={[styles.title]}>{healthProfileData?.pageTitle}</div>}
        {healthProfileData?.noContentToDisplay ? (
          <Error
            errorSource={healthProfileData?.noContentToDisplay?.errorSource}
            errorText={healthProfileData?.noContentToDisplay?.errorText}
            Image={getNoContentImage(healthProfileData?.noContentToDisplay?.type)}
          />
        ) : (
          <InfiniteScroll
            initialLoad={false}
            scrollabletarget="scrollableDiv"
            pageStart={0}
            loadMore={loadMore}
            hasMore={hasMore}
            loader={
              <div key={0} css={[styles.whiteRectanglesContainer, { paddingBottom: '3rem' }]}>
                {loadingNextPage && <InlineLoader />}
                {apiErrorNextPage && !loadingNextPage && (
                  <div key={2} css={styles.PaddingHorizontal}>
                    {getNextPage && <HealthProfileTryAgainComponent onTryAgain={() => getNextPage(1)} />}
                  </div>
                )}
              </div>
            }
            useWindow={false}>
            {
              <Fragment>
                {healthProfileData?.recordsRemovedWarning && (
                  <div style={{ paddingTop: '0.5rem' }}>
                    <div>{healthProfileData?.recordsRemovedWarning && <InlineWarning text={healthProfileData?.recordsRemovedWarning} />}</div>
                  </div>
                )}
                <div css={[styles.itemsGroupByDate]}>
                  <div css={[styles.whiteRectanglesContainer]}>
                    {healthProfileData && healthProfileData?.isGrouped
                      ? healthProfileData?.items.map(groupedItems => {
                          return (
                            <div key={groupedItems.groupedByTitle + new Date()}>
                              <HealthProfileGroupedItemsHeader
                                headerText={groupedItems.groupedByTitle}
                                key={'HealthProfileItem_' + groupedItems && groupedItems.data && groupedItems.data.length > 0 ? groupedItems.data[0].id : ''}
                              />
                              {groupedItems &&
                                groupedItems.data?.map(item => {
                                  return <HealthProfileItemComponent key={'HealthProfileItem_' + item.id} item={item} maxItemsInRow={maxItemsInRow} onSelect={onSelect} />;
                                })}
                            </div>
                          );
                        })
                      : healthProfileData?.items.map(items => {
                          return (
                            <div key={items.groupedByTitle + new Date()}>
                              {items &&
                                items.data?.map(item => {
                                  return <HealthProfileItemComponent key={'HealthProfileItem_' + item.id} item={item} maxItemsInRow={maxItemsInRow} onSelect={onSelect} />;
                                })}
                            </div>
                          );
                        })}
                  </div>
                </div>
              </Fragment>
            }
          </InfiniteScroll>
        )}
      </div>
    </Fragment>
  );
};

export default observer(HealthProfileBasePage);
