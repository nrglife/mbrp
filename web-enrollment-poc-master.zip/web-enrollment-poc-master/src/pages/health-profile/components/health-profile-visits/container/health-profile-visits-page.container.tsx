import React, { Fragment, useEffect } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

//styles
import HealthProfileBasePage from '../../health-profile-base.component';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import { useHistory } from 'react-router-dom';

const useVisitsPageContainerBehavior = () => {
  const { EncountersStore } = useStores();

  useEffect(() => {
    EncountersStore.fetchData({});
  }, [EncountersStore]);

  useEffect(() => () => EncountersStore.resetStore(), [EncountersStore]);

  const history = useHistory();
  const { getPath } = useRouteUtils();

  const onSelectItem = (item: DisplayableHealthProfileItem) => {
    EncountersStore.setSelectedItem(item);
    history.push(`${getPath(RouteName.allergiesAndIntolerancesDetails)}`);
  };

  return {
    isLoading: EncountersStore.initialReqStatus === ReqStatus.IDE || EncountersStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => EncountersStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: EncountersStore.nextPageKey !== null,
    loadingNextPage: EncountersStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: EncountersStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 3,
    healthProfileData: EncountersStore.getUIData(),
    getNextPage: () => EncountersStore.getNextPage({ numberOfRetries: 1 }, true),
    OnSelect: onSelectItem
  };
};

interface IHealthProfileVisitsPageContainer {}

export let HealthProfileVisitsPageContainer: React.FC<IHealthProfileVisitsPageContainer>;
HealthProfileVisitsPageContainer = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage, OnSelect } = useVisitsPageContainerBehavior();

  const { buildSwitch } = useRouteUtils();

  const switchConfig: BuildRouteParams[] = [
    {
      key: 'visits',
      name: RouteName.visits,
      exact: true,
      children: (
        <HealthProfileBasePage
          isLoading={isLoading}
          loadMore={OnloadMore}
          hasMore={hasMore}
          loadingNextPage={loadingNextPage}
          apiErrorNextPage={apiErrorNextPage}
          maxItemsInRow={maxItemsInRow}
          healthProfileData={healthProfileData}
          getNextPage={getNextPage}
          onSelect={OnSelect}
        />
      )
    }
    //TODO: check if there are screen for details in visits
    // ,
    // { key: 'allergies-details', name: RouteName.allergiesAndIntolerancesDetails, children: <HealthProfileAllergiesDetailsPageComponent /> }
  ];

  return <Fragment>{buildSwitch(switchConfig, true)}</Fragment>;
});
