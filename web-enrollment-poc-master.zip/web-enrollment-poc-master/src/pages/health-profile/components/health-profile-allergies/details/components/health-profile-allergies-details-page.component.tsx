import React, { FC } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
import { useStores } from 'stores/useStores';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ReactComponent as AllergyIcon } from '../../../../../../assets/icons/allergy.svg';

import HealthProfileDetailsBasePage from '../../../health-profile-details-base.component';
import { RouteName } from 'stores/RoutesStore';
import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';

interface HealthProfileAllergiesDetailsProps {}

const HealthProfileAllergiesDetailsPage: FC<HealthProfileAllergiesDetailsProps> = ({}) => {
  const { id = '' } = useParams<{ id: string }>();
  const { t } = useTranslation('translation');

  const { AllergiesStore } = useStores();

  const getAllergiesItem = () => {
    let itemForDesplay: DisplayableHealthProfileItem | undefined;

    for (const itemsGroup of AllergiesStore.getUIData().items) {
      for (const it of itemsGroup.data) {
        if (it.id === id) {
          itemForDesplay = it;
        }
      }
    }

    return itemForDesplay;
  };

  return (
    <HealthProfileDetailsBasePage
      item={getAllergiesItem()}
      maxItemsInRow={3}
      IconComponent={AllergyIcon}
      backRoute={RouteName.allergiesAndIntolerances}
      backTitle={'Allergies & intolerances'}></HealthProfileDetailsBasePage>
  );
};

export default observer(HealthProfileAllergiesDetailsPage);
