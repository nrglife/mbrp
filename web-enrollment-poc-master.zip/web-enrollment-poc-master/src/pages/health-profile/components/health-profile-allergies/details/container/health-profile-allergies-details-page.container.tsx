import React, { FC, Fragment, useEffect, useState } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

import HealthProfileAllergiesDetailsPage from '../components/health-profile-allergies-details-page.component';

interface IHealthProfileAllergiesPageContainer {}

export let HealthProfileAllergiesPageContainer: React.FC<IHealthProfileAllergiesPageContainer>;
HealthProfileAllergiesPageContainer = observer(() => {
  return <HealthProfileAllergiesDetailsPage />;
});
