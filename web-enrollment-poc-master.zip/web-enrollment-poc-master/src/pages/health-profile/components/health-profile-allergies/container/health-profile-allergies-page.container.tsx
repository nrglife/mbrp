import React, { Fragment, useEffect } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

//styles
import HealthProfileBasePage from '../../health-profile-base.component';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import HealthProfileAllergiesDetailsPageComponent from '../details/components/health-profile-allergies-details-page.component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import { DisplayableHealthProfileItem, GroupedDisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import { useHistory } from 'react-router-dom';

const useAllergiesPageContainerBehavior = () => {
  const { AllergiesStore } = useStores();

  useEffect(() => {
    AllergiesStore.fetchData({});
  }, [AllergiesStore]);

  useEffect(() => () => AllergiesStore.resetStore(), [AllergiesStore]);

  const history = useHistory();
  const { getPath } = useRouteUtils();

  const onSelectItem = (item: DisplayableHealthProfileItem) => {
    history.push(`${getPath(RouteName.allergiesAndIntolerancesDetails).replace(':id', item.id)}`);
  };

  return {
    //  isError: AllergiesStore.initialReqStatus == ReqStatus.ERROR,
    isLoading: AllergiesStore.initialReqStatus === ReqStatus.IDE || AllergiesStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => AllergiesStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: AllergiesStore.nextPageKey !== null,
    loadingNextPage: AllergiesStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: AllergiesStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 3,
    healthProfileData: AllergiesStore.getUIData(),
    getNextPage: () => AllergiesStore.getNextPage({ numberOfRetries: 1 }, true),
    OnSelect: onSelectItem
  };
};

interface IHealthProfileAllergiesPageContainer {}

export let HealthProfileAllergiesPageContainer: React.FC<IHealthProfileAllergiesPageContainer>;
HealthProfileAllergiesPageContainer = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage, OnSelect } = useAllergiesPageContainerBehavior();

  const { buildSwitch } = useRouteUtils();

  const switchConfig: BuildRouteParams[] = [
    {
      key: 'allergies',
      name: RouteName.allergiesAndIntolerances,
      exact: true,
      children: (
        <HealthProfileBasePage
          isLoading={isLoading}
          loadMore={OnloadMore}
          hasMore={hasMore}
          loadingNextPage={loadingNextPage}
          apiErrorNextPage={apiErrorNextPage}
          maxItemsInRow={maxItemsInRow}
          healthProfileData={healthProfileData}
          getNextPage={getNextPage}
          onSelect={OnSelect}
        />
      )
    },
    { key: 'allergies-details', name: RouteName.allergiesAndIntolerancesDetails, children: <HealthProfileAllergiesDetailsPageComponent /> }
  ];

  return <Fragment>{buildSwitch(switchConfig, true)}</Fragment>;
});
