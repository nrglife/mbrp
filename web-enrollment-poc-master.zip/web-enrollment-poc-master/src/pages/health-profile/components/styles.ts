/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { Preferences } from '../../../stores/ThemeStore';
import { globalStyles } from '../../../styles/global.styles';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const PaddingHorizontal = css({
  paddingRight: '5%',
  paddingLeft: '5%'
});

export const healthProfileMainPage = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  paddingTop: '3%',
  paddingBottom: '3%'
});

export const healthProfileMainPageMobile = css({
  paddingBottom: '12%'
});

export const healthProfileMedicationsPageTabletMode = css({
  maxWidth: '100%',
  padding: '0',
  alignItems: 'center'
});

export const title = css({
  width: '100%',
  maxWidth: '70rem',
  fontSize: '2.4rem',
  lineHeight: '3.4rem',
  color: globalStyles.COLOR.blackTwo,
  fontWeight: 'bold'
});

export const dateLocationContainerTabletMode = css({
  width: '100%',
  maxWidth: '70rem',
  margin: 'auto'
});

export const dateLocationContainerMobiletMode = css({
  paddingTop: '1rem',
  paddingLeft: '1rem',
  maxWidth: '69rem'
});

export const dateTitle = css({
  fontSize: '1.6rem',
  fontWeight: 'bold',
  color: globalStyles.COLOR.darkIndigo,
  marginBottom: '2.3rem'
});

export const completedStatus = css({
  backgroundColor: globalStyles.COLOR.blueGrey
});

export const overviewText = css({
  paddingTop: '1.2rem',
  fontWeight: 400,
  fontSize: '1.4rem',
  lineHeight: '1.8rem',
  color: globalStyles.COLOR.charcoalGreyThree
});

export const itemsGroupByDate = css({
  paddingTop: '0.5rem',
  width: '100%'
});

export const whiteRectanglesContainer = css({
  display: 'flex',
  flexDirection: 'column',
  maxWidth: '62.8rem',
  minWidth: '25rem',
  width: '100%'
});

export const loadMoreErrorDiv = css({
  fontSize: '1.2rem',
  lineHeight: '1.8rem',
  color: globalStyles.COLOR.slateGrey,
  marginTop: '1rem',
  marginLeft: '6%',
  marginBottom: '2rem',
  cursor: 'pointer'
});
