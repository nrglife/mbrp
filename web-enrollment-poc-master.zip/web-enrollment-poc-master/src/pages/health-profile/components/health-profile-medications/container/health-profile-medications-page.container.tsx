import { FC, Fragment, useEffect, useState } from 'react';
//third party
import { Route, Switch, Redirect } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import HealthProfileBasePage from '../../health-profile-base.component';

//styles
import { globalStyles } from '../../../../../styles/global.styles';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useMedicationRequestPageContainerBehavior = () => {
  const { medicationRequestStore, delegateStore } = useStores();

  useEffect(() => {
    medicationRequestStore.fetchData({});
  }, [medicationRequestStore]);

  useEffect(() => () => medicationRequestStore.resetStore(), [medicationRequestStore]);

  return {
    isLoading: medicationRequestStore.initialReqStatus == ReqStatus.IDE || medicationRequestStore.initialReqStatus == ReqStatus.LOADING,
    OnloadMore: () => medicationRequestStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: medicationRequestStore.nextPageKey !== null,
    loadingNextPage: medicationRequestStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: medicationRequestStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 2,
    healthProfileData: medicationRequestStore.getUIData(),
    getNextPage: () => medicationRequestStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface IHealthProfileMedicationsPageContainer {}
export const HealthProfileMedicationsPageContainer: FC<IHealthProfileMedicationsPageContainer> = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useMedicationRequestPageContainerBehavior();
  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
