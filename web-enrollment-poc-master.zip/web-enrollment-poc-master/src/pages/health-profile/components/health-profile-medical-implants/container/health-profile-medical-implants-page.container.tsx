import { FC, useEffect } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import HealthProfileBasePage from '../../health-profile-base.component';

//styles
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useMedicalImplantsPageContainerBehavior = () => {
  const { implantableDeviceStore } = useStores();

  useEffect(() => {
    implantableDeviceStore.fetchData({});
  }, [implantableDeviceStore]);

  useEffect(() => () => implantableDeviceStore.resetStore(), [implantableDeviceStore]);

  return {
    isLoading: implantableDeviceStore.initialReqStatus === ReqStatus.IDE || implantableDeviceStore.initialReqStatus === ReqStatus.LOADING,
    OnloadMore: () => implantableDeviceStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: implantableDeviceStore.nextPageKey !== null,
    loadingNextPage: implantableDeviceStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: implantableDeviceStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 3,
    healthProfileData: implantableDeviceStore.getUIData(),
    getNextPage: () => implantableDeviceStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface HealthProfileMedicalImplantsPageContainerProps {}
export const HealthProfileMedicalImplantsPageContainer: FC<HealthProfileMedicalImplantsPageContainerProps> = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useMedicalImplantsPageContainerBehavior();

  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
