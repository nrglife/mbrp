/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const whiteRectangle = css({
  marginTop: '0rem',
  marginBottom: '0rem',
  backgroundColor: globalStyles.COLOR.white,
  display: 'flex',
  flex: '1',
  width: '100%',
  flexDirection: 'column',
  overflow: 'auto'
});

export const header = css({
  display: 'flex',
  flexDirection: 'row',
  paddingTop: '1rem',
  paddingBottom: '1.6rem',
  paddingLeft: '3.2rem',
  width: '100%'
});

export const iconContainer = css({
  paddingRight: '1.2rem'
});

export const backLink = (theme: Preferences) =>
  css({
    fontSize: '1.2rem',
    fontWeight: 'bold',
    margin: '2.2rem',
    cursor: 'pointer',
    textDecoration: 'none',
    color: theme.colors.actionMedium.published
  });

export const pageTitle = css({
  marginBottom: '1rem',
  fontWeight: 'bold',
  height: '1rem',
  marginTop: '0.7rem'
});

export const titleStatusContainer = css({
  display: 'flex',
  marginBottom: '1rem',
  flexDirection: 'row',
  alignItems: 'center'
});

export const title = css({
  fontSize: '2.4rem',
  fontWeight: 'bold',
  display: 'flex',
  alignItems: 'center',

  color: globalStyles.COLOR.blackTwo,
  lineHeight: '3.4rem'
});

export const pageTitleText = css({
  fontSize: '1rem',

  color: globalStyles.COLOR.slateGrey,
  height: '1rem'
});

export const additionalInfoTitle = css({
  fontSize: '1.6rem',
  fontWeight: 'bold',
  marginTop: '2.4rem',
  marginBottom: '2rem',
  display: 'flex',
  alignItems: 'center',
  marginLeft: '3.2rem',
  color: globalStyles.COLOR.blackTwo,
  height: '2.4rem'
});

export const unavailableTitle = css({
  fontSize: '2.4rem',
  lineHeight: '3.4rem',
  letterSpacing: '0',
  display: 'flex',
  alignItems: 'center',
  color: globalStyles.COLOR.coolGrey,
  fontStyle: 'italic',
  fontWeight: 'normal'
});

export const status = css({
  display: 'flex',
  alignItems: 'center',
  fontSize: '1rem',
  fontWeight: 'bold',
  letterSpacing: '0.05rem',
  color: globalStyles.COLOR.white,
  height: '1.95rem',
  padding: '0rem 0.8rem',
  paddingTop: '0.2rem',
  marginLeft: '12px',
  marginRight: '2rem',
  borderRadius: '2px'
});

export const statusColors = (bkgdColor, useDarkTextColor) =>
  css({
    backgroundColor: bkgdColor,
    color: useDarkTextColor === true ? globalStyles.COLOR.blackTwo : globalStyles.COLOR.white
  });

export const lighterText = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.blueGrey,
  lineHeight: '1.95rem'
});

export const codeAndTitle = css({
  marginTop: '0.3rem'
});

export const unavailableText = (withItalic: boolean) =>
  css({
    fontSize: '1.3rem',
    letterSpacing: '0',
    color: globalStyles.COLOR.coolGrey,
    fontStyle: withItalic ? 'italic' : '',
    fontWeight: 'normal'
  });

export const additionalInfoContainer = css({
  // borderBottomColor: '#DEE4EC',
  //  borderBottomWidth: '0.1rem',
  //  borderBottomStyle: 'solid',
  borderTopColor: '#DEE4EC',
  borderTopWidth: '0.1rem',
  borderTopStyle: 'solid'
  // marginBottom: '2rem'
});

export const extendedInfoContainer = css({
  borderBottomColor: '#DEE4EC',
  borderBottomWidth: '0.1rem',
  borderBottomStyle: 'solid',
  marginLeft: '1.6rem',
  marginRight: '1.6rem'
});

export const extendedInfoContainerNoBorder = css({
  marginLeft: '1.6rem',
  marginRight: '1.6rem'
});

export const itemGroupContainer = css({
  borderBottomColor: '#DEE4EC',
  borderBottomWidth: '0.1rem',
  borderBottomStyle: 'solid',
  paddingBottom: '1.7rem',
  marginBottom: '3.2rem',
  marginLeft: '8.0rem',
  marginRight: '8.0rem',
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap'
});

export const itemGroupContainerNoBorder = css({
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap',
  paddingBottom: '2.9rem',
  marginLeft: '8.0rem',
  marginRight: '8.0rem'
});

export const additionalInfoContainerMobile = css({
  flexDirection: 'column'
});

export const itemContainer = css({
  display: 'flex',
  flexDirection: 'column',
  //marginRight: '10rem',
  marginBottom: '1.5rem',
  paddingRight: '2rem'
});

export const itemLabel = css({
  fontSize: '1.1rem',
  color: globalStyles.COLOR.slateGrey,
  lineHeight: '1.65rem'
});

export const itemCode = css({
  fontSize: '1.1rem',
  color: globalStyles.COLOR.slateGrey,
  lineHeight: '1.65rem'
});

export const itemText = css({
  fontSize: '1.3rem',
  color: globalStyles.COLOR.blackTwo,
  lineHeight: '1.95rem'
});
