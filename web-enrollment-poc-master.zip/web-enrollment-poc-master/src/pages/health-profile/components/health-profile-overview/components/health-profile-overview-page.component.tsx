import React, { FC, Fragment } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

//styles
import * as basestyles from '../../styles';

import { Error } from 'components/error';

import { HealthProfileOverviewData, NoDataType } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';
import Loader from 'components/general/loader/loader.component';

import { toJS } from 'mobx';
import { ReactComponent as WarningThin } from 'assets/icons/warning-thin.svg';
import { ReactComponent as ClockIcon } from 'assets/icons/clock.svg';
import { ReactComponent as NoContentIcon } from 'assets/icons/no-content-icon.svg';
import HealthProfileOverviewItemComponent from 'components/clinicals/health-profile-item/health-profile-overview-item.component';

interface HealthProfileOverviewPageProps {
  overviewData: HealthProfileOverviewData;
  isLoading: boolean;
  maxItemsInRow: number;
}

const HealthProfileOverviewPage: FC<HealthProfileOverviewPageProps> = ({ overviewData, isLoading, maxItemsInRow }) => {
  const { responsiveStore, themeStore } = useStores();

  const getNoContentImage = (type: NoDataType) => {
    switch (type) {
      case NoDataType.error:
        return WarningThin;
      case NoDataType.not_completed:
        return ClockIcon;
      case NoDataType.empty:
        return NoContentIcon;
      default:
        return null;
    }
  };

  return (
    <Fragment>
      <Loader color={themeStore.currentTheme.colors.actionMedium.published} position={'centered'} loading={isLoading} backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published} />
      <div css={[basestyles.healthProfileMainPage, basestyles.PaddingHorizontal, { overflow: 'auto' }, responsiveStore.isMobile && basestyles.healthProfileMainPageMobile]} id="scrollableDiv">
        {!responsiveStore.isMobile && <div css={[basestyles.title]}>{overviewData?.pageTitle}</div>}
        {overviewData?.noContentToDisplay ? (
          <Error
            errorSource={overviewData?.noContentToDisplay?.errorSource}
            errorText={overviewData?.noContentToDisplay?.errorText}
            Image={getNoContentImage(overviewData?.noContentToDisplay?.type)}
          />
        ) : (
          <HealthProfileOverviewItemComponent item={overviewData} maxItemsInRow={maxItemsInRow}></HealthProfileOverviewItemComponent>
        )}
      </div>
    </Fragment>
  );
};

export default observer(HealthProfileOverviewPage);
