import { FC, Fragment, useEffect, useState } from 'react';
//third party
import { Route, Switch, Redirect } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

//styles
import { globalStyles } from '../../../../../styles/global.styles';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';
import HealthProfileOverviewPageComponent from '../components/health-profile-overview-page.component';

const useClinicalsOverviewPageContainerBehavior = () => {
  const { delegateStore, clinicalsOverviewStore } = useStores();

  useEffect(() => {
    clinicalsOverviewStore.getOverviewBaseData();
  }, [clinicalsOverviewStore]);

  useEffect(() => () => clinicalsOverviewStore.resetStore(), [clinicalsOverviewStore]);

  return {
    isLoading: clinicalsOverviewStore.isLoading == true,
    maxItemsInRow: 3,
    overviewData: clinicalsOverviewStore.displayableOverviewData
  };
};

interface IHealthProfileOverviewPageContainer {}
export const HealthProfileOverviewPageContainer: FC<IHealthProfileOverviewPageContainer> = observer(() => {
  const { isLoading, maxItemsInRow, overviewData } = useClinicalsOverviewPageContainerBehavior();
  return <HealthProfileOverviewPageComponent isLoading={isLoading} maxItemsInRow={maxItemsInRow} overviewData={overviewData} />;
});
