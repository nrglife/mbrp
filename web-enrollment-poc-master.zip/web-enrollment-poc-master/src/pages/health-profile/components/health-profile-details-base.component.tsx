import React, { FC, Fragment, useEffect } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';

//developed
import { useStores } from 'stores/useStores';

//styles
import * as styles from './health-profile-details-base.styles';

import { DisplayableHealthProfileItem } from '@healthcareapp/connected-health-common-services/dist/stores/clinicals/types';

import { Link } from 'react-router-dom';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { useTranslation } from 'react-i18next';
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface HealthProfileDetailsBasePageProps {
  item?: DisplayableHealthProfileItem;
  maxItemsInRow: number;
  backTitle: string;
  backRoute: RouteName;
  IconComponent: React.FunctionComponent<React.SVGProps<SVGSVGElement> & { title?: string }>;
}

const HealthProfileDetailsBasePage: FC<HealthProfileDetailsBasePageProps> = ({ item, maxItemsInRow, IconComponent, backTitle, backRoute }) => {
  const { responsiveStore, themeStore } = useStores();
  const { getPath } = useRouteUtils();
  const { t } = useTranslation();

  useEffect(() => {
    responsiveStore.setRemoveScrollbar(true);
    return () => {
      responsiveStore.setRemoveScrollbar(false);
    };
  });

  const value = item ? (
    <div key={item.id} css={[styles.whiteRectangle]}>
      {!responsiveStore.isMobile && (
        <Link to={getPath(backRoute)} css={styles.backLink(themeStore.currentTheme)}>
          &lt; BACK TO {backTitle.toUpperCase()}
        </Link>
      )}
      <div css={[styles.header]}>
        <div css={styles.iconContainer}>
          <IconComponent css={{ color: 'red', height: '8.8rem', width: '8.8rem' }} />
        </div>
        <div>
          <div css={styles.pageTitle}>
            <span css={styles.pageTitleText}>{item.typeName.toUpperCase()}</span>
          </div>
          <div css={styles.titleStatusContainer}>
            {/* description   */}
            {item?.titles[0]?.description ? <span css={styles.title}>{item?.titles[0]?.description}</span> : <span css={styles.unavailableTitle}>{t(LocaleKeys.errors.description_unavailable)}</span>}
            {/* status */}
            {item?.status?.name && item.status?.bkgdColor && (
              <span css={[styles.status, styles.statusColors(item?.status?.bkgdColor, item?.status?.useDarkTextColor)]}>{item?.status?.name?.toString().toUpperCase()}</span>
            )}
          </div>
          {item?.titles[0]?.code ? (
            <span css={styles.lighterText}>{'(' + item?.titles[0]?.code + ') '}</span>
          ) : (
            <span css={styles.unavailableText(false)}>
              (<span css={styles.unavailableText(true)}>{t(LocaleKeys.errors.code_unavailable)}</span>){' '}
            </span>
          )}
        </div>
      </div>

      <div css={styles.additionalInfoContainer}>
        {item.extendedInfo.map((info, index) => {
          return (
            <div key={'extendedInfo_' + index} css={index != item.extendedInfo.length - 1 ? styles.extendedInfoContainer : styles.extendedInfoContainerNoBorder}>
              {info.title ? <span css={styles.additionalInfoTitle}>{info.title}</span> : <div css={{ height: 48 }}></div>}
              {info.items.map((currentItem, index) => {
                return (
                  <div
                    key={'currentItem_' + index}
                    css={[
                      index != info.items.length - 1 ? styles.itemGroupContainer : styles.itemGroupContainerNoBorder,
                      responsiveStore.isMobile ? { marginLeft: '3.2rem', marginRight: '3.2rem' } : null
                    ]}>
                    {currentItem.map((item, index) => {
                      return (
                        (item?.data || item?.code) && (
                          <div key={'field_' + index} css={[styles.itemContainer, responsiveStore.isMobile ? { minWidth: '50%' } : { width: Math.floor(100 / maxItemsInRow) + '%' }]}>
                            <span css={styles.itemLabel}>{item?.label}</span>
                            {!!item?.data ? <span css={styles.itemText}>{item.data}</span> : <span css={styles.unavailableText(true)}>{t(LocaleKeys.errors.description_unavailable)}</span>}
                            {!!item?.code ? <span css={styles.itemCode}>{item?.code}</span> : null}
                          </div>
                        )
                      );
                    })}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  ) : null;

  return value;
};

export default observer(HealthProfileDetailsBasePage);
