import React, { FC, Fragment, useEffect, useState } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';

//styles
import { globalStyles } from '../../../../../styles/global.styles';
import Loader from 'components/general/loader/loader.component';

import { css } from '@emotion/core';
import HealthProfileBasePage from '../../health-profile-base.component';
import { ReqStatus } from '@healthcareapp/connected-health-common-services/dist/stores/BaseListStore';

const useConditionsPageContainerBehavior = () => {
  const { conditionsStore, delegateStore } = useStores();
  const [initializationDone, setInitializationDone] = useState(false);

  useEffect(() => {
    conditionsStore.fetchData({});
  }, [conditionsStore]);

  useEffect(() => () => conditionsStore.resetStore(), [conditionsStore]);

  return {
    isLoading: conditionsStore.initialReqStatus == ReqStatus.IDE || conditionsStore.initialReqStatus == ReqStatus.LOADING,
    OnloadMore: () => conditionsStore.getNextPage({ numberOfRetries: 2 }, false),
    hasMore: conditionsStore.nextPageKey !== null,
    loadingNextPage: conditionsStore.nextPageStatus === ReqStatus.LOADING,
    apiErrorNextPage: conditionsStore.nextPageStatus === ReqStatus.ERROR,
    maxItemsInRow: 2,
    healthProfileData: conditionsStore.getUIData(),
    getNextPage: () => conditionsStore.getNextPage({ numberOfRetries: 1 }, true)
  };
};

interface IHealthProfileConditionsPageContainer {}

export let HealthProfileConditionsPageContainer: React.FC<IHealthProfileConditionsPageContainer>;
HealthProfileConditionsPageContainer = observer(() => {
  const { isLoading, OnloadMore, hasMore, loadingNextPage, apiErrorNextPage, maxItemsInRow, healthProfileData, getNextPage } = useConditionsPageContainerBehavior();

  return (
    <HealthProfileBasePage
      isLoading={isLoading}
      loadMore={OnloadMore}
      hasMore={hasMore}
      loadingNextPage={loadingNextPage}
      apiErrorNextPage={apiErrorNextPage}
      maxItemsInRow={maxItemsInRow}
      healthProfileData={healthProfileData}
      getNextPage={getNextPage}
    />
  );
});
