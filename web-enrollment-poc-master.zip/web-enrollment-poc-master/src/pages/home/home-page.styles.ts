/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';

const homePage = css({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: 'black'
});

export const styles = {
  homePage
};
