import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';

import { styles } from './home-page.styles';

interface HomePageProps {
  isError?: null | boolean;
}

// //THIS INTERFACE SHOULD BE MOVED TO THE LANDING PAGE LOAD
// declare global {
//   interface Window {
//     digitalData: any;
//   }
// }

const HomePage: FC<HomePageProps> = ({ isError = false }) => {
  // var digitalData = (window.digitalData = window.digitalData || []);
  // digitalData.push({
  //   event: 'pageView',
  //   page: {
  //     pagename: 'portal:home',
  //     pagetype: 'portal',
  //     pageUrl: 'http://c02yq5qylvcf:3000/'
  //   }
  // });
  // console.log('window', window.digitalData);
  return (
    <div css={styles.homePage}>
      <h1>HOME PAGE!!</h1>
    </div>
  );
};

export default HomePage;
