import { FC } from 'react';

const HealthCheck: FC = () => {
  return <div>{'{ code: "200", status: "OK" }'}</div>;
};

export default HealthCheck;
