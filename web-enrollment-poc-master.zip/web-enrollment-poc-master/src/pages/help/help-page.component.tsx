import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
//consts
import helpMockImg from '../../assets/images/help_mock.jpg';

interface HelpPageProps {}

const HelpPage: FC<HelpPageProps> = () => {
  return (
    <div css={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'flex-start' }}>
      <div css={{ width: '100%', height: '100%', maxWidth: '750px', backgroundImage: `url(${helpMockImg})`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }} />
    </div>
  );
};

export default HelpPage;
