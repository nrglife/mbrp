import { FC, Fragment, useEffect } from 'react';
//third party
/** @jsxImportSource @emotion/core */
import { jsx, css } from '@emotion/core';
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import PayerContactDetails from '../../../components/contact-details/payer-contact-details';
import AppContactDetails from '../../../components/contact-details/app-contact-details';
import Loader from 'components/general/loader/loader.component';
//styles
import * as styles from './help-contact-us.styles';
import { globalStyles } from '../../../styles/global.styles';

interface HelpContactUsProps {
  isError?: null | boolean;
}

const HelpContactUs: FC<HelpContactUsProps> = ({ isError = false }) => {
  //consts

  const { themeStore, routesStore, appConfigStore, responsiveStore, payerStore } = useStores();

  let technicalAppSupportDisplay = !!(appConfigStore?.phone?.trim() || appConfigStore?.email?.trim())
    && !!appConfigStore?.currentConfig?.appSupportVisible;

  let insuranceSupportDisplay = !!(payerStore?.primaryPhone?.trim() || payerStore?.primaryEmail?.trim() || payerStore?.payer?.address?.trim())
    && !!appConfigStore?.currentConfig?.insuranceSupportVisible;

  let isEmptyContactUs = !technicalAppSupportDisplay && !insuranceSupportDisplay;
  let isWholeContactUs = technicalAppSupportDisplay && insuranceSupportDisplay;

  return (
    <Fragment>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={!!payerStore.loading}
        backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published}
      />
      <div css={[styles.helpOverviewPage, responsiveStore.isTablet && styles.helpOverviewPageTabletView, responsiveStore.isMobile && styles.helpOverviewPageMobileView]}>
        <div css={[styles.contactUsContainer, responsiveStore.isMobile && styles.contactUsContainerMobileView]}>
          <p css={styles.contactUsTitle}>Contact Us</p>
        </div>
        <div css={[styles.whiteRectangle, { display: 'flex', flexDirection: 'column' }, responsiveStore.isTablet && styles.whiteRectangleTabletView]}>
          {!isEmptyContactUs && <>
            {isWholeContactUs && <>
              <h1 css={styles.subTitle}>How can we help you?</h1>
              <div css={styles.contactUsSeparator} />
            </>}
            <div css={[styles.contentWrapper, !isWholeContactUs && { marginLeft: '7rem', marginTop: '3rem' }]}>
              {
                insuranceSupportDisplay &&
                <div css={[responsiveStore.isMobile ? { padding: '0 1rem' } : null]}>
                  {technicalAppSupportDisplay && <h1 css={styles.scondaryTitle}>{'Insurance, Billing & Benefits'}</h1>}
                  <div css={[styles.detailsContainer]}>
                    <PayerContactDetails isReduceView={!technicalAppSupportDisplay} />
                  </div>
                </div>
              }
              {isWholeContactUs && <div css={styles.contactUsSeparator} />}
              {technicalAppSupportDisplay && <div css={[responsiveStore.isMobile ? { padding: '0 1rem' } : null]}>
                {insuranceSupportDisplay && <h1 css={styles.scondaryTitle}>{'Technical & App Issues'}</h1>}
                <div css={[styles.detailsContainer]}>
                  <AppContactDetails isReduceView={!insuranceSupportDisplay} />
                </div>
              </div>}
            </div></>}
          {isEmptyContactUs &&
            <p css={styles.emptyContactUs}>{`Call the number on your ${payerStore?.payerName} card.`}</p>
          }
        </div>
      </div>
    </Fragment>
  );
};

export default observer(HelpContactUs);
