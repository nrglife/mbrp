/** @jsxImportSource @emotion/core */
import { css, jsx } from '@emotion/core';
import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

export const href = (theme: Preferences) =>
  css({
    color: theme.colors.actionMedium.published,
    textDecoration: 'none'
  });

export const helpOverviewPage = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  maxWidth: '81.6rem',
  padding: '3.3rem 5.5%'
});
export const helpOverviewPageTabletView = css({
  alignItems: 'center',
  maxWidth: '100%'
});

export const helpOverviewPageMobileView = css({
  padding: '0rem'
});

export const contactUsTitle = css({
  fontSize: '3rem',
  lineHeight: '3.4rem',
  color: globalStyles.COLOR.charcoalGrey
});

export const contactUsContainer = css({
  width: '100%',
  maxWidth: '74.4rem'
});

export const contactUsContainerMobileView = css({
  display: 'none'
});

export const whiteRectangle = css({
  maxWidth: '74.4rem',
  width: '100%',
  height: '84.1rem',
  backgroundColor: globalStyles.COLOR.white,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  marginTop: '1rem'
});
export const whiteRectangleTabletView = css({
  marginTop: '0rem'
});

export const contactUsSeparator = css({
height: '0.1rem',
  backgroundColor: globalStyles.COLOR.veryLightPinkThree,
  margin: '2rem 0'
});

export const emptyContactUs = css({
  fontSize:'1.6rem',
  lineHeight: '2rem',
  color: globalStyles.COLOR.blackTwo,
  whiteSpace: 'pre-wrap',
  margin: 'auto',
  paddingBottom: '5rem'
});

export const detailsContainer = css({
  paddingTop: '1.2rem',
  float: 'left'
});

export const detailsContainerMobileView = css({
  paddingLeft: '3%'
});

export const scondaryTitle = css({
  fontSize: '2.6rem',
  fontWeight: 600,
  color: globalStyles.COLOR.blackTwo
});

export const contentWrapper = css({
  maxWidth: '52rem',
  margin: '1rem auto',
  display: 'flex',
  flexDirection: 'column'
});

export const subTitle = css({
  fontSize: '2.6rem',
  fontWeight: 600,
  textAlign: 'center',
  margin: '4rem 0 2rem 0'
})