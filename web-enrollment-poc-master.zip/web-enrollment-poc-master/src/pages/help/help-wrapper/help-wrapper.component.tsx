import { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
//third party
import { Redirect } from 'react-router-dom';
import { observer } from 'mobx-react';
//developed
import { useStores } from '../../../stores/useStores';
// import { usePagesMenu } from '../../../customHooks/usePagesMenu';
import PageLayout from '../../../components/page-layout/page-layout.component';
// import NavLinksMenu from '../../../components/general/nav-links-menu/nav-links-menu.component';
import HelpContactUs from 'pages/help/help-contact-us/help-contact-us.component';
//consts
import { styles } from './help-wrapper.styles';
import { RouteName } from 'stores/RoutesStore';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';

interface HelpWrapperProps {}

const HelpWrapper: FC<HelpWrapperProps> = () => {
  const { themeStore } = useStores();
  // const pagesMenu = usePagesMenu();
  const { buildSwitch, getPath } = useRouteUtils();
  //get the path to this route

  const switchConfig: BuildRouteParams[] = [
    { key: 'navigation-help', name: RouteName.help, exact: true, render: () => <Redirect to={{ pathname: getPath(RouteName.helpContactUs) }} /> },
    { key: 'navigation-help-contact-us', name: RouteName.helpContactUs, component: HelpContactUs }
  ];

  //all the links in the menu of Help page
  // const HelpMenu = (
  //   <Fragment>
  //     <div css={{ marginTop: '1.6rem' }}>
  //       <NavLinksMenu links={pagesMenu.helpLinks} linkStyle={styles.linkColor(themeStore.currentTheme)} addAsPrimary={true} />
  //     </div>
  //   </Fragment>
  // );

  const HelpRoutes = (
    <Fragment>
      {/* All the pages in Help page * */}
      {buildSwitch(switchConfig, true)}
    </Fragment>
  );

  return (
    <PageLayout
      //need to be anable again when menu contain more than one route
      // left={responsiveStore.isTablet ? null : HelpMenu}
      leftStyle={styles.leftMainMenu(themeStore.currentTheme)}
      center={HelpRoutes}
      centerStyle={styles.pagesContainer}
    />
  );
};

export default observer(HelpWrapper);
