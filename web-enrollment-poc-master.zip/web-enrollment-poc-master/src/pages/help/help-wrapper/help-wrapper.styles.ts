import { css } from '@emotion/core';

import { globalStyles } from '../../../styles/global.styles';
import { Preferences } from '../../../stores/ThemeStore';

const mainContainer = (theme: Preferences) =>
  css({
    width: '100%',
    flexDirection: 'row',
    display: 'flex',
    justifyContent: 'left',
    alignItems: 'left',
    color: theme.colors.backgroundDark.published
  });

const leftMainMenu = (theme: Preferences) =>
  css({
    width: '20%',
    maxWidth: '19.9rem',
    marginRight: '2.7rem',
    display: 'flex',
    color: theme.colors.backgroundDark.published,
    flexDirection: 'column'
  });

const pagesContainer = css({
  display: 'flex',
  width: '80%',
  borderLeft: `1px solid ${globalStyles.COLOR.lightGrey}`
});

const linkColor = (theme: Preferences) =>
  css({
    color: theme.colors.actionDark.published
  });

export const styles = {
  mainContainer,
  leftMainMenu,
  pagesContainer,
  linkColor
};
