import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';

export const container = css({ display: 'flex', flex: 1, flexDirection: 'column' });
export const backToLinkedServicesLink = (theme: Preferences) =>
  css({
    fontSize: '1.2rem',
    fontWeight: 'bold',
    margin: '2.2rem',
    cursor: 'pointer',
    textDecoration: 'none',
    color: theme.colors.actionMedium.published
  });
export const serviceTitle = css({ fontSize: '2.4rem', lineHeight: '1.42', paddingLeft: '1.1rem' });

export const serviceDataContainer = css({
  display: 'flex',
  maxWidth: '75rem',
  alignItems: 'left',
  flexDirection: 'column',
  background: 'white',
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  margin: '0 7rem',
  padding: '1.6rem 4rem'
});

export const serviceDataContainerMobile = css({
  margin: 0,
  padding: '1.6rem 2rem',
  flex: 1
});

export const serviceDetailsContainer = css({
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap',
  margin: '3rem 0'
});

export const serviceDetailsCol = css({
  margin: '0 2rem',
  width: '50%'
});

export const applicationHeaderContainer = css({
  height: '10.5rem',
  display: 'flex',
  borderBottom: `solid 0.2rem ${globalStyles.COLOR.veryLightPink}`,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'start'
});
