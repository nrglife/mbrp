import { FC, useState, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
import { useParams, Link } from 'react-router-dom';
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
//developed
import { useStores } from 'stores/useStores';
import ServiceDetails from 'components/linked-services/service-details/service-details.component';
import ServiceExtraDetails from 'components/linked-services/service-extra-details/service-extra-details.component';
import ServiceIcon from 'components/linked-services/service-icon/service-icon.component';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
//styles
import * as styles from './connected-app-details-page.styles';
//common
import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface ConnectedAppDetailsPageProps {}

const ConnectedAppDetailsPage: FC<ConnectedAppDetailsPageProps> = () => {
  const { linkedServicesStore, responsiveStore, themeStore, payerStore } = useStores();
  const { getPath } = useRouteUtils();

  const { t } = useTranslation();
  const { serviceId } = useParams<{ serviceId: string }>();
  const [payerName, setPayerName] = useState('');

  const currentService = linkedServicesStore.getService(serviceId);

  useEffect(() => {
    setPayerName(payerStore.payerName);
  }, [payerStore.payerName]);

  return (
    <div css={styles.container}>
      {!responsiveStore.isMobile && (
        <Link to={getPath(RouteName.linkedServicesFindApps)} css={styles.backToLinkedServicesLink(themeStore.currentTheme)}>
          &lt; {t(LocaleKeys.screens.linkedServices.backToLinkedServices)}
        </Link>
      )}

      <div css={[styles.serviceDataContainer, responsiveStore.isMobile && styles.serviceDataContainerMobile]}>
        <div css={styles.applicationHeaderContainer}>
          <ServiceIcon iconLink={currentService?.appIconLink} />
          <div css={styles.serviceTitle}>{currentService?.appName}</div>
        </div>

        <div css={styles.serviceDetailsContainer}>
          <ServiceDetails currentService={currentService} />
          <ServiceExtraDetails currentService={currentService} payerName={payerName} />
        </div>
      </div>
    </div>
  );
};

export default observer(ConnectedAppDetailsPage);
