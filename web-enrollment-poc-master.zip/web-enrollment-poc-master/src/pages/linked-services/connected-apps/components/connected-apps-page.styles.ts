import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';
import { pageLayout } from 'styles/global';

export { pageLayout };

export const container = css({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  padding: '0 6.9rem 3.3rem 6.9rem'
});

export const containerTablet = css({
  padding: '0 2rem 3.3rem 2rem'
});

export const containerMobile = css({
  padding: '0 0rem 3.3rem 0rem'
});

export const linkedServicesTitleContainer = css({
  padding: '0 1rem'
});


export const linkedServicesMainTitleDescription = css({
  maxWidth: '75rem',
});

export const linkedServicesMainTitleDescriptionMobile = css({
  maxWidth: '85%'
});

export const dataContainer = css({});

export const servicesDataContainer = css({
  display: 'flex',
  maxWidth: '75rem',
  alignItems: 'left',
  flexDirection: 'column',
  background: 'white',
  boxShadow: `0 0.2rem 0.4rem 0 ${globalStyles.COLOR.black15}`,
  border: `0.1rem solid ${globalStyles.COLOR.veryLightPink}`,
  padding: '2.4rem 2.3rem 5.9rem 2.3rem',
  marginBottom: '5rem',
  minHeight: 0
});

export const bottomErrorContainer = css({
  display: 'flex',
  flex: 1,
  maxWidth: '75rem',
  alignItems: 'left',
  flexDirection: 'column',
  justifyContent: 'flex-end',
  minHeight: 0
});

export const servicesDataContainerMobile = css({
  maxWidth: '100%',
  padding: '1rem'
});

export const bottomErrorContainerMobile = css({
  maxWidth: '100%'
});

export const separationBorder = css({
  width: '100%',
  borderBottom: `0.2rem solid ${globalStyles.COLOR.veryLightPink}`
});

export const findAppsHeaderContainer = css({
  width: '100%',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between'
});

export const manageYourAppsBtn = (theme: Preferences) =>
  css({
    backgroundColor: theme.colors.actionLight.published,
    textDecoration: 'none',
    padding: '.9rem 1.5rem',
    borderRadius: '.5rem',
    textTransform: 'uppercase',
    fontSize: '1.3rem',
    color: globalStyles.COLOR.charcoalGreyTwo,
    letterSpacing: '.5px',
    fontWeight: 'bold',
    marginRight: '.5rem'
  });

export const headline1 = css({
  fontSize: '1.8rem',
  lineHeight: '1.22',
  color: globalStyles.COLOR.black,
  marginBottom: '1.5rem'
});

export const headline2 = css({
  fontSize: '1.8rem',
  lineHeight: '1.22',
  color: globalStyles.COLOR.black,
  marginBottom: '1.5rem'
});

export const warningDetailsContainerStyle = css({
  display: 'flex',
  flexFlow: 'column wrap',
  width: '100%',
  justifyContent: 'center',
  alignItems: 'center',
  margin: '2rem 0 0rem 0'
});

export const warningIconStyle = css({ color: '#c3c5cd', width: '5.3rem', height: '5.3rem' });

export const warningTextStyle = css({
  width: '25rem',
  marginTop: '1rem',
  textAlign: 'center',
  fontSize: '1.6rem',
  fontWeight: 400,
  fontStyle: 'italic',
  lineHeight: '2rem',
  color: globalStyles.COLOR.charcoalGrey
});

export const securityAndPrivacyText = css({
  margin: '2rem 0 1.2rem 0',
  width: '100%',
  fontSize: '1.4rem',
  color: globalStyles.COLOR.slateGrey
});

export const dontSeeAppText = css({
  margin: '0',
  width: '100%',
  fontSize: '1.4rem',
  color: globalStyles.COLOR.slateGrey
});

export const errorCodeTextStyle = css({
  width: '100%',
  marginTop: '3rem',
  textAlign: 'center',
  alignSelf: 'flex-end',
  marginBottom: '2.3rem',
  fontSize: '1.2rem',
  fontWeight: 400,
  lineHeight: 1.33,
  color: globalStyles.COLOR.battleshipGrey
});

export const submitRequestLink = (theme: Preferences) =>
  css({
    display: 'inline-block',
    color: theme.colors.actionMedium.published,
    cursor: 'pointer',
    textDecoration: 'underline'
  });
