import { FC } from 'react';
/** @jsxImportSource @emotion/core */
//third party
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
//developed
import { useStores } from 'stores/useStores';
import { LinkedServiceStoreType } from 'inversify.config';
import InsurerDetails from 'components/linked-services/insurer/insurer-details.component';
import ServiceList from 'components/linked-services/services-list/service-list.component';
import { Preferences as IPreferences } from 'stores/ThemeStore';
import ErrorCode from 'components/error-code/error-code.component';
//styles
import * as styles from './connected-apps-page.styles';
//assets
import { ReactComponent as WarningTriangle } from 'assets/icons/warning-triangle.svg';
//common
import { failureSource, LocaleKeys } from '@healthcareapp/connected-health-common-services';

interface ConnectedAppsPageProps {
  data: LinkedServiceStoreType[];
  isError?: null | boolean;
  errorCode?: string | number | null;
  theme: IPreferences;
  linkUrl: string;
  payerName: string | undefined;
}

const ConnectedAppsPage: FC<ConnectedAppsPageProps> = ({ data = [], isError = false, errorCode = null, theme, linkUrl, payerName }) => {
  const { t } = useTranslation();
  const error = (
    <div css={styles.warningDetailsContainerStyle}>
      <WarningTriangle css={styles.warningIconStyle} />
      <h1 css={styles.warningTextStyle}>{t(LocaleKeys.errors.apps_not_viewable)}</h1>
    </div>
  );

  const { responsiveStore, appConfigStore } = useStores();

  return (
    <div css={[styles.container, responsiveStore.isTablet && styles.containerTablet, responsiveStore.isMobile && styles.containerMobile, isError ? { paddingBottom: 0 } : {}]}>
      <div css={[responsiveStore.isMobile && styles.linkedServicesTitleContainer]}>
        {!responsiveStore.isMobile && (
          <div css={styles.pageLayout.header.headerTitle}>
            {
              t(LocaleKeys.screens.linkedServices.findApps) // Find Apps
            }
          </div>
        )}
        <div css={[styles.linkedServicesMainTitleDescription, styles.pageLayout.header.headerSubtitle, responsiveStore.isMobile && styles.pageLayout.header.headerSubtitleMobile]}>
          {t(LocaleKeys.screens.linkedServices.linkedServicesDescription)}
        </div>
      </div>
      <div css={styles.dataContainer}>
        <div css={[styles.servicesDataContainer, responsiveStore.isTablet && styles.servicesDataContainerMobile]}>
          <div css={styles.headline1}>{t(LocaleKeys.screens.linkedServices.yourInsurers)}</div>
          <div css={styles.separationBorder} />
          <InsurerDetails />
          <div css={[styles.findAppsHeaderContainer]}>
            <div css={styles.headline2}>{t(LocaleKeys.screens.linkedServices.findApps)}</div>

            {appConfigStore.currentConfig.smileCDRRevokeURL && !isError && data.length > 0 && (
              <div>
                <a href={appConfigStore.currentConfig.smileCDRRevokeURL} css={styles.manageYourAppsBtn(theme)}>
                  {t(LocaleKeys.screens.linkedServices.manageYourAppsBtnText)}
                </a>
              </div>
            )}
          </div>
          <div css={[styles.separationBorder]} />
          {isError ? error : <ServiceList data={data} linkUrl={linkUrl} />}
          {!isError ? (
            <>
              <div css={styles.separationBorder} />
              <div css={styles.securityAndPrivacyText}>{t(LocaleKeys.screens.linkedServices.securityAndPrivacyText)}</div>
              <div css={styles.dontSeeAppText}>
                {t(LocaleKeys.screens.linkedServices.dontSeeAppText)}{' '}
                <a css={styles.submitRequestLink(theme)} href={linkUrl} target="_blank" rel="noopener noreferrer">
                  {t(LocaleKeys.screens.linkedServices.submitARequest)}
                </a>
              </div>
            </>
          ) : null}
        </div>
      </div>
      <ErrorCode errorSource={failureSource.AppRegistry_Get_AllApplicationRequests} componentStyle={styles.errorCodeTextStyle} />
    </div>
  );
};

export default observer(ConnectedAppsPage);
