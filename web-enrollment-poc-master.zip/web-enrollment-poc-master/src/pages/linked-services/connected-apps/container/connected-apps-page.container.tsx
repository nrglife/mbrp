import { FC, Fragment, useEffect } from 'react';
/** @jsxImportSource @emotion/core */
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import FindAppsPage from '../components/connected-apps-page.component';
import ServiceDetailsPage from '../components/connected-app-details/connected-app-details-page.component';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
// import ServiceDetailsPage from '../components/service-details/service-details-page.component';
import Loader from 'components/general/loader/loader.component';

const useFindAppsPageContainerBehavior = () => {
  const { linkedServicesStore, themeStore, appConfigStore, imageStore, payerStore } = useStores();


  useEffect(() => {
    linkedServicesStore.setIsLoading(true);
    if (payerStore?.payer?.guid) {
      imageStore.loadLogoByType(payerStore.payer.guid, 'dark', false);
    }

    (async () => {
      await linkedServicesStore.getAppsList();
    })();
  }, [linkedServicesStore]);

  const payerName = payerStore.payer?.fullName;
  let linkUrl: string = appConfigStore.config.surveyURL;
  if (!!linkUrl) {
    linkUrl = !/^(?:f|ht)tps?\:\/\//.test(linkUrl) ? `https://${linkUrl}` : linkUrl;
  }

  return {
    linkedServices: linkedServicesStore.linkedServices,
    isError: linkedServicesStore.isError,
    errorCode: linkedServicesStore.errorCode,
    theme: themeStore.currentTheme,
    linkUrl,
    payerName
  };
};

interface ConnectedAppsPageContainerProps {}
export const ConnectedAppsPageContainer: FC<ConnectedAppsPageContainerProps> = observer(() => {
  const { linkedServices, isError, errorCode, theme, linkUrl, payerName } = useFindAppsPageContainerBehavior();
  const { linkedServicesStore, themeStore } = useStores();
  const { buildSwitch } = useRouteUtils();

  const switchConfig: BuildRouteParams[] = [
    {
      key: 'navigation-connected-services-overview',
      exact: true,
      name: RouteName.linkedServicesFindApps,
      children: <FindAppsPage data={linkedServices} isError={isError} errorCode={errorCode} theme={theme} linkUrl={linkUrl} payerName={payerName} />
    },
    { key: 'navigation-connected-services-service-details', name: RouteName.linkedServicesDetails, children: <ServiceDetailsPage /> }
  ];

  return (
    <Fragment>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={!!linkedServicesStore.loading}
        backgroundColor={themeStore.currentTheme.colors.backgroundMedium.published}
      />
      {buildSwitch(switchConfig, true)}
    </Fragment>
  );
});

export default ConnectedAppsPageContainer;
