import { FC, Fragment } from 'react';
/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import ConnectedAppsPageContainer from '../connected-apps/container/connected-apps-page.container';
import P2pMainPage from '../p2p/p2p-main/container/p2p-main-page.container';
import P2pPayerPage from '../p2p/p2p-payer/p2p-payer-page.component';
import { BuildRouteParams, useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { usePagesMenu } from '../../../customHooks/usePagesMenu';
import NavLinksMenu from '../../../components/general/nav-links-menu/nav-links-menu.component';
import PageLayout from '../../../components/page-layout/page-layout.component';
//styles
import { styles } from '../../../styles/side-menu-wrapper.styles';

interface LinkedServicesWrapperProps {}
export const LinkedServicesWrapper: FC<LinkedServicesWrapperProps> = observer(() => {
  const { themeStore, responsiveStore } = useStores();
  const pagesMenu = usePagesMenu();

  const { buildSwitch } = useRouteUtils();
  //get the path to this route

  const switchConfig: BuildRouteParams[] = [
    { key: 'navigation-connected-apps', name: RouteName.linkedServicesFindApps, component: ConnectedAppsPageContainer },
    { key: 'navigation-p2p-main', exact: true, name: RouteName.linkedServicesRequests, component: P2pMainPage },
    { key: 'navigation-p2p-payer', name: RouteName.linkedServicesRequestsDetails, component: P2pPayerPage }
  ];

  const linkedServicesMenu = (
    <Fragment>
      <div css={styles.linkWrapperStyles}>{<NavLinksMenu links={pagesMenu.linkedServicesLinks} linkStyle={styles.linkColor(themeStore.currentTheme)} addAsPrimary={true} />}</div>
    </Fragment>
  );

  const linkedServicesRoutes = <Fragment>{buildSwitch(switchConfig, true)}</Fragment>;

  return (
    <Fragment>
      <PageLayout
        left={responsiveStore.isTablet ? null : linkedServicesMenu}
        leftStyle={styles.leftMainMenu(themeStore.currentTheme)}
        center={linkedServicesRoutes}
        // centerStyle={[styles.pagesContainer, css({backgroundColor: 'white', paddingRight: '10rem'})]}
        centerStyle={[styles.pagesContainer, css({ backgroundColor: 'white' })]}
      />
    </Fragment>
  );
});

export default LinkedServicesWrapper;
