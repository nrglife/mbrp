import React, { FC, useEffect, useState } from 'react';
//third party
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import { StoreRequestStatus } from 'stores';
import P2pMainPage from '../components/p2p-main-page.component';
import Loader from 'components/general/loader/loader.component';
// import { useTranslation } from 'react-i18next';
//styles
import { globalStyles } from 'styles/global.styles';
//common
// import { LocaleKeys } from '@healthcareapp/connected-health-common-services';

export enum p2pViewMode {
  topInsurers = 'topInsurers',
  alphabetical = 'alphabetical'
}

interface P2pMainPageContainerProps {}

const P2pMainPageContainer: FC<P2pMainPageContainerProps> = () => {
  const [selectedViewMode, setSeclectedViewMode] = useState<p2pViewMode>(p2pViewMode.topInsurers);
  const [searchText, setSearchText] = useState('');
  const { payerToPayerStore, themeStore } = useStores();

  useEffect(() => {
    payerToPayerStore.getAllPayers();
  }, [payerToPayerStore]);

  const getActuallDisplayedViewMode = () => {
    return searchText && searchText.length > 0 ? p2pViewMode.alphabetical : selectedViewMode;
  };

  return (
    <>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={payerToPayerStore.payersRequestStatus === StoreRequestStatus.Idle || payerToPayerStore.payersRequestStatus === StoreRequestStatus.Loading}
        backgroundColor={globalStyles.COLOR.white}
      />
      {(payerToPayerStore.payersRequestStatus === StoreRequestStatus.Loaded || payerToPayerStore.payersRequestStatus === StoreRequestStatus.Error) && (
        <P2pMainPage
          displayedPayersList={getActuallDisplayedViewMode() === p2pViewMode.topInsurers ? payerToPayerStore.topInsuranceList : payerToPayerStore.getFilteredListByValue(searchText)}
          searchText={searchText}
          searchTextChange={setSearchText}
          selectedViewMode={selectedViewMode}
          actuallDisplayedViewMode={getActuallDisplayedViewMode()}
          viewModeChanged={setSeclectedViewMode}
          isNoPayerList={payerToPayerStore.payersRequestStatus === StoreRequestStatus.Error || !payerToPayerStore.payerItems || payerToPayerStore.payerItems.length === 0}
        />
      )}
    </>
  );
};

export default observer(P2pMainPageContainer);
