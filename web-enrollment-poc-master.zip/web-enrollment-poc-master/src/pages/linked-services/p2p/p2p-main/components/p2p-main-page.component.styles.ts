/** @jsxImportSource @emotion/core */
import { css } from '@emotion/core';
import { globalStyles } from 'styles/global.styles';
import { Preferences } from 'stores/ThemeStore';
import { pageLayout } from 'styles/global';

export { pageLayout };

export const pageTopActionSection = css({
  marginBottom: '3.3rem',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-end'
});

export const pageTopActionSectionMobile = css({
  flexWrap: 'wrap',
  paddingLeft: '0',
  justifyContent: 'center'
});

export const searchInputWrap = css({
  position: 'relative',
  width: '100%'
});

export const searchIcon = css({
  position: 'absolute',
  left: '14px',
  top: '14px',
  cursor: 'pointer',
  background: 'none',
  border: 'none',
  outline: 'none'
});

export const searchInput = (theme: Preferences) =>
  css({
    height: '4.4rem',
    backgroundColor: globalStyles.COLOR.white,
    border: '1px solid #8891AA',
    borderRadius: '8px',
    maxWidth: '432px',
    minWidth: '280px',
    width: '70%',
    paddingLeft: '4rem',
    paddingRight: '1.4rem',
    boxShadow: '0px 2px 6px rgb(140 148 168 / 16%)',
    ':focus': {
      border: '1px solid',
      borderColor: theme.colors.actionMedium.published
    }
  });

export const searchInputMobile = css({
  width: '100%',
  maxWidth: '100%',
  marginBottom: '1.5rem'
});

export const selectWrap = css({
  minWidth: '226px'
});

export const dropdownStyles = {
  containerHeight: '44px'
};

export const selectWrapMobile = css({
  width: '100%'
});

export const emptyListContainer = css({
  textAlign: 'center',
  margin: '10rem 0',
  fontStyle: 'italic',
  fontSize: '1.8rem',
  color: globalStyles.COLOR.charcoalGreyThree,
  flex: 1
});
