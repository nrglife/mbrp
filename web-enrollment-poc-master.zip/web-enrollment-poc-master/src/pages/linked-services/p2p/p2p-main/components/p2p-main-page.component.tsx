import { FC } from 'react';
/** @jsxImportSource @emotion/core */
import { observer } from 'mobx-react';
//developed
import { useStores } from 'stores/useStores';
import { useTranslation } from 'react-i18next';
import { PayerItem } from 'stores';
import { p2pViewMode } from '../container/p2p-main-page.container';
import ServicesCardsList from '../../../../../components/linked-services/services-cards-list/services-cards-list.component';
import ServicesAlphabeticalList from '../../../../../components/linked-services/service-alphabetical-list/service-alphabetical-list.component';
import SelectDropdown from '../../../../../components/select-dropdown/select-dropdown.component';
import { Error } from 'components/error';
//styles

import * as styles from './p2p-main-page.component.styles';
//assets
import { ReactComponent as SearchIcon } from 'assets/icons/search-icon.svg';
//common
import { LocaleKeys, failureSource } from '@healthcareapp/connected-health-common-services';
interface P2pMainPageProps {
  displayedPayersList: PayerItem[];
  searchText: string;
  searchTextChange: (newText: string) => void;
  selectedViewMode: p2pViewMode;
  actuallDisplayedViewMode: p2pViewMode;
  viewModeChanged: (newMode: p2pViewMode) => void;
  isNoPayerList: boolean;
}

const P2pMainPage: FC<P2pMainPageProps> = ({ displayedPayersList, searchText, searchTextChange, selectedViewMode, actuallDisplayedViewMode, viewModeChanged, isNoPayerList }) => {
  const { themeStore, responsiveStore } = useStores();
  const { t } = useTranslation();

  const handleChangeMode = newMode => {
    viewModeChanged(newMode);
  };

  const handleSearchTextChange = event => {
    const newText = event?.target?.value || '';
    if (searchTextChange) {
      searchTextChange(newText);
    }
  };

  return (
    <div css={styles.pageLayout.pageContainer}>
      <div css={[styles.pageLayout.contentContainerResponsive(responsiveStore.isTablet, responsiveStore.isMobile)]}>
        {!responsiveStore.isMobile && (
          <div css={styles.pageLayout.header.headerTitle}>
            <span>{t(LocaleKeys.screens.P2p.requestSendHealthRecords)}</span>
          </div>
        )}
        <div css={[styles.pageLayout.header.headerSubtitle, responsiveStore.isMobile && styles.pageLayout.header.headerSubtitleMobile]}>
          <p>{t(LocaleKeys.screens.P2p.mainListHeader)}</p>
        </div>
        {isNoPayerList === false && (
          <div css={[styles.pageTopActionSection, responsiveStore.isMobile && styles.pageTopActionSectionMobile]}>
            <div css={styles.searchInputWrap}>
              <input
                value={searchText}
                onChange={handleSearchTextChange}
                css={[styles.searchInput(themeStore.currentTheme), responsiveStore.isMobile && styles.searchInputMobile]}
                type="search"
                placeholder={t(LocaleKeys.screens.P2p.searchPlaceHolder)}
              />
              <button type="button" css={styles.searchIcon}>
                <SearchIcon />
              </button>
            </div>
            <div css={[styles.selectWrap, responsiveStore.isMobile && styles.selectWrapMobile]}>
              <SelectDropdown
                selectOptions={[
                  {
                    label: t(LocaleKeys.screens.P2p.topInsurers),
                    value: p2pViewMode.topInsurers
                  },
                  {
                    label: t(LocaleKeys.screens.P2p.alphabetical),
                    value: p2pViewMode.alphabetical
                  }
                ]}
                onSelect={handleChangeMode}
                propStyles={styles.dropdownStyles}
                optionPlaceholderPrefix={t(LocaleKeys.screens.P2p.viewBy) + ': '}
              />
            </div>
          </div>
        )}
      </div>
      <div css={styles.pageLayout.devider}></div>
      {isNoPayerList ? (
        <Error errorSource={failureSource.PTP_GET_PAYERS} errorText={t(LocaleKeys.errors.no_insurers_to_show)} />
      ) : (
        <div css={styles.pageLayout.contentContainerResponsive(responsiveStore.isTablet, responsiveStore.isMobile)}>
          {displayedPayersList && displayedPayersList.length > 0 ? (
            <>
              {actuallDisplayedViewMode === p2pViewMode.topInsurers && <ServicesCardsList data={displayedPayersList} />}
              {actuallDisplayedViewMode === p2pViewMode.alphabetical && <ServicesAlphabeticalList data={displayedPayersList} />}
            </>
          ) : searchText && searchText.length > 0 ? (
            <div css={styles.emptyListContainer}>No results</div>
          ) : (
            <div css={styles.emptyListContainer}>{t(LocaleKeys.errors.no_insurers_to_show)}</div>
          )}
        </div>
      )}
    </div>
  );
};

export default observer(P2pMainPage);
