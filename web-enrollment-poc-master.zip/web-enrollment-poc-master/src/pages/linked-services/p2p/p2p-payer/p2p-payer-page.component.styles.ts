import { css } from '@emotion/core';
import { Preferences } from 'stores/ThemeStore';
import { globalStyles } from 'styles/global.styles';
import { pageLayout, fontStyle, general } from 'styles/global';

export { pageLayout, general };

export const backToRequestsLink = (theme: Preferences) =>
  css({
    fontSize: '1.2rem',
    fontWeight: 'bold',
    margin: '2.2rem 2.2rem 2.2rem min(2.2rem,2%)',
    cursor: 'pointer',
    textDecoration: 'none',
    color: theme.colors.actionMedium.published
  });

export const backToRequestsLinkTablet = css({
  margin: '2.2rem 2.2rem 2.2rem min(1.4rem,1.4%)'
});



export const headerContainer = css({
  minHeight: '10.5rem',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  flexWrap: 'wrap'
});

export const headerContainerMobile = css({
  marginTop: '2rem'
});

export const headerPayerContainer = css({ backgroundColor: 'white', display: 'flex', position: 'relative', minWidth: '20rem', paddingRight: '4rem', paddingBottom: '2rem' });
export const headerPayerData = css({ display: 'flex', flexDirection: 'column' });
export const headerPayerTitle = css({ fontSize: '2.4rem', fontWeight: 'bold', lineHeight: '1.42', color: globalStyles.COLOR.blackTwo, paddingLeft: '1.1rem', display: 'inline-block' });
export const headerPayerSecondTitle = css({ fontSize: '1.3rem', color: globalStyles.COLOR.blackTwo, lineHeight: '1.42', paddingLeft: '1.1rem', display: 'inline-block' });

export const headerConnectContainer = css({ paddingTop: '1rem', paddingBottom: '3rem' });
export const headerConnectContainerMobile = css({ width: '100%' });
export const headerConnectTitle = css({ fontSize: '1.3rem', color: globalStyles.COLOR.blackTwo, textAlign: 'center', paddingBottom: '1rem' });

export const buttonsContainer = css({ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap' });

export const connectButton = (theme: Preferences) =>
  css({
    backgroundColor: theme.colors.actionLight.published,
    cursor: 'pointer',
    textDecoration: 'none',
    padding: '.9rem 1.5rem',
    borderRadius: '.5rem',
    textTransform: 'uppercase',
    fontSize: '1.3rem',
    color: globalStyles.COLOR.charcoalGreyTwo,
    letterSpacing: '.5px',
    fontWeight: 'bold',
    marginRight: '.5rem',
    display: 'inline-block'
  });

export const connectButtonMobile = css({
  width: '49%',
  textAlign: 'center',
  marginBottom: '1rem',
  marginRight: 0,
  '@media (max-width: 500px)': {
    width: '100%'
  }
});

export const connectButtonDisabled = css({
  backgroundColor: globalStyles.COLOR.veryLightPink,
  border: `1px solid ${globalStyles.COLOR.veryLightPinkFour}`,
  color: globalStyles.COLOR.steelGrey,
  cursor: 'default'
});

export const pageBodyContainer = css({
  paddingTop: '1.6rem',
  paddingBottom: '1.6rem'
});

export const pageBodyContainerMobile = css({
  paddingBottom: '6rem'
});

export const detailsContainer = css({
  flexDirection: 'row',
  flexWrap: 'wrap',
  margin: '1rem 0 1rem 0'
});

export const detailsDescription = [
  fontStyle.Medium,
  css({
    color: globalStyles.COLOR.blackTwo
  })
];

export const descriptionLineExtraSpace = css({
  marginBottom: '2rem'
});

export const approveDialogSection = css({
  width: '100%',
  fontSize: '1.7rem'
});

export const approveDialogSectionTitle = css({
  width: '100%',
  // fontSize: '1.6rem',
  fontWeight: 'bold',
  marginTop: '4rem'
});

export const approveDialogSectionSmall = css({
  width: '100%',
  fontSize: '1.6rem',
  marginTop: '1rem'
});

export const warningSmall = css({
  color: '#C7624A',
  fontWeight: 'bold'
});
