import { FC, useEffect, useState } from 'react';
/** @jsxImportSource @emotion/core */
import { Link, useHistory, useParams } from 'react-router-dom';
import { observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
//developed
import { useStores } from 'stores/useStores';
import ServiceIcon from 'components/linked-services/service-icon/service-icon.component';
import Loader from 'components/general/loader/loader.component';
import { useRouteUtils } from 'customHooks/useRouteUtils';
import { RouteName } from 'stores/RoutesStore';
import { PayerItem, StoreRequestStatus } from 'stores';
import { useNotificationModal } from 'components/notification-modal/use-notification-modal';
import { Error } from 'components/error';
//styles
import { globalStyles, applyOpacity } from 'styles/global.styles';
import * as styles from './p2p-payer-page.component.styles';
// Components
import P2pHistoryTable, { RecordsStatus } from 'components/linked-services/p2p/p2p-history-table/p2p-history-table.component';
//common
import { LocaleKeys, failureSource } from '@healthcareapp/connected-health-common-services';
import { PlatformType } from '@healthcareapp/connected-health-common-services/dist/services/apis/payer-to-payer/payer-to-payer-api';

interface P2pPayerPageProps {}

export const tableColumns = ['Transaction Type', 'Member', 'Data Types', 'Date Range', 'Request Date', 'Status'];

const P2pPayerPage: FC<P2pPayerPageProps> = () => {
  const { storageStore, payerToPayerStore, payerStore, responsiveStore, themeStore } = useStores();
  const { t } = useTranslation();
  const history = useHistory();
  const { getPath } = useRouteUtils();
  const [payerItem, setPayerItem] = useState<PayerItem | null | undefined>(undefined);
  const [p2pCode, setP2pCode] = useState<string | null>(null);
  const [isTransparentLoading, setIsTransparentLoading] = useState<boolean>(false);
  const { payerId } = useParams<{ payerId: string }>();

  const { NotificationModal: ResultNotificationModal, setNotificationModalVisibility: setResultNotificationModalVisibility } = useNotificationModal({
    isUseState: true,
    buttonText: 'OK',
    useThemeForHeader: false,
    useThemeForBackgroundColor: false,
    showErrorCode: false
  });

  const onRequestRecordsApproved = async () => {
    setIsTransparentLoading(true);
    let isAuthRequestSuccess = false;
    try {
      const payerAuthUrl = await payerToPayerStore.getPayerAuthUrl(payerId, PlatformType.WEB);
      if (payerAuthUrl && payerAuthUrl.length > 0) {
        storageStore.setItem('p2pTargetLocation', window.location.href);
        isAuthRequestSuccess = true;
        window.location.href = payerAuthUrl;
        // window.stop();
      }
    } catch (e) {
      isAuthRequestSuccess = false;
    } finally {
      if (!isAuthRequestSuccess) {
        setIsTransparentLoading(false);
        setResultNotificationModalVisibility(
          true,
          t(LocaleKeys.screens.P2p.requestFailedTitle), // Something went wrong
          t(LocaleKeys.screens.P2p.requestFailedDescription) // "Your request did not go through. Please try again."
        );
      } else {
        setTimeout(() => {
          setIsTransparentLoading(false);
          window.stop();
          setResultNotificationModalVisibility(
            true,
            t(LocaleKeys.screens.P2p.requestFailedTitle), // Something went wrong
            t(LocaleKeys.screens.P2p.requestFailedDescription) // "Your request did not go through. Please try again."
          );
        }, 20000);
      }
    }
  };

  const { NotificationModal: ApproveNotificationModal, setNotificationModalVisibility: setApproveNotificationModalVisibility } = useNotificationModal({
    isUseState: true,
    buttonText: 'Continue',
    secondButtonText: 'Cancel',
    useThemeForHeader: true,
    useThemeForBackgroundColor: false,
    onButtonClickHandler: onRequestRecordsApproved,
    showErrorCode: false
  });

  const onRequestRecordsClicked = async () => {
    setApproveNotificationModalVisibility(true, `You are being redirected to ${payerItem?.name}`);
  };

  const postRequestHistoricalDataFromPayer = async (payerId: string, p2pCode: string) => {
    setIsTransparentLoading(true);
    payerToPayerStore
      .postRequestHistoricalDataFromPayer(payerId, p2pCode, PlatformType.WEB)
      .then(() => {
        setResultNotificationModalVisibility(
          true,
          t(LocaleKeys.screens.P2p.requestSent), // 'Request sent'
          t(LocaleKeys.screens.P2p.requestDescription, { name: payerItem?.name }) // "Your request for medical records has been sent to {{name}}. You can check the status of your request anytime in Linked Services.\n\nThe transfer will take up to five days. When it is complete you will see the data available in your Health Profile."
        );
      })
      .catch(error => {
        setResultNotificationModalVisibility(
          true,
          t(LocaleKeys.screens.P2p.requestFailedTitle), // Something went wrong
          t(LocaleKeys.screens.P2p.requestFailedDescription) // "Your request did not go through. Please try again."
        );
      })
      .finally(() => {
        setIsTransparentLoading(false);
      });
  };

  useEffect(() => {
    if (payerToPayerStore.payersRequestStatus === StoreRequestStatus.Idle) {
      payerToPayerStore.getAllPayers();
    } else if (payerId && payerId.length > 0 && payerToPayerStore.payersRequestStatus === StoreRequestStatus.Loaded) {
      const currentPayerItem: PayerItem | null = payerToPayerStore.getPayerById(payerId);
      setPayerItem(currentPayerItem);
    }
  }, [payerToPayerStore.payersRequestStatus, payerId]);

  useEffect(() => {
    if (p2pCode && p2pCode.length > 0 && payerItem?.payerId) {
      postRequestHistoricalDataFromPayer(payerItem?.payerId, p2pCode);
    }
  }, [p2pCode, payerItem]);

  useEffect(() => {
    let timeout: NodeJS.Timeout | null = null;
    // Dont get or refresh historical table when notification modal is shown (causing a blink).
    if (payerId) {
      payerToPayerStore.getRecords(payerId);
      timeout = setInterval(() => {
        payerToPayerStore.getRecords(payerId, true);
      }, 10000);
    }
    return () => {
      timeout && clearInterval(timeout);
    };
  }, [payerId]);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const p2pcodeParam = urlParams.get('p2pcode');

    if (p2pcodeParam && p2pcodeParam.length > 0) {
      setP2pCode(p2pcodeParam);
      history.replace(history.location.pathname);
    }
  }, [history]);

  return (
    <div css={styles.pageLayout.pageContainer}>
      {!responsiveStore.isMobile && (
        <Link to={getPath(RouteName.linkedServicesRequests)} css={[styles.backToRequestsLink(themeStore.currentTheme), responsiveStore.isTablet && styles.backToRequestsLinkTablet]}>
          &lt;{' '}
          {
            t(LocaleKeys.screens.P2p.backToP2pMain) // BACK TO REQUEST & SEND HEALTH RECORDS
          }
        </Link>
      )}

      {(payerToPayerStore.payersRequestStatus === StoreRequestStatus.Error || payerItem === null) && (
        <Error errorSource={failureSource.PTP_GET_PAYERS} errorText={t(LocaleKeys.errors.no_insurers_to_show)} />
      )}

      {payerItem && (
        <>
          <div css={styles.pageLayout.contentContainerResponsive(responsiveStore.isTablet, responsiveStore.isMobile)}>
            <div css={[styles.headerContainer, responsiveStore.isMobile && styles.headerContainerMobile]}>
              <div css={styles.headerPayerContainer}>
                <ServiceIcon iconLink={payerItem.icon} />
                <div css={styles.headerPayerData}>
                  <div css={styles.headerPayerTitle}>{payerItem?.name}</div>
                  <div css={styles.headerPayerSecondTitle}>{payerItem?.types}</div>
                </div>
              </div>
              <div css={[styles.headerConnectContainer, responsiveStore.isMobile && styles.headerConnectContainerMobile]}>
                <div css={styles.headerConnectTitle}>
                  {
                    t(LocaleKeys.screens.P2p.connectWith, { payerName: payerItem?.name }) // Connect with {{payerName}}
                  }
                </div>
                <div css={styles.buttonsContainer}>
                  <div css={[styles.connectButton(themeStore.currentTheme), responsiveStore.isMobile && styles.connectButtonMobile]} onClick={onRequestRecordsClicked}>
                    {
                      t(LocaleKeys.screens.P2p.requestRecordsButton) // Request Records
                    }
                  </div>
                  <div css={[styles.connectButton(themeStore.currentTheme), responsiveStore.isMobile && styles.connectButtonMobile, styles.connectButtonDisabled]}>
                    {
                      t(LocaleKeys.screens.P2p.sendRecordsButton) // Send Records
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div css={styles.pageLayout.devider}></div>
          <div
            css={[
              styles.pageLayout.contentContainerResponsive(responsiveStore.isTablet, responsiveStore.isMobile),
              styles.pageBodyContainer,
              responsiveStore.isMobile && styles.pageBodyContainerMobile
            ]}>
            <div css={styles.detailsContainer}>
              <div css={[styles.pageLayout.section.sectionTitle]}>
                {
                  t(LocaleKeys.screens.P2p.mainHeader) // What happens when you request or send records?
                }
              </div>
              <div css={[styles.detailsDescription, styles.descriptionLineExtraSpace]}>
                <p css={styles.pageLayout.section.sectionParagraph}>
                  {
                    t(LocaleKeys.screens.P2p.reqInstructions1, { name: payerStore.payerName, payerName: payerItem?.name }) //If you’re requesting data, Aetna will transfer a copy of the specified medical records to Alden.
                  }
                </p>
                <p css={styles.pageLayout.section.sectionParagraph}>
                  {
                    t(LocaleKeys.screens.P2p.reqInstructions2, { name: payerStore.payerName, payerName: payerItem?.name }) //If you’re sending data, Alden will transfer a copy of the specified medical records to Aetna.
                  }
                </p>
                <p css={styles.pageLayout.section.sectionParagraph}>
                  {
                    t(LocaleKeys.screens.P2p.reqInstructions3) // Both parties comply with HIPAA and all applicable security standards. All data transfers are encrypted for your security.
                  }
                </p>
                <p css={styles.pageLayout.section.sectionParagraph}>
                  <a href={(window as any)?.env?.REACT_APP_PRIVACY_POLICY_LINK} css={styles.general.href(themeStore.currentTheme)} target="_blank" rel="noopener noreferrer">
                    {
                      t(LocaleKeys.screens.P2p.learnHowWeKeepYourDataSafe) // Learn how we keep your data safe.
                    }
                  </a>
                  <br />
                  <a href={(window as any)?.env?.REACT_APP_PRIVACY_POLICY_LINK} css={styles.general.href(themeStore.currentTheme)} target="_blank" rel="noopener noreferrer">
                    {
                      t(LocaleKeys.screens.P2p.readOuPrivacyPolicy) // Read our privacy policy.
                    }
                  </a>
                </p>
              </div>
            </div>
            <div css={[styles.pageLayout.section.sectionTitle]}>
              {
                t(LocaleKeys.screens.P2p.recordsTransferHistory) // Records Transfer History
              }
            </div>

            <P2pHistoryTable
              tableColumns={tableColumns}
              payerRecords={payerToPayerStore.payerRecords}
              status={
                payerToPayerStore.getRequestPayerRecordsStatus === StoreRequestStatus.Idle || payerToPayerStore.getRequestPayerRecordsStatus === StoreRequestStatus.Loading
                  ? RecordsStatus.Loading
                  : payerToPayerStore.getRequestPayerRecordsStatus === StoreRequestStatus.Error
                  ? RecordsStatus.Error
                  : payerToPayerStore.getRequestPayerRecordsStatus === StoreRequestStatus.Loaded && payerToPayerStore.payerRecords?.length === 0
                  ? RecordsStatus.Empty
                  : RecordsStatus.Loaded
              }
            />
          </div>
        </>
      )}

      <ResultNotificationModal />
      <ApproveNotificationModal>
        <div css={styles.approveDialogSection}>
          {`Your records request must be initiated from the ${payerItem?.name} website. Upon submitting your authorization, the data sharing process will begin utilizing reliable and secure protocols designed
          specifically for the exchange of Electronic Health Record data.`}
        </div>
        <div css={styles.approveDialogSectionTitle}>Our commitment to your privacy and security</div>
        <div css={styles.approveDialogSectionSmall}>
          As part of normal business operations, we may collect and retain personal data. This personal data will only be shared with third parties meeting our privacy and security standards upon your
          consent. You maintain all designated rights, protections and controls to access, modify and/or remove your data from our platform.
        </div>
        <div css={styles.approveDialogSectionSmall}>Your privacy and security is extremely important to us. We are compliant with all HIPAA and HITRUST security standards.</div>
        <div css={styles.approveDialogSectionSmall}>
          <a href={(window as any)?.env?.REACT_APP_PRIVACY_POLICY_LINK} css={styles.general.href(themeStore.currentTheme)} target="_blank" rel="noopener noreferrer">
            {
              t(LocaleKeys.screens.P2p.readOuPrivacyPolicy) // Read our privacy policy.
            }
          </a>
        </div>
        <div css={[styles.approveDialogSectionSmall, styles.warningSmall]}>The text above is subject to change.</div>
      </ApproveNotificationModal>
      <Loader
        color={themeStore.currentTheme.colors.actionMedium.published}
        position={'centered'}
        loading={payerToPayerStore.payersRequestStatus === StoreRequestStatus.Idle || payerToPayerStore.payersRequestStatus === StoreRequestStatus.Loading || isTransparentLoading}
        backgroundColor={isTransparentLoading ? applyOpacity(globalStyles.COLOR.white, 0.8) : globalStyles.COLOR.white}
      />
    </div>
  );
};

export default observer(P2pPayerPage);
