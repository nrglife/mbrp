#!/bin/bash
echo "*** Starting nginx ***"
echo "$(ls -la /usr/share/nginx/html/)"
#echo "$(cat /usr/share/nginx/html/echofile.txt)"
#echo "$(</usr/share/nginx/html/env.js)"
nginx -g "daemon off;"
