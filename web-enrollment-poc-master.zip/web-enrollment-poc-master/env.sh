#!/bin/bash

#exit the script on first error
set -e

#set -x
echo "0" $0
echo "1" $1
# Recreate config file
FILE=/usr/share/nginx/html/env.js

rm -f $FILE
touch  $FILE

# Add assignment 
echo "window.env = {" >>  $FILE
# Read each line in var-names.txt file - Each line represents key

NL=$'\n'

while read -r line || [[ -n "$line" ]];
do     
  varname=$(printf '%s\n' "${line%$NL}" | sed -e 's/\r//' | xargs)  
  [[ -z $varname ]] && continue
  value=$(printf '%s\n' "${!varname}")

  #all variables must be supplied
  if [[ -z $value ]]; then    
    echo >&2 "Missing environment variable: ${varname} "; exit 1;  
  fi

  # Append configuration property to JS file
  echo "  $varname: \"$value\"," >>  $FILE
  
done < /usr/share/nginx/html/var-names.txt

echo "}" >>  $FILE

