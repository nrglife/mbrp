//add new ts file for docker build with the EDOP pipeline
