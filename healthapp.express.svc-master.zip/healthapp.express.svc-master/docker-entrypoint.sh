#!/bin/sh
#exit the script on first error
set -e

#start app process
if [ "$1" = 'app' ]; then
    exec npm run start:ecs
fi

exec "$@"
