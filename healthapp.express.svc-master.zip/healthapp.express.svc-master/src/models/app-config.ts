import moment from "moment";
import appLogger from "../utilities/app-logger";
import {parseBool} from "../utilities/String";

export class AppConfig {
  public appVersions: any;
  public appSupportDetails: any;
  public appSupportVisible: boolean;
  public insuranceSupportVisible: boolean;
  public surveyURL?: string | null;
  public filterFindCareByLocation: boolean;
  public hideFindCare: boolean;
  public hideP2P: boolean;
  public hideHealthProfile: boolean;
  public useAuthCodeFlow: boolean;
  public useFederatedId: boolean;
  public showMessagingPlatform: boolean;
  public smileCDRRevokeURL: string | null;
  public appMessage: any;
  public payersConfig?: string;
  public disableDisplayErrorCodes: boolean;
  public healthProfileHideInvalidRecords: boolean;
  public deprecatedVersion: { android: string, ios: string }

  constructor() {
    this.appVersions = this.getAppVersions();
    this.appSupportDetails = this.getAppDetails();
    this.appSupportVisible = this.getAppSupportVisible();
    this.insuranceSupportVisible = this.getInsuranceSupportVisible();
    this.surveyURL = this.getsurveyURL();
    this.filterFindCareByLocation = this.getfilterFindCareByLocation();
    this.hideFindCare = this.hideFindCareFeature();
    this.hideP2P = this.hideP2PFeature();
    this.hideHealthProfile = this.hideHealthProfileFeature();
    this.useAuthCodeFlow = this.isUseAuthCodeFlow();
    this.useFederatedId = this.isUseFederatedId();
    this.showMessagingPlatform = this.getMessagingPlatform();
    this.smileCDRRevokeURL = this.getSmileCDRRevokeURL();
    this.appMessage = this.getAppMessage();
    this.payersConfig = this.getPayerConfig();
    this.disableDisplayErrorCodes = this.isDisableDisplayErrorCodes();
    this.healthProfileHideInvalidRecords =
      this.getHealthProfileHideInvalidRecords();
    this.deprecatedVersion = this.getDeprecatedVersion()
  }

  public getPayerConfig() {
    try {
      const regexBase64 =
        /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
      const isBase64 =
        process?.env?.payersConfig &&
        regexBase64.test(process.env.payersConfig);

      //reverting the process.env.payersConfig base 64 back to string if needed
      const payerConfig =
        (isBase64 &&
          process?.env?.payersConfig &&
          Buffer.from(process.env.payersConfig, "base64").toString()) ||
        process.env.payersConfig;

      return payerConfig;
    } catch (error) {
      appLogger.error("Error:", error);
      return process?.env?.payersConfig;
    }
  }

  private getHealthProfileHideInvalidRecords() {
    const hide = process.env.healthProfileHideInvalidRecords;
    return parseBool(hide);
  }

  public getAppMessage() {
    let showMessage = false;
    try {
      showMessage = parseBool(process.env.appMessageShowMessage);
    } catch (err) {
    }

    const title = process.env.appMessageTitle;
    const message = process.env.appMessageMessage;

    let showCloseButton = false;
    try {
      showCloseButton = parseBool(process.env.appMessageShowCloseButton);
    } catch (err) {
    }

    const closeButtonText = process.env.appMessageCloseButtonText;
    let startDate;
    try {
      startDate = moment(
        process.env.appMessageStartDate,
        "MM/DD/YYYY"
      ).toDate();
    } catch (err) {
      startDate = moment("01/01/1999", "MM/DD/YYYY").toDate();
    }

    let endDate;
    try {
      endDate = moment(process.env.appMessageEndDate, "MM/DD/YYYY").toDate();
    } catch (err) {
      endDate = moment("01/01/1999", "MM/DD/YYYY").toDate();
    }

    return {
      showMessage,
      title,
      message,
      showCloseButton,
      closeButtonText,
      startDate,
      endDate,
    };
  }

  public getAppVersions() {
    const allowed = this.getVersionsObject(
      process.env.appConfigVersionsAllowed,
      "allowed"
    );
    const deprecated = this.getVersionsObject(
      process.env.appConfigVersionsDeprecated,
      "deprecated"
    );
    const latestVersion = this.getVersionsObject(
      process.env.appConfigVersionsLatestVersion,
      "allowed"
    );

    return {
      latestVersion,
      ...allowed,
      ...deprecated,
    };
  }

  public getAppDetails() {
    const supportDetails = this.getSupportDetailsObject();

    return supportDetails;
  }

  public getAppSupportVisible() {
    const appSupportVisible = process.env.appConfigSupportVisible;
    return appSupportVisible && appSupportVisible.toLowerCase() === "true"
      ? true
      : false;
  }

  public getDeprecatedVersion() {
    return {android: process.env.deprecatedVersionAndroid ?? '1.0', ios:process.env.deprecatedVersionIos?? '1.0'}
  }

  public getInsuranceSupportVisible() {
    const insuranceSupportVisible = process.env.insuranceSupportVisible;
    return insuranceSupportVisible &&
      insuranceSupportVisible.toLowerCase() === "true"
      ? true
      : false;
  }

  private getVersionsObject(
    versionsSequence?: string,
    status?: "allowed" | "deprecated"
  ) {
    return (
      versionsSequence &&
      versionsSequence.split(",").reduce((prev: any, curr) => {
        if (curr.trim()) {
          prev[curr.trim()] = status;
        }

        return prev;
      }, {})
    );
  }

  private getPayerObject(payerData: string) {
    return (
      payerData &&
      payerData.split(",").reduce((obj: any, curr) => {
        if (curr.trim()) {
          let pair = curr.split("=");
          if (pair && pair.length > 1 && pair[0]) {
            obj[pair[0].trim()] = pair[1] ? pair[1].trim() : "";
          }
        }

        return obj;
      }, {})
    );
  }

  private getSupportDetailsObject() {
    const appConfigSupportNames = process.env.appConfigSupportName
      ? process.env.appConfigSupportName.split(",").map((item) => item.trim())
      : [];
    const appConfigSupportPhoneNumbers = process.env.appConfigSupportPhoneNumber
      ? process.env.appConfigSupportPhoneNumber
        .split(",")
        .map((item) => item.trim())
      : [];
    const appConfigSupportEmails = process.env.appConfigSupportEmail
      ? process.env.appConfigSupportEmail.split(",").map((item) => item.trim())
      : [];

    return {
      appSupportNames: [...appConfigSupportNames],
      appSupportEmails: [...appConfigSupportEmails],
      appSupportPhoneNumbers: [...appConfigSupportPhoneNumbers],
    };
  }

  private getPayersDetailsObject() {
    const payers = process.env.payers
      ? process.env.payers.split(";").map((item) => item.trim())
      : [];

    let payersData =
      payers &&
      payers.length > 0 &&
      payers.reduce((obj: any, curr) => {
        if (curr.trim()) {
          let pair = curr.split("::");
          if (pair && pair.length > 1 && pair[0]) {
            obj[pair[0].trim()] = pair[1]
              ? this.getPayerObject(pair[1].trim())
              : "";
          }
        }

        return obj;
      }, {});

    return {...payersData};
  }

  private getPayers() {
    const payers = this.getPayersDetailsObject();
    return payers ? payers : null;
  }

  private getsurveyURL() {
    const surveyURL = process.env.appConfigSurveyURL;
    return surveyURL ? surveyURL : null;
  }

  private getfilterFindCareByLocation() {
    const filter = process.env.filterFindCareByLocation;
    return parseBool(filter);
  }

  private hideFindCareFeature() {
    const hide = process.env.hideFindCareFeature;
    return parseBool(hide);
  }

  private hideP2PFeature() {
    const hide = process.env.hideP2PFeature;
    return parseBool(hide);
  }

  private hideHealthProfileFeature() {
    const hide = process.env.hideHealthProfileFeature;
    return parseBool(hide);
  }

  private isDisableDisplayErrorCodes() {
    const disable = process.env.disableDisplayErrorCodes;
    return parseBool(disable);
  }

  private isUseAuthCodeFlow() {
    const useAuthCodeFlow = process.env.useAuthCodeFlow;
    return !useAuthCodeFlow || useAuthCodeFlow.toLowerCase() !== "false";
  }

  private isUseFederatedId() {
    const useFederatedId = process.env.useFederatedId;
    return !useFederatedId || useFederatedId.toLowerCase() !== "false";
  }

  private getMessagingPlatform() {
    const show = process.env.showMessagingPlatform;
    return parseBool(show);
  }

  private getSmileCDRRevokeURL() {
    const url = process.env.smileCDRRevokeURL;
    return url ? url : null;
  }
}
