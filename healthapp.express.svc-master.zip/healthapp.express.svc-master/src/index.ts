import express from "express";
//middleware imports
import { json, urlencoded } from "express";
import cors from "cors";
import logger from "./middleware/logger";
import nocache from "./middleware/nocache";
import initIdTracing from "./middleware/initIdTracing";
import errorHandler from "./middleware/errorHandler";
import responseNormalizer from "./middleware/responseNormalizer";
//routers import
import configRouter from "./routes/configRouter";
import localesRouter from "./routes/localesRouter";
import healthCheckRouter from "./routes/healthCheckRouter";
import consentRouter from "./routes/consentRouter";
import enrollmentValidationRouter from "./routes/enrollmentValidationRouter";
import enrollmentRouter from "./routes/enrollmentRouter";
import authRouter from "./routes/authRouter";
import p2pRouter from "./routes/p2pRouter";
//developed
import { parseBool } from "./utilities/String";
import { getRootPath, printRoutesToConsole } from "./utilities/routing";
//init env files
import "./config/config";

//init express app
const app = express();

const corsOptions = {
  // for preflight request - some legacy browsers (IE11, various SmartTVs) choke on 204
  optionsSuccessStatus: 200,
};

// Init middleware
app.use(logger);
app.use(nocache);
app.use(initIdTracing);
// Body Parser Middleware
app.use(json());
app.use(urlencoded({ extended: true }));
app.use(responseNormalizer);
//Cors Middleware - handled by apigee
app.use(cors(corsOptions));

const rootPath = getRootPath();
// appConfig API Routes
app.use(rootPath, configRouter);
// locales API Routes
app.use(rootPath, localesRouter);
// healthCheck API Routes
app.use(rootPath, healthCheckRouter);
// consent API Routes
app.use(rootPath, consentRouter);
// enrollment validation API Routes
app.use(rootPath, enrollmentValidationRouter);
// enrollment API Routes
app.use(rootPath, enrollmentRouter);
// authentication API Routes
app.use(rootPath, authRouter);
// p2p API Routes
!parseBool(process.env.hideP2PFeature) && app.use(rootPath, p2pRouter);

//error handler - last midleware to catch all errors that was thrown from the api calls above
app.use(errorHandler);

const PORT = process.env.servicePort || 4000;

app.listen(PORT, () => {
  console.log("\x1b[33m" + `\nServer started on port ${PORT}\n`);
  printRoutesToConsole(app);
});
