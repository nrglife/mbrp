import { Express } from "express";

export const getRootPath = () =>
  process.env.currentServerBaseUrl?.includes("localhost")
    ? `/${process.env.currentServerBaseUrl.split("/").pop()}`
    : "/";

export const printRoutesToConsole = (app: Express) => {
  const routes: any[] = [];
  const registeredRoute = app._router.stack.map((r: any) => r.route);

  const routersStacks = app._router.stack
    .filter((r: any) => r.name === "router")
    .map((router: any) => router.handle.stack);
  const registeredRouteFromRouters: any[] = [];
  for (const routerStack of routersStacks) {
    for (const r of routerStack) {
      r.route && registeredRouteFromRouters.push(r.route);
    }
  }

  const baseURL = process.env.currentServerBaseUrl
    ? process.env.currentServerBaseUrl
    : "";

  routes.push(...registeredRoute, ...registeredRouteFromRouters);
  const routesForPrinting = routes
    .map((r: any) =>
      r?.path && r?.methods
        ? `${Object.keys(r.methods)[0].toUpperCase()} | ${baseURL}${r.path}`
        : null
    )
    .filter((r) => r);

  routesForPrinting.length > 0 && console.log(`Avilable routes:\n`);
  for (const r of routesForPrinting) {
    r && r.includes("GET") && console.log("\x1b[36m" + r);
    r && r.includes("POST") && console.log("\x1b[35m" + r);
  }
  //reset color for the terminal
  console.log("\x1b[0m");
};
