import jwt from "jsonwebtoken";
import moment from "moment";
//developed
import { IHDPApi } from "../data-managers/ihdp/ihdp-api";
import { ActivityLogIHDPApi } from "../data-managers/activity-log-ihdp/activity-log-ihdp-api";
import { getCiamIssuerConfig } from "../ciam-config/ciam-issuer-config";

export async function getIHDPToken() {
  const ihdpApi = new IHDPApi(
    `${process.env.apigeeBaseUrl}/apip/auth/v2/token`
  );

  const response = await ihdpApi.getIHDPToken();

  return { token: response.data.access_token, traceID: ihdpApi.chcTraceID };
}

export async function getAppFirstToken() {
  const ihdpApi = new IHDPApi(`${process.env.AppFirstTokenUrl}`);
  const response = await ihdpApi.getIHDPTokenWithCustomCredentials(
    `${process.env.AppFirstClientID}`,
    `${process.env.AppFirstClientSecret}`
  );
  return { token: response.data.access_token, traceID: ihdpApi.chcTraceID };
}

export async function getActivityLogIHDPToken() {
  const activityLogIhdpApi = new ActivityLogIHDPApi();
  const response = await activityLogIhdpApi.getActivityLogIHDPToken();
  const { token_type, access_token } = response.data;

  return `${token_type} ${access_token}`;
}

export async function getAccessTokenFromCode(
  code: string,
  redirectUri: string
) {
  const ihdpApi = new IHDPApi(getCiamIssuerConfig().token_endpoint);
  const response = await ihdpApi.getAccessToken(code, redirectUri);
  return response.data;
}

export function verifyJWTToken(token: string) {
  let parsedToken = token;

  if (token && token.indexOf("Bearer") >= 0) {
    parsedToken = token.split(" ")[1];
  }

  const decoded = jwt.decode(parsedToken) as { [key: string]: any };

  if (!decoded) {
    return false;
  }

  const expMoment = moment.unix(decoded.exp);
  const iatMoment = moment.unix(decoded.iat);
  const leftTTL = expMoment.diff(moment(), "minutes");
  const expirationTime = expMoment.diff(iatMoment, "minutes");

  return leftTTL >= expirationTime / 2;
}
