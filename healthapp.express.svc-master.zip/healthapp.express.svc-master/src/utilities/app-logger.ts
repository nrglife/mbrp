enum LogLevel {
  Error = "error",
  Warning = "warning",
  Info = "info",
  Debug = "debug",
}

class AppLogger {
  public static instance: AppLogger;

  private traceId?: string;
  private memberId?: string;

  constructor() {
    if (!AppLogger.instance) {
      AppLogger.instance = this;
    }

    return AppLogger.instance;
  }

  public setTraceId(traceId: string) {
    this.traceId = traceId || this.traceId;
  }

  public setMemberId(memberId: string) {
    this.memberId = memberId || this.memberId;
  }

  public info(message?: string, data?: any, extendPrevLog?: boolean) {
    switch (process.env.logLevel) {
      case LogLevel.Debug:
      case LogLevel.Info:
        this.log(message, data, LogLevel.Info, extendPrevLog);
    }
  }

  public warning(message?: string, data?: any, extendPrevLog?: boolean) {
    switch (process.env.logLevel) {
      case LogLevel.Debug:
      case LogLevel.Info:
      case LogLevel.Warning:
        this.log(message, data, LogLevel.Warning, extendPrevLog);
    }
  }

  public error(message?: string, data?: any, extendPrevLog?: boolean) {
    this.log(message, data, LogLevel.Error, extendPrevLog);
  }

  public debug(message?: string, data?: any, extendPrevLog?: boolean) {
    if (process.env.logLevel === LogLevel.Debug) {
      this.log(message, data, LogLevel.Debug, extendPrevLog);
    }
  }

  public log(
    message?: string,
    data?: any,
    level: LogLevel = process.env.logLevel as LogLevel,
    extendPrevLog = false
  ) {
    const memberIdToPrint =
      process.env.logLevel === LogLevel.Debug ? this.memberId : "";

    if (!extendPrevLog) {
      console.log(
        `\x1b[36mHEALTHAPP.SVC - ${
          this.traceId
        } | ${memberIdToPrint} - ${new Date().toISOString()} - ${level.toUpperCase()}\x1b[37m`
      );
    }

    switch (level.toLowerCase()) {
      case LogLevel.Info:
      case LogLevel.Debug:
        data
          ? console.log(message + "\n" + this.stringifyData(data))
          : console.log(message);
        break;
      case LogLevel.Warning:
        data
          ? console.warn(message + "\n" + this.stringifyData(data))
          : console.warn(message);
        break;
      case LogLevel.Error:
        data
          ? console.error(message + "\n" + this.stringifyData(data))
          : console.error(message);
        break;
      default:
        data
          ? console.log(message + "\n" + this.stringifyData(data))
          : console.log(message);
    }
  }

  private stringifyData(data: any) {
    let stringified = null;

    try {
      stringified = JSON.stringify(data, null, 2);
    } catch (e) {
      stringified = data.message ? data.message : JSON.stringify({});
    }

    return stringified;
  }
}

const appLogger = new AppLogger();

export default appLogger;
