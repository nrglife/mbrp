export const parseBool = (val: any) => {
  return (
    val === true ||
    (typeof val === "string" && val.trim().toLowerCase() === "true")
  );
};
