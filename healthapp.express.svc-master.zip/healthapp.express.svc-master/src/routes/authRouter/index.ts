import { Router } from "express";
import AuthController from "../../controllers/auth.controller";
import { withAuthorization } from "../../middleware/withAuthorization";

const router = Router();

// Gets /authCodeFlow
/*
 */
router.get(
  "/authCodeFlow",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  AuthController.getAuthCodeFlow
);

export default router;
