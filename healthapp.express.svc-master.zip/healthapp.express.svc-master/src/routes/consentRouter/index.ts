import { Router } from "express";
import ConsentController, {
  schema,
} from "../../controllers/consent.controller";
//middlewares
import { withAuthorization } from "../../middleware/withAuthorization";
import schemaValidation from "../../middleware/schemaValidation";

const router = Router();
// Consent Api
// GET /contract
/*
 */
router.get(
  "/contract",
  withAuthorization,
  (req, res, next) => schemaValidation(req, res, next, schema.getContract),
  ConsentController.getContract
);

// GET /consent
/*
 */
router.get(
  "/consent",
  withAuthorization,
  (req, res, next) => schemaValidation(req, res, next, schema.getConsent),
  ConsentController.getConsent
);

// POST /consent
/*
 */
router.post(
  "/consent",
  withAuthorization,
  (req, res, next) => schemaValidation(req, res, next, schema.postConsent),
  ConsentController.postConsent
);

export default router;
