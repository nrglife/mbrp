import { Router } from "express";
import AppLocalesController from "../../controllers/locales.controller";
const router = Router();

// Gets Locales Files
/*
 */
router.get("/locales", AppLocalesController.getLocales);

export default router;
