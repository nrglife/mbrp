import { Router } from "express";
import AppConfigController from "../../controllers/config.controller";
const router = Router();

// Gets /app configuration
/*
 */
router.get("/appConfiguration", AppConfigController.getConfig);

export default router;
