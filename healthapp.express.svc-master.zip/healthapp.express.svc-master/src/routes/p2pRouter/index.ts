import { Router } from "express";
import P2PController, { schema } from "../../controllers/p2p.controller";
//middlewares
import { withAuthorization } from "../../middleware/withAuthorization";
import schemaValidation from "../../middleware/schemaValidation";

const router = Router();
// P2P Api

// GET /payertopayer/payerAuthURL/{payerId}
/*
 */
router.get("/payertopayer/payer", withAuthorization, P2PController.getPayer);

// GET /payertopayer/payerAuthURL/{payerId}
/*
 */
router.get(
  "/payertopayer/payerAuthURL/:payerId",
  withAuthorization,
  (req, res, next) => schemaValidation(req, res, next, schema.getPayerAuthURL),
  P2PController.getPayerAuthURL
);

// POST /payertopayer/createAccessToken/{payerId}
/*
 */
router.post(
  "/payertopayer/createAccessToken/:payerId",
  withAuthorization,
  (req, res, next) =>
    schemaValidation(req, res, next, schema.postCreateAccessToken),
  P2PController.postCreateAccessToken
);

// GET /payertopayer/request/{payerId}
/*
 */
router.get(
  "/payertopayer/request/:payerId",
  withAuthorization,
  (req, res, next) =>
    schemaValidation(req, res, next, schema.getRequestStatusForPayer),
  P2PController.getRequestStatusForPayer
);

export default router;
