import { Router, Request, Response } from "express";
import { StatusCode } from "../../models/app-error";
const router = Router();

// check the server is up and running
router.get("/healthcheck", (req, res) => {
  res
    .status(StatusCode.Success)
    .json({ data: "healthcheck for express server" });
});

export default router;
