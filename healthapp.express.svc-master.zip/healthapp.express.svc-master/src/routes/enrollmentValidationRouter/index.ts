import { Router } from "express";
import EnrollmentValidationController from "../../controllers/enrollment-validation.controller";
//middlewares
import { withAuthorization } from "../../middleware/withAuthorization";

const router = Router();
// Enrollment Validation API
// GET /enrollment
/*
 */
router.get(
  "/enrollment",
  withAuthorization,
  EnrollmentValidationController.getEnrollment
);

export default router;
