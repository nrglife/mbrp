import { Router } from "express";
import EnrollmentController, {
  schema,
} from "../../controllers/enrollment.controller";
//middlewares
import { withAuthorization } from "../../middleware/withAuthorization";
import schemaValidation from "../../middleware/schemaValidation";

const router = Router();

// Enrollment Api
// GET /invitation/{invitationCode}
/*
 */
router.get(
  "/invitation/:invitationCode",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) =>
    schemaValidation(req, res, next, schema.getEnrollmentInvitation),
  EnrollmentController.getEnrollmentInvitation
);

// POST /
/*
 */
router.post(
  "/invitation/:invitationCode",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) =>
    schemaValidation(req, res, next, schema.postEnrollmentInvitation),
  EnrollmentController.postEnrollmentInvitation
);

// POST /invitation/{invitationCode}/otp
/*
 */
router.post(
  "/invitation/:invitationCode/otp",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) =>
    schemaValidation(req, res, next, schema.postInvitationCodeOptPasscode),
  EnrollmentController.postInvitationCodeOptPasscode
);

// POST /invitation/{invitationCode}/otp/{phone}
/*
 */
router.post(
  "/invitation/:invitationCode/otp/:phone",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) =>
    schemaValidation(req, res, next, schema.postEnrollmentInvitationOtp),
  EnrollmentController.postEnrollmentInvitationOtp
);

// POST /invitation/{invitationCode}/email
/*
 */
router.post(
  "/invitation/:invitationCode/email",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) =>
    schemaValidation(req, res, next, schema.postInvitationVerificationEmail),
  EnrollmentController.postInvitationVerificationEmail
);

// POST /invitation/{invitationCode}/identity
/*
 */
router.post(
  "/invitation/:invitationCode/identity",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) => schemaValidation(req, res, next, schema.postIdentity),
  EnrollmentController.postIdentity
);

// POST /invitation/{invitationCode}/password/{userId}
/*
 */
router.post(
  "/invitation/:invitationCode/password/:userId",
  (req, res, next) => withAuthorization(req, res, next, { useCIAM: false }),
  (req, res, next) => schemaValidation(req, res, next, schema.postSetPassword),
  EnrollmentController.postSetPassword
);

export default router;
