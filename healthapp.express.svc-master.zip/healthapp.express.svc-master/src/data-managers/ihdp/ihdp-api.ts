import * as qs from "qs";
import { IHDPRequest } from "./ihdp-request";

export class IHDPApi extends IHDPRequest {
  constructor(baseURL: string) {
    super(baseURL);
  }

  public getIHDPTokenWithCustomCredentials(
    clientId: string,
    clientSecret: string
  ) {
    return this.instance
      .post(
        "",
        qs.stringify({
          client_id: clientId, //process.env.apigeeClientId,
          client_secret: clientSecret, // process.env.apigeeClientSecret,
          grant_type: "client_credentials",
        })
      )
      .catch(this.errorHandler());
  }

  public getIHDPToken() {
    return this.instance
      .post(
        "",
        qs.stringify({
          client_id: process.env.apigeeClientId,
          client_secret: process.env.apigeeClientSecret,
          grant_type: "client_credentials",
        })
      )
      .catch(this.errorHandler());
  }

  public getAccessToken(code: string, redirectUri: string) {
    const body = qs.stringify({
      grant_type: "authorization_code",
      code: code,
      client_id: process.env.memberPortalClientId,
      client_secret: process.env.memberPortalClientSecret,
      redirect_uri: redirectUri,
    });
    return this.instance.post("", body).catch(this.errorHandler());
  }
}
