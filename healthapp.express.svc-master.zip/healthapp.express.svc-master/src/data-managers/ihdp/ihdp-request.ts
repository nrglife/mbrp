import appLogger from "../../utilities/app-logger";
import { BaseRequest } from "../base-request";

export class IHDPRequest extends BaseRequest {
  public chcTraceID?: string;

  constructor(baseURL: string) {
    super(baseURL, {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
      "cache-control": "no-cache",
    });
  }

  protected initInterceptors() {
    super.initInterceptors(null, (response) => {
      this.chcTraceID = response.headers["x-chc-traceid"];

      appLogger.debug(`with trace ID: ${this.chcTraceID}`, null, true);
    });
  }

  protected errorHandler(customCallback?: (e: any) => void) {
    return super.errorHandler(customCallback, (error) => {
      const { response } = error;

      this.chcTraceID = response ? response.headers["x-chc-traceid"] : undefined;

      return ` with traceID: ${this.chcTraceID}`;
    });
  }
}
