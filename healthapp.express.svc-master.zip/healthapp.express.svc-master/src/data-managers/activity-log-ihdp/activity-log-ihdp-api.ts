import * as qs from "qs";

import { ActivityLogIHDPRequest } from "./activity-log-ihdp-request";

export class ActivityLogIHDPApi extends ActivityLogIHDPRequest {
  //generat ihdp tokn for activity log - the secret and the id are different from the normal getIHDPToken() at the ihdp data-manager
    public getActivityLogIHDPToken() {
      return this.instance.post(
        "",
        qs.stringify({
          client_id: process.env.apigeeClientIdForActivityLog,
          client_secret: process.env.apigeeClientSecretForActivityLog,
          grant_type: "client_credentials",
        })
      ).catch(this.errorHandler());
    }
}
