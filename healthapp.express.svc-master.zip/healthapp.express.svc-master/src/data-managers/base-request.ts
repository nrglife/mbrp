import axios, {
  AxiosError,
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
} from "axios";
//developed
import { AppError, AppErrorWithData } from "../models/app-error";
import appLogger from "../utilities/app-logger";

export type BaseRequestErrorType = {
  error: AppError;
  data: {
    remoteReques: {
      status: number | null;
      meta: any | null;
    };
  };
};

export class BaseRequest {
  protected readonly instance: AxiosInstance;

  constructor(baseURL: string, headers?: any) {
    this.instance = axios.create({
      baseURL,
      timeout: 1200000,
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
    });

    this.initInterceptors();
  }

  protected initInterceptors(
    onRequest?: ((config: AxiosRequestConfig) => void) | null,
    onResponse?: (res: AxiosResponse) => void
  ) {
    this.instance.interceptors.request.use((config) => {
      appLogger.info(`External request to - ${config.baseURL}${config.url}`);

      if (onRequest) {
        onRequest(config);
      }

      return config;
    });

    this.instance.interceptors.response.use((response) => {
      appLogger.debug(
        `Response from - ${response.config.url} ${response.status}`
      );

      if (onResponse) {
        onResponse(response);
      }

      //we add this just for assign param and don't need to send is as data to user. so we will delete it later.
      if (typeof response.data === "object")
        response.data.status = response.status;
      return response;
    });
  }

  protected errorHandler(
    customCallback?: (e: any) => void,
    extraMsg?: (err: AxiosError) => string
  ) {
    return (requestError: AxiosError) => {
      let throwException: any;
      if (customCallback) {
        try {
          customCallback(requestError);
        } catch (e) {
          throwException = e;
        }
      }

      let { response } = requestError;
      if (!response) {
        response = {
          data: requestError.message,
          headers: [],
        } as unknown as  AxiosResponse;
      }

      appLogger.debug(
        `Error from - ${requestError.config ? requestError.config.url : ""}${
          extraMsg ? extraMsg(requestError) : ""
        }\n\t${requestError.message}`
      );

      if (!throwException) {
        throwException = response.status
          ? AppError.getAppErrorByCode(response.status)
          : AppError.ErrorPerformingAction;
      }

      throw new AppErrorWithData(throwException, {
        remoteRequest: {
          status: response.status || null,
          meta: response.data || null,
        },
      });
    };
  }
}
