import { AxiosRequestConfig } from "axios";
import { BaseCIAMRequest } from "../base-ciam-request";
import appLogger from "../../utilities/app-logger";

type PostSmilecdrPayerTokenParams = {
  client_id?: string;
  code?: string;
  client_secret?: string;
  redirect_uri?: string;
  grant_type?: string;
  scope?: string;
};

type SmileCDRFhirApiAuthParams = {
  client_id?: string;
  client_secret?: string;
};

export class SmileCDRFhirApi extends BaseCIAMRequest {
  constructor(
    baseUrl: string = "",
    authParams: SmileCDRFhirApiAuthParams = {}
  ) {
    const { client_id = "", client_secret = "" } = authParams;
    const authToken = `Basic ${Buffer.from(
      `${client_id}:${client_secret}`
    ).toString("base64")}`;
    appLogger.log(`authToken  ${authToken}`);

    super(baseUrl, {
      Authorization: authToken,
    });
  }

  //https://smilecdr.com/docs/smart/smart_on_fhir_authorization_flows.html#authorization-code-flow  - 15.2.1Launch Flow: Authorization Code - step 4
  public postSmilecdrPayerToken(params: PostSmilecdrPayerTokenParams) {

    appLogger.log(`params  ${JSON.stringify(params)}`);
    appLogger.log(`headers  ${JSON.stringify(this.instance.defaults.headers)}`);
    return this.instance
      .post(
        ``,
        {},
        {
          params,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      )
      .catch((error)=>{
        appLogger.log(`error postSmilecdrPayerToken  ${JSON.stringify(error)}`);
        appLogger.error(
          "Error while trying to get access token from code.",
          error
        );
      });
  }
}
