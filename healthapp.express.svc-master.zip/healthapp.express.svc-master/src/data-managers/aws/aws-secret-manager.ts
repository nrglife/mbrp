import aws from "aws-sdk";
import appLogger from "../../utilities/app-logger";

const region = process.env.awsSecretManagerRegion || "";
const arn = process.env.awsSecretManagerARN || "";

type SecretValue = {
  token_url?: string;
  authorize_url?: string;
  client_id?: string;
  response_type?: string;
  code?: string;
  client_secret?: string;
  redirect_uri?: string;
  grant_type?: string;
  scope?: string;
  [key: string]: string | undefined;
};

export class AWSSecretManager {
  constructor() {}

  //ex for redirect url - http://10.224.144.239:9200/oauth/authorize?response_type=code&scope=online_access%2Bopenid%2Bpatient%2F%2A.read%2Bprofile&client_id=humana-XYz1Eh6rltqME9qtqrP1mbMHI&redirect_uri=http%3A%2F%2Flocalhost%3A5020%2Fp2pauth
  public async getSecretValue(secretKey: string) {
    try {
      appLogger.log(`get value from aws secret manager for ${secretKey}`);

      let secretValue: SecretValue = {};

      if (process.env.MODE === "development") {
        //for now return a mock for the P2P api use
        secretValue = {
          token_url: "http://10.224.144.239:9200/oauth/token",
          client_id: "humana-XYz1Eh6rltqME9qtqrP1mbMHI",
          response_type: "code",
          code: "authorization code",
          client_secret: "GV7LHrsSNqZya3OfXytIwhKN24zL4TGo",
          redirect_uri: "http://localhost:5020",
          grant_type: "authorization_code",
          authorize_url: "http://10.224.144.239:9200/oauth/authorize",
          scope: "online_access,openid,patient/*.read,profile",
        };
      } else {
        //real connection to secret manager
        appLogger.log(`connect to aws secret manager at ${region}`);
        const smClient = new aws.SecretsManager({
          region,
        });

        const secretData = await smClient
          .getSecretValue({
            SecretId: `${arn}:secret:${secretKey}`,
          })
          .promise();

        try {
          secretValue =
            (secretData.SecretString && JSON.parse(secretData.SecretString)) ||
            {};
        } catch (error) {
          appLogger.error("JSON parse of secret value has faild", error);
        }
      }

      return secretValue;
    } catch (error) {
      appLogger.error("Error while trying to get secret value.", error);
      throw error;
    }
  }
}
