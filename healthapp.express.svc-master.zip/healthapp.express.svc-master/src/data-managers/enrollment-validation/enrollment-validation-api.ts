import { EnrollmentValidationRequest } from "./enrollment-validation-request";
import appLogger from "../../utilities/app-logger";

export class EnrollmentValidationApi extends EnrollmentValidationRequest {
  public getEnrollment() {
    const baseUrl = this.instance?.defaults?.baseURL;
    //add log for external api call in case of debug that need to be done at the server
    appLogger.log("External request to - GET - " + baseUrl);

    return this.instance.get(`/enrollment`).catch(this.errorHandler());
  }
}
