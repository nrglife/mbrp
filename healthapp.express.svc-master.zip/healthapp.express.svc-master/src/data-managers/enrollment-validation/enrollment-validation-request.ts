import { BaseCIAMRequest } from "../base-ciam-request";

export class EnrollmentValidationRequest extends BaseCIAMRequest {
  constructor(ciamAuthenticationToken: string = "") {
    const baseUrl = process.env.enrollmentApiUrl || "";
    const headers = {
      Authorization: ciamAuthenticationToken,
    };

    super(baseUrl, headers);
  }
}
