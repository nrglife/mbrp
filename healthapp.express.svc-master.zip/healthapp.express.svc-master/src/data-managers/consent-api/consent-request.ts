import { BaseCIAMRequest } from "../base-ciam-request";

export class ConsentRequest extends BaseCIAMRequest {
  constructor(ciamAuthenticationToken: string = "") {
    const baseUrl = process.env.consentApiUrl || "";

    super(baseUrl, {
      Authorization: ciamAuthenticationToken,
    });
  }
}
