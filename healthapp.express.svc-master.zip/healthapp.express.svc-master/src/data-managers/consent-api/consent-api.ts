import { ConsentRequest } from "./consent-request";

export class ConsentApi extends ConsentRequest {
  public getContract(params: any) {
    return this.instance
      .get("/contract", { params })
      .catch(this.errorHandler());
  }

  public getConsent(params: any) {
    return this.instance.get("/consent", { params }).catch(this.errorHandler());
  }

  public postConsent(data: any) {
    return this.instance.post("/consent", data).catch(this.errorHandler());
  }
}
