import { BaseCIAMRequest } from "../base-ciam-request";
import appLogger from "../../utilities/app-logger";

//https://wiki.healthcareit.net/pages/viewpage.action?spaceKey=IHDP&title=InternalToExternal+Swagger
export class P2PApi extends BaseCIAMRequest {
  constructor(ciamAuthenticationToken: string = "") {
    const baseUrl = process.env.p2pApiUrl || "";

    super(baseUrl, {
      Authorization: ciamAuthenticationToken,
    });
  }

  public getPayer() {
    return this.instance.get(`/payer`).catch(this.errorHandler());
  }

  public getPayerInfo(payerId: string) {
    return this.instance.get(`/payer/${payerId}`).catch(this.errorHandler());
  }

  public postPayerInfo(
    payerId: string,
    tokens: { access_token: string; refresh_token: string }
  ) {
    appLogger.log(`postPayerInfo  ${payerId}`);

    const { access_token, refresh_token } = tokens;
    const config = {
      headers: {
        "X-Payer-Access-Token": access_token,
        "X-Payer-Refresh-Token": refresh_token,
      },
    };

    return this.instance
      .post(`/request/${payerId}`, null, config)
      .catch(this.errorHandler());
  }

  public getRequestStatusForPayer(payerId: string) {
    return this.instance.get(`/request/${payerId}`).catch(this.errorHandler());
  }
}
