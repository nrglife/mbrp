import { EnrollmentRequest } from "./enrollment-request";

export class EnrollmentApi extends EnrollmentRequest {
  public getEnrollmentInvitation(invitationCode: string) {
    return this.instance
      .get(`/invitation/${invitationCode}`)
      .catch(this.errorHandler());
  }

  public postInvitationVerificationEmail(invitationCode: string, body: any) {
    return this.instance
      .post(`invitation/${invitationCode}/email`, body)
      .catch(this.errorHandler());
  }

  public postEnrollmentInvitation(invitationCode: string, body: any) {
    return this.instance
      .post(`/invitation/${invitationCode}`, body)
      .catch(this.errorHandler());
  }

  public postEnrollmentInvitationOtp(invitationCode: string, phone: string, body: any) {
    return this.instance
      .post(`/invitation/${invitationCode}/otp/${phone}`, body)
      .catch(this.errorHandler());
  }

  public postInvitationCodeOptPasscode(invitationCode: string, body: any) {
    return this.instance
      .post(`/invitation/${invitationCode}/otp`, body)
      .catch(this.errorHandler());
  }

  public async postIdentity(invitationCode: string, data: any) {
    return this.instance
      .post(`/invitation/${invitationCode}/identity`, data)
      .catch(this.errorHandler());
  }

  public async postSetPassword(
    invitationCode: string,
    userId: string,
    data: any
  ) {
    return this.instance
      .post(`/invitation/${invitationCode}/password/${userId}`, data)
      .catch(this.errorHandler());
  }

  public getEnrollmentSupportInvitation(invitationCode: string) {
    return this.instance
      .get(`/support/invitation/${invitationCode}`)
      .catch(this.errorHandler());
  }

  public getSupportUser(employeeId: string | string[]) {
    return this.instance
      .get(`/support/user`, {
        params: {
          employeeId,
        },
      })
      .catch(this.errorHandler());
  }
}
