import { BaseIHDPRequest } from "../base-ihdp-request";

export class EnrollmentRequest extends BaseIHDPRequest {
  constructor(
    ihdpAuthenticationToken: string = "",
    XCiamApiToken: string = ""
  ) {
    const baseUrl = process.env.enrollmentApiUrl || "";

    const headers =
      XCiamApiToken === ""
        ? {
            Authorization: ihdpAuthenticationToken,
          }
        : {
            Authorization: ihdpAuthenticationToken,
            "X-CIAM-API-Token": XCiamApiToken,
          };

    super(baseUrl, headers);
  }
}
