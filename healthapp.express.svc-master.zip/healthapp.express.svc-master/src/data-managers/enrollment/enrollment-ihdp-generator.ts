import * as qs from "qs";
import { BaseRequest } from "../base-request";

export default class EnrollmentIHDPTokenGetter extends BaseRequest {
  constructor() {
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
    };

    super(`${process.env.apigeeBaseUrl}/apip/auth/v2/token`, headers);
  }

  public async generateIHDPToken() {
    try {
      const client_id = process.env.enrollmentClientId;
      const client_secret = process.env.enrollmentClientSecret;
      const res = await this.instance.post(
        ``,
        qs.stringify({
          client_id,
          client_secret,
          grant_type: "client_credentials",
        })
      );

      if (res && res.data) {
        const { access_token: accessToken } = res.data;
        return accessToken;
      }
    } catch (error) {
      this.errorHandler();
    }
  }
}
