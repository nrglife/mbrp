import { Request, Response, NextFunction } from "express";
import { EnrollmentApi } from "../data-managers/enrollment/enrollment-api";
import EnrollmentIHDPTokenGetter from "../data-managers/enrollment/enrollment-ihdp-generator";
import { getAppFirstToken } from "../utilities/authentication";

import { SchemaType } from "../middleware/schemaValidation";

type ControllerSchema = {
  getEnrollmentInvitation: SchemaType;
  postEnrollmentInvitation: SchemaType;
  postInvitationCodeOptPasscode: SchemaType;
  postEnrollmentInvitationOtp: SchemaType;
  postInvitationVerificationEmail: SchemaType;
  postIdentity: SchemaType;
  postSetPassword: SchemaType;
};

export const schema: ControllerSchema = {
  getEnrollmentInvitation: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
    ],
  },
  postEnrollmentInvitation: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
    ],
    body: [
      { name: "dateOfBirth", type: "string", required: true },
      { name: "ssn", type: "string", required: true },
      { name: "secret", type: "string", required: true },
      { name: "postalcode", type: "string", required: true },
    ],
  },
  postInvitationCodeOptPasscode: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
    ],
    body: [{ name: "passCode", type: "string", required: true }],
  },
  postEnrollmentInvitationOtp: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
      { name: "phone", type: "string", required: true },
    ],
  },
  postInvitationVerificationEmail: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
    ],
    body: [{ name: "emailAddress", type: "string", required: true }],
  },
  postIdentity: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
    ],
    body: [
      { name: "idp", type: "string", required: true },
      { name: "ciamFederationId", type: "string", required: true },
      { name: "token", type: "string", required: true },
      { name: "emailOtp", type: "string", required: true },
    ],
  },
  postSetPassword: {
    pathParameters: [
      { name: "invitationCode", type: "string", required: true },
      { name: "userId", type: "string", required: true },
    ],
    body: [{ name: "password", type: "string", required: true }],
  },
};

export default class EnrollmentController {
  public static async getEnrollmentInvitation(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const { invitationCode } = req.params;

      const enrollmentApi = new EnrollmentApi(`Bearer ${ihdpToken}`);
      const response = await enrollmentApi.getEnrollmentInvitation(
        invitationCode
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postEnrollmentInvitation(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const { invitationCode } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(`Bearer ${ihdpToken}`);
      const response = await enrollmentApi.postEnrollmentInvitation(
        invitationCode,
        body
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postInvitationCodeOptPasscode(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const { invitationCode } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(`Bearer ${ihdpToken}`);
      const response = await enrollmentApi.postInvitationCodeOptPasscode(
        invitationCode,
        body
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postEnrollmentInvitationOtp(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const { invitationCode, phone } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(`Bearer ${ihdpToken}`);
      const response = await enrollmentApi.postEnrollmentInvitationOtp(
        invitationCode,
        phone,
        body
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postInvitationVerificationEmail(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const { invitationCode } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(`Bearer ${ihdpToken}`);
      const response = await enrollmentApi.postInvitationVerificationEmail(
        invitationCode,
        body
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postIdentity(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const XCiamApiToken = await getAppFirstToken();
      const { invitationCode } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(
        `Bearer ${ihdpToken}`,
        XCiamApiToken.token
      );
      const response = await enrollmentApi.postIdentity(invitationCode, body);
      return res.status(response.status).json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async postSetPassword(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const enrollmentIHDPgetter = new EnrollmentIHDPTokenGetter();
      const ihdpToken = await enrollmentIHDPgetter.generateIHDPToken();
      const XCiamApiToken = await getAppFirstToken();
      const { invitationCode, userId } = req.params;
      const body = req.body;

      const enrollmentApi = new EnrollmentApi(
        `Bearer ${ihdpToken}`,
        XCiamApiToken.token
      );
      const response = await enrollmentApi.postSetPassword(
        invitationCode,
        userId,
        body
      );

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }
}
