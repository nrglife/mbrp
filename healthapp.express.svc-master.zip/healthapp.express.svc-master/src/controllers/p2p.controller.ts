import { Request, Response, NextFunction } from "express";
import { AWSSecretManager } from "../data-managers/aws/aws-secret-manager";
import { P2PApi } from "../data-managers/p2p-api/p2p-api";
import { SmileCDRFhirApi } from "../data-managers/smile-cdr-fhir-api/smile-cdr-fhir-api";
import { SchemaType } from "../middleware/schemaValidation";
import { StatusCode } from "../models/app-error";
import {
  getRedirectURI,
  parseScope,
  buildEncodeURI,
  PlatformTypeEnum,
} from "./helpers/p2p.helper";
import appLogger from "../utilities/app-logger";

type ControllerSchema = {
  getPayerAuthURL: SchemaType;
  postCreateAccessToken: SchemaType;
  getRequestStatusForPayer: SchemaType;
};

export const schema: ControllerSchema = {
  getPayerAuthURL: {
    pathParameters: [{ name: "payerId", type: "string", required: true }],
    queryStringParameters: [
      { name: "platformType", type: "string", required: true },
    ],
  },

  postCreateAccessToken: {
    pathParameters: [{ name: "payerId", type: "string", required: true }],
    body: [
      { name: "authCode", type: "string", required: true },
      { name: "platformType", type: "string", required: true },
    ],
  },

  getRequestStatusForPayer: {
    pathParameters: [{ name: "payerId", type: "string", required: true }],
  },
};

export default class P2PController {
  public static async getPayer(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { ciamToken } = req.headers;
      const p2pApi = new P2PApi(`${ciamToken}`);

      const response = await p2pApi.getPayer();

      return res.json({ data: response.data });
    } catch (error) {
      next(error);
    }
  }

  public static async getPayerAuthURL(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { payerId } = req.params;
      const { ciamToken } = req.headers;
      const { platformType = "" } = req.query;
      const p2pApi = new P2PApi(`${ciamToken}`);

      //get specific payer auth data form p2p api
      const response = await p2pApi.getPayerInfo(payerId);
      const { secretName = "" } = response.data;

      //get secret value payer auth data form p2p api
      const awsSecretManager = new AWSSecretManager();
      const payerAuthInfo = await awsSecretManager.getSecretValue(secretName);

      const {
        authorize_url = "",
        client_id,
        response_type,
        scope = "",
      } = payerAuthInfo;

      const params = {
        client_id,
        response_type,
        scope: parseScope(scope),
        redirect_uri: getRedirectURI(`${platformType}`),
      };

      const data = {
        authorize_uri: buildEncodeURI(authorize_url, params),
      };

      return res.json({ data });
    } catch (error) {
      next(error);
    }
  }

  public static async postCreateAccessToken(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { payerId } = req.params;
      const { ciamToken } = req.headers;
      const { authCode, platformType } = req.body;
      const p2pApi = new P2PApi(`${ciamToken}`);

      //get specific payer auth data form p2p api
      const response = await p2pApi.getPayerInfo(payerId);
      const { secretName = "" } = response.data;

      //get secret value payer auth data form p2p api
      const awsSecretManager = new AWSSecretManager();
      const payerAuthInfo = await awsSecretManager.getSecretValue(secretName);
      let payerAuthTokens
      const {
        token_url = "",
        client_secret,
        client_id,
        grant_type,
        scope = "",
      } = payerAuthInfo;

      //get access token and refresh token
      const smileCDRFhirApi = new SmileCDRFhirApi(token_url, {
        client_id,
        client_secret,
      });
      try {
        payerAuthTokens = await smileCDRFhirApi.postSmilecdrPayerToken({
          client_id,
          code: authCode,
          client_secret,
          redirect_uri: getRedirectURI(platformType),
          grant_type,
          scope: parseScope(scope),
        });
      } catch (e) {
        appLogger.error(`payerAuthTokens`, e);
        appLogger.log(`payerAuthTokens error ${JSON.stringify(e)}`);
        throw(e)

      }

      const { access_token = "", refresh_token = "" } = payerAuthTokens?.data;

      //post specific payer auth data with p2p
      const postResponse = await p2pApi.postPayerInfo(payerId, {
        access_token,
        refresh_token,
      });

      return res.status(StatusCode.Success).send();
    } catch (error) {
      next(error);
    }
  }

  public static async getRequestStatusForPayer(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { payerId } = req.params;
      const { ciamToken } = req.headers;
      const p2pApi = new P2PApi(`${ciamToken}`);

      const response = await p2pApi.getRequestStatusForPayer(payerId);

      return res.json({ data: response.data });
    } catch (error) {
      next(error);
    }
  }
}
