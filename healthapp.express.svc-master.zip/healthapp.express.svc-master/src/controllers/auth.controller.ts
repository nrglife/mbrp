import { Request, Response, NextFunction } from "express";
import appLogger from "../utilities/app-logger";
import { getAccessTokenFromCode } from "../utilities/authentication";
import { AppError, StatusCode } from "../models/app-error";

export default class AuthController {
  public static async getAuthCodeFlow(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { code, apikey } = req.query;
      const originalRedirectUri = `${process.env.currentServerBaseUrl}/authCodeFlow?apikey=${apikey}`;
      appLogger.log("Original redirect url " + originalRedirectUri);
      let accessToken = null;

      try {
        if (code) {
          accessToken = await getAccessTokenFromCode(
            `${code}`,
            originalRedirectUri
          );
        }
      } catch (error) {
        appLogger.error(
          "Error while trying to get access token from code.",
          error
        );
      }

      const chcTraceID = req.headers["chcTraceID"];
      res.header("Access-Control-Allow-Origin", "*");
      res.header("Access-Control-Allow-Credentials");
      let resBody = {};
      if (accessToken) {
        res.header("Location", `${process.env.memberPortalBaseUrl}/auth`);
        res.header(
          "Set-Cookie",
          `accessToken=${JSON.stringify(accessToken)};Domain=${
            process.env.memberPortalDomain
          };Path=/auth;SameSite=Lax`
        );
        resBody = {
          success: true,
          message: AppError.Success.errorDescription,
          chcTraceID: chcTraceID,
        };
      } else {
        res.header(
          "Location",
          `${process.env.memberPortalBaseUrl}/auth#error=1`
        );
        resBody = {
          success: false,
          message: AppError.NotAuthenticated.errorDescription,
          chcTraceID: chcTraceID,
        };
      }

      return res.status(StatusCode.MovedPermanently).json(resBody);
    } catch (error) {
      next(error);
    }
  }
}
