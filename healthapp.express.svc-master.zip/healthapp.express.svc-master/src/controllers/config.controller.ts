import { Request, Response, NextFunction } from "express";
import { AppConfig } from "../models/app-config";

class AppConfigController {
  public static getConfig(req: Request, res: Response, next: NextFunction) {
    try {
      const dataToSend = new AppConfig();
      return res.json({
        data: dataToSend,
      });
    } catch (error) {
      next(error);
    }
  }
}

export default AppConfigController;
