import { Request, Response, NextFunction } from "express";
import { ConsentApi } from "../data-managers/consent-api/consent-api";
import { SchemaType } from "../middleware/schemaValidation";

type ControllerSchema = {
  getContract: SchemaType;
  getConsent: SchemaType;
  postConsent: SchemaType;
};

export const schema: ControllerSchema = {
  getContract: {
    queryStringParameters: [
      { name: "applicationId", type: "string", required: true },
    ],
  },

  getConsent: {
    queryStringParameters: [
      { name: "applicationId", type: "string", required: true },
    ],
  },

  postConsent: {
    body: [
      { name: "contractId", type: "string", required: true },
      { name: "consentFlag", type: "boolean", required: true },
      { name: "mac", type: "string" },
      { name: "deviceInfo", type: "string" },
    ],
  },
};

export default class ConsentController {
  public static async getContract(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { applicationId } = req.query;
      const { ciamToken } = req.headers;
      const consentApi = new ConsentApi(`${ciamToken}`);

      const response = await consentApi.getContract({ applicationId });

      return res.json({
        ...response.data,
      });
    } catch (error) {
      next(error);
    }
  }

  public static async getConsent(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { applicationId } = req.query;
      const { ciamToken } = req.headers;
      const consentApi = new ConsentApi(`${ciamToken}`);

      const response = await consentApi.getConsent({ applicationId });

      return res.json({ data: response.data });
    } catch (error) {
      next(error);
    }
  }

  public static async postConsent(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { ciamToken } = req.headers;
      const consentApi = new ConsentApi(`${ciamToken}`);

      const response = await consentApi.postConsent(req.body);
      return res.json({ ...response.data });
    } catch (error) {
      next(error);
    }
  }
}
