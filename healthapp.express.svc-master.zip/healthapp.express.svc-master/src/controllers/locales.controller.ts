import { Request, Response, NextFunction } from "express";
//locale files
import { DefaultLocales } from "@healthcareapp/connected-health-translation";

class AppLocalesController {
  public static getLocales(req: Request, res: Response, next: NextFunction) {
    try {
      const language = `${req.query?.language}`;

      const dataToSend = {
        ...DefaultLocales,
      };

      if (language && language in dataToSend) {
        const filteredData = {};
        (filteredData as any)[language] = (dataToSend as any)[language];
        return res.json({
          data: filteredData,
        });
      }

      return res.json({
        data: dataToSend,
      });
    } catch (error) {
      next(error);
    }
  }
}

export default AppLocalesController;
