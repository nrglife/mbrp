export enum PlatformTypeEnum {
  WEB = "web",
  MOBILE = "mobile",
}

export const getRedirectURI = (platformType: string) => {
  const webRedirectURL =
    process.env.MODE === "development"
      ? `http://localhost:5020/p2pauth`
      : `${process.env.memberPortalBaseUrl}/p2pauth`;

  const mobileRedirectURL = "healthapp://p2pauth";

  return PlatformTypeEnum.WEB === platformType
    ? webRedirectURL
    : mobileRedirectURL;
};

export const parseScope = (scope: string) => {
  return scope.split(",").join(" ");
};

export const buildEncodeURI = (baseURL: string, queryParams: object) => {
  const URI = `${baseURL}?${Object.keys(queryParams)
    .map((key) => `${key}=${(queryParams as any)[key]}`)
    .join("&")}`;

  return encodeURI(URI);
};
