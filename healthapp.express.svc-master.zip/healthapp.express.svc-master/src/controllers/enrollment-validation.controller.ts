import { Request, Response, NextFunction } from "express";
import { EnrollmentValidationApi } from "../data-managers/enrollment-validation/enrollment-validation-api";
import { SchemaType } from "../middleware/schemaValidation";

type ControllerSchema = {};

export const schema: ControllerSchema = {};

export default class EnrollmentValidationController {
  public static async getEnrollment(
    req: Request,
    res: Response,
    next: NextFunction
  ) {
    try {
      const { ciamToken } = req.headers;
      const enrollmentValidationApi = new EnrollmentValidationApi(
        `${ciamToken}`
      );

      const response = await enrollmentValidationApi.getEnrollment();

      return res.json({
        data: response.data,
      });
    } catch (error) {
      next(error);
    }
  }
}
