import { Response, Request, NextFunction } from "express";
//developed
import appLogger from "../utilities/app-logger";
import { getIHDPToken } from "../utilities/authentication";

const addCIAMTokenHeaders = (req: Request, res: Response) => {
  const xAuthorizationHeader = req.headers["x-authorization"];

  appLogger.debug(`VALIDATE TOKEN`);
  //VALIDATION SHOULD BE PERFORMED ON TOKEN WITHOUT BEARER PREFIX
  //API CALL NEEDS THE "BEARER" prefix
  req.headers["ciamToken"] = "Bearer " + xAuthorizationHeader;
};

const addIHDPTokenHeaders = async (req: Request, res: Response) => {
  const tokenWithTraceID = await getIHDPToken();
  req.headers["chcTraceID"] = tokenWithTraceID?.traceID;
  const newToken = tokenWithTraceID?.token;

  if (newToken) req.headers["ihdpToken"] = `Bearer ${newToken}`;
};

export const withAuthorization = async (
  req: Request,
  res: Response,
  next: NextFunction,
  isWithAuthorization: {
    useCIAM?: boolean;
    useIHDP?: boolean;
  } = {}
) => {
  try {
    const { useCIAM = true, useIHDP = true } = isWithAuthorization;
    if (useCIAM) {
      addCIAMTokenHeaders(req, res);
    }
    if (useIHDP) {
      await addIHDPTokenHeaders(req, res);
    }

    next();
  } catch (error) {
    next(error);
  }
};
