import { Request, Response, NextFunction, response } from "express";
import appLogger from "../utilities/app-logger";

const initIdTracing = (req: Request, res: Response, next: NextFunction) => {
  appLogger.setTraceId(`${req.headers["X-Trace-Id"]}`);
  next();
};

export default initIdTracing;
