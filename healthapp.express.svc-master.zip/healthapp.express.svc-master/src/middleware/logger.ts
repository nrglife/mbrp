import { Request, Response, NextFunction } from "express";

const logger = (req: Request, res: Response, next: NextFunction) => {
  const date = new Date();
  let logData = {
    type: "request",
    timeStart: date.toISOString(),
    userAgent: req.headers["user-agent"] + "" || "",
    protocol: req.protocol,
    cookies: req.cookies,
    method: req.method,
    uri: req.originalUrl,
    query: req.query ? JSON.stringify(req.query) : "",
    host: req.get("host") || "",
  };

  console.log("\n");
  console.log(
    `${
      logData.timeStart
    } - [${logData.type.toUpperCase()}] - ${logData.method.toUpperCase()} - ${
      logData.protocol
    } - ${logData.host}${logData.uri} - Query: ${
      logData.query
    } - Cookies: ${JSON.stringify(logData.cookies)} - User Agent - ${
      logData.userAgent
    }`
  );

  //loging the respons body
  const [oldWrite, oldEnd] = [res.write, res.end];
  const chunks: Buffer[] = [];

  (res.write as unknown) = function (chunk: any) {
    chunks.push(Buffer.from(chunk));
    (oldWrite as Function).apply(res, arguments);
  };

  res.end = function (chunk) {
    if (chunk) {
      chunks.push(Buffer.from(chunk));
    }
    const body = Buffer.concat(chunks).toString();

    const resDate = new Date();

    const responseLogData = {
      type: "response",
      time: date.toISOString(),
      userAgent: req.headers["user-agent"] + "" || "",
      protocol: req.protocol,
      cookies: req.cookies,
      method: req.method,
      uri: req.originalUrl,
      query: req.query ? JSON.stringify(req.query) : "",
      host: req.get("host") || "",
      processingTime: `${(resDate.getTime() - date.getTime()) / 1000} s`,
      statusCode: res.statusCode,
      data: res.statusCode === 200 ? {} : body,
    };

    (oldEnd as Function).apply(res, arguments);

    console.log("\n");
    console.log(
      `${responseLogData.time} - [${responseLogData.type.toUpperCase()}] - [${
        responseLogData.statusCode
      }] - ${responseLogData.method.toUpperCase()} - ${
        responseLogData.protocol
      } - ${responseLogData.host}${responseLogData.uri} - Query: ${
        responseLogData.query
      } - Cookies: ${JSON.stringify(responseLogData.cookies)} - User Agent - ${
        responseLogData.userAgent
      } - Processing Time: ${
        responseLogData.processingTime
      } - Data: ${JSON.stringify(responseLogData.data)}`
    );
  };

  next();
};

export default logger;
