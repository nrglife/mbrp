import { Request, Response, NextFunction } from "express";
import { AppError } from "../models/app-error";
import appLogger from "../utilities/app-logger";

const responseNormalizer = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let oldSend = res.send;
  res.send = (data: any) => {
    let modifiedResponseBody = data;
    try {
      const body = typeof data === "object" ? data : JSON.parse(data);
      const chcTraceID = req.headers["chcTraceID"] || req.headers["X-Trace-Id"];

      if (typeof body === "object") {
        const updatedBody = {
          success: true,
          message: AppError.Success.errorDescription,
          chcTraceID: chcTraceID,
          status: res.statusCode,
          //if response was handled by error middleware:
          //success, message and status will be run over with the same keys and values found in the body that was changed by the error middleware
          ...body,
        };
        modifiedResponseBody = JSON.stringify(updatedBody);
      }
    } catch (error) {
      appLogger.error("Error:", error);
    }

    res.send = oldSend; // set function back to avoid the 'double-send'
    return res.send(modifiedResponseBody); // just call as normal with data
  };

  next();
};

export default responseNormalizer;
