import { Request, Response, NextFunction } from "express";
import { AppError, AppErrorWithData, StatusCode } from "../models/app-error";

export type QueryParameterType = {
  name: string;
  type:
    | "number"
    | "string"
    | "boolean"
    | "function"
    | "object"
    | "symbol"
    | "bigint"
    | "undefined";
  required?: boolean;
};

export type SchemaType = {
  queryStringParameters?: QueryParameterType[];
  body?: QueryParameterType[];
  pathParameters?: QueryParameterType[];
};

export type ControllerSchema = {
  [key: string]: SchemaType;
};

export type InputSchemaError = {
  paramName: string;
  message: string;
};

const schemaValidation = (
  req: Request,
  res: Response,
  next: NextFunction,
  inputSchema: SchemaType
) => {
  //if middleware were used without inputSchema param
  if (!inputSchema) return next();

  const inputSchemaErrors: InputSchemaError[] = [];

  for (const key in inputSchema) {
    switch (key) {
      case "queryStringParameters":
        const queryStringParameters = inputSchema[key] || [];
        for (const param of queryStringParameters) {
          const paramFromReq = req.query[param.name];

          const isParamExist =
            //for null && undefined
            paramFromReq != null &&
            //for values -  0, empty string "" or boolean false to not change isParamExist to false
            Object.keys(req.query).indexOf(param.name) != -1;
          const missingRequiredParameter = param.required && !isParamExist;

          const wrongTypeOfRequiredParameter =
            param.required &&
            isParamExist &&
            typeof paramFromReq !== param.type;

          const errorMsg = missingRequiredParameter
            ? `missing required query parameter - ${param.name}`
            : wrongTypeOfRequiredParameter
            ? `wrong type of required query parameter - ${
                param.name
              } - required type ${
                param.type
              } - actual type ${typeof paramFromReq}`
            : "";

          const error: InputSchemaError = {
            paramName: param.name,
            message: errorMsg,
          };

          (missingRequiredParameter || wrongTypeOfRequiredParameter) &&
            inputSchemaErrors.push(error);
        }
        break;

      case "body":
        const bodyParameters = inputSchema[key] || [];
        for (const param of bodyParameters) {
          const paramFromReq = req.body[param.name];

          const isParamExist =
            //for null && undefined
            paramFromReq != null &&
            //for values -  0, empty string "" or boolean false to not change isParamExist to false
            Object.keys(req.body).indexOf(param.name) != -1;
          const missingRequiredParameter = param.required && !isParamExist;

          const wrongTypeOfRequiredParameter =
            param.required &&
            isParamExist &&
            typeof paramFromReq !== param.type;

          const errorMsg = missingRequiredParameter
            ? `missing required body parameter - ${param.name}`
            : wrongTypeOfRequiredParameter
            ? `wrong type of required body parameter - ${
                param.name
              } - required type ${
                param.type
              } - actual type ${typeof paramFromReq}`
            : "";

          const error: InputSchemaError = {
            paramName: param.name,
            message: errorMsg,
          };

          (missingRequiredParameter || wrongTypeOfRequiredParameter) &&
            inputSchemaErrors.push(error);
        }
        break;

      case "pathParameters":
        const pathParameters = inputSchema[key] || [];
        for (const param of pathParameters) {
          const paramFromReq = req.params[param.name];

          const isParamExist =
            //for null && undefined
            paramFromReq != null &&
            //for values -  0, empty string "" or boolean false to not change isParamExist to false
            Object.keys(req.params).indexOf(param.name) != -1;
          const missingRequiredParameter = param.required && !isParamExist;

          const wrongTypeOfRequiredParameter =
            param.required &&
            isParamExist &&
            typeof paramFromReq !== param.type;

          const errorMsg = missingRequiredParameter
            ? `missing required path parameter - ${param.name}`
            : wrongTypeOfRequiredParameter
            ? `wrong type of required path parameter - ${
                param.name
              } - required type ${
                param.type
              } - actual type ${typeof paramFromReq}`
            : "";

          const error: InputSchemaError = {
            paramName: param.name,
            message: errorMsg,
          };

          (missingRequiredParameter || wrongTypeOfRequiredParameter) &&
            inputSchemaErrors.push(error);
        }
        break;
      default:
        break;
    }
  }

  //there was error
  if (inputSchemaErrors.length > 0) {
    const throwException = AppError.RequestValidation;

    const error = new AppErrorWithData(throwException, {
      status: StatusCode.BadRequest,
      meta: inputSchemaErrors,
    });

    return next(error);
  } else {
    //no error in schema
    next();
  }
};

export default schemaValidation;
