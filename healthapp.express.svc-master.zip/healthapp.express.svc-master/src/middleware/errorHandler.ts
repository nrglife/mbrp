import { Request, Response, NextFunction } from "express";
//developed
import { BaseRequestErrorType } from "../data-managers/base-request";
import { AppError, AppErrorWithData } from "../models/app-error";
//Define error-handling middleware functions in the same way as other middleware functions, except with four arguments instead of three,
// specifically with the signature (err, req, res, next)):
//For details about error-handling middleware, see: https://expressjs.com/en/guide/error-handling.html
export const errorHandler = (
  err: BaseRequestErrorType,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let error: AppError;
  let meta: any = null;

  if (err instanceof AppError) {
    error = err;
  } else if (err instanceof AppErrorWithData) {
    error = err.error;
    meta = err.data;
  } else {
    error = AppError.ErrorPerformingAction;

    if (!meta) {
      meta = err;
    }
  }

  //change message to exceptionMessage
  if (meta && meta.message) {
    meta.exceptionMessage = meta.message;
    delete meta.message;
  }

  res.status(error.statusCode).json({
    success: false,
    message: error.errorDescription,
    chcTraceID: req.headers["chcTraceID"],
    meta,
  });
};

export default errorHandler;
