import { Request, Response, NextFunction, response } from "express";

const nocache = (req: Request, res: Response, next: NextFunction) => {
  // Disable caching for content files
  res.header("Cache-Control", "no-cache, no-store, must-revalidate");
  res.header("Pragma", "no-cache");
  res.header("Expires", "0");
  next();
};

export default nocache;
