import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import dotenvExpand from "dotenv-expand";

//load env vars from env file only if in development mode
if (process.env.MODE === "development") {
  console.log("\x1b[33m" + "\nrun server in development mode");
  console.log(`try to load .env.${process.env.NODE_ENV} file`);
  try {
    const pathToEnvFile = path
      .join(__dirname, `.env.${process.env.NODE_ENV}`)
      .trim();
    //check if env file exist
    if (fs.existsSync(pathToEnvFile)) {
      //load environment vars
      const myEnv = dotenv.config({
        path: pathToEnvFile,
      });
      dotenvExpand(myEnv);
      console.log("\x1b[32m" + "environment variables loaded successfully");
    } else {
      console.log(
        "\x1b[31m" +
          `.env.${process.env.NODE_ENV} file dosn't exists in the config folder`
      );
      console.log(`environment variables loading failed`);
    }
  } catch (error) {
    console.log("\x1b[31m" + "Error:");
    console.error(error);
  }
}
