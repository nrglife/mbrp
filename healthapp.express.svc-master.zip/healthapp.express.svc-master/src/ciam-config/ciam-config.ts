export const getCiamConfig = () => {
  return {
    baseUrl: "https://sso-test.changehealthcare.com",
    clientId: "IIN2-eof49T7l1Lh71",
    clientSecret:
      "PCYgHCAW06KzUWco1BNw1aI3g6PkC9IfO4AAlOEf5IWf6cOhF0AejE07kGjpeSkN",
    redirect: process.env.authRedirectUrl,
  };
};
