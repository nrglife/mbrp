# CommonConnectedHealth

CommonConnectedHealth is a package of services and stores used by both the Connected Health mobile app and the Payer portal Web app.

# Befor Installation

**If you dont have user in HealthcareApp gitlab group you will not be able to install this package**

## Set npm configuration with the next commands:

### Set URL for your scoped packages.

```bash
npm config set @healthcareapp:registry https://gitlab.healthcareit.net/api/v4/packages/npm/
```

### Add the token for the scoped packages URL. This will allow you to download

```bash
npm config set '//gitlab.healthcareit.net/api/v4/packages/npm/:_authToken' "ivkm1ZMK8DEazkRzKxjx"
```

### Add token for uploading to the registry.

**This command only need to be done if publish package in needed**

```bash
npm config set '//gitlab.healthcareit.net/api/v4/projects/25794/packages/npm/:_authToken' "ivkm1ZMK8DEazkRzKxjx"
```

# OR

## Creat .npmrc file with the following config:

**The last line in the .npmrc only need to be added if publish package in needed**

```bash
@healthcareapp:registry=https://gitlab.healthcareit.net/api/v4/packages/npm/
//gitlab.healthcareit.net/api/v4/packages/npm/:_authToken=ivkm1ZMK8DEazkRzKxjx
//gitlab.healthcareit.net/api/v4/projects/25794/packages/npm/:_authToken=ivkm1ZMK8DEazkRzKxjx
```

# Installation

**If you dont have user in HealthcareApp gitlab group you will not be able to install this package**

### With npm:

```bash
npm i @healthcareapp/connected-health-common-services
```

### With yarn:

```bash
yarn add @healthcareapp/connected-health-common-services
```

# Publish Package

**Before publishing the package make sure you done the right npm configuration**

### With npm:

**DEVELOP branch - Publish cmd with auto-increment vresion and auto build:**

```bash
npm run publish:dev
```

**MASTER branch - Publish cmd with auto-increment vresion and auto build:**

```bash
npm run publish:patch
```

```bash
npm run publish:minor
```

```bash
npm run publish:major
```

### With yarn:

**Normal publish:**

```bash
yarn run build
yarn publish
```

**Publish cmd with auto-increment vresion and auto build:**

```bash
yarn run publish:patch
```

```bash
yarn run publish:minor
```

```bash
yarn run publish:major
```
