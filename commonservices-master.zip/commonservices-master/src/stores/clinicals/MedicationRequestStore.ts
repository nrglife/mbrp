import { observable, action, decorate, runInAction, toJS, computed } from 'mobx';
import { injectable } from 'inversify';

import { I18nCommonType, IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Dosage, Medication, MedicationRequest, Organization, Practitioner, Patient } from '../../utilities/fhir/clinicals/clinicals-types';
import { Bundle_Entry, ContainedReference, Reference, Resource } from '../../utilities/fhir/types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { getCodeableCodeValue, getCodeableDisplayValue, getFirstIncludedByReferenceId, getFullName } from '../../utilities/fhir/helper';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { DisplayableHealthProfileItem, FieldData, FieldType, HealthProfileDisplayableType, ItemStatus, ItemTitle, SortOptions } from './types';

import { failureSource } from '../..';
import AppConfigStore from '../AppConfigStore';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';

export enum MedicationStatus {
  Active = 'active'
}

export enum MedicationStatusColor {
  Green = '#358600',
  Grey = '#626d8a'
}

@injectable()
class MedicationRequestStore extends ClinicalsBaseStore<MedicationRequest> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.MedicationRequest,
      LocaleKeys.screens.Clinical.Medications.medications,
      {
        sortBy: FieldsToArrangeBy.Autoredon,
        sortOptions: SortOptions.Descending,
        groupBySorted: true
      },
      failureSource.Clinical_Get_Medication_Requests,
      failureSource.Clinical_Invalid_Medication_Requests
    );
  }

  protected groupBySortedImpl(): {} {
    const isGrouped = this.listSettings.groupBySorted && this.listSettings.sortBy && this.listSettings.sortBy != '';

    let groupedRequests = null;
    if (isGrouped && this.listSettings.sortBy == FieldsToArrangeBy.Autoredon) {
      groupedRequests = this.FilteredDisplayableList.reduce((groupedRequests, item) => {
        const date = Array.isArray(item.secondaryTitle.data) ? item.secondaryTitle.data[0] : item.secondaryTitle.data ?? '';
        if (!groupedRequests[date]) {
          groupedRequests[date] = [];
        }

        groupedRequests[date].push(item);
        return groupedRequests;
      }, {});
    }
    return groupedRequests;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getMedicationRequests.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  ////DATA RELATED
  getRequesterName(requesterReference: Reference | null | undefined) {
    let fullName: string | null | undefined = null;

    const requesterResource = getFirstIncludedByReferenceId(this.includedResources, requesterReference?.reference);

    switch (requesterResource?.resourceType) {
      case ClinicalsResourcesTypes.Practitioner:
        fullName = requesterResource ? getFullName((requesterResource as Practitioner)?.name) : null;

        break;
      case ClinicalsResourcesTypes.Patient:
        fullName = requesterResource ? getFullName((requesterResource as Patient)?.name) : null;

        break;
      case ClinicalsResourcesTypes.Organization:
        fullName = requesterResource ? (requesterResource as Organization).name : null;
        break;
    }
    return fullName;
  }

  getDosageInstructionsText(dosages: Dosage[] | null | undefined) {
    const dosage = dosages && dosages.find(dosage => dosage.text && dosage.text.trim() !== '');
    return dosage ? dosage.text : '';
  }

  getMedicationDataByReference(medicationReference: Reference | null | undefined) {
    let medication: Medication | null | undefined = null;
    if (medicationReference && medicationReference.reference && medicationReference.reference !== '') {
      medication = getFirstIncludedByReferenceId(this.includedResources, medicationReference.reference, ClinicalsResourcesTypes.Medication) as Medication;

      return medication;
    }
    return null;
  }

  getMedicationStatus(medicationStatus: string | null | undefined) {
    if (!!medicationStatus === false) return null;

    switch (medicationStatus?.trim().toLowerCase()) {
      case MedicationStatus.Active:
        return new ItemStatus(MedicationStatus.Active, MedicationStatusColor.Green);
      default:
        return new ItemStatus(medicationStatus?.trim().toLowerCase(), MedicationStatusColor.Grey);
    }
  }

  getPrescribedDate(medicationRequest: MedicationRequest | null | undefined) {
    return isValidDate(medicationRequest?.authoredOn) ? formatDate(medicationRequest?.authoredOn, FULL_DATE_FORMAT, false) : null;
  }

  getMedicationDescription(medicationReference: Reference | null | undefined) {
    let medication: Medication | null | undefined;
    medication = this.getMedicationDataByReference(medicationReference);
    return getCodeableDisplayValue(medication?.code);
  }

  getMedicationCode(medicationReference: Reference | null | undefined) {
    let medication: Medication | null | undefined;
    medication = this.getMedicationDataByReference(medicationReference);
    return getCodeableCodeValue(medication?.code);
  }

  prepareDisplayableItem(item: MedicationRequest): DisplayableHealthProfileItem {
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Medications.medicationTypeName);

    let items: FieldData[] = [];

    //TITLE

    let title = new ItemTitle(this.getMedicationDescription(item?.medicationReference), this.getMedicationCode(item?.medicationReference));

    //Secondary Title
    const prescribedDate = this.getPrescribedDate(item);
    let secondaryTitle = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Medications.prescribed), FieldType.flat, null, prescribedDate);

    // status

    const medicationStatus = this.getMedicationStatus(item?.status);

    //ITEMS
    //1. Requested By
    const requestedByContent = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Medications.requestedBy), FieldType.flat, null, this.getRequesterName(item?.requester));

    //2. Dosage
    const dosageInstructions = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Medications.dosage), FieldType.flat, null, this.getDosageInstructionsText(item?.dosageInstruction));

    requestedByContent && requestedByContent.data && items.push(requestedByContent);
    dosageInstructions && dosageInstructions.data && items.push(dosageInstructions);

    return new DisplayableHealthProfileItem({
      type: HealthProfileDisplayableType.medication,
      typeName,
      titles: [title],
      secondaryTitle,
      status: medicationStatus,
      extendedInfo: [
        {
          title: '',
          detailedViewOnly: false,
          items: [items]
        }
      ],
      isValidToShow: this.isItemValidToShow(title, medicationStatus?.name)
    });
  }
}

export default MedicationRequestStore;
export { MedicationRequestStore as MedicationRequestStoreType };
