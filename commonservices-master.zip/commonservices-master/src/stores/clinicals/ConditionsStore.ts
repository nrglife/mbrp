import { observable, action, decorate, runInAction, computed, toJS } from 'mobx';
import { injectable } from 'inversify';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';

import { I18nCommonType, IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Condition } from '../../utilities/fhir/clinicals/clinicals-types';
import { Bundle_Entry, Reference, Resource } from '../../utilities/fhir/types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { HTTP_STATUS_CODES, ApiError } from '../../services/apis/base-api';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { getCodeableDisplayValue, getCodeableCodeValue } from '../../utilities/fhir/helper';
import {
  ListSettings,
  DisplayableHealthProfileData,
  DisplayableHealthProfileItem,
  FieldData,
  FieldType,
  GroupedDisplayableHealthProfileItem,
  ItemStatus,
  ItemTitle,
  SortOptions,
  ENTERED_IN_ERROR_STATUS_CODE,
  HealthProfileDisplayableType
} from './types';
import { AppConfigStore, ErrorStoreType } from '..';
import { failureSource } from '../..';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';

export enum ConditionSeverityStatus {
  severe = '#BF1616',
  moderate = '#FFC107',
  mild = '#358600'
}

export interface GetNextPageParams {
  numberOfRetries?: number;
}

@injectable()
class ConditionsStore extends ClinicalsBaseStore<Condition> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.Condition,
      LocaleKeys.screens.Clinical.Conditions.problemsConditions,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_Conditions,
      failureSource.Clinical_Invalid_Conditions
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getConditions.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  //CONDITIONS DATA RELATED

  getRecordedDate(condition: Condition | null | undefined) {
    return isValidDate(condition?.recordedDate) ? formatDate(condition?.recordedDate, FULL_DATE_FORMAT, false) : null;
  }

  getConditionDisplayName(condition: Condition | null | undefined) {
    return getCodeableDisplayValue(condition?.code);
  }

  getConditionSeverityLevel(condition: Condition | null | undefined) {
    return getCodeableDisplayValue(condition?.severity);
  }

  getConditionCode(condition: Condition | null | undefined) {
    return getCodeableCodeValue(condition?.code);
  }

  getConditionClinicalStatus(condition: Condition | null | undefined) {
    return getCodeableDisplayValue(condition?.clinicalStatus);
  }

  getConditionVerificationStatus(condition: Condition | null | undefined) {
    return getCodeableDisplayValue(condition?.verificationStatus);
  }

  getConditionVerificationStatusCode(condition: Condition | null | undefined) {
    return getCodeableCodeValue(condition?.verificationStatus);
  }

  prepareDisplayableItem(item: Condition): DisplayableHealthProfileItem {
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Conditions.conditionTypeName);
    let items: FieldData[] = [];
    //ITEMS
    //1. Clinical Status
    const clinicalStatus = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Conditions.clinicalStatus), FieldType.flat, null, this.getConditionClinicalStatus(item));

    //2. Verification Status

    const verificationStatus = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Conditions.verificationStatus), FieldType.flat, null, this.getConditionVerificationStatus(item));
    items.push(clinicalStatus);
    items.push(verificationStatus);
    //TITLE

    let title = new ItemTitle(this.getConditionDisplayName(item), this.getConditionCode(item));

    //Secondary Title
    const prescribedDate = this.getRecordedDate(item);
    let secondaryTitle = new FieldData('', FieldType.flat, null, prescribedDate);

    // status

    const severityStatus = this.getConditionSeverityLevel(item);

    const severityLevelColor = ConditionSeverityStatus[severityStatus?.trim().toLowerCase()];

    const status = new ItemStatus(severityStatus, severityLevelColor, severityLevelColor === ConditionSeverityStatus.moderate);

    //contain minimal data to show

    const verificationStatusCode = this.getConditionVerificationStatusCode(item);

    return new DisplayableHealthProfileItem({
      type: HealthProfileDisplayableType.condition_problem,
      typeName,
      titles: [title],
      secondaryTitle,
      status,
      extendedInfo: [
        {
          title: '',
          detailedViewOnly: false,
          items: [items]
        }
      ],
      isValidToShow: this.isItemValidToShow(title, verificationStatusCode)
    });
  }
}

export default ConditionsStore;
export { ConditionsStore as ConditionsStoreType };
