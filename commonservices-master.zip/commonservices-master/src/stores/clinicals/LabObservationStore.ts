import { injectable } from 'inversify';
import { IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Observation, ReferenceRange } from '../../utilities/fhir/clinicals/clinicals-types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { getCodeableCodeValue, getCodeableDisplayValue, getCodeFormattedDisplayString } from '../../utilities/fhir/helper';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { DisplayableHealthProfileItem, FieldData, FieldType, HealthProfileDisplayableType, ItemStatus, ItemTitle, SortOptions } from './types';
import { failureSource } from '../..';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';
import _ from 'lodash';
import moment from 'moment';

const NORMAL = 'normal';
const BOOLEAN = 'boolean';

const TIME_REGEX = /^([01][0-9]|2[0-3]):[0-5][0-9]:([0-5][0-9]|60)(\.[0-9]+)?$/;

@injectable()
class LabObservationStore extends ClinicalsBaseStore<Observation> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.Observation,
      LocaleKeys.screens.Clinical.LabObservation.labObservation,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_LaboratoryResultObservation,
      failureSource.Clinical_Invalid_LaboratoryResultObservation
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getLaboratoryResultObservation.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  // Procedures data related

  getDescription(procedure: Observation | null | undefined) {
    return getCodeableDisplayValue(procedure?.code);
  }

  getCode(procedure: Observation | null | undefined) {
    return getCodeableCodeValue(procedure?.code);
  }

  getStatus(procedure: Observation | null | undefined) {
    return procedure?.status;
  }

  getPerformedDate(observation: Observation | null | undefined) {
    if (isValidDate(observation?.effectiveDateTime)) return formatDate(observation?.effectiveDateTime, FULL_DATE_FORMAT, false);

    const startDate = isValidDate(observation?.effectivePeriod?.start) ? formatDate(observation?.effectivePeriod?.start, FULL_DATE_FORMAT, false) : null;
    const endDate = isValidDate(observation?.effectivePeriod?.end) ? formatDate(observation?.effectivePeriod?.end, FULL_DATE_FORMAT, false) : null;

    let performedDate = null;

    if (startDate || endDate) {
      if (startDate === endDate) performedDate = `${startDate}`;
      else {
        const separatorString = startDate && endDate ? ' - ' : '';
        performedDate = `${!!startDate ? startDate : ''}${separatorString}${!!endDate ? endDate : ''}`;
      }
    }
    return performedDate;
  }

  buildRangeString(emptyValueString: string, valueLow?: string, valueHigh?: string, suffixLow = '', suffixHigh = '', prefixLow = '', prefixHigh = ''): string | undefined {
    let valueToReturn = undefined;
    if (valueLow && valueHigh) {
      valueToReturn = `${prefixLow} ${valueLow} ${suffixLow} - ${prefixHigh} ${valueHigh} ${suffixHigh}`;
    } else if (valueHigh) {
      valueToReturn = `? - ${prefixHigh} ${valueHigh} ${suffixHigh} ${emptyValueString}`;
    } else if (valueLow) {
      valueToReturn = `${prefixLow} ${valueLow} ${suffixLow} - ? ${emptyValueString}`;
    }
    return valueToReturn;
  }

  getValidStandardsRanges(item: Observation): ReferenceRange[] {
    return item.referenceRange.filter(item => item.type?.coding[0]?.code === NORMAL).filter(this.isValidRange);
  }

  buildRaceString(range: ReferenceRange): string {
    let raceString = '';
    const racesArr = range?.appliesTo?.filter(item => item.coding[0].display);
    racesArr?.length > 0 &&
      racesArr.forEach((race, index) => {
        const endOfList = racesArr.length - 1 === index ? ')' : ',';
        const startOfList = index === 0 ? '(' : '';

        race.coding.length > 0 && (raceString += `${startOfList}${race.coding[0]?.display}${endOfList}`);
      });

    return raceString;
  }

  isValidRange(range: ReferenceRange): boolean {
    return !!(range.low?.value || range.high?.value);
  }

  buildStandardRange(item: Observation): string[] {
    let standardRanges = [];
    const ranges = this.getValidStandardsRanges(item);
    ranges.forEach((range, index) => {
      const ageRange = this.buildRangeString(
        this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.fullRangeInNotAvailable),
        range.age?.low?.value?.toString(),
        range.age?.high?.value?.toString(),
        range.age?.low?.unit,
        range.age?.high?.unit,
        range.age?.low?.comparator,
        range.age?.high?.comparator
      );
      const valueRange = this.buildRangeString(
        this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.fullRangeInNotAvailable),
        range.low?.value?.toString(),
        range.high?.value?.toString(),
        range.low?.unit,
        range.high?.unit,
        range.low?.comparator,
        range.high?.comparator
      );

      standardRanges.push(`${!!ageRange ? `${this.i18n.t(LocaleKeys.screens.Settings.age)} ${ageRange}:` : ''} ${this.buildRaceString(range)} ${valueRange}`);
    });
    return standardRanges;
  }

  buildValuePeriod(item: Observation) {
    if (isValidDate(item.valuePeriod?.start) && isValidDate(item.valuePeriod?.end) && item.valuePeriod?.start === item.valuePeriod?.end) {
      return formatDate(item.valuePeriod?.start);
    } else {
      return this.buildRangeString(
        this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.fullPeriodAvailable),
        isValidDate(item.valuePeriod?.start) && formatDate(item.valuePeriod?.start),
        isValidDate(item.valuePeriod?.end) && formatDate(item.valuePeriod?.end)
      );
    }
  }

  getResult(item: Observation): string {
    const valueQuantity = item.valueQuantity?.value && `${item?.valueQuantity?.comparator?.toString() ?? ''} ${item?.valueQuantity?.value.toString()} ${item?.valueQuantity?.unit?.toString() ?? ''}`;
    const valueCodeableConcept = item?.valueCodeableConcept?.coding[0]?.display;
    const valueBoolean =
      typeof item?.valueBoolean == BOOLEAN &&
      (item?.valueBoolean ? this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.positive) : this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.negative));
    const valueInteger = item?.valueInteger?.toString();
    const valueTime = TIME_REGEX.test(item?.valueTime) && moment(item?.valueTime, 'HH:mm:ss.SSS').format('HH:mm:ss.SSS');
    const valueString = item?.valueString;
    const valueRatio =
      item?.valueRatio?.numerator?.value &&
      item?.valueRatio?.denominator?.value &&
      `${item?.valueRatio?.numerator?.value} ${item?.valueRatio?.numerator?.unit ?? ''} / ${item?.valueRatio?.denominator?.value} ${item?.valueRatio?.denominator?.unit ?? ''}`;

    const valueRange = this.buildRangeString(
      this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.fullRangeInNotAvailable),
      item.valueRange?.low?.value?.toString(),
      item.valueRange?.high?.value?.toString(),
      item.valueRange?.low?.unit,
      item.valueRange?.high?.unit,
      item.valueRange?.low?.comparator,
      item.valueRange?.high?.comparator
    );
    const valueDateTime = isValidDate(item?.valueDateTime) && formatDate(item?.valueDateTime);
    const valuePeriod = this.buildValuePeriod(item);
    const valueSampledData = item.valueSampledData && this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.resultNotViewableThisTime);

    return (
      valueQuantity ||
      valueRatio ||
      valueCodeableConcept ||
      valueBoolean ||
      valueInteger ||
      valueTime ||
      valueString ||
      valueDateTime ||
      valueRange ||
      valuePeriod ||
      valueSampledData ||
      this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.resultNotViewableThisTime)
    );
  }

  prepareDisplayableItem(item: Observation): DisplayableHealthProfileItem {
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.labObservationTypeName);
    const description = this.getDescription(item);
    const code = this.getCode(item);
    const status = this.getStatus(item);
    const result = this.getResult(item);
    const standardRange = this.getValidStandardsRanges(item).length > 0 && this.buildStandardRange(item);
    const performedDate = this.getPerformedDate(item);
    const title = new ItemTitle(description, code);

    let items: FieldData[] = [];

    !!result && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.Result), FieldType.flat, null, this.getResult(item), false, true));
    !!standardRange && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.standardRange), FieldType.collection, null, standardRange));
    !!status && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Procedures.status), FieldType.flat, null, _.upperFirst(status)));
    !!performedDate && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.LabObservation.collected), FieldType.flat, null, performedDate));

    return new DisplayableHealthProfileItem({
      type: HealthProfileDisplayableType.labObservation,
      typeName,
      titles: [title],
      extendedInfo: [
        {
          title: '',
          detailedViewOnly: false,
          items: [items]
        }
      ],
      isValidToShow: this.isItemValidToShow(title, status)
    });
  }
}

export default LabObservationStore;
export { LabObservationStore as LabObservationStoreType };
