import { observable, action, decorate, runInAction, computed, toJS } from 'mobx';
import { injectable } from 'inversify';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';

import { IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Procedure } from '../../utilities/fhir/clinicals/clinicals-types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { getCodeableDisplayValue, getCodeableCodeValue, getCodeFormattedDisplayString } from '../../utilities/fhir/helper';
import { DisplayableHealthProfileItem, FieldData, FieldType, ItemTitle, SortOptions, HealthProfileDisplayableType } from './types';
import { failureSource } from '../..';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';

export interface GetNextPageParams {
  numberOfRetries?: number;
}

@injectable()
class ProceduresStore extends ClinicalsBaseStore<Procedure> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.Procedure,
      LocaleKeys.screens.Clinical.Procedures.procedures,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_Procedure,
      failureSource.Clinical_Invalid_Procedure
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getProcedure.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  // Procedures data related

  getProcedureDescription(procedure: Procedure | null | undefined) {
    return getCodeableDisplayValue(procedure?.code);
  }

  getProcedureCode(procedure: Procedure | null | undefined) {
    return getCodeableCodeValue(procedure?.code);
  }

  getProcedureStatus(procedure: Procedure | null | undefined) {
    return procedure?.status;
  }

  getProcedureStatusDisplay(procedure: Procedure | null | undefined) {
    return getCodeFormattedDisplayString(procedure?.status);
  }

  getProcedurePerformedDate(procedure: Procedure | null | undefined) {
    return isValidDate(procedure?.performedDateTime) ? formatDate(procedure?.performedDateTime, FULL_DATE_FORMAT, false) : null;
  }

  getProcedurePerformedPeriod(procedure: Procedure | null | undefined) {
    let returnPeriod = null;

    const startDate = isValidDate(procedure?.performedPeriod?.start) ? formatDate(procedure?.performedPeriod?.start, FULL_DATE_FORMAT, false) : null;
    const endDate = isValidDate(procedure?.performedPeriod?.end) ? formatDate(procedure?.performedPeriod?.end, FULL_DATE_FORMAT, false) : null;

    if (startDate || endDate) {
      if (startDate === endDate) returnPeriod = `${startDate}`;
      else {
        const separatorString = startDate && endDate ? ' - ' : '';
        returnPeriod = `${!!startDate ? startDate : ''}${separatorString}${!!endDate ? endDate : ''}`;
      }
    }

    return returnPeriod;
  }

  prepareDisplayableItem(procedureItem: Procedure): DisplayableHealthProfileItem {
    const procedureDescription = this.getProcedureDescription(procedureItem);
    const procedureCode = this.getProcedureCode(procedureItem);
    const procedureStatus = this.getProcedureStatus(procedureItem);
    const procedureStatusDisplay = this.getProcedureStatusDisplay(procedureItem);
    const procedurePerformedDate = this.getProcedurePerformedDate(procedureItem);
    const procedurePerformedPeriod = this.getProcedurePerformedPeriod(procedureItem);

    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Procedures.procedureTypeName);
    const title = new ItemTitle(procedureDescription, procedureCode);
    const secondaryTitle = new FieldData('', FieldType.flat, null, procedurePerformedDate ? procedurePerformedDate : procedurePerformedPeriod ? procedurePerformedPeriod : null);

    let items: FieldData[] = [];
    const procedureStatusField = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Procedures.status), FieldType.flat, null, procedureStatusDisplay);
    items.push(procedureStatusField);

    return new DisplayableHealthProfileItem({
      type: HealthProfileDisplayableType.procedure,
      typeName,
      titles: [title],
      secondaryTitle,
      extendedInfo: [
        {
          title: '',
          detailedViewOnly: false,
          items: [items]
        }
      ],
      isValidToShow: this.isItemValidToShow(title, procedureStatus)
    });
  }
}

export default ProceduresStore;
export type { ProceduresStore as ProceduresStoreType };
