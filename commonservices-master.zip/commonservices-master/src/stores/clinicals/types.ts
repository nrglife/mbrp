import { Interface } from 'readline';
import { failureSource, I18nCommonType, IocContainer, IocTypes } from '../..';
import { generateRandomID } from '../../utilities/random-generator';

export const ENTERED_IN_ERROR_STATUS_CODE = 'entered-in-error';
export const US_CORE_RACE = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-race';
export const US_CORE_ETHNICITY = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity';

export enum HealthProfileDisplayableType {
  medication = 'Medication',
  condition_problem = 'Condition / Problem',
  allergy = 'Allergy',
  procedure = 'Procedure',
  implantable_device = 'Medical Implant',
  encounter = 'Visit',
  labObservation = 'labObservation',
  immunization = 'Immunization'
}

export enum NoDataType {
  error = 'error',
  not_completed = 'not_completed',
  empty = 'empty'
}

export enum FieldType {
  flat = 'flat',
  collection = 'collection'
}

export enum SortOptions {
  None = 'none',
  Descending = 'descending',
  Ascending = 'ascending'
}

export enum commonFHIRSearchFields {
  LastUpdated = '_lastUpdated'
}

export interface ListSettings {
  sortBy: string;
  sortOptions: SortOptions;
  groupBySorted: boolean;
}

export interface GetNextPageParams {
  numberOfRetries?: number;
}

export class FieldData {
  label: string;
  type: FieldType;
  code?: string;
  data?: string | string[];
  detailedViewOnly?: boolean;
  isHighlighted?: boolean;
  constructor(label: string, type: FieldType, code: string = null, data: string | string[], detailedViewOnly: boolean = false, isHighlighted: boolean = false) {
    (this.label = label), (this.type = type), (this.code = code), (this.data = data);
    this.detailedViewOnly = detailedViewOnly;
    this.isHighlighted = isHighlighted;
  }
  public isValid() {
    return (this.code != null && this.code != '') || (this.data != null && (this.data != '' || this.data?.length > 0));
  }
}

export class ItemStatus {
  name: string;
  bkgdColor: string;
  useDarkTextColor?: boolean;
  constructor(name: string, bkgdColor: string, useDarkTextColor = false) {
    (this.name = name), (this.bkgdColor = bkgdColor), (this.useDarkTextColor = useDarkTextColor);
  }
}

export class ItemTitle {
  description: string;
  code: string;
  constructor(description: string, code: string) {
    (this.description = description), (this.code = code);
  }
}

export type ExtendedInfo = {
  title?: string;
  detailedViewOnly: boolean;
  items: FieldData[][];
};

export type EmptyDataSource = {
  errorSource?: failureSource;
  errorText: string;
  type: NoDataType;
};

export interface DisplayableHealthProfileItemParams {
  id?: string;
  type?: HealthProfileDisplayableType;
  typeName?: string;
  titles: ItemTitle[];
  secondaryTitle?: FieldData | null;
  status?: ItemStatus | null;
  extendedInfo: ExtendedInfo[];
  isValidToShow: boolean;
}

export class DisplayableHealthProfileItem {
  id: string;
  type: HealthProfileDisplayableType;
  typeName: string;
  titles: ItemTitle[];
  secondaryTitle: FieldData;
  status: ItemStatus;
  extendedInfo: ExtendedInfo[];
  isValidToShow: boolean;

  constructor(params: DisplayableHealthProfileItemParams) {
    this.id = params.id || generateRandomID();
    this.type = params.type;
    this.typeName = params.typeName;
    this.titles = params.titles;
    this.secondaryTitle = params.secondaryTitle ?? null;
    this.status = params.status ?? null;
    this.extendedInfo = params.extendedInfo;
    this.isValidToShow = params.isValidToShow;
  }

  public isDetailedViewRequired() {
    return !!this.extendedInfo.find(section => {
      if (section.detailedViewOnly) {
        return true;
      }
      return !!section.items?.find(list => {
        return !!list.find(datafield => datafield.detailedViewOnly === true);
      });
    });
  }

  public setID(id: string) {
    this.id = id;
  }
}

export interface HealthProfileOverviewDataParams {
  id: string;
  pageTitle?: string;
  info: ExtendedInfo[];
  noContentToDisplay: EmptyDataSource;
}

export class HealthProfileOverviewData {
  id: string;
  pageTitle: string;
  info: ExtendedInfo[];
  noContentToDisplay: EmptyDataSource;

  constructor(params: HealthProfileOverviewDataParams) {
    this.id = params.id;
    this.pageTitle = params.pageTitle;
    this.info = params.info;
    this.noContentToDisplay = params.noContentToDisplay;
  }
}

export class GroupedDisplayableHealthProfileItem {
  groupedByTitle: string;
  data: DisplayableHealthProfileItem[];
  constructor(groupedByTitle, data) {
    this.groupedByTitle = groupedByTitle;
    this.data = data;
  }
}

export class DisplayableHealthProfileData {
  items: GroupedDisplayableHealthProfileItem[];

  recordsRemovedWarning: string | null;
  missingFieldsToDisplayWarning: string | null;
  isGrouped: boolean;
  noContentToDisplay: EmptyDataSource;
  pageTitle: string;
  constructor(
    pageTitle: string,
    recordsRemovedWarning: string,
    isGrouped: boolean,
    noContentToDisplay: EmptyDataSource,
    items: GroupedDisplayableHealthProfileItem[]
  ) {
    this.items = items;
    this.recordsRemovedWarning = recordsRemovedWarning;
    this.isGrouped = isGrouped;
    this.noContentToDisplay = noContentToDisplay;
    this.pageTitle = pageTitle;
  }
}
