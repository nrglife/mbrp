import { observable, action, computed, decorate, reaction, isComputedProp, runInAction, toJS } from 'mobx';
import { injectable, interfaces, unmanaged } from 'inversify';

import { IocContainer, IocTypes } from '../../inversify.config';

import { Bundle_Entry, Extension, Gender, Reference, Resource } from '../../utilities/fhir/types';

import { ClinicalApi, failureSource, I18nCommonType } from '../..';
import { EmptyDataSource, NoDataType, HealthProfileOverviewData, FieldData, FieldType, US_CORE_RACE, US_CORE_ETHNICITY } from './types';
import { ClinicalsResourcesTypes, Patient, Observation } from '../../utilities/fhir/clinicals/clinicals-types';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import { DelegateStore, ErrorStoreType } from '..';
import { getFullName } from '../../utilities/fhir/helper';
import { uppercaseFirstLetter } from '../../utilities/string';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { generateRandomID } from '../../utilities/random-generator';

// CURRENTLY IS NOT SUPORTED IN REACT_NATIVE
const allSettled = promises => {
  return Promise.all(promises.map(promise => promise.then(value => ({ state: 'fulfilled', value })).catch(reason => ({ state: 'rejected', reason }))));
};

@injectable()
class ClinicalsOverviewStore {
  protected patientResource: Patient;
  protected smokingStatusResource: Observation;
  protected i18n: I18nCommonType;
  @observable isLoading: boolean;
  @observable
  public displayableOverviewData: HealthProfileOverviewData;

  constructor() {
    this.init();
  }

  protected init() {
    this.patientResource = null;
    this.smokingStatusResource = null;
    this.i18n = IocContainer.get<I18nCommonType>(IocTypes.I18nProvider);
    this.setDisplayableOverviewData(null);
    this.setIsLoading(true);
  }

  protected getLanguages() {
    const languagesArr = this.patientResource?.communication?.map(cm => cm.language?.coding[0]?.display)?.filter(l => !!l);
    return languagesArr && languagesArr.length > 0 ? languagesArr.join(', ') : null;
  }

  protected getPatientExtensionDataByType(extType: string) {
    const extensionByType = this.patientResource?.extension?.find(item => item?.url == extType)?.extension;
    const arr = extensionByType?.map(item => (!!item.valueCoding?.display ? item.valueCoding?.display : item.valueString))?.filter(l => !!l);
    return arr && arr.length > 0 ? arr.join(', ') : null;
  }

  protected prepareDisplayableOverviewItem() {
    const name = getFullName(this.patientResource?.name);
    const gender =
      this.patientResource?.gender && (this.patientResource?.gender?.trim().toLocaleLowerCase() === Gender.female || this.patientResource?.gender?.trim().toLocaleLowerCase() === Gender.male)
        ? uppercaseFirstLetter(this.patientResource?.gender?.trim())
        : null;

    const birthdate = isValidDate(this.patientResource?.birthDate) ? formatDate(this.patientResource?.birthDate, FULL_DATE_FORMAT) : null;

    const languages = this.getLanguages();

    const preferredLanguage = this.patientResource?.communication?.find(cm => cm.preferred === true && cm.language?.coding[0]?.display)?.language?.coding[0].display;

    const smokingStatus = this.smokingStatusResource?.valueCodeableConcept?.coding[0]?.display;

    const race = this.getPatientExtensionDataByType(US_CORE_RACE);

    const ethnicity = this.getPatientExtensionDataByType(US_CORE_ETHNICITY);

    let patientDetails: FieldData[] = [];
    !!name && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.name), FieldType.flat, null, name));
    !!gender && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.gender), FieldType.flat, null, gender));
    !!birthdate && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.born), FieldType.flat, null, birthdate));
    !!languages && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.languages), FieldType.flat, null, languages));
    !!preferredLanguage && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.preferred_language), FieldType.flat, null, preferredLanguage));
    !!race && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.race), FieldType.flat, null, race));
    !!ethnicity && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.ethnicity), FieldType.flat, null, ethnicity));
    !!smokingStatus && patientDetails.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Overview.smoking_status), FieldType.flat, null, smokingStatus));

    this.setDisplayableOverviewData(
      new HealthProfileOverviewData({
        id: this.patientResource?.id ?? generateRandomID(),
        pageTitle: this.i18n.t(LocaleKeys.screens.Clinical.Overview.hp_overview),
        info: [
          {
            title: '',
            detailedViewOnly: false,
            items: [patientDetails]
          }
        ],
        noContentToDisplay: this.getEmptyContentToShow()
      })
    );
  }

  @action
  public resetStore() {
    this.patientResource = null;
    this.smokingStatusResource = null;
    this.setDisplayableOverviewData(null);
    this.setIsLoading(true);
  }

  protected getEmptyContentToShow(): EmptyDataSource | null {
    const isEmpty = !this.patientResource?.name;

    const no_records_message = this.i18n.t(LocaleKeys.errors.no_records_to_show);
    const data_still_loading = this.i18n.t(LocaleKeys.errors.data_still_loading);
    const general_error_message = `${this.i18n.t(LocaleKeys.errors.something_went_wrong)}. ${this.i18n.t(LocaleKeys.errors.try_reloading_the_page)}`;

    const error = IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).getLastFilteredError(failureSource.Clinical_Get_Patient);

    const noContentToShow: EmptyDataSource | null = error
      ? {
          errorSource: error.source,
          errorText: general_error_message,
          type: NoDataType.error
        }
      : isEmpty
      ? IocContainer.get<DelegateStore>(IocTypes.DelegateStore).isMemberConsentIn12HoursRange
        ? {
            errorText: data_still_loading,
            type: NoDataType.not_completed
          }
        : {
            errorText: no_records_message,
            type: NoDataType.empty
          }
      : null;

    return noContentToShow;
  }

  @action
  public setIsLoading(value: boolean) {
    this.isLoading = value;
  }

  @action
  public setDisplayableOverviewData(value: HealthProfileOverviewData | null) {
    this.displayableOverviewData = value;
  }

  @action
  public getOverviewBaseData() {
    const getPatientData = () =>
      IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi)
        .getPatientData()
        .then(response => {
          this.patientResource =
            response?.data?.entry &&
            response?.data?.entry.length > 0 &&
            response?.data?.entry[0]?.resource?.resourceType === ClinicalsResourcesTypes.Patient &&
            (response?.data?.entry[0]?.resource as Patient);
        });

    const getSmokingStatusData = () =>
      IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi)
        .getObservationSmokingStatus()
        .then(response => {
          this.smokingStatusResource =
            response?.data?.entry &&
            response?.data?.entry.length > 0 &&
            response?.data?.entry[0]?.resource?.resourceType === ClinicalsResourcesTypes.Observation &&
            (response?.data?.entry[0]?.resource as Observation);
        });

    allSettled([getPatientData(), getSmokingStatusData()]).then(response => {
      this.prepareDisplayableOverviewItem();
      this.setIsLoading(false);
    });
  }
}
export default ClinicalsOverviewStore;
export { ClinicalsOverviewStore as ClinicalsOverviewStoreType };
