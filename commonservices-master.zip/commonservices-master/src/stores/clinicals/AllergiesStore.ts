import { observable, action, decorate, runInAction, computed, toJS } from 'mobx';
import { injectable, unmanaged } from 'inversify';

import { I18nCommonType, IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, AllergyIntolerance, AllergyIntollerance_Reaction } from '../../utilities/fhir/clinicals/clinicals-types';
import { Bundle_Entry, Reference, Resource } from '../../utilities/fhir/types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { HTTP_STATUS_CODES, ApiError } from '../../services/apis/base-api';
import { getCodeableCodeValue, getCodeableDisplayValue } from '../../utilities/fhir/helper';
import { formatDate, isValidDate, SHORT_DATE_FORMAT } from '../../utilities/dates';
import { DisplayableHealthProfileItem, FieldData, FieldType, HealthProfileDisplayableType, ItemStatus, ItemTitle, SortOptions, ExtendedInfo, DisplayableHealthProfileItemParams } from './types';

import { failureSource } from '../..';
import { uppercaseFirstLetter } from '../../utilities/string';
import AppConfigStore from '../AppConfigStore';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import { unique } from 'mobx/lib/internal';
import { ComparatorOptions } from '../../utilities/fhir/types';
import { isNumber } from '../../utilities/Numeric';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';
import { FetchDataParamsBase } from '../BaseListStore';

export enum AllergyClinicalStatus {
  Active = 'active',
  Inactive = 'inactive',
  Resolved = 'resolved'
}

export enum AllergyClinicalStatusColor {
  Active = '#626d8a',
  Inactive = '#626d8a',
  Resolved = '#358600'
}

@injectable()
class AllergiesStore extends ClinicalsBaseStore<AllergyIntolerance> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.AllergyIntolerance,
      LocaleKeys.screens.Clinical.Allergies.allergies_intolerances,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_Allergy_Intolerances,
      failureSource.Clinical_Invalid_Allergy_Intolerances
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getAllergyIntolerances.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  ////DATA RELATED
  getAllergyCategories(allergy: AllergyIntolerance | null | undefined) {
    return allergy?.category && allergy?.category.length > 0
      ? new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.category), FieldType.flat, null, allergy?.category.map(c => uppercaseFirstLetter(c)).join(', '))
      : null;
  }

  getAllergyDescription(allergy: AllergyIntolerance | null | undefined) {
    return getCodeableDisplayValue(allergy?.code);
  }

  getAllergyCode(allergy: AllergyIntolerance | null | undefined) {
    return getCodeableCodeValue(allergy?.code);
  }

  getAllergyClinicalStatus(allergy: AllergyIntolerance | null | undefined) {
    const codeValue = getCodeableCodeValue(allergy?.clinicalStatus);
    const displayValue = getCodeableDisplayValue(allergy?.clinicalStatus);

    switch (codeValue?.trim().toLowerCase()) {
      case AllergyClinicalStatus.Active:
        return new ItemStatus(displayValue ? displayValue : codeValue, AllergyClinicalStatusColor.Active);
      case AllergyClinicalStatus.Inactive:
        return new ItemStatus(displayValue ? displayValue : codeValue, AllergyClinicalStatusColor.Inactive);
      case AllergyClinicalStatus.Resolved:
        return new ItemStatus(displayValue ? displayValue : codeValue, AllergyClinicalStatusColor.Resolved);
      default:
        return null;
    }
  }

  getAllergyVerificationStatusCode(allergy: AllergyIntolerance | null | undefined) {
    return getCodeableCodeValue(allergy?.verificationStatus);
  }

  getAllergyCriticality(allergy: AllergyIntolerance | null | undefined) {
    return allergy?.criticality ? new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.severity), FieldType.flat, null, uppercaseFirstLetter(allergy?.criticality)) : null;
  }

  getAllergyOnsetInfo(allergy: AllergyIntolerance | null | undefined) {
    let onsetInfo: FieldData | null | undefined;
    if (!allergy) return null;
    switch (true) {
      case 'onsetAge' in allergy && isNumber(allergy?.onsetAge?.value):
        let ageStr = `${!!allergy.onsetAge?.comparator ? allergy.onsetAge?.comparator : ''} ${allergy.onsetAge?.value} ${!!allergy.onsetAge?.unit ? allergy.onsetAge?.unit : ''}`.trim();

        onsetInfo = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.onsetAge), FieldType.flat, null, ageStr);
        break;
      case 'onsetPeriod' in allergy && (isValidDate(allergy.onsetPeriod?.start) || isValidDate(allergy.onsetPeriod?.end)):
        let date =
          isValidDate(allergy.onsetPeriod?.start) && isValidDate(allergy.onsetPeriod?.end)
            ? `${formatDate(allergy.onsetPeriod.start, SHORT_DATE_FORMAT)} - ${formatDate(allergy.onsetPeriod.end, SHORT_DATE_FORMAT)}`
            : isValidDate(allergy.onsetPeriod?.start)
            ? `From ${formatDate(allergy.onsetPeriod?.start, SHORT_DATE_FORMAT)}`
            : `To ${formatDate(allergy.onsetPeriod?.end, SHORT_DATE_FORMAT)}`;
        onsetInfo = new FieldData('Onset Period', FieldType.flat, null, date);
        break;
      case 'onsetDateTime' in allergy && isValidDate(allergy?.onsetDateTime):
        onsetInfo = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.onsetDate), FieldType.flat, null, formatDate(allergy?.onsetDateTime, SHORT_DATE_FORMAT));
        break;
      case 'onsetString' in allergy && !!allergy?.onsetString:
        onsetInfo = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.onset), FieldType.flat, null, allergy.onsetString);
        break;
      case 'onsetRange' in allergy && (isNumber(allergy.onsetRange?.low?.value) || isNumber(allergy.onsetRange?.high?.value)):
        let lowStr = isNumber(allergy.onsetRange?.low?.value)
          ? `${!!allergy.onsetRange?.low?.comparator ? allergy.onsetRange?.low?.comparator : ''} ${allergy.onsetRange?.low?.value} ${
              !!allergy.onsetRange?.low?.unit ? allergy.onsetRange?.low?.unit : ''
            }`.trim()
          : null;
        let highStr = isNumber(allergy.onsetRange?.high?.value)
          ? `${!!allergy.onsetRange?.high?.comparator ? allergy.onsetRange?.high?.comparator : ''} ${allergy.onsetRange?.high?.value} ${
              !!allergy.onsetRange?.high?.unit ? allergy.onsetRange?.high?.unit : ''
            }`.trim()
          : null;
        let range = !!lowStr && !!highStr ? `${lowStr} - ${highStr}` : !!lowStr ? `${lowStr}` : `${highStr}`;
        onsetInfo = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.onsetRange), FieldType.flat, null, range);
        break;
      default:
        null;
    }
    return onsetInfo;
  }

  protected getReactionData(reaction: AllergyIntollerance_Reaction): FieldData[] {
    let reactionData: FieldData[] = [];
    const substance = new FieldData(
      this.i18n.t(LocaleKeys.screens.Clinical.Allergies.substance),
      FieldType.flat,
      getCodeableCodeValue(reaction?.substance),
      getCodeableDisplayValue(reaction?.substance),
      true,
      true
    );
    const description = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.description), FieldType.flat, null, reaction?.description, true);

    const onset = new FieldData(
      this.i18n.t(LocaleKeys.screens.Clinical.Allergies.onsetDate),
      FieldType.flat,
      null,
      isValidDate(reaction?.onset) && formatDate(reaction?.onset, SHORT_DATE_FORMAT),
      true
    );

    const severity = new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Allergies.reactionSeverity), FieldType.flat, null, uppercaseFirstLetter(reaction?.severity), true);

    const exposureRoute = new FieldData(
      this.i18n.t(LocaleKeys.screens.Clinical.Allergies.exposureRoute),
      FieldType.flat,
      getCodeableCodeValue(reaction?.exposureRoute),
      getCodeableDisplayValue(reaction?.exposureRoute),
      true
    );

    //Manifestations array
    let manifestations: FieldData[] = [];

    reaction?.manifestation?.forEach(manifestation => {
      let mf = new FieldData(
        this.i18n.t(LocaleKeys.screens.Clinical.Allergies.manifestation) + ' ' + `${manifestations.length + 1}`,
        FieldType.flat,
        getCodeableCodeValue(manifestation),
        getCodeableDisplayValue(manifestation),
        true
      );
      mf.isValid() && manifestations.push(mf);
    });

    if (manifestations.length === 1) manifestations[0].label = this.i18n.t(LocaleKeys.screens.Clinical.Allergies.manifestation);

    //Create the reaction content
    substance.isValid() && reactionData.push(substance);
    manifestations.forEach(m => reactionData.push(m));
    description.isValid() && reactionData.push(description);
    onset.isValid() && reactionData.push(onset);
    severity.isValid() && reactionData.push(severity);
    exposureRoute.isValid() && reactionData.push(exposureRoute);

    return reactionData;
  }

  prepareDisplayableItem(item: AllergyIntolerance): DisplayableHealthProfileItem {
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Allergies.allergyTypeName);

    //TITLE
    let title = new ItemTitle(this.getAllergyDescription(item), this.getAllergyCode(item));

    //Status
    const clinicalStatus = this.getAllergyClinicalStatus(item);

    //FieldData ITEMS

    //Category
    const categories = this.getAllergyCategories(item);

    //Onset
    const onsetInfo = this.getAllergyOnsetInfo(item);

    //Criticality/Severity
    const criticality = this.getAllergyCriticality(item);

    let items: FieldData[] = [];

    criticality && items.push(criticality);
    categories && items.push(categories);
    onsetInfo && items.push(onsetInfo);

    let reactions: FieldData[][] = [];
    item.reaction?.forEach(reaction => {
      let reactionData = this.getReactionData(reaction);
      reactionData && reactionData?.length > 0 && reactions.push(reactionData);
    });

    //fields to display:
    let info: ExtendedInfo[] = [];
    if (items?.length > 0) info.push({ title: '', detailedViewOnly: false, items: [items] });
    if (reactions?.length > 0)
      info.push({
        title: this.i18n.t(LocaleKeys.screens.Clinical.Allergies.reactions),
        detailedViewOnly: true,
        items: reactions
      });

    const displayableHealthProfileItem = new DisplayableHealthProfileItem({
      id: item.id,
      type: HealthProfileDisplayableType.allergy,
      typeName,
      titles: [title],
      status: clinicalStatus,
      extendedInfo: info,
      isValidToShow: this.isItemValidToShow(title, this.getAllergyVerificationStatusCode(item))
    });

    return displayableHealthProfileItem;
  }
}

export default AllergiesStore;
export { AllergiesStore as AllergiesStoreType };
