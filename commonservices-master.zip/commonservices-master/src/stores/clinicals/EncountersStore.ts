import { observable, action, decorate, runInAction, computed, toJS } from 'mobx';
import { injectable, unmanaged } from 'inversify';

import { I18nCommonType, IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Encounter, AllergyIntolerance, AllergyIntollerance_Reaction, Practitioner, Location } from '../../utilities/fhir/clinicals/clinicals-types';
import { Bundle_Entry, Reference, Resource } from '../../utilities/fhir/types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { HTTP_STATUS_CODES, ApiError } from '../../services/apis/base-api';
import { getCodeableCodeValue, getCodeableDisplayValue } from '../../utilities/fhir/helper';
import { formatDate, FULL_DATE_FORMAT, isValidDate, SHORT_DATE_FORMAT } from '../../utilities/dates';
import { DisplayableHealthProfileItem, FieldData, FieldType, HealthProfileDisplayableType, ItemStatus, ItemTitle, SortOptions, ExtendedInfo } from './types';

import { failureSource } from '../..';
import { titleCase, uppercaseFirstLetter } from '../../utilities/string';
import AppConfigStore from '../AppConfigStore';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import { unique } from 'mobx/lib/internal';
import { ComparatorOptions } from '../../utilities/fhir/types';
import { isNumber } from '../../utilities/Numeric';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';
import { FetchDataParamsBase } from '../BaseListStore';
import { getFirstIncludedByReferenceId, getFullName } from '../../utilities/fhir/helper';

@injectable()
class EncountersStore extends ClinicalsBaseStore<Encounter> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.Encounter,
      LocaleKeys.screens.Clinical.Encounter.visitDetails,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_Encounter,
      failureSource.Clinical_Invalid_Encounter
    );
  }

  protected groupBySortedImpl(): {} {
    console.error('GROUPING IN ENCOUNTERS IS NOT IMPLEMENTED');
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getEncounter.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  getEncounterTitles(encounter: Encounter | null | undefined) {
    let titles: ItemTitle[] = [];

    encounter?.reasonCode.forEach(codeableConcept => {
      let description = getCodeableDisplayValue(codeableConcept);
      let code = getCodeableCodeValue(codeableConcept);
      (!!description || !!code) && titles.push(new ItemTitle(description, code));
    });

    return titles;
  }

  getEncounterPeriod(encounter: Encounter | null | undefined) {
    let returnPeriod = null;

    const startDate = isValidDate(encounter?.period?.start) ? formatDate(encounter?.period?.start, FULL_DATE_FORMAT, false) : null;
    const endDate = isValidDate(encounter?.period?.end) ? formatDate(encounter?.period?.end, FULL_DATE_FORMAT, false) : null;

    if (startDate || endDate) {
      if (startDate === endDate) returnPeriod = `${startDate}`;
      else {
        const separatorString = startDate && endDate ? ' - ' : '';
        returnPeriod = `${!!startDate ? startDate : ''}${separatorString}${!!endDate ? endDate : ''}`;
      }
    }

    return new FieldData('', FieldType.flat, null, returnPeriod);
  }

  ////DATA RELATED
  getEncounterStatus(encounter: Encounter | null | undefined) {
    return new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Encounter.status), FieldType.flat, null, uppercaseFirstLetter(encounter?.status));
  }

  getEncounterPrimaryPerformer(encounter: Encounter | null | undefined) {
    let participant = null;
    for (const pnt of encounter.participant) {
      try {
        if (pnt.type[0].coding[0].code.toLowerCase() == 'pprf') {
          participant = pnt;
          break;
        }
      } catch (error) {}
    }

    const requesterResource = getFirstIncludedByReferenceId(this.includedResources, participant?.individual?.reference);
    let primaryPerformer = requesterResource ? getFullName((requesterResource as Practitioner)?.name) : null;
    return new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Encounter.primaryPerformer), FieldType.flat, null, primaryPerformer);
  }

  getEncounterLocations(encounter: Encounter | null | undefined) {
    let locationsFieldData: FieldData[] = [];

    encounter?.location.forEach(locationItem => {
      const locationResource = getFirstIncludedByReferenceId(this.includedResources, locationItem?.location?.reference);
      locationResource &&
        !!(locationResource as Location)?.name &&
        locationsFieldData.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Encounter.location), FieldType.flat, null, (locationResource as Location)?.name));
    });

    if (locationsFieldData.length > 1) for (let i = 0; i < locationsFieldData.length; i++) locationsFieldData[i].label += ` ${i + 1}`;

    return locationsFieldData;
  }

  getDischargeDisposition(encounter: Encounter | null | undefined) {
    let dischargeDispositionCode = getCodeableCodeValue(encounter?.hospitalization?.dischargeDisposition);
    if (dischargeDispositionCode?.toLocaleLowerCase() !== 'exp')
      return new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Encounter.dischargeDisposition), FieldType.flat, null, getCodeableDisplayValue(encounter?.hospitalization?.dischargeDisposition));
    else return null;
  }

  prepareDisplayableItem(item: Encounter): DisplayableHealthProfileItem {
    // change to encounterTypeName
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Encounter.visit);

    //TITLES
    const titles = this.getEncounterTitles(item);
    //DATE
    const secondaryTitle = this.getEncounterPeriod(item);

    //FieldData ITEMS

    //Encounter Status
    const encounterStatus = this.getEncounterStatus(item);

    //Primary Performer
    const primaryPerformer = this.getEncounterPrimaryPerformer(item);

    //Encounter Locations
    const encounterLocations = this.getEncounterLocations(item);

    //Discharge Disposition
    const dischargeDisposition = this.getDischargeDisposition(item);

    let items: FieldData[] = [];

    encounterStatus && items.push(encounterStatus);
    primaryPerformer && items.push(primaryPerformer);
    encounterLocations && items.push(...encounterLocations);
    dischargeDisposition && items.push(dischargeDisposition);

    //fields to display:
    let info: ExtendedInfo[] = [];
    if (items?.length > 0) info.push({ title: '', detailedViewOnly: false, items: [items] });

    return new DisplayableHealthProfileItem({ type: HealthProfileDisplayableType.encounter, typeName, titles, secondaryTitle, extendedInfo: info, isValidToShow: this.isItemValidToShow(titles) });
  }
}

export default EncountersStore;
export { EncountersStore as EncountersStoreType };
