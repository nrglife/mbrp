import { observable, action, computed, decorate, reaction, isComputedProp, runInAction, toJS } from 'mobx';
import { injectable, interfaces, unmanaged } from 'inversify';

import { IocContainer, IocTypes } from '../../inversify.config';

import { Bundle_Entry, Reference, Resource } from '../../utilities/fhir/types';

import { HTTP_STATUS_CODES, ApiError, BaseResponse, ApiCallParamsBase } from '../../services/apis/base-api';
import { link } from 'fs';
import BaseListStore, { FetchDataParamsBase } from '../BaseListStore';
import { GetNextPageParams } from '../BaseListStore';
import { ClinicalApi, failureSource, I18nCommonType } from '../..';
import {
  ListSettings,
  DisplayableHealthProfileData,
  DisplayableHealthProfileItem,
  ENTERED_IN_ERROR_STATUS_CODE,
  EmptyDataSource,
  GroupedDisplayableHealthProfileItem,
  ItemTitle,
  SortOptions,
  NoDataType
} from './types';
import { AllergyIntolerance, ClinicalsResourcesTypes, Condition, MedicationRequest, Procedure, ImplantableDevice } from '../../utilities/fhir/clinicals/clinicals-types';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import { DelegateStore, ErrorStoreType } from '..';
import { title } from 'process';

export interface GetEOBsNextPageParams {
  numberOfRetries?: number;
}

const MINIMUM_TICKETS = 5;

export enum FieldsToArrangeBy {
  Autoredon = 'authoredon',
  None = 'none'
}

@injectable()
abstract class ClinicalsBaseStore<ClinicalTypeData> extends BaseListStore<ApiCallParamsBase, BaseResponse, FetchDataParamsBase, GetNextPageParams> {
  protected resourceType: ClinicalsResourcesTypes;
  protected includedResources: Resource[];
  protected listSettings: ListSettings;
  protected hideInvalid: boolean;
  protected apiErrorSource: failureSource;
  protected invalidRecordsErrorSource: failureSource | null;
  protected titleKey: string;
  protected i18n: I18nCommonType;
  @observable
  public displayableList: DisplayableHealthProfileItem[];
  @observable
  public selectedItem: DisplayableHealthProfileItem;

  constructor() {
    super();
  }

  protected init(resourceType: ClinicalsResourcesTypes, titleKey: string, listSettings: ListSettings, apiErrorSource: failureSource, invalidRecordsErrorSource: failureSource | null) {
    this.i18n = IocContainer.get<I18nCommonType>(IocTypes.I18nProvider);
    this.displayableList = [];
    this.includedResources = [];
    this.resourceType = resourceType;
    this.apiErrorSource = apiErrorSource;
    this.invalidRecordsErrorSource = invalidRecordsErrorSource;
    this.selectedItem = null;
    this.listSettings = listSettings;
    this.hideInvalid = true;
    this.titleKey = titleKey;
  }

  protected abstract groupBySortedImpl(): {} | null;

  protected resetStoreImpl() {
    this.selectedItem = null;
    this.displayableList = [];
    this.includedResources = [];

    !!this.invalidRecordsErrorSource && IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).clearError(this.invalidRecordsErrorSource);

    this.resetErrorsAndLoaders();
  }

  protected getApi() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi);
  }

  protected mapParams(params: FetchDataParamsBase) {
    return {
      withIncluded: true,
      errorHandlerParam: null,
      successHandlerParam: null,
      precallHandlerParam: null,
      sortBy:
        this.listSettings.sortOptions !== SortOptions.None && this.listSettings.sortBy !== FieldsToArrangeBy.None
          ? {
              descending: this.listSettings.sortOptions === SortOptions.Descending,
              fieldName: this.listSettings.sortBy
            }
          : null
    };
  }

  protected mapNextPageParams(params: GetNextPageParams) {
    const { numberOfRetries = 1 } = params;
    return {
      errorHandlerParam: null,
      successHandlerParam: null,
      precallHandlerParam: null,
      numberOfRetries: numberOfRetries
    };
  }

  protected setData(response: BaseResponse) {
    this.setClinicals(response.data.entry);
  }

  protected setClinicals(entries: Bundle_Entry[]) {
    if (!entries || entries.length === 0) {
      return;
    }
    let clinicalRecords = [];
    entries.forEach((item: Bundle_Entry) => {
      if (item.resource?.resourceType === this.resourceType) {
        const itemResourceData = item.resource as ClinicalTypeData;
        itemResourceData && clinicalRecords.push(itemResourceData);
      } else {
        const includedResourceData = item.resource as Reference;
        includedResourceData && this.includedResources.push(includedResourceData);
      }
    });

    clinicalRecords.forEach(record => {
      this.displayableList.push(this.prepareDisplayableItem(record));
    });

    if (this.isEmptyList && this.NumOfInvalidItems > 0) {
      !!this.invalidRecordsErrorSource && IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).setError(this.invalidRecordsErrorSource, null, false);
    } else {
      !!this.invalidRecordsErrorSource && IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).clearError(this.invalidRecordsErrorSource);
    }
  }

  protected setDataNextPage(entries: any) {
    this.setData(entries);
  }

  protected getDefaultNextPageParams() {
    return {};
  }

  protected shouldLoadNextPage() {
    return this.isEmptyList || this.FilteredDisplayableList.length < MINIMUM_TICKETS;
  }

  protected isItemValidToShow(title: ItemTitle | ItemTitle[], validationStatusCode?: string) {
    //validationStatusCode is optional, because not every API has mandatory "status" parameter
    let isTitleExists = Array.isArray(title) ? title?.length > 0 && !!title?.find(t => t.code || t.description) : !!(title?.code || title?.description);
    return validationStatusCode ? isTitleExists && validationStatusCode?.trim().toLowerCase() !== ENTERED_IN_ERROR_STATUS_CODE : isTitleExists;
  }

  protected abstract prepareDisplayableItem(item: ClinicalTypeData): DisplayableHealthProfileItem;

  @action
  getUIData(): DisplayableHealthProfileData {
    const recordsRemovedWarning = this.hideInvalid && this.NumOfInvalidItems > 0 ? this.i18n.t(LocaleKeys.errors.some_records_not_available) : null;


    const title = this.i18n.t(this.titleKey);

    return new DisplayableHealthProfileData(title, recordsRemovedWarning, this.listSettings.groupBySorted, this.getEmptyContentToShow(), this.getDisplayableItemsList());
  }

  protected getDisplayableItemsList(): GroupedDisplayableHealthProfileItem[] {
    let displayableItems = [];

    if (this.listSettings.sortBy && this.listSettings.sortBy != '' && this.listSettings.groupBySorted) {
      const groupedRequests = this.groupBySortedImpl();

      displayableItems =
        groupedRequests &&
        Object.keys(groupedRequests).map(groupBy => {
          return new GroupedDisplayableHealthProfileItem(groupBy, groupedRequests[groupBy]);
        });
    } else {
      displayableItems = this.FilteredDisplayableList?.length > 0 ? [new GroupedDisplayableHealthProfileItem('', this.FilteredDisplayableList)] : [];
    }
    return displayableItems;
  }

  protected getEmptyContentToShow(): EmptyDataSource | null {
    const numOfInvalidRemoved = this.hideInvalid ? this.NumOfInvalidItems : 0;
    const isEmptyList = this.FilteredDisplayableList?.length == 0;
    const no_records_message = this.i18n.t(LocaleKeys.errors.no_records_to_show);
    const general_error_message = `${this.i18n.t(LocaleKeys.errors.something_went_wrong)}. ${this.i18n.t(LocaleKeys.errors.try_reloading_the_page)}`;
    const records_removed_message = this.i18n.t(LocaleKeys.errors.not_available_to_display, { numOfInvalidRemoved: numOfInvalidRemoved });
    const data_still_loading = this.i18n.t(LocaleKeys.errors.data_still_loading);

    const error = !!this.invalidRecordsErrorSource
      ? IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).getLastFilteredError([this.invalidRecordsErrorSource, this.apiErrorSource])
      : IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).getLastFilteredError([this.apiErrorSource]);

    const noContentToShow: EmptyDataSource | null = error
      ? {
          errorSource: error.source,
          errorText: numOfInvalidRemoved === 0 ? general_error_message : records_removed_message,
          type: NoDataType.error
        }
      : isEmptyList
      ? IocContainer.get<DelegateStore>(IocTypes.DelegateStore).isMemberConsentIn12HoursRange
        ? {
            errorText: data_still_loading,
            type: NoDataType.not_completed
          }
        : {
            errorText: no_records_message,
            type: NoDataType.empty
          }
      : null;

    return noContentToShow;
  }

  @computed
  get NumOfInvalidItems() {
    return this.displayableList.filter(item => item.isValidToShow === false).length;
  }

  @computed
  get isEmptyList() {
    return this.FilteredDisplayableList?.length == 0;
  }

  @computed
  get FilteredDisplayableList() {
    return this.hideInvalid === true ? this.displayableList?.filter(item => !!item.isValidToShow) : this.displayableList;
  }

  @action
  public setSelectedItem(item: DisplayableHealthProfileItem) {
    this.selectedItem = item;
  }
}

export default ClinicalsBaseStore;
export { ClinicalsBaseStore as ClinicalsBaseStoreType };
