import { injectable } from 'inversify';
import { IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, ImplantableDevice } from '../../utilities/fhir/clinicals/clinicals-types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { getCodeableCodeValue, getCodeableDisplayValue } from '../../utilities/fhir/helper';
import { formatDate, isValidDate, FULL_DATE_FORMAT } from '../../utilities/dates';
import { DisplayableHealthProfileItem, FieldData, FieldType, HealthProfileDisplayableType, ItemTitle, SortOptions, ExtendedInfo } from './types';
import { failureSource } from '../..';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';

@injectable()
class ImplantableDeviceStore extends ClinicalsBaseStore<ImplantableDevice> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.ImplantableDevice,
      LocaleKeys.screens.Clinical.ImplantableDevice.implantableDevice,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_ImplantableDevice,
      failureSource.Clinical_Invalid_ImplantableDevice
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getImplantableDevice.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  ////DATA RELATED
  getDeviceTitle(device: ImplantableDevice | null | undefined) {
    return getCodeableDisplayValue(device?.type);
  }

  getDeviceCode(device: ImplantableDevice | null | undefined) {
    return getCodeableCodeValue(device?.type);
  }

  getDeviceIdentifiers(device: ImplantableDevice | null | undefined) {
    return device?.udiCarrier && device?.udiCarrier.length > 0 && device?.udiCarrier.filter(item => item?.deviceIdentifier != null && item?.deviceIdentifier != '')?.map(item => item.deviceIdentifier);
  }

  getDeviceLotNumber(device: ImplantableDevice | null | undefined) {
    return device?.lotNumber ? device?.lotNumber : null;
  }

  getDeviceSerialNumber(device: ImplantableDevice | null | undefined) {
    return device?.serialNumber ? device?.serialNumber : null;
  }

  getDeviceExpirationDate(device: ImplantableDevice | null | undefined) {
    return isValidDate(device?.expirationDate) ? formatDate(device?.expirationDate, FULL_DATE_FORMAT, false) : null;
  }

  getDeviceManufactureDate(device: ImplantableDevice | null | undefined) {
    return isValidDate(device?.manufactureDate) ? formatDate(device?.manufactureDate, FULL_DATE_FORMAT, false) : null;
  }

  prepareDisplayableItem(item: ImplantableDevice): DisplayableHealthProfileItem {
    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.implantableDeviceTypeName);

    //TITLE
    let title = new ItemTitle(this.getDeviceTitle(item), this.getDeviceCode(item));

    //FieldData ITEMS
    const identifiers = this.getDeviceIdentifiers(item);
    const lotNumber = this.getDeviceLotNumber(item);
    const serialNumber = this.getDeviceSerialNumber(item);
    const expirationDate = this.getDeviceExpirationDate(item);
    const manufactureDate = this.getDeviceManufactureDate(item);

    let items: FieldData[] = [];

    identifiers?.length === 1
      ? items.push(new FieldData(`${this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.deviceIdentifier)}`, FieldType.flat, null, identifiers[0]))
      : identifiers?.length > 1
      ? identifiers.forEach((identifier, i) => items.push(new FieldData(`${this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.deviceIdentifier)} ${i + 1}`, FieldType.flat, null, identifier)))
      : null;

    lotNumber && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.lotNumber), FieldType.flat, null, lotNumber));
    serialNumber && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.serialNumber), FieldType.flat, null, serialNumber));
    manufactureDate && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.manufactureDate), FieldType.flat, null, manufactureDate));
    expirationDate && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.ImplantableDevice.expirationDate), FieldType.flat, null, expirationDate));

    //fields to display:
    let info: ExtendedInfo[] = [
      {
        title: '',
        detailedViewOnly: false,
        items: [items]
      }
    ];
    return new DisplayableHealthProfileItem({ type: HealthProfileDisplayableType.implantable_device, typeName, titles: [title], extendedInfo: info, isValidToShow: this.isItemValidToShow(title) });
  }
}

export default ImplantableDeviceStore;
export { ImplantableDeviceStore as ImplantableDeviceStoreType };
