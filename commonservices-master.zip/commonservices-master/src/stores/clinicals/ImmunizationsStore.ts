import { observable, action, decorate, runInAction, computed, toJS } from 'mobx';
import { injectable } from 'inversify';
import { LocaleKeys } from '@healthcareapp/connected-health-translation';

import { IocContainer, IocTypes } from '../../inversify.config';
import { ClinicalsResourcesTypes, Immunization, Procedure } from '../../utilities/fhir/clinicals/clinicals-types';
import { ClinicalApi } from '../../services/apis/clinical/clinical-api';
import { formatDate, FULL_DATE_FORMAT, isValidDate } from '../../utilities/dates';
import { getCodeableDisplayValue, getCodeableCodeValue, getCodeFormattedDisplayString } from '../../utilities/fhir/helper';
import { DisplayableHealthProfileItem, FieldData, FieldType, ItemTitle, SortOptions, HealthProfileDisplayableType } from './types';
import { failureSource } from '../..';
import ClinicalsBaseStore, { FieldsToArrangeBy } from './ClinicalsBaseStore';

export interface GetNextPageParams {
  numberOfRetries?: number;
}

@injectable()
class ImmunizationsStore extends ClinicalsBaseStore<Immunization> {
  constructor() {
    super();

    this.init(
      ClinicalsResourcesTypes.Immunization,
      LocaleKeys.screens.Clinical.Immunization.vaccinations,
      {
        sortBy: FieldsToArrangeBy.None,
        sortOptions: SortOptions.None,
        groupBySorted: false
      },
      failureSource.Clinical_Get_ImmunizationProfile,
      failureSource.Clinical_Invalid_ImmunizationProfile
    );
  }

  protected groupBySortedImpl(): {} {
    return null;
  }

  protected getFetchFunc() {
    return IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi).getImmunizationProfile.bind(IocContainer.get<ClinicalApi>(IocTypes.ClinicalApi));
  }

  // Immunizations data related

  getDescription(immunization: Immunization | null | undefined) {
    return getCodeableDisplayValue(immunization?.vaccineCode);
  }

  getCode(immunization: Immunization | null | undefined) {
    return getCodeableCodeValue(immunization?.vaccineCode);
  }

  getStatus(immunization: Immunization | null | undefined) {
    return immunization?.status;
  }

  getStatusReason(immunization: Immunization | null | undefined) {
    const description = getCodeableDisplayValue(immunization?.statusReason);
    const code = getCodeableCodeValue(immunization?.statusReason);
    return !!description && !!code ? description + ' ' + `${'(' + code + ')'}` : !!description ? description : !!code ? `Code: ${code}` : null;
  }

  getOccurrenceDate(immunization: Immunization | null | undefined): string {
    return isValidDate(immunization?.occurrenceDateTime)
      ? formatDate(immunization?.occurrenceDateTime, FULL_DATE_FORMAT, false)
      : isValidDate(immunization?.occurrenceString)
      ? formatDate(immunization?.occurrenceString, FULL_DATE_FORMAT, false)
      : immunization?.occurrenceString;
  }

  prepareDisplayableItem(item: Immunization): DisplayableHealthProfileItem {
    const description = this.getDescription(item);
    const code = this.getCode(item);
    const status = this.getStatus(item);
    const occuranceDate = this.getOccurrenceDate(item);
    const statusReason = this.getStatusReason(item);

    const typeName = this.i18n.t(LocaleKeys.screens.Clinical.Immunization.vaccinationTypeName);
    const title = new ItemTitle(description, code);
    const secondaryTitle = new FieldData('', FieldType.flat, null, occuranceDate);

    let items: FieldData[] = [];

    !!status && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Immunization.status), FieldType.flat, null, getCodeFormattedDisplayString(status)));
    !!statusReason && items.push(new FieldData(this.i18n.t(LocaleKeys.screens.Clinical.Immunization.statusReason), FieldType.flat, null, statusReason));

    return new DisplayableHealthProfileItem({
      type: HealthProfileDisplayableType.immunization,
      typeName,
      titles: [title],
      secondaryTitle,
      extendedInfo: [
        {
          title: '',
          detailedViewOnly: false,
          items: [items]
        }
      ],
      isValidToShow: this.isItemValidToShow(title, status)
    });
  }
}

export default ImmunizationsStore;
export { ImmunizationsStore as ImmunizationsStoreType };
