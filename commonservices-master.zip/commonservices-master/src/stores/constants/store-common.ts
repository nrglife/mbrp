export enum StoreRequestStatus {
  Idle = 'Idle',  // Init
  Loading = 'Loading',
  Loaded = 'Loaded',
  Error = 'Error'
}
