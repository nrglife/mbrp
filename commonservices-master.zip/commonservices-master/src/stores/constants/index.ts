import { AUTH_DOMAINS, DEFAULT_CONFIG } from './auth';

export { AUTH_DOMAINS, DEFAULT_CONFIG };
