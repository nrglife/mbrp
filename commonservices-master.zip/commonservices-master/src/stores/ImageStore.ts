import { map } from 'lodash';
import { observable, action, computed, decorate, runInAction } from 'mobx';
import { injectable } from 'inversify';
import { HTTP_STATUS_CODES } from '../services/apis/base-api';
import { IocContainer, IocTypes, DataServicesApiType, IStorageService } from '../inversify.config';

export type Image = {
  data: string | undefined;
  state: ImageState;
};

export enum LogoType {
  Light = 'light',
  Dark = 'dark',
  Mobile = 'mobile',
  Landing = 'landing'
}

export enum ImageState {
  Init = 'Init',
  Loading = 'Loading',
  Loaded = 'Loaded',
  Error = 'Error'
}

export interface Logos {
  light: Image;
  dark: Image;
  mobile: Image;
  landing: Image;
}

export interface Images {
  payerId: string | null;
  logos: Record<LogoType, Image>;
}
export interface ImagesCache {
  logos: Record<LogoType, Image>;
}

const DEFAULT_IMAGES: Images = {
  payerId: null,
  logos: {
    light: {
      data: '',
      state: ImageState.Init
    },
    dark: {
      data: '',
      state: ImageState.Init
    },
    mobile: {
      data: '',
      state: ImageState.Init
    },
    landing: {
      data: '',
      state: ImageState.Init
    }
  }
};
@injectable()
class ImageStore {
  public images: Images = DEFAULT_IMAGES;
  private imagesCache: Record<string, Images> = {};

  private storageService = IocContainer.get<IStorageService>(IocTypes.StorageService);
  private dataServicesApi = IocContainer.get<DataServicesApiType>(IocTypes.DataServicesApi);

  async loadLogoByType(payerId: string, type: LogoType | string, useStorageCache: boolean) {
    // Checking if logo exists locally as a resource and should not be retrieved from API
    const logoIsLocalResource = !!DEFAULT_IMAGES?.logos[type]?.data && DEFAULT_IMAGES?.logos[type]?.data !== '';

    // If this is the first logo request for this payer, clearing the images store to avoid logo mix from several payers.
    if (payerId !== this.currentPayerId) {
      // Trying to cache the store before clearing
      this.cacheStore();

      // For the new payer if not available in cache, reset to default blank store.
      this.images = this.imagesCache[payerId] || { ...DEFAULT_IMAGES, payerId: payerId };
    }

    if (!logoIsLocalResource) {
      if (!payerId || payerId === '') {
        const image: Image = { data: '', state: ImageState.Loading };
        this.images.logos[type] = image;
        console.log('Payer data is not found - using default logo:', type);
      } else {
        try {
          // First trying to get image data from the store
          let dataUrlImage = this.images.logos[type]?.data;
          // If not available trying to get from local storage
          if (!dataUrlImage && useStorageCache) {
            const storageImageData = this.storageService.getValueByKey(this.storageImageName(payerId, type));
            if (storageImageData) {
              dataUrlImage = JSON.parse(storageImageData);
            }
          }
          // If still not available getting image from API
          if (!dataUrlImage) {
            const response = await this.dataServicesApi.getPayerImagesByCategory({
              payerId,
              stage: 'published',
              category: type,
              metadata: true
            });
            if (response.status === HTTP_STATUS_CODES.SUCCESS) {
              dataUrlImage = `data:image/png;base64,${response?.data?.body}`;
              this.storageService.setItem(this.storageImageName(payerId, type), JSON.stringify(dataUrlImage));
            } else {
              throw new Error('Response was not successful');
            }
          }

          runInAction(() => {
            //save image in image store
            const image: Image = { data: dataUrlImage, state: ImageState.Loaded };
            this.images.logos[type] = image;
            this.images = { ...this.images };
          });
        } catch (error) {
          console.error(`error loading image of type "${type}": `, error);
          runInAction(() => {
            //default behavior - save clean image object at image store
            const image: Image = { data: '', state: ImageState.Error };
            this.images.logos[type] = image;
            //added behavior by the user
          });
        }
      }
    }
  }

  async loadAllLogos(payerId: string | undefined, useStorageCache: boolean) {
    if (!payerId) {
      return;
    }
    // Loads logos individually
    await Promise.all(map(DEFAULT_IMAGES.logos, (_value, key) => this.loadLogoByType(payerId, `${key}`, true)));
    console.log('Finished loading all images');
  }

  resetStore() {
    this.cacheStore();
    this.images = DEFAULT_IMAGES;
  }

  get logos() {
    return this.images.logos;
  }

  private cacheStore() {
    if (this.currentPayerId) {
      this.imagesCache[this.currentPayerId] = this.images;
    }
  }

  private storageImageName(payerId: string, type: string) {
    return `${payerId}_${type}_img`;
  }
  private get currentPayerId() {
    return this.images.payerId;
  }
}

decorate(ImageStore, {
  images: observable,
  logos: computed,
  loadLogoByType: action,
  loadAllLogos: action,
  resetStore: action
});

export default ImageStore;
export type { ImageStore as ImageStoreType };
