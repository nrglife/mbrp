import { action, computed, decorate, observable } from 'mobx';
import { injectable } from 'inversify';
import AppConfigStore from './AppConfigStore';
import { DataServicesApi, IocContainer, IocTypes } from '..';
import { DataServicesApiData } from '../services/apis/data-services/data-services-api';

export interface ThemeStoreHandler {
  loadPayerTheme(customerId: string, useStorageCache: boolean): Promise<void>;
  resetStore(): void;
}
export interface BrandingTheme {
  backgroundLight: string;
  backgroundDark: string;
  backgroundMedium: string;
  actionLight: string;
  actionMedium: string;
  actionDark: string;
}
/*
@injectable()
class ThemeStore implements ThemeStoreHandler {
  theme: BrandingTheme;
  public isDefaultTheme: boolean;

  public get appConfigStore() {
    return IocContainer.get<AppConfigStore>(IocTypes.AppConfigStore);
  }

  constructor() {
    this.theme = this.defaultTheme;
    this.isDefaultTheme = true;
  }

  async loadPayerTheme(customerId: string) {
    const stage: string = 'published';
    try {
      const getPreferenceListByPayerIdResponse = await IocContainer.get<DataServicesApi>(IocTypes.DataServicesApi).getPreferenceListByPayerId({
        payerId: customerId,
        stage
      });

      this.setCurrentTheme(this.convertTheme(getPreferenceListByPayerIdResponse));
      this.isDefaultTheme = false;
    } catch (error) {
      console.error(`loadPayerBranding ${error}`);
      this.resetStore();
    }
  }

  resetStore(): void {
    this.theme = this.defaultTheme;
  }

  get actionDark(): string {
    return '#183734';
  }

  get blackMain(): string {
    return '#262626';
  }

  get getIsDefaultTheme(): boolean {
    return this.isDefaultTheme;
  }

  setIsDefaultTheme(isDefaultTheme) {
    this.isDefaultTheme = isDefaultTheme;
  }

  get defaultTheme(): BrandingTheme {
    return {
      backgroundLight: '#F2F8FA',
      backgroundDark: '#0F4E6D',
      backgroundMedium: '#E1EDF1',
      actionLight: '#82D8FF',
      actionMedium: '#1188C1',
      actionDark: '#0F0F59'
    };
  }

  setCurrentTheme(theme: BrandingTheme) {
    this.theme = theme;
  }

  convertTheme(res: DataServicesApiData.GetPreferenceListByPayerId.Response): BrandingTheme {
    const colorKeys = Object.keys(res.data.colors);
    const ret: BrandingTheme = this.defaultTheme;
    colorKeys.forEach(key => {
      if (res.data.colors[key].published && res.data.colors[key].published != '') {
        ret[key] = res.data.colors[key].published;
      }
    });

    return ret;
  }

  get label(): string {
    return '#979797';
  }

  get currentTheme(): BrandingTheme {
    return this.theme;
  }
}

decorate(ThemeStore, {
  // aldenTheme: computed,
  theme: observable.shallow,
  currentTheme: computed,
  setCurrentTheme: action
});

export default ThemeStore;
export { ThemeStore as BrandingStoreType };

*/
