import { observable, action, computed, decorate, runInAction, autorun } from 'mobx';

import { injectable } from 'inversify';
import {
  IocTypes,
  IocContainer,
  I18nCommonType,
  WhoAmIApiType,
  IStorageService,
  AllergiesStoreType,
  EncountersStoreType,
  ConditionsStoreType,
  MedicationRequestStoreType,
  ImplantableDeviceStoreType,
  WhoAmIStoreType,
  PayerStoreType,
  EOBListStoreType,
  LinkedServicesListStoreType,
  ImmunizationsStoreType,
  ClinicalsOverviewStoreType
} from '../inversify.config';
import { formatDate, FULL_DATE_FORMAT, getDateDiffInHoursFromNow, isNowDateBetween, isValidDate } from '../utilities/dates';
import { getFullNameFormatWhoAmI } from '../utilities/fhir/helper';
import { ConsentDateProvider } from '../services/apis/base-config';

export type HumanName = {
  family: string | null;
  given: string[] | null;
  prefix: string | null;
  suffix: string | null;
  fullName: string | null;
  use: string | null;
  period: {
    start: string | null;
    end: string | null;
  };
};

export type MemberForDelegate = {
  userId: string | null;
  humanName: HumanName;
  customerId: string[];
  isMember: boolean;
  delegateStartDate: string | null;
  delegateEndDate: string | null;
};

export type DelegateMenuItem = {
  name: string;
  userID: string;
  isHighlighted: boolean;
  onClick: () => void;
};

export type DelegateMenu = {
  mainMember: DelegateMenuItem;
  otherMembers: DelegateMenuItem[];
};

export enum DelegateStoreState {
  PreInit = 'PreInit',
  Running = 'Running',
  RunningShowError = 'RunningShowError',
  ReloadingPayer = 'ReloadingPayer',
  Error = 'Error',
  InitError = 'InitError'
}

const SELECTED_DELEGATE_INDEX = 'SelectedDelegateIndex';
const SELECTED_DELEGATE_ID = 'SelectedDelegateId';

@injectable()
class DelegateStore {
  private payerStore: PayerStoreType;
  private whoAmIApi: WhoAmIApiType;
  private storageService: IStorageService;
  private eobListStore: EOBListStoreType;
  private medicationRequestStore: MedicationRequestStoreType;
  private allergiesStore: AllergiesStoreType;
  private encountersStore: EncountersStoreType;
  private conditionsStore: ConditionsStoreType;
  private implantableDeviceStore: ImplantableDeviceStoreType;
  private linkedServicesListStore: LinkedServicesListStoreType;
  private immunizationsStore: ImmunizationsStoreType;
  private clinicalsOverviewStore: ClinicalsOverviewStoreType;

  public membersForDelegate: MemberForDelegate[];
  public selectedMemberForDelegateIndex: number;
  private whoAmIStore: WhoAmIStoreType;
  public state: DelegateStoreState;
  private nextSelectedIndex = -1;

  resetStore() {
    this.membersForDelegate = null;
    this.selectedMemberForDelegateIndex = -1;
    this.state = DelegateStoreState.PreInit;
  }

  constructor() {
    this.resetStore();
    this.payerStore = IocContainer.get<PayerStoreType>(IocTypes.PayerStore);
    this.whoAmIStore = IocContainer.get<WhoAmIStoreType>(IocTypes.WhoAmIStore);
    this.whoAmIApi = IocContainer.get<WhoAmIApiType>(IocTypes.WhoAmIApi);
    this.storageService = IocContainer.get<IStorageService>(IocTypes.StorageService);
    this.eobListStore = IocContainer.get<EOBListStoreType>(IocTypes.EOBListStore);
    this.medicationRequestStore = IocContainer.get<MedicationRequestStoreType>(IocTypes.MedicationRequestStore);
    this.allergiesStore = IocContainer.get<AllergiesStoreType>(IocTypes.AllergiesStore);
    this.encountersStore = IocContainer.get<EncountersStoreType>(IocTypes.EncountersStore);

    this.conditionsStore = IocContainer.get<ConditionsStoreType>(IocTypes.ConditionsStore);
    this.implantableDeviceStore = IocContainer.get<ImplantableDeviceStoreType>(IocTypes.ImplantableDeviceStore);
    this.immunizationsStore = IocContainer.get<ImmunizationsStoreType>(IocTypes.ImmunizationsStore);
    this.linkedServicesListStore = IocContainer.get<LinkedServicesListStoreType>(IocTypes.LinkedServicesListStore);
    this.clinicalsOverviewStore = IocContainer.get<ClinicalsOverviewStoreType>(IocTypes.ClinicalsOverviewStore);
  }

  setMembersForDelegate(members) {
    this.membersForDelegate = members;
  }

  public async init() {
    let selectedIndex = 0;
    this.resetStore();
    try {
      this.setMembersForDelegate(null);

      const response = await this.whoAmIApi.getMembersForDelegate({});

      if (response.status === 200 && response?.data) {
        const membersForDelegateList: MemberForDelegate[] = response.data.map((data, index) => {
          const { userId = null, customerId = null, isMember = false, delegateStartDate = null, delegateEndDate = null } = data;
          const {
            family = null,
            given = null,
            prefix = null,
            suffix = null,
            fullName = null,
            use = null,
            period: { start = null, end = null }
          } = data.humanName;

          const memberData: MemberForDelegate = {
            userId,
            customerId,
            isMember,
            delegateStartDate: isValidDate(delegateStartDate) ? formatDate(delegateStartDate, FULL_DATE_FORMAT, false) : null,
            delegateEndDate: isValidDate(delegateEndDate) ? formatDate(delegateEndDate, FULL_DATE_FORMAT, false) : null,
            humanName: {
              family,
              given,
              prefix,
              suffix,
              fullName,
              use,
              period: { start, end }
            }
          };
          return memberData;
        });

        const filteredList = membersForDelegateList.filter(elem => {
          return isNowDateBetween(elem.delegateStartDate, elem.delegateEndDate, FULL_DATE_FORMAT);
        });

        filteredList.forEach((elem, index) => {
          if (elem.isMember) {
            selectedIndex = index;
          }
        });

        this.setMembersForDelegate(filteredList);
        const savedIndex = this.getStoredDelegateIndex();
        if (savedIndex != -1) {
          selectedIndex = savedIndex;
        }

        await this.setSelectedMemberForDelegate(selectedIndex);
      } else {
        this.setState(DelegateStoreState.InitError);

        console.error('error', response);
      }
    } catch (error) {
      console.error('error', error);

      this.setState(DelegateStoreState.InitError);
    }
  }

  public get selectedDelegateId() {
    return this.membersForDelegate && this.membersForDelegate[this.selectedMemberForDelegateIndex] ? this.membersForDelegate[this.selectedMemberForDelegateIndex].userId : null;
  }

  public get selectedDelegateName() {
    return this.membersForDelegate && this.membersForDelegate[this.selectedMemberForDelegateIndex] && this.membersForDelegate[this.selectedMemberForDelegateIndex].humanName
      ? getFullNameFormatWhoAmI(this.membersForDelegate[this.selectedMemberForDelegateIndex].humanName)
      : null;
  }

  public get selectedDelegateIsMember() {
    return this.membersForDelegate && this.membersForDelegate[this.selectedMemberForDelegateIndex] ? this.membersForDelegate[this.selectedMemberForDelegateIndex].isMember : false;
  }

  public get isMemberConsentIn12HoursRange() {
    if (this.selectedDelegateIsMember) {
      const date = IocContainer.get<ConsentDateProvider>(IocTypes.ConsentDateProvider)();
      return isValidDate(date) && getDateDiffInHoursFromNow(date) < 12 ? true : false;
    }
    return false;
  }

  public clearError() {
    if (this.state == DelegateStoreState.RunningShowError) {
      this.setState(DelegateStoreState.Running);
    }
  }

  public get delegateMenu() {
    const menu: DelegateMenu = {
      mainMember: null,
      otherMembers: []
    };
    const listCopy = this.membersForDelegate ? [...this.membersForDelegate] || [] : [];
    if (listCopy.length == 1) {
      return null;
    }

    return listCopy.reduce((ret: DelegateMenu, item: MemberForDelegate, index: number) => {
      const newItem: DelegateMenuItem = {
        name: getFullNameFormatWhoAmI(item.humanName),
        userID: item.userId,
        isHighlighted: this.membersForDelegate[this.selectedMemberForDelegateIndex] && item.userId == this.membersForDelegate[this.selectedMemberForDelegateIndex].userId,
        onClick: () => {
          runInAction(() => {
            this.setSelectedMemberForDelegate(index);
          });
        }
      };
      if (item.isMember) {
        ret.mainMember = newItem;
      } else {
        ret.otherMembers.push(newItem);
      }
      return ret;
    }, menu);
  }

  setSelectedMemberForDelegateIndex(index: number) {
    this.selectedMemberForDelegateIndex = index;
  }

  getStoredDelegateIndex() {
    if (this.membersForDelegate && this.storageService) {
      const index = this.storageService.getValueByKey(SELECTED_DELEGATE_INDEX);
      const id = this.storageService.getValueByKey(SELECTED_DELEGATE_ID);
      if (id && index && index.trim() != '' && id.trim() != '') {
        if (this.membersForDelegate[parseInt(index)] && this.membersForDelegate[parseInt(index)].userId == id) {
          return parseInt(index);
        }
      }
    }
    return -1;
  }

  clearStoredDelegateIndex() {
    if (this.storageService) {
      this.storageService.removeItemByKey(SELECTED_DELEGATE_INDEX);
      this.storageService.removeItemByKey(SELECTED_DELEGATE_ID);
    }
  }

  saveDelegateIndex(index) {
    if (this.membersForDelegate && this.storageService) {
      if (this.membersForDelegate[index]) {
        this.storageService.setItem(SELECTED_DELEGATE_INDEX, index + '');
        this.storageService.setItem(SELECTED_DELEGATE_ID, this.membersForDelegate[index].userId + '');
      }
    }
  }

  @action
  private selectMemberIsDone() {
    this.setSelectedMemberForDelegateIndex(this.nextSelectedIndex);
    this.eobListStore.resetStore();
    this.medicationRequestStore?.resetStore();
    this.allergiesStore?.resetStore();
    this.encountersStore?.resetStore();
    this.conditionsStore?.resetStore();
    this.implantableDeviceStore?.resetStore();
    this.immunizationsStore?.resetStore();
    this.whoAmIStore?.resetStore();
    this.clinicalsOverviewStore?.resetStore();
    this.linkedServicesListStore?.resetStore();
    this.saveDelegateIndex(this.nextSelectedIndex);
    this.nextSelectedIndex = -1;
    this.setState(DelegateStoreState.Running);
  }

  public retrySelectMember() {
    if (this.nextSelectedIndex != -1) {
      this.setSelectedMemberForDelegate(this.nextSelectedIndex);
    }
  }

  public async setSelectedMemberForDelegate(newIndex: number) {
    // Selected member hasnt changed
    if (this.selectedMemberForDelegateIndex == newIndex) {
      return;
    }

    this.nextSelectedIndex = newIndex;

    if (this.payerStore?.payer?.guid == this.membersForDelegate[newIndex].customerId[0]) {
      this.selectMemberIsDone();
    } else {
      this.setState(DelegateStoreState.ReloadingPayer);
      await this.payerStore.loadPayerFullData(this.membersForDelegate[newIndex].customerId[0], {
        loadConfig: true,
        waitForAllLoadingTasks: true,
        loadTheme: true,
        loadImageLogos: true,
        loadDocuments: false,
        useStorageCache: true
      });
      if (this.payerStore.apiError) {
        if (this.selectedMemberForDelegateIndex == -1) {
          this.setState(DelegateStoreState.Error);
        } else {
          this.setState(DelegateStoreState.RunningShowError);
        }
      } else {
        this.selectMemberIsDone();
      }
    }
  }

  setState(state: DelegateStoreState) {
    this.state = state;
  }
}

decorate(DelegateStore, {
  selectedMemberForDelegateIndex: observable,
  membersForDelegate: observable,
  delegateMenu: computed,
  selectedDelegateName: computed,
  selectedDelegateId: computed,
  init: action,
  setSelectedMemberForDelegate: action,
  state: observable,
  setState: action,
  setSelectedMemberForDelegateIndex: action,
  setMembersForDelegate: action,
  retrySelectMember: action,
  clearError: action,
  selectedDelegateIsMember: computed,
  isMemberConsentIn12HoursRange: computed,
  resetStore: action
});

export default DelegateStore;
export type { DelegateStore as DelegateStoreType };
