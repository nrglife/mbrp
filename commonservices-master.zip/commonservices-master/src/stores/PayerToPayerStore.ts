import { action, computed, decorate, observable } from 'mobx';
import { injectable } from 'inversify';

import { IocContainer, IocTypes, PayerToPayerApiType } from '../inversify.config';
import { ErrorStoreType, StoreRequestStatus } from '../stores';
import { failureSource } from '../';
import { HTTP_STATUS_CODES } from '../services/apis/base-api';
import { PlatformType, Request_Record } from '../services/apis/payer-to-payer/payer-to-payer-api';

export type PayerItem = {
  payerId: string | null;
  name: string | null;
  types: string | null;
  isLinked: boolean | null;
  icon: string;
  isTopInsurance: boolean | null;
};

@injectable()
class PayerToPayerStore {
  public payerItems: PayerItem[];
  public payersRequestStatus: StoreRequestStatus = StoreRequestStatus.Idle;
  public payerRecords?: Request_Record[];
  public getRequestPayerRecordsStatus: StoreRequestStatus;
  private payerToPayerApi = IocContainer.get<PayerToPayerApiType>(IocTypes.PayerToPayerApi);
  private errorStore = IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore);
  public postRequestHistoricalDataFromPayerStatus: StoreRequestStatus;

  constructor() {
    this.payerItems = null;
    this.payerRecords = null;
    this.payersRequestStatus = StoreRequestStatus.Idle;
    this.getRequestPayerRecordsStatus = StoreRequestStatus.Idle;
    this.postRequestHistoricalDataFromPayerStatus = StoreRequestStatus.Idle;
  }

  public setPayerItems(payerItems: PayerItem[]) {
    this.payerItems = payerItems;
  }

  public setPayersRequestStatus(payersRequestStatus: StoreRequestStatus) {
    this.payersRequestStatus = payersRequestStatus;
  }

  public resetStore() {
    this.payerItems = [];
    this.payersRequestStatus = StoreRequestStatus.Idle;
    this.postRequestHistoricalDataFromPayerStatus = StoreRequestStatus.Idle;
    this.clearPayerRecords();
  }

  getFilteredListByValue(value: string): PayerItem[] {
    return this.alphabeticList.filter(name => name.name.toLowerCase().includes(value.toLowerCase()));
  }

  getPayerById(payerId: string): PayerItem | null {
    let returnPayerItem = null;

    const payers = this.payerItems.filter(payer => payer.payerId === payerId);
    if (payers && payers.length > 0) {
      returnPayerItem = payers[0];
    }

    return returnPayerItem;
  }

  get alphabeticList(): PayerItem[] {
    return this.payerItems.sort((a, b) => a.name.localeCompare(b.name)).filter(payer => payer.isLinked);
  }

  get topInsuranceList(): PayerItem[] {
    return this.payerItems.filter(payer => payer.isLinked && payer.isTopInsurance);
  }

  clearPayerRecords() {
    this.payerRecords = null;
    this.setPayerRecordsRequestStatus(StoreRequestStatus.Idle);
  }

  setPayerRecordsRequestStatus(status: StoreRequestStatus) {
    this.getRequestPayerRecordsStatus = status;
  }

  setPayerRecord(records: Request_Record[]) {
    this.payerRecords = records;
  }

  async getAllPayers() {
    try {
      this.setPayersRequestStatus(StoreRequestStatus.Loading);
      this.setPayerItems(null);
      const response = await this.payerToPayerApi.getAllPayers();
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        //filter first
        this.setPayerItems(response.data.data);
        this.setPayersRequestStatus(StoreRequestStatus.Loaded);
      } else {
        this.setPayerItems([]);
        this.setPayersRequestStatus(StoreRequestStatus.Error);
        this.errorStore.setError(failureSource.PTP_GET_PAYERS, response.status, false);
      }
    } catch (err) {
      this.setPayerItems([]);
      this.setPayersRequestStatus(StoreRequestStatus.Error);

      console.error('Loading payers (p2p), error occured: ', err);
    }
  }

  async getRecords(payerId: string, isRefresh = false) {
    try {
      if (!isRefresh) {
        this.payerRecords = [];
        this.setPayerRecordsRequestStatus(StoreRequestStatus.Loading);
      }

      const response = await this.payerToPayerApi.getPayerRecords({
        payerId
      });
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        this.setPayerRecord(response.data?.data);
        this.setPayerRecordsRequestStatus(StoreRequestStatus.Loaded);
      } else {
        this.setPayerRecord([]);
        this.setPayerRecordsRequestStatus(StoreRequestStatus.Error);
        this.errorStore.setError(failureSource.PTP_GET_RECORDS, response.status, false);
      }
    } catch (e) {
      this.setPayerRecord([]);
      this.setPayerRecordsRequestStatus(StoreRequestStatus.Error);

      console.error(e, 'api error');
    }
  }

  async getPayerAuthUrl(payerId: string, platformType: PlatformType) {
    try {
      const response = await this.payerToPayerApi.getPayerAuthURL({ payerId, platformType });
      if (response.status === HTTP_STATUS_CODES.SUCCESS && response.data?.data) {
        const { data } = response.data;
        return data.authorize_uri;
      } else {
        console.error('Error: unsuccessful getPayerAuthUrl response');
        this.errorStore.setError(failureSource.PTP_GET_payerAuthURL, response.status, false);
        throw new Error('Unsuccessful getPayerAuthUrl response');
      }
    } catch (exception) {
      console.error('Error while executing getPayerAuthUrl');
      throw exception;
    }
  }

  setPostRequestHistoricalDataFromPayerStatus(status: StoreRequestStatus) {
    this.postRequestHistoricalDataFromPayerStatus = status;
  }

  async postRequestHistoricalDataFromPayer(payerId: string, authCode: string, platformType: PlatformType) {
    this.setPostRequestHistoricalDataFromPayerStatus(StoreRequestStatus.Loading);
    try {
      const response = await this.payerToPayerApi.postRequestHistoricalDataFromPayer({
        payerId,
        authCode,
        platformType
      });
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        const resultData = response?.data?.data;
        this.setPostRequestHistoricalDataFromPayerStatus(StoreRequestStatus.Loaded);
        return resultData;
      } else {
        console.error('Error: unsuccessful postRequestHistoricalDataFromPayer response');
        this.errorStore.setError(failureSource.PTP_POST_REQUEST, response.status, false);
        this.setPostRequestHistoricalDataFromPayerStatus(StoreRequestStatus.Error);
        throw new Error('Unsuccessful postRequestHistoricalDataFromPayer response');
      }
    } catch (exception) {
      console.error('Error while executing postRequestHistoricalDataFromPayer');
      this.setPostRequestHistoricalDataFromPayerStatus(StoreRequestStatus.Error);
      throw exception;
    }
  }
}

decorate(PayerToPayerStore, {
  payerItems: observable,
  payersRequestStatus: observable,
  payerRecords: observable,
  getRequestPayerRecordsStatus: observable,
  postRequestHistoricalDataFromPayerStatus: observable,

  getAllPayers: action,
  getRecords: action,
  clearPayerRecords: action,
  setPayerRecordsRequestStatus: action,
  setPayerRecord: action,
  resetStore: action,
  setPayerItems: action,
  setPayersRequestStatus: action,
  setPostRequestHistoricalDataFromPayerStatus: action,

  alphabeticList: computed,
  topInsuranceList: computed
});

export type { Request_Record };
export default PayerToPayerStore;
export type { PayerToPayerStore as PayerToPayerStoreType };
