import { observable, action, computed, decorate, runInAction } from 'mobx';
import { injectable } from 'inversify';
import { IocContainer, IocTypes, ThemeStoreHandler, PayerDocumentsStoreType, ImageStoreType } from '../inversify.config';
import { LogoType } from './';
import { DataServicesApi, DataServicesApiData } from '../services/apis/data-services/data-services-api';
import { HTTP_STATUS_CODES, ApiError } from '../services/apis/base-api';
import { uppercaseFirstLetter } from '../utilities/string';
import { AppConfigStore, DocumentsCategories } from '.';

const NavigationMenuItemName = 'navigation-menu';

export enum PayerStoreFeatures {
  EOBs = 'EOBs',
  LinkedServices = 'LinkedServices',
  HealthProfile = 'HealthProfile',
  FindCare = 'FindCare',
  Profile = 'Profile',
  Help = 'Help',
  LinkedServicesRequests = 'LinkedServicesRequests',
  LinkedServicesFind = 'LinkedServicesFind',
  Other = 'Other'
}

type IdToFeatureMapType = {
  [key in PayerPayerConfigFeatureIds]: PayerStoreFeatures;
};

export enum PayerPayerConfigFeatureIds {
  EOBs = 'eobs',
  LinkedServices = 'linkedServices',
  HealthProfile = 'clinical',
  FindCare = 'findCare',
  Profile = 'profile',
  Help = 'help'
}

const idToFeatureMap: IdToFeatureMapType = {
  [PayerPayerConfigFeatureIds.EOBs]: PayerStoreFeatures.EOBs,
  [PayerPayerConfigFeatureIds.LinkedServices]: PayerStoreFeatures.LinkedServices,
  [PayerPayerConfigFeatureIds.HealthProfile]: PayerStoreFeatures.HealthProfile,
  [PayerPayerConfigFeatureIds.FindCare]: PayerStoreFeatures.FindCare,
  [PayerPayerConfigFeatureIds.Profile]: PayerStoreFeatures.Profile,
  [PayerPayerConfigFeatureIds.Help]: PayerStoreFeatures.Help
};

export type FeaturesMap = {
  [key in PayerStoreFeatures]: boolean;
};

export interface IPayer {
  guid: string;
  fullName: string;
  shortName: string;
  federatedId: string | null;
  mdmId: string | null;
  phoneNumbers: IPhoneNumber[];
  emailAddresses: IEmailAddress[];
  address: string;
  url: string;
  publicName: string;
  copyrightStatement?: string;
}

export interface IPhoneNumber {
  primary: boolean;
  description: string;
  number: string;
}

export interface IEmailAddress {
  primary: boolean;
  email: string;
}

type LoadPayerFullDataOptions = {
  loadConfig?: boolean;
  waitForAllLoadingTasks?: boolean;
  loadTheme?: boolean;
  loadDocuments?: boolean;
  loadImageLogos?: boolean;
  loadImageLandingBackground?: boolean;
  useStorageCache: boolean;
};

@injectable()
class PayerStore {
  public featuresMap: FeaturesMap;
  public loading: boolean;
  public apiError: ApiError | null;
  public payer: IPayer | null;

  public clearPayerStore(): void {
    this.featuresMap = {
      [PayerStoreFeatures.EOBs]: true,
      [PayerStoreFeatures.LinkedServices]: true,
      [PayerStoreFeatures.HealthProfile]: true,
      [PayerStoreFeatures.FindCare]: true,
      [PayerStoreFeatures.Profile]: true,
      [PayerStoreFeatures.Help]: true,
      [PayerStoreFeatures.Other]: true,
      [PayerStoreFeatures.LinkedServicesRequests]: true,
      [PayerStoreFeatures.LinkedServicesFind]: true
    };
    this.loading = false;
    this.apiError = null;
    this.payer = null;
  }

  private appConfigStore = IocContainer.get<AppConfigStore>(IocTypes.AppConfigStore);
  private themeStoreHandler = IocContainer.get<ThemeStoreHandler>(IocTypes.ThemeStore);
  private imageStore = IocContainer.get<ImageStoreType>(IocTypes.ImageStore);
  private payerDocumentsStore = IocContainer.get<PayerDocumentsStoreType>(IocTypes.PayerDocumentsStore);

  constructor() {
    this.clearPayerStore();
  }

  public setPayer(payer: IPayer) {
    this.payer = payer;
  }

  public isRouteAllowed(feature: PayerStoreFeatures) {
    return this.featuresMap[feature];
  }

  public async loadPayerConfigByName(payerName: string) {
    payerName = payerName.toLowerCase();

    return this.loadPayerConfigInternal(() => {
      return IocContainer.get<DataServicesApi>(IocTypes.DataServicesApi).getPayerConfigByName({ payerShortName: payerName });
    });
  }

  public async loadPayerConfigByPayerId(customerId: string) {
    return this.loadPayerConfigInternal(() => {
      return IocContainer.get<DataServicesApi>(IocTypes.DataServicesApi).getPayerConfigByPayerId({
        payerId: customerId
      });
    });
  }

  public async loadPayerFullData(customerId: string, data: LoadPayerFullDataOptions) {
    const { loadConfig = true, waitForAllLoadingTasks = false, loadTheme = true, loadDocuments = false, loadImageLogos = false, loadImageLandingBackground = false } = data || {};

    if (loadConfig) {
      await this.loadPayerConfigByPayerId(customerId);
    }
    if (this.apiError) {
      return;
    }

    const loadingPromises = [];

    if (loadTheme) {
      loadingPromises.push(this.themeStoreHandler.loadPayerTheme(customerId, data.useStorageCache));
    }
    if (loadDocuments) {
      loadingPromises.push(this.payerDocumentsStore.getDocument(customerId, DocumentsCategories.Landing, true));
    }
    if (loadImageLogos) {
      loadingPromises.push(this.imageStore.loadLogoByType(customerId, LogoType.Dark, data.useStorageCache));
      loadingPromises.push(this.imageStore.loadLogoByType(customerId, LogoType.Light, data.useStorageCache));
    }
    if (loadImageLandingBackground) {
      loadingPromises.push(this.imageStore.loadLogoByType(customerId, LogoType.Landing, data.useStorageCache));
    }

    if (waitForAllLoadingTasks) {
      await Promise.all(loadingPromises);
    }
  }
  public async loadPayerFullDataByName(customerName: string, data: LoadPayerFullDataOptions) {
    const { loadConfig = true, loadTheme = true, loadDocuments = false, loadImageLogos = false, loadImageLandingBackground = false } = data || {};

    await this.loadPayerConfigByName(customerName).then(async () => {
      if (this.payer?.guid) {
        this.loadPayerFullData(this.payer?.guid, { ...data, loadConfig: false });
      }
    });
  }
  private async loadPayerConfigInternal(loader: () => Promise<DataServicesApiData.GetPayerConfigByPayerId.Response> | Promise<DataServicesApiData.GetPayerConfigByName.Response>) {
    try {
      runInAction(() => {
        this.loading = true;
        this.apiError = null;
      });
      if (!this.appConfigStore?.currentConfig?.payersConfig) {
        await this.appConfigStore.loadConfig();
      }

      const response = await loader();
      if (response.status == HTTP_STATUS_CODES.SUCCESS) {
        const { data } = response;

        const payerId = data?.customer_id;
        const payerName = data?.customer_name;
        if (payerId == null || payerId.trim() === '') {
          runInAction(() => {
            this.apiError = new ApiError(response.status, '');
          });
          return;
        }

        const responsePayerSettings = await IocContainer.get<DataServicesApi>(IocTypes.DataServicesApi).getPayerSettingsByPayerId({
          payerId,
          stage: 'published'
        });

        const responsePayerFeatureToHide = await IocContainer.get<DataServicesApi>(IocTypes.DataServicesApi).getPayerSettings({
          payerId
        });

        if (responsePayerSettings.status == HTTP_STATUS_CODES.SUCCESS) {
          const useFederatedId = this.appConfigStore?.currentConfig?.useFederatedId != false;

          let payer: IPayer = {
            guid: data?.customer_id,
            fullName: data?.customer_name,
            shortName: data?.short_name,
            federatedId: useFederatedId ? data?.federated_id : null,
            mdmId: data?.mdm_id,
            phoneNumbers: responsePayerSettings?.data?.phoneNumbers,
            emailAddresses: responsePayerSettings?.data?.emailAddresses,
            address: responsePayerSettings?.data?.address,
            url: responsePayerSettings?.data?.url,
            publicName: responsePayerSettings?.data?.publicName,
            copyrightStatement: responsePayerFeatureToHide?.data?.legal?.copyright?.published
          };

          let newFeaturesMap = { ...this.featuresMap };

          const payerConfigsVal = this.appConfigStore?.currentConfig?.payersConfig;
          if (payerConfigsVal) {
            const payerConfigs = JSON.parse(payerConfigsVal);
            const payerConfig = payerConfigs[payerName];
            if (payerConfig && payerConfig['featuresToHide']) {
              newFeaturesMap = {
                ...newFeaturesMap,
                [PayerStoreFeatures.EOBs]: payerConfig['featuresToHide']['eobs'] !== undefined ? !payerConfig['featuresToHide']['eobs'] : newFeaturesMap[PayerStoreFeatures.EOBs],
                [PayerStoreFeatures.HealthProfile]:
                  payerConfig['featuresToHide']['healthprofile'] !== undefined ? !payerConfig['featuresToHide']['healthprofile'] : newFeaturesMap[PayerStoreFeatures.HealthProfile],
                [PayerStoreFeatures.FindCare]: payerConfig['featuresToHide']['findcare'] !== undefined ? !['featuresToHide']['findcare'] : newFeaturesMap[PayerStoreFeatures.FindCare]
              };
            }
          }

          if (responsePayerFeatureToHide.status === HTTP_STATUS_CODES.SUCCESS && responsePayerFeatureToHide.data && responsePayerFeatureToHide.data[NavigationMenuItemName]) {
            const navMenu = responsePayerFeatureToHide.data[NavigationMenuItemName];

            Object.keys(navMenu).forEach(key => {
              if (navMenu[key]?.active?.published && navMenu[key].id && idToFeatureMap[navMenu[key].id]) {
                newFeaturesMap[idToFeatureMap[navMenu[key].id]] = true;
              } else if (navMenu[key].id && idToFeatureMap[navMenu[key].id]) {
                newFeaturesMap[idToFeatureMap[navMenu[key].id]] = false;
              }
            });
          }

          const appConfig = this.appConfigStore.currentConfig;
          if (appConfig.hideFindCare) {
            newFeaturesMap[PayerStoreFeatures.FindCare] = false;
          }
          if (appConfig.hideHealthProfile) {
            newFeaturesMap[PayerStoreFeatures.HealthProfile] = false;
          }
          if (appConfig.hideP2P) {
            newFeaturesMap[PayerStoreFeatures.LinkedServicesRequests] = false;
          }

          runInAction(() => {
            this.featuresMap = newFeaturesMap;
            this.setPayer(payer);
          });
        } else {
          runInAction(() => {
            this.apiError = new ApiError(responsePayerSettings.status, '');
          });
        }
      } else {
        runInAction(() => {
          this.apiError = new ApiError(response.status, '');
        });
      }
    } catch (err) {
      runInAction(() => {
        this.apiError = err;
      });

      console.log(err);
    } finally {
      runInAction(() => {
        this.loading = false;
      });
    }
  }

  get payerName(): string {
    const payerName = this.payer?.fullName || this.payer?.shortName || '';
    return payerName;
  }

  get primaryPhone(): string {
    let primaryPhone = this.payer?.phoneNumbers?.find(phoneNumber => phoneNumber.primary)?.number;
    if (!primaryPhone) primaryPhone = this.payer?.phoneNumbers?.find(phoneNumber => phoneNumber.number)?.number;
    return primaryPhone ?? '';
  }

  get primaryEmail(): string {
    let primaryEmail = this.payer?.emailAddresses?.find(emailAddress => emailAddress.primary)?.email;
    if (!primaryEmail) primaryEmail = this.payer?.emailAddresses?.find(emailAddress => emailAddress.email)?.email;
    return primaryEmail ?? '';
  }

  //ConnectedHealthSupport@changehealthcare.com -> ConnectedHealthSupport
  get primaryEmailPart1() {
    let emailPart1 = '';
    try {
      emailPart1 = this.primaryEmail?.split('@')[0] || '';
    } catch {}
    return emailPart1;
  }

  //ConnectedHealthSupport@changehealthcare.com -> @changehealthcare.com
  get primaryEmailPart2() {
    let emailPart2 = '';
    try {
      emailPart2 = '@' + this.primaryEmail?.split('@')[1] || '';
    } catch {}
    return emailPart2;
  }
}

decorate(PayerStore, {
  loadPayerConfigByName: action,
  loadPayerConfigByPayerId: action,
  clearPayerStore: action,
  loadPayerFullData: action,
  loadPayerFullDataByName: action,
  payer: observable,
  setPayer: action,
  loading: observable,
  payerName: computed,
  primaryPhone: computed,
  primaryEmail: computed,
  primaryEmailPart1: computed,
  primaryEmailPart2: computed,
  apiError: observable,
  featuresMap: observable
});

export default PayerStore;
export type { PayerStore as PayerStoreType };
