import { observable, action, decorate } from 'mobx';
import { injectable, interfaces } from 'inversify';

import { IocContainer, IocTypes, LinkedServiceStoreType } from '../inversify.config';
import { LinkedService } from '.';
import { LinkedServicesApi } from '../services/apis/linked-services/linked-services-api';
import { HTTP_STATUS_CODES } from '../services/apis/base-api';

@injectable()
class LinkedServicesListStore {
  public linkedServices: LinkedServiceStoreType[];
  public loading: boolean | null;
  public isError: boolean;
  public errorCode: number | null;

  private linkedServiceStoreType = IocContainer.get<interfaces.Newable<LinkedServiceStoreType>>(IocTypes.LinkedServiceStore);

  constructor() {
    this.linkedServices = [];
    this.loading = false;
    this.isError = false;
    this.errorCode = null;
  }

  public resetStore() {
    this.linkedServices = [];
    this.loading = false;
    this.isError = false;
    this.errorCode = null;
  }

  setIsLoading(isLoading: boolean) {
    this.loading = isLoading;
  }

  setError(isError: boolean, errorCode: number | null = null) {
    this.isError = isError;
    this.errorCode = errorCode;
  }

  private addService(service: LinkedService) {
    const linkedServiceStoreInstance = new this.linkedServiceStoreType(service);
    this.linkedServices.push(linkedServiceStoreInstance);
  }

  setLinkedServices(incomingServices: LinkedService[]) {
    if (!incomingServices || incomingServices.length === 0) return;

    this.linkedServices = [];
    incomingServices.forEach((application: LinkedService) => {
      this.addService(application);
    });
  }

  async getAppsList() {
    this.setIsLoading(true);

    try {
      this.setIsLoading(true);

      const response = await IocContainer.get<LinkedServicesApi>(IocTypes.LinkedServicesApi).getAllApplications({});
      // const response = await linkedServicesApi.getAllApplications();
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        this.setLinkedServices(response.data);
        this.setError(false);
      } else {
        this.setLinkedServices([]);
        this.setError(true, response.status);
      }
    } catch (err) {
      this.setIsLoading(false);
      this.setLinkedServices([]);
      console.error('linked Services: error occured: ', err);
      this.setError(true, err.statusCode);
      console.error('linked Services: Something went wrong: ', JSON.stringify(err));
    } finally {
      this.setIsLoading(false);
    }
  }

  public getService(id: string) {
    return this.linkedServices?.find(service => service.id === id);
  }
}

decorate(LinkedServicesListStore, {
  linkedServices: observable,
  loading: observable,
  isError: observable,
  errorCode: observable,

  setLinkedServices: action,
  setIsLoading: action,
  setError: action,
  resetStore: action
});

export default LinkedServicesListStore;
export { LinkedServicesListStore as LinkedServicesListStoreType };
