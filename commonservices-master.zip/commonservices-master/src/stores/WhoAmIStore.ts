import { observable, action, computed, decorate, runInAction } from 'mobx';
import moment from 'moment';

import { cloneDeep } from 'lodash';
//CommonServices

import { injectable } from 'inversify';
import { ADDRESS, APPS, COMPANY, PHONE_NUMBERES } from '../utilities/Auth';
import { ApiError, IocContainer, IocTypes, WhoAmIApi } from '..';
import { formatDate, FULL_DATE_FORMAT, isNowDateBetween, isValidDate } from '../utilities/dates';
import { getFullNameFormatWhoAmI, concatFullName } from '../utilities/fhir/helper';

export interface UserProfile {
  address: ADDRESS;
  full_name: string | null;
  birth_date: string | null;
  gender: string | null;
  phone_number: string | null; //check what to do with that duplicate:
  email: string;
  avatar: Avatar | null;
  dependents: Dependent[] | null;
}

export type Dependent = {
  dependentFullName: string;
  dependentBirthDate: string; //YYYY-MM-DD
  dependentPlanName: string;
  dependentMemberNumber: string;
};

export type Avatar = {
  contentType: string;
  data: string;
  url: string;
};

export type PayerInfo = {
  subscriberNumber: string | null;
  healthCoverage: {
    groupNumber: string | null;
    policyNumber: string | null;
    planId: string | null;
    planName: string | null;
    coverageStart: string | null; //YYYY-MM-DD
    coverageEnd: string | null; //YYYY-MM-DD
  };
};

export type DelegateForMember = {
  family: string | null;
  given: string | null;
  fullName: string | null;
  emailAddress: string | null;
  periodStartDateTime: string | null;
  periodEndDateTime: string | null;
};

enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other',
  Unknown = 'Unknown'
}
@injectable()
class WhoAmIStore {
  public basicInfo: UserProfile | null;
  public basicInfoError: ApiError;
  public basicInfoLoading: boolean;
  public _payerInfo: PayerInfo[] | null;
  public payerInfoError: ApiError;
  public payerInfoLoading: boolean;
  public delegatesForMember: DelegateForMember[] | null;
  public delegatesForMemberError: ApiError;
  public delegatesForMemberLoading: boolean;

  constructor() {
    this.payerInfoLoading = false;
    this.basicInfoLoading = false;
    this.delegatesForMemberLoading = false;
    this.basicInfo = null;
    this.basicInfoError = null;
    this._payerInfo = null;
  }
  resetStore() {
    this.payerInfoLoading = false;
    this.basicInfoLoading = false;
    this.basicInfo = null;
    this.basicInfoError = null;
    this._payerInfo = null;
    this.delegatesForMember = null;
    this.delegatesForMemberError = null;
  }

  public async loadBasicInfo() {
    try {
      runInAction(() => {
        this.basicInfo = null;
        this.basicInfoLoading = true;
        this.basicInfoError = null;
      });

      const response = await IocContainer.get<WhoAmIApi>(IocTypes.WhoAmIApi).getBasicInfo({ defaultUser: false });

      if (response.status === 200) {
        const humanName = response.data?.humanName;
        let fullName: string | null = getFullNameFormatWhoAmI(humanName);
        const birthDate = response?.data?.birthDate;
        const gender = response?.data?.gender;
        const email = response?.data?.email;

        let address: ADDRESS = {
          city: '',
          line1: '',
          line2: '',
          state: '',
          zip: ''
        };
        address.line1 = !(response?.data?.address?.line?.length > 0) ? '' : response?.data?.address?.line[0];
        address.city = response?.data?.address?.city;
        address.state = response?.data?.address?.state;
        address.zip = response?.data?.address?.postalCode;

        let avatar: Avatar = {
          contentType: response?.data?.avatar?.contentType,
          data: response?.data?.avatar?.data,
          url: response?.data?.avatar?.url
        };

        const phone = response?.data?.phone;

        let dependents: Dependent[] = [];
        for (const element of response?.data?.dependents || []) {
          let dependent: Dependent = {
            dependentFullName: element?.dependentFullName,
            dependentBirthDate: element?.dependentBirthDate ?? element?.dependentDob,
            dependentMemberNumber: element?.dependentMemberNumber,
            dependentPlanName: element?.dependentPlanName
          };
          dependents.push(dependent);
        }

        let userProfile: UserProfile = {
          address: address,
          full_name: fullName,
          birth_date: birthDate,
          gender: gender,
          phone_number: phone,
          email: email,
          avatar: avatar,
          dependents: dependents
        };

        userProfile.dependents = this.getSortedDependents(userProfile.dependents);
        userProfile.gender = this.formatGender(userProfile.gender);
        userProfile.birth_date = this.formatBirthDate(userProfile.birth_date);
        runInAction(() => {
          this.basicInfo = userProfile;
        });
      } else {
        runInAction(() => {
          this.basicInfoError = new ApiError(response.status, '');
        });
      }
    } catch (error) {
      runInAction(() => {
        this.basicInfoError = error;
      });
    } finally {
      runInAction(() => {
        this.basicInfoLoading = false;
      });
    }
  }

  public async loadPayerInfo() {
    try {
      runInAction(() => {
        this._payerInfo = null;
        this.payerInfoLoading = true;
        this.payerInfoError = null;
      });

      const response = await IocContainer.get<WhoAmIApi>(IocTypes.WhoAmIApi).getPayerInfo({});

      if (response.status === 200 && response?.data) {
        const payerInfoList: PayerInfo[] = response.data.map(infoData => {
          const { subscriberNumber = null } = infoData;
          const { coverageStart = null, coverageEnd = null, groupNumber = null, policyNumber = null, planId = null, planName = null } = infoData.healthCoverage;
          const payerInfo: PayerInfo = {
            subscriberNumber,
            healthCoverage: {
              groupNumber,
              policyNumber,
              planId,
              planName,
              coverageStart: isValidDate(coverageStart) ? coverageStart : null,
              coverageEnd: isValidDate(coverageEnd) ? coverageEnd : null
            }
          };
          return payerInfo;
        });
        runInAction(() => {
          this._payerInfo = payerInfoList;
        });
      } else {
        runInAction(() => {
          this.payerInfoError = new ApiError(response.status, '');
        });
      }
    } catch (error) {
      runInAction(() => {
        this.payerInfoError = error;
      });
    } finally {
      runInAction(() => {
        this.payerInfoLoading = false;
      });
    }
  }

  private formatBirthDate(birth_date: string) {
    return isValidDate(birth_date) ? formatDate(birth_date, FULL_DATE_FORMAT, false) : null;
  }

  private getSortedDependents(dependents: Dependent[]) {
    dependents = [...dependents];
    dependents?.sort((a, b) => {
      if (a.dependentBirthDate && b.dependentBirthDate) {
        return moment(a.dependentBirthDate, 'YYYY-MM-DD').valueOf() - moment(b.dependentBirthDate, 'YYYY-MM-DD').valueOf();
      } else if (a.dependentBirthDate) {
        return -1;
      } else if (b.dependentBirthDate) {
        return 1;
      } else {
        return 0;
      }
    });
    return dependents;
  }

  private formatGender(gender: string) {
    if (gender?.trim().toUpperCase() === Gender.Female.toUpperCase()) {
      gender = Gender.Female.toString();
    } else if (gender?.trim().toUpperCase() === Gender.Male.toUpperCase()) {
      gender = Gender.Male.toString();
    } else {
      gender = '';
    }
    return gender;
  }

  // The earliest (coverageStart) active payer info.
  public get payerInfo(): PayerInfo | null {
    if (!this._payerInfo) {
      return null;
    }

    const now = new Date();
    // Taking the earliest (by coverageStart) payer between active ones (current date is inside coverage range).
    const currentPayerInfoList = this._payerInfo
      .filter(
        payerInfo =>
          payerInfo.healthCoverage &&
          (!payerInfo.healthCoverage.coverageEnd || moment(payerInfo.healthCoverage.coverageEnd).isSameOrAfter(now)) &&
          payerInfo.healthCoverage.coverageStart &&
          moment(payerInfo?.healthCoverage?.coverageStart).isSameOrBefore(now)
      )
      .sort((a: PayerInfo, b: PayerInfo) => (moment(b.healthCoverage.coverageStart).isSameOrAfter(moment(a.healthCoverage.coverageStart)) ? -1 : 1));

    return currentPayerInfoList.length > 0 ? currentPayerInfoList[0] : null;
  }

  public async loadDelegatesForMember() {
    try {
      runInAction(() => {
        this.delegatesForMember = null;
        this.delegatesForMemberLoading = true;
        this.delegatesForMemberError = null;
      });
      const response = await IocContainer.get<WhoAmIApi>(IocTypes.WhoAmIApi).getDelegatesForMember({});

      if (response.status === 200 && response?.data) {
        const delegatesForMemberList: DelegateForMember[] = response.data.map(data => {
          const { family = null, given = null, emailAddress = null, periodStartDateTime = null, periodEndDateTime = null } = data;
          let fullName: string | null = concatFullName(data);

          const delegateData: DelegateForMember = {
            family,
            given,
            fullName,
            emailAddress,
            periodStartDateTime: isValidDate(periodStartDateTime) ? formatDate(periodStartDateTime, FULL_DATE_FORMAT, false) : null,
            periodEndDateTime: isValidDate(periodEndDateTime) ? formatDate(periodEndDateTime, FULL_DATE_FORMAT, false) : null
          };
          return delegateData;
        });
        runInAction(() => {
          this.delegatesForMember = delegatesForMemberList;
        });
      } else {
        console.error('error', response);
        runInAction(() => {
          this.delegatesForMemberError = new ApiError(response.status, '');
        });
      }
    } catch (error) {
      console.error('error', error);
      runInAction(() => {
        this.delegatesForMemberError = error;
      });
    } finally {
      runInAction(() => {
        this.delegatesForMemberLoading = false;
      });
    }
  }
  public get activeDelegatesForMember() {
    return this.delegatesForMember
      ? this.delegatesForMember.filter(elem => {
          return isNowDateBetween(elem.periodStartDateTime, elem.periodEndDateTime, FULL_DATE_FORMAT);
        })
      : null;
  }
}

decorate(WhoAmIStore, {
  basicInfoLoading: observable,
  basicInfo: observable,
  basicInfoError: observable,
  delegatesForMember: observable,
  activeDelegatesForMember: computed,
  delegatesForMemberLoading: observable,
  delegatesForMemberError: observable,
  payerInfoLoading: observable,
  _payerInfo: observable,
  payerInfo: computed,
  loadPayerInfo: action,
  loadBasicInfo: action,
  loadDelegatesForMember: action,
  resetStore: action
});

export default WhoAmIStore;

export { WhoAmIStore as WhoAmIStoreType };
