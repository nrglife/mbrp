import { observable, action, decorate } from "mobx";
import { injectable } from "inversify";

import { ApiError } from "../services/apis/base-api";

export interface GetNextPageParams {
  numberOfRetries?: number;
  callback: ([]) => void;
}

@injectable()
class BaseStore {
  public nextPageKey: string;
  public loading: boolean | null;
  public loadingNextPage: boolean | null;
  public apiError: ApiError;
  public apiErrorNextPage: ApiError;

  constructor() {
    this.loading = false;
    this.loadingNextPage = false;
    this.apiError = null;
    this.apiErrorNextPage = null;
  }

  resetErrorsAndLoaders() {
    this.nextPageKey = null;
    this.loading = false;
    this.loadingNextPage = false;
    this.apiErrorNextPage = null;
  }

  setIsLoading(isLoading: boolean) {
    this.loading = isLoading;
  }

  setIsLoadingNextPage(isLoading: boolean) {
    this.loadingNextPage = isLoading;
  }

  setApiErrorNextPage(apiError: ApiError | null) {
    this.apiErrorNextPage = apiError;
  }
}

decorate(BaseStore, {
  apiError: observable,
  apiErrorNextPage: observable,
  nextPageKey: observable,
  loading: observable,
  loadingNextPage: observable,
  setIsLoading: action,
  setIsLoadingNextPage: action,
  setApiErrorNextPage: action,
  resetErrorsAndLoaders: action,
});

export default BaseStore;
export { BaseStore as BaseStoreType };
