import { observable, action, computed, decorate, reaction, isComputedProp, runInAction } from 'mobx';
import { injectable, interfaces } from 'inversify';

import { IocContainer, IocTypes, EOBStoreType } from '../inversify.config';
// import EOBStore from './EOBStore';
import { getDateFromDateTime } from '../utilities/dates';
import { EOB, eobBundleEntry } from '../utilities/fhir/eob-types';
import { getTotalAmounts, isValidAmount } from '../utilities/fhir/helper';
import { ContainedReference, ContainedResourcesTypes, CurrencyCodes } from '../utilities/fhir/types';
import { EOBSapi, EOBSapiGetExplanationOfBenefitParams } from '../services/apis/eobs/eobs-api';
import { HTTP_STATUS_CODES, ApiError, BaseResponse } from '../services/apis/base-api';
import { link } from 'fs';
import BaseListStore, { FetchDataParamsBase } from './BaseListStore';
import { GetNextPageParams } from './BaseListStore';

export interface GetEOBsNextPageParams {
  numberOfRetries?: number;
}

enum FieldsToArrangeBy {
  Created = 'created',
  None = 'none'
}

@injectable()
class EOBListStore extends BaseListStore<EOBSapiGetExplanationOfBenefitParams, BaseResponse, FetchDataParamsBase, GetNextPageParams> {
  //public nextPageKey: string;
  public eobs: EOBStoreType[];
  public selected: EOBStoreType | null;
  public includedResources: ContainedReference[];
  //public pageNumber: number;

  private eobStoreType = IocContainer.get<interfaces.Newable<EOBStoreType>>(IocTypes.EOBStore);

  constructor() {
    super();
    this.eobs = [];
    this.selected = null;
    this.includedResources = [];
  }

  protected getDefaultNextPageParams() {
    return {};
  }

  protected shouldLoadNextPage() {
    return !this.eobs || this.eobs.length == 0;
  }

  protected getApi() {
    return IocContainer.get<EOBSapi>(IocTypes.EOBSapi);
  }

  protected getFetchFunc() {
    return IocContainer.get<EOBSapi>(IocTypes.EOBSapi).getExplanationOfBenefit.bind(IocContainer.get<EOBSapi>(IocTypes.EOBSapi));
  }

  protected mapParams(params: FetchDataParamsBase) {
    return {
      withIncluded: true,
      errorHandlerParam: null,
      successHandlerParam: null,
      precallHandlerParam: null,
      sortBy: {
        descending: true,
        fieldName: FieldsToArrangeBy.Created
      }
    };
  }
  protected mapNextPageParams(params: GetNextPageParams) {
    const { numberOfRetries = 1 } = params;
    return {
      errorHandlerParam: null,
      successHandlerParam: null,
      precallHandlerParam: null,
      numberOfRetries: numberOfRetries
    };
  }

  protected setData(response: BaseResponse) {
    this.setEOBs(response.data.entry);
  }

  protected setDataNextPage(response: BaseResponse) {
    this.setEOBs(response.data.entry, false);
  }

  protected resetStoreImpl() {
    this.eobs = [];
    this.selected = null;
    this.includedResources = [];
    this.resetErrorsAndLoaders();
  }

  private addEOB(eob: EOB) {
    const eobStore = new this.eobStoreType(eob, this.includedResources);
    this.eobs.push(eobStore);
  }

  setEOBs(entries: eobBundleEntry[], newList: boolean = true) {
    if (!entries || entries.length === 0) return;
    if (!newList) {
      this.eobs = [...this.eobs];
    }
    entries.forEach((item: eobBundleEntry) => {
      if (item.resource?.resourceType === ContainedResourcesTypes.ExplanationOfBenefit) {
        this.addEOB(item.resource as EOB);
      } else {
        this.includedResources.push(item.resource as ContainedReference);
      }
    });
  }

  setSelectedEOB(eob: EOBStoreType | null) {
    this.selected = eob;
  }

  get totalCoveredByInsuranceForPeriod() {
    if (this.eobs == null || this.eobs.length === 0) return null;

    let coveredByInsurancePerEOB = this.eobs
      .filter(eob => isValidAmount(eob.coveredByInsuranceAmount?.amount, eob.coveredByInsuranceAmount?.isComplete))
      .map(eob => eob.coveredByInsuranceAmount?.amount);

    let isComplete = coveredByInsurancePerEOB?.length === this.eobs.length;

    return getTotalAmounts(coveredByInsurancePerEOB, isComplete);
  }
}

decorate(EOBListStore, {
  eobs: observable,
  selected: observable,
  totalCoveredByInsuranceForPeriod: computed,
  setSelectedEOB: action,
  setEOBs: action.bound
});

export default EOBListStore;
export { EOBListStore as EOBListStoreType };
