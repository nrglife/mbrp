import { observable, computed, decorate, action, autorun, toJS } from 'mobx';
import { injectable } from 'inversify';
import { failureSource } from '../utilities/consts/failureSource';
import { isArray } from 'lodash';
import { IocContainer, IocTypes } from '../inversify.config';
import { ErrorStoreConfigProvider } from '../services/apis/base-config';

interface ErrorEntry {
  code?: number;
  source: failureSource;
  isNextPage: boolean;
  timeStamp: number;
}

type Errors = {
  [key in failureSource]?: ErrorEntry;
};

@injectable()
class ErrorStore {
  public errors: Errors;
  constructor() {
    this.errors = {};
  }

  clearError(source: failureSource) {
    if (this.errors[source]) {
      delete this.errors[source];
      this.errors = { ...this.errors };
    }
  }

  getLastFilteredError(errorSource: null | failureSource[] | failureSource = null, ignoreNextPageError: boolean | null = true): ErrorEntry {
    let ret: ErrorEntry[] = [];
    let sources: failureSource[] = Object.keys(this.errors) as failureSource[];

    if (errorSource) {
      if (isArray(errorSource)) {
        sources = errorSource;
      } else {
        sources = [errorSource];
      }
    }
    sources.forEach(errorSource => {
      if (this.errors[errorSource] && (!ignoreNextPageError || (ignoreNextPageError && !this.errors[errorSource].isNextPage))) {
        ret.push(this.errors[errorSource]);
      }
    });
    ret.sort((a, b) => {
      return a.timeStamp - b.timeStamp;
    });
    return ret.length ? ret[ret.length - 1] : null;
  }

  clearAllErrors() {
    this.errors = {};
  }

  setError(source: failureSource, code: number | null = null, isNextPage: boolean) {
    if (IocContainer.get<ErrorStoreConfigProvider>(IocTypes.ErrorStoreConfigProvider)().disableLogging) {
      return;
    }
    this.errors = {
      ...this.errors,
      [source]: {
        code: code,
        source: source,
        isNextPage: isNextPage,
        timeStamp: new Date().getTime()
      }
    };
  }
}

decorate(ErrorStore, {
  errors: observable,
  clearError: action,
  clearAllErrors: action,
  setError: action
});

export default ErrorStore;
export { ErrorStore as ErrorStoreType };
