import { observable, action, decorate, runInAction } from 'mobx';
import { injectable } from 'inversify';

import { ApiCallParamsBase, ApiError, BaseApi, BaseResponse, HTTP_STATUS_CODES } from '../services/apis/base-api';
import { IocContainer, IocTypes } from '..';
import { AlertProvider } from '../services/apis/base-config';

export interface GetNextPageParams {
  numberOfRetries?: number;
  callback?: ([]) => void;
}

export interface FetchDataParamsBase {}

export enum ReqStatus {
  IDE = 'IDE',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
  LOADING = 'LOADING',
  NO_INTERNET = 'NO_INTERNET'
}

@injectable()
abstract class BaseListStore<ApiCallParams extends ApiCallParamsBase, ResponseType extends BaseResponse, FetchDataParams extends FetchDataParamsBase, NextPageParams extends GetNextPageParams> {
  @observable
  public initialReqStatus: ReqStatus;
  @observable
  public nextPageStatus: ReqStatus;
  @observable
  public nextPageKey: string;

  protected abstract getFetchFunc(): (FetchDataParamsT) => Promise<ResponseType>;
  protected abstract getApi(): BaseApi<any>;
  protected abstract mapParams(FetchDataParams): ApiCallParams;
  protected abstract mapNextPageParams(NextPageParams): ApiCallParamsBase;
  protected abstract resetStoreImpl();
  protected abstract setData(ResponseType);
  protected abstract setDataNextPage(ResponseType);
  protected abstract shouldLoadNextPage(): boolean;
  protected abstract getDefaultNextPageParams(): NextPageParams;
  @action
  resetStore() {
    this.resetErrorsAndLoaders();

    this.resetStoreImpl();
  }

  async fetchData(params: FetchDataParams) {
    try {
      this.setInitialReqStatus(ReqStatus.LOADING);

      const response = await this.getFetchFunc()(this.mapParams(params));
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        this.resetStore();
        this.setNextPageKey(response.nextPageKey);
        this.setData(response);
        if (!this.shouldLoadNextPage()) {
          this.setInitialReqStatus(ReqStatus.SUCCESS);
        } else {
          await this.getNextPage(null, false, true);
        }
      } else {
        this.setInitialReqStatus(ReqStatus.ERROR);
      }
    } catch (err) {
      if ((err as ApiError).statusCode == HTTP_STATUS_CODES.NO_INTERNET) {
        // this.setInitialReqStatus(ReqStatus.NO_INTERNET);
        this.setInitialReqStatus(ReqStatus.ERROR);
      } else {
        this.setInitialReqStatus(ReqStatus.ERROR);
      }
    } finally {
    }
  }

  @action
  setNextPageKey(key: string) {
    this.nextPageKey = key;
  }

  async getNextPage(params: NextPageParams, isRetry: boolean, isInitial?: boolean) {
    if (!isInitial && (this.nextPageStatus == ReqStatus.LOADING || (!isRetry && this.nextPageStatus == ReqStatus.ERROR) || this.initialReqStatus != ReqStatus.SUCCESS)) {
      return;
    }
    params = !params ? this.getDefaultNextPageParams() : params;
    if (!this.nextPageKey) {
      if (isInitial) {
        this.setInitialReqStatus(ReqStatus.SUCCESS);
      } else {
        this.setNextPageStatus(ReqStatus.SUCCESS);
      }
      return;
    }
    try {
      if (isInitial) {
        this.setInitialReqStatus(ReqStatus.LOADING);
      } else {
        this.setNextPageStatus(ReqStatus.LOADING);
      }

      const response = await this.getApi().getNextPage(this.nextPageKey, this.mapNextPageParams(params));
      if (response.status === HTTP_STATUS_CODES.SUCCESS) {
        this.setNextPageKey(response.nextPageKey);
        this.setDataNextPage(response);
        if (!this.shouldLoadNextPage()) {
          if (isInitial) {
            this.setInitialReqStatus(ReqStatus.SUCCESS);
          } else {
            this.setNextPageStatus(ReqStatus.SUCCESS);
          }
        } else {
          await this.getNextPage(params, isRetry, isInitial);
        }
      } else {
        if (isInitial) {
          this.setInitialReqStatus(ReqStatus.ERROR);
        } else {
          this.setNextPageStatus(ReqStatus.ERROR);
        }
      }
    } catch (err) {
      if (isInitial) {
        this.setInitialReqStatus(ReqStatus.ERROR);
      } else {
        this.setNextPageStatus(ReqStatus.ERROR);
      }
    } finally {
    }
  }

  constructor() {
    this.nextPageKey = null;
    this.initialReqStatus = ReqStatus.IDE;
    this.nextPageStatus = ReqStatus.IDE;
  }
  @action
  resetErrorsAndLoaders() {
    this.nextPageKey = null;
    this.initialReqStatus = ReqStatus.IDE;
    this.nextPageStatus = ReqStatus.IDE;
  }
  @action
  setInitialReqStatus(status: ReqStatus) {
    this.initialReqStatus = status;
  }

  @action
  setNextPageStatus(status: ReqStatus) {
    this.nextPageStatus = status;
  }
}

export default BaseListStore;
export { BaseListStore as BaseListStoreType };
