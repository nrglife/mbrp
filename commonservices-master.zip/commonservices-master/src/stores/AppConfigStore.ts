import { injectable } from "inversify";
import { observable, action, computed, decorate, runInAction } from "mobx";
import { AppConfigurationApi, IocContainer, IocTypes } from "..";

enum Category {
  appSupportEmails = "appSupportEmails",
  appSupportNames = "appSupportNames",
  appSupportPhoneNumbers = "appSupportPhoneNumbers",
}

export type Categories =
  | Category.appSupportEmails
  | Category.appSupportNames
  | Category.appSupportPhoneNumbers;

export interface AppMessage {
  showMessage: boolean;
  title: string;
  message: string;
  showCloseButton: boolean;
  closeButtonText: string;
  startDate: Date;
  endDate: Date;
}

export interface AppPreferences {
  appMessage: AppMessage;
  appSupportDetails: Record<Categories, [string | null]>;
  appSupportVisible: boolean;
  insuranceSupportVisible: boolean;
  appVersions: any;
  surveyURL: string;
  payersConfig: string;
  filterFindCareByLocation: boolean;
  hideFindCare: boolean;
  hideHealthProfile: boolean;
  useAuthCodeFlow: boolean;
  useFederatedId: boolean;
  showMessagingPlatform: boolean;
  smileCDRRevokeURL: string;
  disableDisplayErrorCodes: boolean;
  healthProfileHideInvalidRecords: boolean;
  hideP2P:boolean
}

const DEFAULT_CONFIG: AppPreferences = {
  appMessage: null,
  appSupportDetails: {
    appSupportEmails: [null],
    appSupportNames: [null],
    appSupportPhoneNumbers: [null],
  },
  appSupportVisible: true,
  insuranceSupportVisible: true,
  appVersions: {},
  surveyURL: "",
  payersConfig: null,
  filterFindCareByLocation: true,
  hideFindCare: true,
  hideP2P:true,
  hideHealthProfile: true,
  useAuthCodeFlow: true,
  useFederatedId: true,
  showMessagingPlatform: false,
  smileCDRRevokeURL: "",
  disableDisplayErrorCodes: false,
  healthProfileHideInvalidRecords: false,
};
@injectable()
class AppConfigStore {
  public config: AppPreferences = DEFAULT_CONFIG;
  public loading: boolean = true;
  public error: boolean = false;

  async loadConfig() {
    this.loading = true;
    try {
      const response = await IocContainer.get<AppConfigurationApi>(
        IocTypes.AppConfigurationApi
      ).getAppConfiguration({});

      runInAction(() => {
        this.config = response?.data?.success
          ? response.data.data
          : (this.config = DEFAULT_CONFIG);
        this.error = response?.data?.success ? false : true;
      });
    } catch (error) {
      runInAction(() => {
        this.error = true;
      });
    } finally {
      runInAction(() => {
        this.loading = false;
      });
    }
  }

  get currentConfig() {
    return this.config;
  }

  get email() {
    return this.config.appSupportDetails.appSupportEmails.length >= 1
      ? this.config.appSupportDetails.appSupportEmails[0]
      : null;
  }

  //ConnectedHealthSupport@changehealthcare.com -> ConnectedHealthSupport
  get emailPart1() {
    let emailPart1 = "";
    try {
      emailPart1 = this.email?.split("@")[0] || "";
    } catch {}
    return emailPart1;
  }

  //ConnectedHealthSupport@changehealthcare.com -> @changehealthcare.com
  get emailPart2() {
    let emailPart2 = "";
    try {
      emailPart2 = "@" + this.email?.split("@")[1] || "";
    } catch {}
    return emailPart2;
  }

  get phone() {
    return this.config.appSupportDetails.appSupportPhoneNumbers.length >= 1
      ? this.config.appSupportDetails.appSupportPhoneNumbers[0]
      : null;
  }

  get name() {
    return this.config.appSupportDetails.appSupportNames.length >= 1
      ? this.config.appSupportDetails.appSupportNames[0]
      : null;
  }

  get isLoading() {
    return this.loading;
  }

  get isError() {
    return this.error;
  }
}

decorate(AppConfigStore, {
  loading: observable,
  config: observable,
  error: observable,

  currentConfig: computed,
  isLoading: computed,
  isError: computed,
  email: computed,
  phone: computed,

  loadConfig: action,
});
export default AppConfigStore;
export { AppConfigStore as AppConfigStoreType };
