import { observable, computed, decorate, action, autorun, toJS } from 'mobx';
import { injectable } from 'inversify';

import { AdjudicationCategories, EOB, ServicesItem, TotalsAmountCategories } from '../utilities/fhir/eob-types';
import {
  getAdjudicationValueByCategory,
  getBillingAddress,
  getCareTeamReferenceIDByRole,
  getEOBItemDateString,
  getEOBItemMemberPrice,
  getEOBItemName,
  getEOBsServicesDatesRange,
  getFirstIncludedByReferenceId,
  getInsuranceCoveredAmountViaServices,
  getTotalByCategory
} from '../utilities/fhir/eob-helper';
import { isValidDate, sortByDate, sortByMemberPrice, SortTypes } from '../utilities/dates';
import { generateRandomID } from '../utilities/random-generator';
import { getAddressAs2Lines, getFullName, getTotalAmounts, isEmptyString, isValidAmount } from '../utilities/fhir/helper';
import {
  CalculatedAmount,
  CareTeamRoles,
  ContainedReference,
  ContainedResourcesTypes,
  ContainedResource_Location,
  ContainedResource_Organization,
  ContainedResource_Patient,
  ContainedResource_Practitioner,
  CurrencyCodes,
  Money,
  Reference
} from '../utilities/fhir/types';
import { uppercaseFirstLetter } from '../utilities/string';

@injectable()
class EOBStore {
  public uuid: string;
  public includedReferences: ContainedReference[];
  constructor(public eob: EOB, includedReferences: ContainedReference[]) {
    this.uuid = generateRandomID();
    this.includedReferences = includedReferences;
  }

  getPractitionerByRole(roles: CareTeamRoles[]) {
    const referenceId = getCareTeamReferenceIDByRole(this.eob, roles);

    let practitioner: ContainedResource_Practitioner | ContainedResource_Organization | null | undefined = null;
    if (referenceId && referenceId !== '') {
      practitioner = getFirstIncludedByReferenceId(this.includedReferences, referenceId, ContainedResourcesTypes.Practitioner) as ContainedResource_Practitioner;
      if (!practitioner) {
        practitioner = getFirstIncludedByReferenceId(this.includedReferences, referenceId, ContainedResourcesTypes.Organization) as ContainedResource_Organization;
      }
      return practitioner;
    }
    return null;
  }

  get EOBDate() {
    return getEOBsServicesDatesRange(this.eob);
  }

  getIncludedResourceByReferenceId(referenceObj: Reference | null | undefined, type: ContainedResourcesTypes) {
    const referenceId = referenceObj?.reference ? referenceObj?.reference : null;
    if (!referenceId || referenceId.trim() === '') return null;
    return getFirstIncludedByReferenceId(this.includedReferences, referenceId, type);
  }

  getFullName = (practitioner: ContainedResource_Practitioner | ContainedResource_Organization | null) => {
    let fullName: string | null | undefined = null;
    switch (practitioner?.resourceType) {
      case ContainedResourcesTypes.Practitioner:
        fullName = practitioner ? getFullName((practitioner as ContainedResource_Practitioner)?.name) : null;
        break;
      case ContainedResourcesTypes.Organization:
        fullName = practitioner ? (practitioner as ContainedResource_Organization).name : null;
        break;
    }
    return fullName;
  };

  get id() {
    return this.eob.id;
  }

  get patientName() {
    const patientId = this.eob.patient ? this.eob.patient.reference : '';
    const patient = getFirstIncludedByReferenceId(this.includedReferences, patientId);
    if (patient) {
      const patientData = patient as ContainedResource_Patient;

      const patientFullName = getFullName(patientData.name);

      return patientFullName;
    }

    return '';
  }

  get performingPractitionerFullName() {
    return this.performingPractitioner ? this.getFullName(this.performingPractitioner) : null;
  }

  get estimatedBalance(): CalculatedAmount | null | undefined {
    //Primary Strategy – At Claim Level:
    //Try to get by memberliability code
    let estimatedAmount = getTotalByCategory(this.eob, AdjudicationCategories.Member_Liability);
    //Try to get by copay code if no match
    if (!isValidAmount(estimatedAmount)) {
      estimatedAmount = getTotalByCategory(this.eob, AdjudicationCategories.Copay);
    }
    if (isValidAmount(estimatedAmount))
      return {
        amount: estimatedAmount,
        isComplete: true,
        isContainUnknownCurrency: isEmptyString(estimatedAmount?.currency)
      };

    //SecondaryStrategy – At Service line level:
    const serviceLineLevel = this.servicesTotalEstimatedBalance; //getEstimatedEobBalanceByServices(this.eob);
    return serviceLineLevel;
  }

  get totalPrice(): CalculatedAmount | null | undefined {
    //Primary Strategy – At Claim Level:
    //Try to get by eligible code
    let totalPriceAmount = getTotalByCategory(this.eob, TotalsAmountCategories.Eligible);
    if (isValidAmount(totalPriceAmount))
      return {
        amount: totalPriceAmount,
        isComplete: true,
        isContainUnknownCurrency: isEmptyString(totalPriceAmount?.currency)
      };

    //SecondaryStrategy – At Service line level:
    const serviceLineLevel = this.servicesTotalMemberPrice;
    return serviceLineLevel;
  }

  get coveredByInsuranceAmount(): CalculatedAmount | null | undefined {
    //PrimaryStrategy – Claim level 1:
    const coveredByInsuranceAmount = this.eob.payment?.amount;
    if (isValidAmount(coveredByInsuranceAmount))
      return {
        amount: coveredByInsuranceAmount,
        isComplete: true,
        isContainUnknownCurrency: isEmptyString(coveredByInsuranceAmount?.currency)
      };

    //Secondary Strategy – Claim level 2:
    const paymentAmount = getTotalByCategory(this.eob, TotalsAmountCategories.Payment_Amount);
    if (isValidAmount(paymentAmount))
      return {
        amount: paymentAmount,
        isComplete: true,
        isContainUnknownCurrency: isEmptyString(paymentAmount?.currency)
      };

    //Tertiary Strategy –Service Line Level
    const coveredEobByServices = getInsuranceCoveredAmountViaServices(this.eob);
    return coveredEobByServices;
  }

  get performingPractitioner() {
    return this.getPractitionerByRole([CareTeamRoles.Performing, CareTeamRoles.Prescribing]);
  }

  get facility() {
    return this.getIncludedResourceByReferenceId(this.eob?.facility, ContainedResourcesTypes.Location) as ContainedResource_Location;
  }

  get provider(): ContainedResource_Practitioner | ContainedResource_Organization | null {
    let provider: ContainedResource_Practitioner | ContainedResource_Organization | null = null;
    provider = this.getIncludedResourceByReferenceId(this.eob?.provider, ContainedResourcesTypes.Practitioner) as ContainedResource_Practitioner;
    if (provider == null) {
      provider = this.getIncludedResourceByReferenceId(this.eob?.provider, ContainedResourcesTypes.Organization) as ContainedResource_Organization;
    }
    return provider;
  }

  get providerFullName() {
    return this.provider ? this.getFullName(this.provider) : null;
  }

  get providerAddress() {
    const selectedAddress = this.provider ? getBillingAddress(this.provider.address) : null;
    return selectedAddress;
  }

  get servicesLevelData() {
    let tableData: ServicesItem[] = [];

    if (this.eob?.item != null && this.eob?.item.length > 0) {
      for (const item of this.eob.item) {
        const serviceLevel = {
          sortByDate: isValidDate(item?.servicedPeriod?.start) ? item?.servicedPeriod?.start : isValidDate(item?.servicedDate) ? item?.servicedDate : null,
          name: getEOBItemName(item),
          date: getEOBItemDateString(item),
          memberPrice: getAdjudicationValueByCategory(item, AdjudicationCategories.Eligible) ?? getEOBItemMemberPrice(item),
          insurancePaid: getAdjudicationValueByCategory(item, AdjudicationCategories.Benefit),
          estimatedBalance: getAdjudicationValueByCategory(item, AdjudicationCategories.Member_Liability) ?? getAdjudicationValueByCategory(item, AdjudicationCategories.Copay)
        };

        tableData.push(serviceLevel);
      }
    }
    let sortedTableData = tableData.slice().sort((a, b) => {
      let sortRes = sortByDate(a.sortByDate, b.sortByDate);
      //in case the start date are equal, secondary sort is by memberPrice Descending
      if (sortRes === 0) {
        sortRes = sortByMemberPrice(a.memberPrice, b.memberPrice, SortTypes.Descending);
      }
      return sortRes;
    });
    return sortedTableData;
  }

  get servicesTotalMemberPrice() {
    //check data
    const isServiceDetailsArrayExist = Array.isArray(this.servicesLevelData) && this.servicesLevelData.length > 0;

    const memberPriceItems = isServiceDetailsArrayExist ? this.servicesLevelData?.map(item => item?.memberPrice) : null;
    const totalMemberPrice = memberPriceItems != null && memberPriceItems.length > 0 ? getTotalAmounts(memberPriceItems) : null;

    return totalMemberPrice;
  }

  get servicesTotalInsurancePaid() {
    //check data
    const isServiceDetailsArrayExist = Array.isArray(this.servicesLevelData) && this.servicesLevelData.length > 0;

    const insurancePaidItems = isServiceDetailsArrayExist ? this.servicesLevelData?.map(item => item?.insurancePaid) : null;
    const totalInsurancePaid = insurancePaidItems != null && insurancePaidItems.length > 0 ? getTotalAmounts(insurancePaidItems) : null;
    return totalInsurancePaid;
  }

  get servicesTotalEstimatedBalance() {
    //check data
    const isServiceDetailsArrayExist = Array.isArray(this.servicesLevelData) && this.servicesLevelData.length > 0;

    const estimatedBalanceItems = isServiceDetailsArrayExist ? this.servicesLevelData?.map(item => item?.estimatedBalance) : null;

    const totalEstimatedBalance = estimatedBalanceItems != null && estimatedBalanceItems.length > 0 ? getTotalAmounts(estimatedBalanceItems) : null;

    return totalEstimatedBalance;
  }

  get showForeignCurrencyDataWarningPerEOB() {
    let currencies = this.currenciesListPerEOB?.currencies;
    return !currencies.every(cur => cur === currencies[0]);
  }

  get currenciesListPerEOB() {
    //Calculated amounts - services level validation + estimated balance

    let currencies: string[] = [];
    let isContainUnknownCurrency = false;

    this.servicesLevelData.forEach(item => {
      if (!item.estimatedBalance?.currency) isContainUnknownCurrency = true;
      else if (isValidAmount(item.estimatedBalance)) currencies.push(item.estimatedBalance.currency.trim().toUpperCase());

      if (!item.insurancePaid?.currency) isContainUnknownCurrency = true;
      else if (isValidAmount(item.insurancePaid)) currencies.push(item.insurancePaid.currency.trim().toUpperCase());

      if (!item.memberPrice?.currency) isContainUnknownCurrency = true;
      else if (isValidAmount(item.memberPrice)) currencies.push(item.memberPrice.currency.trim().toUpperCase());
    });

    if (!this.estimatedBalance?.amount?.currency) isContainUnknownCurrency = true;
    else if (isValidAmount(this.estimatedBalance?.amount) && this.estimatedBalance?.isComplete) currencies.push(this.estimatedBalance.amount.currency.trim().toUpperCase());

    if (!this.totalPrice?.amount?.currency) isContainUnknownCurrency = true;
    else if (isValidAmount(this.totalPrice?.amount) && this.totalPrice?.isComplete) currencies.push(this.totalPrice.amount.currency.trim().toUpperCase());

    return {
      currencies: currencies,
      isContainUnknownCurrency: isContainUnknownCurrency
    };
  }

  get isForeignCurrencyExist() {
    let currencies = this.currenciesListPerEOB?.currencies;
    if (currencies.every(cur => cur === CurrencyCodes.USD)) return false;

    return true;
  }

  get showUnknownCurrencyDataWarningPerEOB() {
    if (!this.isForeignCurrencyExist) return false;
    return this.currenciesListPerEOB?.isContainUnknownCurrency;
  }

  get showMissingDataWarning() {
    const patientNameMissing = this.patientName == null || this.patientName == '';
    const practiotionerMissing = this.performingPractitionerFullName == null || this.performingPractitionerFullName == '';

    const facilityAddressIn2Lines = getAddressAs2Lines(this.facility?.address);
    const facilityContentMissing =
      (this.facility?.name == null || this.facility?.name.trim() === '') &&
      (facilityAddressIn2Lines.line1 == null || facilityAddressIn2Lines.line1.trim() === '') &&
      (facilityAddressIn2Lines.line2 == null || facilityAddressIn2Lines.line2.trim() === '');

    //SERVICES LEVEL MISSING
    //Check array this.servicesLevelData => all calculated fields inside
    let itemDataMissingContent = this.servicesLevelData.find(item => {
      let foundMissing = !isValidAmount(item.estimatedBalance) || !isValidAmount(item.insurancePaid) || !isValidAmount(item.memberPrice) || !item.name || !item.date;
      return foundMissing;
    });

    return patientNameMissing || practiotionerMissing || facilityContentMissing || itemDataMissingContent != null;
  }

  get areServicesExist() {
    const serviceExist: boolean = this.eob?.item != null && this.eob?.item?.length > 0 && this.eob?.item?.find(item => item != null) != null;

    return serviceExist;
  }

  get practitionerRole() {
    const role = this?.eob.careTeam?.find(t => t.provider?.reference === this?.performingPractitioner?.resourceType + '/' + this?.performingPractitioner?.id)?.role;
    const displayRole =
      role?.coding && role?.coding?.length > 0
        ? role?.coding[0].display
          ? uppercaseFirstLetter(role?.coding[0].display)
          : role?.coding[0].code
          ? uppercaseFirstLetter(role?.coding[0].code)
          : null
        : null;
    return displayRole;
  }

  get referenceNum() {
    try {
      const referenceNum: string | null | undefined = this.eob?.identifier?.length === 1 && this.eob?.identifier[0] ? this.eob.identifier[0]?.value : null;

      return referenceNum;
    } catch (error) {
      return null;
    }
  }
}

decorate(EOBStore, {
  eob: observable,
  id: computed,
  estimatedBalance: computed,
  totalPrice: computed,
  EOBDate: computed,
  patientName: computed,
  performingPractitionerFullName: computed,
  performingPractitioner: computed,
  provider: computed,
  providerFullName: computed,
  providerAddress: computed,
  facility: computed,
  showMissingDataWarning: computed,
  areServicesExist: computed,
  servicesLevelData: computed,
  servicesTotalMemberPrice: computed,
  servicesTotalInsurancePaid: computed,
  servicesTotalEstimatedBalance: computed,
  showForeignCurrencyDataWarningPerEOB: computed,
  showUnknownCurrencyDataWarningPerEOB: computed,
  isForeignCurrencyExist: computed,
  practitionerRole: computed,
  referenceNum: computed
});

export default EOBStore;
export { EOBStore as EOBStoreType };
