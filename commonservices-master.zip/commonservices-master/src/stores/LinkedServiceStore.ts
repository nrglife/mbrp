import { observable, computed, decorate } from 'mobx';
import { injectable } from 'inversify';

export interface LinkedService {
  linkedService: LinkedService;
  appName: string;
  id: string;
  companyName: string;
  createdBy: string;
  customerSupportEmail: string;
  appDescription: string;
  appSubtitle: string;
  appIconLink: string;
  productImage1link: string;
  productImage2link: string;
  productImage3link: string;
  productImages: string[];
  companyIconLink: string;
  appWebsiteHomepageLink: string;
  appTermsAndConditionslink: string;
  lastUpdatedOn: string;
  appPrivacyPolicyLink: string;
  benefitsofconnecting: string;
  appSignOnPageLink: string;
  requestedDataCategories: string[];
}

@injectable()
class LinkedServiceStore {
  constructor(public linkedService: LinkedService) {}

  get appName(): string {
    return this.linkedService.appName;
  }

  get id(): string {
    return this.linkedService.id;
  }

  get companyName(): string {
    return this.linkedService.companyName;
  }

  get createdBy(): string {
    return this.linkedService.createdBy;
  }

  get customersupportEmail(): string {
    return this.linkedService.customerSupportEmail;
  }

  get appdescription(): string {
    return this.linkedService.appDescription;
  }

  get appsubtitle(): string {
    return this.linkedService.appSubtitle;
  }

  get appIconLink(): string {
    return this.linkedService.appIconLink;
  }

  get productImages(): string[] {
    const images: string[] = [];
    if (this.linkedService) {
      // Filtering all thumbnail properties from the connected service object, sorting by alphabet (numbers).
      Object.keys(this.linkedService)
        .filter(objectPropertyKey => objectPropertyKey.startsWith('productImage'))
        .sort()
        .forEach(thumbnailPropertyKey => {
          const image = this.linkedService[thumbnailPropertyKey];
          if (!!image) {
            images.push(image);
          }
        });
    }
    return images;
  }

  get companyIconLink(): string {
    return this.linkedService.companyIconLink;
  }

  get appwebsitehomepageLink(): string {
    return this.linkedService.appWebsiteHomepageLink;
  }

  get apptermsAndConditionslink(): string {
    return this.linkedService.appTermsAndConditionslink;
  }
  get lastUpdatedOn(): string {
    return this.linkedService.lastUpdatedOn;
  }

  get appprivacyPolicyLink(): string {
    return this.linkedService.appPrivacyPolicyLink;
  }
  get benefitsofconnecting(): string {
    return this.linkedService.benefitsofconnecting;
  }

  get appsignonpagelink(): string {
    return this.linkedService.appSignOnPageLink;
  }

  get requestedDataCategories(): string[] {
    return this.linkedService.requestedDataCategories;
  }
}

decorate(LinkedServiceStore, {
  linkedService: observable,

  appName: computed,
  id: computed,
  companyName: computed,
  createdBy: computed,
  customersupportEmail: computed,
  appdescription: computed,
  appsubtitle: computed,
  appIconLink: computed,
  productImages: computed,
  companyIconLink: computed,
  appwebsitehomepageLink: computed,
  apptermsAndConditionslink: computed,
  lastUpdatedOn: computed,
  appprivacyPolicyLink: computed,
  benefitsofconnecting: computed,
  appsignonpagelink: computed,
  requestedDataCategories: computed
});

export default LinkedServiceStore;
export { LinkedServiceStore as LinkedServiceStoreType };
