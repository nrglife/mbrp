import { observable, action, computed, decorate, runInAction } from 'mobx';
import { injectable } from 'inversify';
import he from 'he';
import { IocContainer, IocTypes, DataServicesApiType } from '../inversify.config';
import { HTTP_STATUS_CODES } from '../services/apis/base-api';

export type Doc = {
  published: string | undefined;
  loading: boolean;
};

export enum DocumentsCategories {
  FAQ = 'faq',
  AboutUs = 'aboutus',
  ContactUs = 'contactus',
  Landing = 'landing'
}
type categories = DocumentsCategories.FAQ | DocumentsCategories.AboutUs | DocumentsCategories.ContactUs | DocumentsCategories.Landing;

export interface Docs {
  faq: Doc;
  aboutus: Doc;
  contactus: Doc;
  landing: Doc;
}

export interface PayerDocuments {
  docs: Record<categories, Doc>;
}

const DEFAULT_DOCUMENTS: PayerDocuments = {
  docs: {
    faq: {
      published: '',
      loading: false
    },
    aboutus: {
      published: '',
      loading: false
    },
    contactus: {
      published: '',
      loading: false
    },
    landing: {
      published: '',
      loading: false
    }
  }
};
@injectable()
class PayerDocumentsStore {
  public payerDocs: PayerDocuments = DEFAULT_DOCUMENTS;

  private dataServicesApi = IocContainer.get<DataServicesApiType>(IocTypes.DataServicesApi);

  async getDocument(payerId: string | undefined, category: DocumentsCategories, withMetadata: boolean) {
    if (payerId && payerId !== '') {
      this.payerDocs.docs[category].loading = true;

      try {
        const response = await this.dataServicesApi.getPayerDocumentsByCategory({ payerId, stage: 'published', category, metadata: withMetadata });
        if (response.status !== HTTP_STATUS_CODES.SUCCESS) {
          throw new Error('Loading document - response was not successful');
        }

        runInAction(() => {
          const doc: Doc = {
            published: response?.status === HTTP_STATUS_CODES.SUCCESS ? (withMetadata ? he.unescape(response.data?.body) : he.unescape(response.data)) : DEFAULT_DOCUMENTS.docs[category].published,
            loading: false
          };

          this.payerDocs.docs[category] = doc;
        });
      } catch (error) {
        console.error('error loading document: ', error);
        runInAction(() => {
          // will use default  content
          const doc: Doc = { published: DEFAULT_DOCUMENTS.docs[category].published, loading: false };
          this.payerDocs.docs[category] = doc;
        });
      } finally {
        console.log('End loading document preferences.');
      }
    } else {
      console.log(`Cannot load document, payer not found.`);
    }
  }

  get docs() {
    return this.payerDocs.docs;
  }
}

decorate(PayerDocumentsStore, {
  payerDocs: observable,
  docs: computed,
  getDocument: action
});

export default PayerDocumentsStore;
export type { PayerDocumentsStore as PayerDocumentsStoreType };
