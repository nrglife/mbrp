import { injectable, interfaces } from "inversify";
import { noConflict } from "lodash";
import {
  observable,
  action,
  computed,
  decorate,
  runInAction,
  toJS,
} from "mobx";

import { IocContainer, IocTypes, IHttpService } from "../../inversify.config";
import { sortBy } from "../../utilities/arrays";
import {
  FindCareSearchOptionsType,
  getUnifiedSpecialtiesList,
  getServicesList,
} from "../../utilities/fhir/find-care/find-care-search-categorites";
import {
  FindCareResourcesTypes,
  OrganizationAffiliation,
  PractitionerRole,
} from "../../utilities/fhir/find-care/findcare-types";
import { getCodeableValue } from "../../utilities/fhir/helper";
import { Bundle, Bundle_Entry } from "../../utilities/fhir/types";
import FindCareResultStore, {
  FindCareResultStoreType,
} from "./FindCareResultStore";

export enum SearchOptions {
  All = "All",
  Practitioners = "Practitioners",
  Organizations = "Organizations",
  Specialties = "Specialties",
  Services = "Services",
  ServicesResults = "ServicesResults",
  SpecialtiesResults = "SpecialtiesResults",
}
export enum LocationSelectType {
  None,
  Home,
  CurrentLocation,
}

export type Location = {
  formatted_address: string;
  placeId: string;
  latitude: number;
  longitude: number;
  locationSelectType: LocationSelectType;
};
@injectable()
class FindCareStore {
  public loading: boolean | null;
  public isError: boolean;
  public errorCode: number | null;
  public filterResultsByLocation: boolean;
  public searchRadius: number;
  public searchByFilter: string;
  public specialtiesList: FindCareSearchOptionsType[] | null;
  public servicesList: FindCareSearchOptionsType[] | null;
  public _selectedLocation: Location | null;
  public _homeLocation: Location | null | undefined;
  public _currentLocation: Location | null | undefined;
  public searchType: SearchOptions;
  public selectedSpecialty: FindCareSearchOptionsType | null;
  public selectedService: FindCareSearchOptionsType | null;

  public results: FindCareResultStoreType[];
  public selected: FindCareResultStoreType | null;

  private findCareResultStoreType = IocContainer.get<
    interfaces.Newable<FindCareResultStoreType>
  >(IocTypes.FindCareResultStore);

  constructor() {
    this.loading = false;
    this.isError = false;
    this.errorCode = null;
    this.searchRadius = 10;
    this.searchByFilter = "";
    this._selectedLocation = null;
    this._homeLocation = undefined;
    this._currentLocation = undefined;
    this.searchType = SearchOptions.All;
    this.selectedSpecialty = null;
    this.selectedService = null;
    this.filterResultsByLocation = true;

    this.results = [];
    this.specialtiesList = getUnifiedSpecialtiesList();
    this.servicesList = getServicesList();
  }

  get isLoading() {
    return this.loading;
  }

  get selectedLocation(): Location {
    return toJS(this._selectedLocation);
  }

  get homeLocation(): Location {
    return toJS(this._homeLocation);
  }

  get currentLocation(): Location {
    return toJS(this._currentLocation);
  }

  get showSearchOptions() {
    return (
      this.selectedLocation ||
      (!this.selectedLocation &&
        (this.searchType === SearchOptions.ServicesResults ||
          this.searchType === SearchOptions.SpecialtiesResults ||
          this.searchType === SearchOptions.Organizations ||
          this.searchType === SearchOptions.Practitioners))
    );
  }

  get filteredResults() {
    //DO NOT SHOW RESULTS that don't include name or organization name + filter by location
    let defaultFilter = this.results
      .filter((result) => result.Name && result.OrganizationName)
      .filter(
        (result) =>
          (this.filterResultsByLocation &&
            result.Distance &&
            result.Distance <= this.searchRadius) ||
          !this.filterResultsByLocation
      );
    if (!this.searchByFilter || this.searchByFilter.trim() === "") {
      return defaultFilter;
    } else {
      let filtered = defaultFilter.filter((item) =>
        item.result.resourceType === FindCareResourcesTypes.PractitionerRole
          ? item.Name.toLowerCase().includes(
              this.searchByFilter.toLowerCase()
            ) ||
            item.OrganizationName.toLowerCase().includes(
              this.searchByFilter.toLowerCase()
            )
          : item.Name.toLowerCase().includes(this.searchByFilter.toLowerCase())
      );

      return filtered;
    }
  }

  sortBy(results: FindCareResultStore[], sortBy: SortBy) {
    return results.sort((item1, item2) => {
      if (sortBy == SortBy.Distance) {
        if (item1.Distance < item2.Distance) {
          return -1;
        } else if (item1.Distance > item2.Distance) {
          return 1;
        } else {
          return 0;
        }
      }
      return 0;
    });
  }

  setSearchByFilter(searchBy: string) {
    this.searchByFilter = searchBy;
  }
  setIsLoading(isLoading: boolean) {
    this.loading = isLoading;
  }

  setFilterResultsByLocation(filter: boolean) {
    this.filterResultsByLocation = filter;
  }

  setSearchType(searchType: SearchOptions) {
    this.searchType = searchType;
  }

  setSelectedSpecialty(selectedSpecialty: FindCareSearchOptionsType) {
    this.selectedSpecialty = selectedSpecialty;
  }

  setSelectedService(selectedService: FindCareSearchOptionsType) {
    this.selectedService = selectedService;
  }

  setSelectedResult(selectedResult: FindCareResultStoreType) {
    this.selected = selectedResult;
    this.selected.selectedLocation = this.selectedLocation;
  }

  clearSelectedResult() {
    this.selected = null;
  }

  setError(isError: boolean, errorCode: number | null = null) {
    this.isError = isError;
    this.errorCode = errorCode;
  }

  setSearchRadius(radius: number) {
    this.searchRadius = radius;
  }

  setSelectedLocation(location: Location | null) {
    if (!location) {
      this._selectedLocation = null;
    } else {
      this._selectedLocation = { ...location };
      this.selected = null;
    }
  }

  setHomeLocation(location: Location) {
    this._homeLocation = { ...location };
  }

  setCurrentLocation(location: Location) {
    this._currentLocation = { ...location };
  }

  setResults(response: Bundle, cleanExisting: boolean = true) {
    let newResults = cleanExisting ? [] : this.results.map((item) => item);
    if (!response?.entry || response?.entry.length === 0) return;
    response?.entry?.forEach((result: Bundle_Entry) => {
      const resultStore = new this.findCareResultStoreType(
        result.resource,
        this.selectedLocation
      );
      newResults.push(resultStore);
    });
    newResults = this.sortBy(newResults, SortBy.Distance);
    this.results = newResults;
  }

  clearResults() {
    this.results = [];
  }

  filteredCategoriesItems(
    list: FindCareSearchOptionsType[],
    includeCode: boolean = true,
    additionalInfo: boolean = false
  ) {
    return list.filter(
      (item) =>
        item.display
          .toLowerCase()
          .includes(this.searchByFilter.toLowerCase()) ||
        (includeCode &&
          item.code
            .toLowerCase()
            .includes(this.searchByFilter.toLowerCase())) ||
        (additionalInfo &&
          item.additionaInfo
            ?.toLowerCase()
            .includes(this.searchByFilter.toLowerCase()))
    );
  }

  get currentServicesList() {
    if (this.searchType === SearchOptions.Services) {
      if (!this.searchByFilter || this.searchByFilter.trim() === "") {
        return this.servicesList;
      } else
        return this.filteredCategoriesItems(this.servicesList, false, true);
    }
    return this.servicesList;
  }

  get currentSpecialtiesList() {
    if (this.searchType === SearchOptions.Specialties) {
      if (!this.searchByFilter || this.searchByFilter.trim() === "") {
        return this.specialtiesList;
      } else
        return this.filteredCategoriesItems(this.specialtiesList, true, false);
    }
    return this.specialtiesList;
  }

  resetStore() {
    this.results = [];
    this.loading = false;
    this.isError = false;
    this.errorCode = null;
    this.selected = null;
    this.searchType = SearchOptions.All;
    this.selectedSpecialty = null;
    this.selectedService = null;
    this._selectedLocation = undefined;
    this.searchByFilter = "";
    this.filterResultsByLocation = true;
  }
}

decorate(FindCareStore, {
  loading: observable,
  specialtiesList: observable,
  servicesList: observable,
  results: observable,
  selected: observable,
  filterResultsByLocation: observable,
  selectedSpecialty: observable,
  selectedService: observable,
  searchType: observable,
  searchRadius: observable,
  _selectedLocation: observable,
  _homeLocation: observable,
  _currentLocation: observable,
  isError: observable,
  errorCode: observable,
  searchByFilter: observable,

  setError: action,
  setSearchRadius: action,
  setSelectedLocation: action,
  setHomeLocation: action,
  setCurrentLocation: action,
  setIsLoading: action,
  resetStore: action,
  setSearchType: action,
  setSelectedSpecialty: action,
  setSelectedService: action,
  setSelectedResult: action,
  clearResults: action,
  setResults: action,
  clearSelectedResult: action,
  sortBy: action,
  setSearchByFilter: action,
  setFilterResultsByLocation: action,

  showSearchOptions: computed,
  selectedLocation: computed,
  filteredResults: computed,
  currentServicesList: computed,
  currentSpecialtiesList: computed,
});

export default FindCareStore;
export { FindCareStore as FindCareStoreType };

export type FindCreSeatchRadiusOptionType = {
  display: string;
  radius: number;
};

export enum SortBy {
  Distance,
  Alphabertical,
}

export const searchRadiusOptions: FindCreSeatchRadiusOptionType[] = [
  { display: "1 mile", radius: 1 },
  { display: "2 miles", radius: 2 },
  { display: "5 miles", radius: 5 },
  { display: "10 miles", radius: 10 },
  { display: "20 miles", radius: 20 },
  { display: "50 miles", radius: 50 },
];
