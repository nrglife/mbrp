import { observable, computed, decorate, action, autorun, toJS } from "mobx";
import { injectable, interfaces } from "inversify";
import { v4 as uuidv4 } from "uuid";

import {  isValidDate,  sortByDate,  sortByMemberPrice,  SortTypes,} from "../../utilities/dates";
import { generateRandomID } from "../../utilities/random-generator";
import {  getAddressAs2Lines,  getFullName,  getTotalAmounts,  isValidAmount} from "../../utilities/fhir/helper";
import {  Reference} from "../../utilities/fhir/types";
import { FindCareResourcesTypes, Organization, OrganizationAffiliation, Practitioner, PractitionerRole, HealthcareService, Location } from "../../utilities/fhir/find-care/findcare-types";
import { getFirstContainedByReferenceId, getContainedByResourceType } from "../../utilities/fhir/find-care/findcare-helper";

import {  Location as SelectedLocation} from "./FindCareStore";

import { Point } from "../../utilities/maps/types";
import { calculateDistanceInMiles } from "../../utilities/maps";

import FindCareLocationStore, {FindCareLocationStoreType,} from "./FindCareLocationStore";
import { IocContainer, IocTypes } from "../..";
@injectable()
class FindCareResultStore {
  public uuid: string; 
  public selectedLocation : SelectedLocation;

  public locations: FindCareLocationStoreType[];
  private findCareLocationStoreType = IocContainer.get<interfaces.Newable<FindCareLocationStoreType>>(IocTypes.FindCareLocationStore);


  constructor(public result: PractitionerRole | OrganizationAffiliation, selectedLocation: SelectedLocation) {
    this.uuid = generateRandomID();
    this.selectedLocation = selectedLocation;
    this.setLocations();
  }

 
  getContainedResourceByReferenceId(
    referenceObj: Reference |  null | undefined,
    type: FindCareResourcesTypes
  ) {
    const referenceId = referenceObj?.reference
      ? referenceObj?.reference
      : null;
    if (!referenceId || referenceId.trim() === "") return null;
    return getFirstContainedByReferenceId(this.result?.contained, referenceId, type);
  }

  setLocations() {

    let locationStores: FindCareLocationStoreType[] = [];
    for (let index = 0; index <  this.result?.location?.length; index++) {
      const reference = this.result?.location[index];
      const location = getFirstContainedByReferenceId(this.result.contained, reference?.reference ,FindCareResourcesTypes.Location);
      const locationStore = new this.findCareLocationStoreType(location,this.selectedLocation);
      
      locationStores.push(locationStore);
    }
    
    locationStores.sort((item1, item2)=> { 
      if(isNaN(item1.Distance) || isNaN(item2.Distance)){
        return 0;
      }
      if(item1.Distance < item2.Distance){
        return -1;  
      }
      else if(item1.Distance > item2.Distance){
          return 1;
      }
      else {
        return 0;
      }
    });

    // newResults = this.sortBy(newResults, SortBy.Distance) ==> Add sorting for locations
    this.locations = locationStores;
    
  }

  //Get name relying on type: practitioner name  PractitionerRole and organization name for OrganizationAffiliation resource type.
  get Name () {
    let name: string | null | undefined = null;
    switch (this.result?.resourceType) {
      case FindCareResourcesTypes.PractitionerRole:
        const practitioner = this.getContainedResourceByReferenceId((this.result as PractitionerRole)?.practitioner,FindCareResourcesTypes.Practitioner);
        name = practitioner ? getFullName((practitioner as Practitioner)?.name) : null;
        break;
      case FindCareResourcesTypes.OrganizationAffiliation:
        const organization = this.getContainedResourceByReferenceId((this.result as OrganizationAffiliation)?.organization,FindCareResourcesTypes.Organization);
        name = organization ? (organization as Organization)?.name: null;
        break;
    }
    return name;
  };


  //Get organization name both for PractitionerRole and ORganizationAffiliation resource type.
  get OrganizationName ()  {
    let name: string | null | undefined = null;
    const organization = this.getContainedResourceByReferenceId(this.result?.organization,FindCareResourcesTypes.Organization);
    name = (organization as Organization)?.name ?? (organization as Organization)?.name;
    return name;
  };


  //Get organization name both for PractitionerRole and ORganizationAffiliation resource type.
  get healthcareServices ()  {
    return getContainedByResourceType(this.result?.contained, FindCareResourcesTypes.HealthcareService) as HealthcareService[];
  };

   get Distance ()  {
    let distance : null | number = null;
    if(this.locations != null  && this.locations.length > 0){
      distance = this.locations[0].Distance;
    }
    return distance && distance!= NaN ? distance : null;
  }

}

decorate(FindCareResultStore, {
  result: observable,
  locations: observable,

  OrganizationName: computed,
  Name: computed,
  Distance: computed

});

export default FindCareResultStore;
export { FindCareResultStore as FindCareResultStoreType };
