import { observable, computed, decorate, action, autorun, toJS } from "mobx";
import { injectable } from "inversify";

import { generateRandomID } from "../../utilities/random-generator";
import {  Location } from "../../utilities/fhir/find-care/findcare-types";
import {  Location as SelectedLocation} from "./FindCareStore";


import { Point } from "../../utilities/maps/types";
import { calculateDistanceInMiles } from "../../utilities/maps";

@injectable()
class FindCareLocationStore {
  public uuid: string; 
  public selectedLocation : SelectedLocation;
  constructor(public location: Location, selectedLocation: SelectedLocation) {
    this.uuid = generateRandomID();
    this.selectedLocation = selectedLocation;
  }


  get Distance ()  {
    let distance : null | number = null;
    try {   
        let point1 : Point = { lat: this.selectedLocation?.latitude,  lng: this.selectedLocation?.longitude};
        let point2 : Point = { lat: this.location.position.latitude,  lng: this.location.position?.longitude};       
        distance = calculateDistanceInMiles(point1, point2);
    }
    catch {
        return distance !=  NaN ? distance : null ;
    }
    return distance && distance!= NaN ? distance : null;
  }

}

decorate(FindCareLocationStore, {
  location: observable,

  Distance: computed

});

export default FindCareLocationStore;
export { FindCareLocationStore as FindCareLocationStoreType };
