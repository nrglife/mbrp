import { observable, action, computed, decorate, runInAction } from "mobx";
import { injectable } from "inversify";
import { IocContainer, IocTypes, ITimeoutService } from "./../inversify.config";

export enum PersonalSecretIdentifier {
  ssn = "ssn",
  secret = "secret",
}

export interface UserCredentials {
  firstname: string;
  phone: string | string[];
}

export interface AttemptsNumber {
  attemptCount: number;
  attemptMax: number;
}

export interface UserSecretMetadata {
  personalIdentifier: PersonalSecretIdentifier; //'secret';
  secretDisplayName: string; //'MySecret';
  delegateData: any;
}

export enum EnrollmentSteps {
  InvitationCode = "InvitationCode",
  PersonalInfo = "PersonalInfo",
  ConfirmPhoneNumber = "ConfirmPhoneNumber",
  ConfirmSms = "ConfirmSms",
  EmailVerification = "EmailVerification",
  CreatePassword = "CreatePassword",
  Locked = "Locked",
  Enrolled = "Enrolled",
  MissingInfo = "MissingInfo",
  GeneralError = "GeneralError",
  WrongPayerError = "WrongPayerError",
  Timeout = "Timeout",
  RecaptchaClientError = "RecaptchaClientError",
  RecaptchaServerError = "RecaptchaServerError",
  NoUserPhone = "NoUserPhone",
  ContactUs = "ContactUs",
  AlreadyEnrolled = "AlreadyEnrolled",
}

export enum EnrollmentType {
  Unknown = "Unknown",
  Member = "Member",
  Delegate = "Delegate",
}

export enum EnrollmentOrigin {
  LandingPage = "LandingPage",
  AddDelegateButton = "AddDelegateButton",
  LandingPageUnified = "LandingPageUnified",
}
export interface EnrollmentContext {
  isDelegate: boolean;
  isLandingPage: boolean;
  isLandingPageUnified: boolean;
}

const INITIAL_ENROLLMENT_STEP = EnrollmentSteps.InvitationCode;
const ENROLLMENT_STORE = "ENROLLMENT_STORE";

@injectable()
class EnrollmentStore {
  private timeoutService: ITimeoutService = IocContainer.get<ITimeoutService>(
    IocTypes.ITimeoutService
  );

  public step: EnrollmentSteps = INITIAL_ENROLLMENT_STEP;
  public prevStep: EnrollmentSteps = null;
  public showModal: boolean = false;
  public enrollmentType: EnrollmentType = EnrollmentType.Unknown;
  public enrollmentOrigin: EnrollmentOrigin =
    EnrollmentOrigin.LandingPageUnified;
  public modalMessage: string = "Opps... Something went wrong at the server";
  public loading: null | boolean = false;
  public invitationCode: string = "";
  public userCredentials: UserCredentials | null = null;
  public selectedPhoneNumber: string = "";
  public userSecretMetadata: UserSecretMetadata | null = null;
  public attemptsNumber: AttemptsNumber | null = null;
  public showErrorModal: boolean = false;
  public selectedIdentityProvider: string = "";
  public selectedEmail: string | null = null;
  public emails: string[] = [];
  public userId: string = "";
  public showContactUsModal: boolean = false;

  constructor() {}

  // reset the values to their initial state
  setInitialValues() {
    this.invitationCode = "";
    this.userCredentials = null;
    this.selectedPhoneNumber = "";
    this.userSecretMetadata = null;
    this.attemptsNumber = null;
    this.loading = null;
    this.step = INITIAL_ENROLLMENT_STEP;
    this.enrollmentType = EnrollmentType.Unknown;
    this.enrollmentOrigin = EnrollmentOrigin.LandingPageUnified;
    this.showModal = false;
    this.modalMessage = "Opps... Something went wrong at the server";
    this.showErrorModal = false;
    this.selectedIdentityProvider = "";
    this.selectedEmail = null;
    this.emails = [];
    this.userId = "";
    this.prevStep = null;
    this.showContactUsModal = false;
  }

  setStep(step: EnrollmentSteps, storeHistory = true) {
    storeHistory && (this.prevStep = this.step);
    this.step = step;
  }

  setEnrollmentOrigin(enrollmentOrigin: EnrollmentOrigin) {
    this.enrollmentOrigin = enrollmentOrigin;
  }

  setIsLoading(isLoading: boolean) {
    this.loading = isLoading;
  }

  setInvitationCode(code: string) {
    this.invitationCode = code;
  }

  setModalVisibility(value: boolean) {
    this.showModal = value;
    if (!value) {
      setTimeout(() => {
        this.setInitialValues();
      }, 400);
      this.clearAllRegisteredTimeouts();
    }
  }

  setContactUsVisibility(value: boolean) {
    this.showContactUsModal = value;
  }

  setErrorModalVisibility(value: boolean) {
    this.showErrorModal = value;
  }

  setModalMsg(value: string) {
    this.modalMessage = value;
  }

  setAttemptsNumber(attempts: AttemptsNumber) {
    this.attemptsNumber = attempts;
    const { attemptCount, attemptMax } = attempts;

    if (!!attemptCount && !!attemptMax && this.remainingAttempts === 0)
      this.setStep(EnrollmentSteps.Locked);
  }

  setUserCredentials(user: UserCredentials) {
    this.userCredentials = user;
    //set the selected user phone to be by defult the first phone in the array
    const userPhoneNumber = user.phone;
    if (
      Array.isArray(userPhoneNumber) &&
      userPhoneNumber.length > 0 &&
      this.selectedPhoneNumber === ""
    )
      this.selectedPhoneNumber = userPhoneNumber[0];
  }

  setSelectedPhoneNumber(phone: string) {
    this.selectedPhoneNumber = phone;
  }

  setSelectedIdentityProvider(providerName: string) {
    this.selectedIdentityProvider = providerName;
  }

  setUserSecretMetadata(secretMetadata: UserSecretMetadata) {
    this.userSecretMetadata = secretMetadata;
    this.enrollmentType = this.userSecretMetadata?.delegateData
      ? EnrollmentType.Delegate
      : EnrollmentType.Member;
  }

  setSelectedEmail(email: string | null) {
    this.selectedEmail = email;
  }

  setEmails(emails: string[]) {
    if (!emails || !Array.isArray(emails) || emails.length === 0) return;
    this.emails = emails;
  }

  setUserId(userId: string) {
    this.userId = userId;
  }

  registerEnrollmentTimeout(callback: () => void, time: number = 0) {
    const timeoutId = this.timeoutService.setTimeout(
      ENROLLMENT_STORE,
      () => {
        runInAction(() => {
          callback();
        });
      },
      time
    );

    return timeoutId;
  }

  clearTimeout(timeoutId: NodeJS.Timeout) {
    this.timeoutService.clearTimeout(ENROLLMENT_STORE, timeoutId);
  }

  clearAllRegisteredTimeouts() {
    this.timeoutService.clearAllTimeoutsByGroup(ENROLLMENT_STORE);
  }

  get modalMsg() {
    return this.modalMessage;
  }

  get isLoading() {
    return this.loading;
  }

  get maxAttempts() {
    return this.attemptsNumber?.attemptMax;
  }

  get attemptsCount() {
    return this.attemptsNumber?.attemptCount;
  }

  get remainingAttempts() {
    const { attemptCount = 0, attemptMax = 0 } = this.attemptsNumber || {};
    return attemptMax - attemptCount;
  }

  get enrollmentContext(): EnrollmentContext {
    return {
      isDelegate: this.enrollmentType === EnrollmentType.Delegate,
      isLandingPage:
        this.enrollmentOrigin === EnrollmentOrigin.LandingPage ||
        this.enrollmentOrigin === EnrollmentOrigin.LandingPageUnified,
      isLandingPageUnified:
        this.enrollmentOrigin === EnrollmentOrigin.LandingPageUnified,
    };
  }

  get delegateData() {
    return this.userSecretMetadata?.delegateData;
  }
}

decorate(EnrollmentStore, {
  step: observable,
  prevStep: observable,
  enrollmentType: observable,
  enrollmentOrigin: observable,
  showModal: observable,
  showErrorModal: observable,
  modalMessage: observable,
  loading: observable,
  userCredentials: observable,
  selectedPhoneNumber: observable,
  selectedIdentityProvider: observable,
  userSecretMetadata: observable,
  attemptsNumber: observable,
  selectedEmail: observable,
  emails: observable,
  userId: observable,
  showContactUsModal: observable,

  isLoading: computed,
  maxAttempts: computed,
  enrollmentContext: computed,
  delegateData: computed,
  attemptsCount: computed,
  remainingAttempts: computed,
  modalMsg: computed,

  clearTimeout: action,
  clearAllRegisteredTimeouts: action,
  registerEnrollmentTimeout: action,
  setInitialValues: action,
  setAttemptsNumber: action,
  setIsLoading: action,
  setInvitationCode: action,
  setUserCredentials: action,
  setSelectedPhoneNumber: action,
  setSelectedIdentityProvider: action,
  setUserSecretMetadata: action,
  setStep: action,
  setEnrollmentOrigin: action,
  setModalVisibility: action,
  setErrorModalVisibility: action,
  setModalMsg: action,
  setSelectedEmail: action,
  setEmails: action,
  setUserId: action,
  setContactUsVisibility: action,
});

export default EnrollmentStore;
export { EnrollmentStore as EnrollmentStoreType };
