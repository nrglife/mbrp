import { Container, interfaces } from 'inversify';
import {
  LinkedServicesListStore,
  LinkedServicesListStoreType,
  LinkedServiceStore,
  LinkedServiceStoreType,
  PayerToPayerStore,
  PayerToPayerStoreType,
  DelegateStore,
  PayerStore,
  PayerStoreType,
  PayerDocumentsStore,
  PayerDocumentsStoreType,
  ImageStore,
  ImageStoreType,
  EOBListStore,
  EOBListStoreType,
  EOBStore,
  EOBStoreType,
  ErrorStoreType,
  ErrorStore,
  WhoAmIStore,
  WhoAmIStoreType,
  DelegateStoreType,
  AllergiesStore,
  AllergiesStoreType,
  EncountersStore,
  EncountersStoreType,
  ConditionsStore,
  ConditionsStoreType,
  MedicationRequestStore,
  MedicationRequestStoreType,
  ImplantableDeviceStore,
  ImplantableDeviceStoreType,
  ProceduresStore,
  ProceduresStoreType,
  ThemeStoreHandler,
  LabObservationStore,
  LabObservationStoreType,
  ImmunizationsStore,
  ImmunizationsStoreType,
  ClinicalsOverviewStore,
  ClinicalsOverviewStoreType
} from './stores';
import BaseStore, { BaseStoreType } from './stores/BaseStore';
import FindCareStore, { FindCareStoreType } from './stores/findcare/FindCareStore';
import FindCareResultStore, { FindCareResultStoreType } from './stores/findcare/FindCareResultStore';
import FindCareLocationStore, { FindCareLocationStoreType } from './stores/findcare/FindCareLocationStore';
import AppConfigStore, { AppConfigStoreType } from './stores/AppConfigStore';

import { EOBSapi } from './services/apis/eobs/eobs-api';
import { WhoAmIApi } from './services/apis/whoAmI/whoAmI-api';
import { ApiConfigsProvider } from './services/apis/base-config';
import { EnrollmentApi } from './services/apis/enrollment/enrollment-api';
import { LinkedServicesApi } from './services/apis/linked-services/linked-services-api';
import { PayerToPayerApi } from './services/apis/payer-to-payer/payer-to-payer-api';
import { ConsentApi } from './services/apis/consent/consent-api';
import { AppConfigurationApi } from './services/apis/app-configuration/app-configuration-api';
import { AppLocalesApi } from './services/apis/app-locales/app-locales-api';
import { DataServicesApi } from './services/apis/data-services/data-services-api';
import { ProviderDirectoryServicesApi } from './services/apis/provider-directory-services/provider-directory-services-api';
import { ClinicalApi } from './services/apis/clinical/clinical-api';

import { i18n } from 'i18next';

// Export Services Types
export type { IHttpService } from './services/HttpService';
export type { IStorageService } from './services/StorageService';
export type { ITimeoutService } from './services/TimeoutService';
export type { WhoAmIApi as WhoAmIApiType };
export type { DataServicesApi as DataServicesApiType };

// Export Stores Types
export type { LinkedServicesListStoreType, LinkedServiceStoreType };
export type { EOBListStoreType, EOBStoreType };
export type { BaseStoreType, BaseStore };
export type { FindCareStoreType };
export type { FindCareResultStoreType };
export type { FindCareLocationStoreType };
export type { EncountersStoreType, AllergiesStoreType, ConditionsStoreType, MedicationRequestStoreType, ProceduresStoreType, ImplantableDeviceStoreType, ImmunizationsStoreType };
export type { WhoAmIStoreType };
export type { PayerStoreType };
export type { ThemeStoreHandler };
export type { PayerDocumentsStoreType };
export type { ImageStoreType };
export type { ClinicalsOverviewStoreType };

// Export API Types
export type { PayerToPayerApi as PayerToPayerApiType };

export type I18nCommonType = i18n;

export const IocTypes = {
  // Services sybols
  IHttpService: Symbol.for('IHttpService'),
  StorageService: Symbol.for('StorageService'),
  ITimeoutService: Symbol.for('ITimeoutService'),

  //Stores symbols
  BaseStore: Symbol.for('BaseStore'),
  EnrollmentStore: Symbol.for('EnrollmentStore'),
  ThemeStore: Symbol.for('ThemeStore'),
  ImageStore: Symbol.for('ImageStore'),
  LinkedServicesListStore: Symbol.for('LinkedServicesListStore'),
  LinkedServiceStore: Symbol.for('LinkedServiceStore'),
  PayerToPayerStore: Symbol.for('PayerToPayerStore'),
  EOBListStore: Symbol.for('EOBListStore'),
  EOBStore: Symbol.for('EOBStore'),
  ErrorStore: Symbol.for('ErrorStore'),
  FindCareStore: Symbol.for('FindCareStore'),
  FindCareResultStore: Symbol.for('FindCareResultStore'),
  WhoAmIStore: Symbol.for('WhoAmIStore'),
  FindCareLocationStore: Symbol.for('FindCareLocationStore'),
  MedicationRequestStore: Symbol.for('MedicationRequestStore'),
  LabObservationStore: Symbol.for('LabObservationStore'),
  ConditionsStore: Symbol.for('ConditionsStore'),
  AllergiesStore: Symbol.for('AllergiesStore'),
  EncountersStore: Symbol.for('EncountersStore'),
  ImplantableDeviceStore: Symbol.for('ImplantableDeviceStore'),
  ProceduresStore: Symbol.for('ProceduresStore'),
  PayerStore: Symbol.for('PayerStore'),
  AppConfigStore: Symbol.for('AppConfigStore'),
  EOBSapi: Symbol.for('EOBSapi'),
  ApiConfigsProvider: Symbol.for('ApiConfigsProvider'),
  ErrorStoreConfigProvider: Symbol.for('ErrorStoreConfigProvider'),
  AuthProvider: Symbol.for('AuthProvider'),
  WhoAmIApi: Symbol.for('WhoAmIApi'),
  LinkedServicesApi: Symbol.for('LinkedServicesApi'),
  PayerToPayerApi: Symbol.for('PayerToPayerApi'),
  EnrollmentApi: Symbol.for('EnrollmentApi'),
  ConsentApi: Symbol.for('ConsentApi'),
  ClinicalApi: Symbol.for('ClinicalApi'),
  AppConfigurationApi: Symbol.for('AppConfigurationApi'),
  AppLocalesApi: Symbol.for('AppLocalesApi'),
  DataServicesApi: Symbol.for('DataServicesApi'),
  ProviderDirectoryServicesApi: Symbol.for('ProviderDirectoryServicesApi'),
  I18nProvider: Symbol.for('I18nProvider'),
  DelegateStore: Symbol.for('DelegateStore'),
  PayerDocumentsStore: Symbol.for('PayerDocumentsStore'),
  ImmunizationsStore: Symbol.for('ImmunizationsStore'),
  ClinicalsOverviewStore: Symbol.for('ClinicalsOverviewStore'),
  ConsentDateProvider: Symbol.for('ConsentDateProvider')
};

export const IocContainer = new Container();

IocContainer.bind<ClinicalApi>(IocTypes.ClinicalApi).toConstantValue(
  new ClinicalApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.headers
      },
      maxItems: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().clinicalApi.maxItems
    };
  })
);

IocContainer.bind<EOBSapi>(IocTypes.EOBSapi).toConstantValue(
  new EOBSapi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.headers
      },
      maxEobs: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().eobsApi.maxEobs
    };
  })
);
IocContainer.bind<ConsentApi>(IocTypes.ConsentApi).toConstantValue(
  new ConsentApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.headers
      },
      REACT_APP_ID_CONSENT: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.REACT_APP_ID_CONSENT
    };
  })
);

IocContainer.bind<AppConfigurationApi>(IocTypes.AppConfigurationApi).toConstantValue(
  new AppConfigurationApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().consentApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appConfigurationApi.headers
      },
      apikey: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appConfigurationApi.apikey
    };
  })
);

IocContainer.bind<AppLocalesApi>(IocTypes.AppLocalesApi).toConstantValue(
  new AppLocalesApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.headers
      },
      apikey: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().appLocalesApi.apikey
    };
  })
);

IocContainer.bind<WhoAmIApi>(IocTypes.WhoAmIApi).toConstantValue(
  new WhoAmIApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().whoAmIapi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().whoAmIapi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().whoAmIapi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().whoAmIapi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().whoAmIapi.headers
      }
    };
  })
);

IocContainer.bind<DataServicesApi>(IocTypes.DataServicesApi).toConstantValue(
  new DataServicesApi({}, () => {
    return {
      XCHCClientId: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.XCHCClientId,
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().dataServicesApi.headers
      }
    };
  })
);

IocContainer.bind<ProviderDirectoryServicesApi>(IocTypes.ProviderDirectoryServicesApi).toConstantValue(
  new ProviderDirectoryServicesApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().providerDirectoryServicesApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().providerDirectoryServicesApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().providerDirectoryServicesApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().providerDirectoryServicesApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().providerDirectoryServicesApi.headers
      }
    };
  })
);

IocContainer.bind<EnrollmentApi>(IocTypes.EnrollmentApi).toConstantValue(
  new EnrollmentApi({}, () => {
    return {
      apikey: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.apikey,
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().enrollmentApi.headers
      }
    };
  })
);

IocContainer.bind<LinkedServicesApi>(IocTypes.LinkedServicesApi).toConstantValue(
  new LinkedServicesApi({}, () => {
    return {
      precallHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().linkedServicesApi.precallHandler,
      successHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().linkedServicesApi.successHandler,
      errorHandler: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().linkedServicesApi.errorHandler,
      baseUrl: IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().linkedServicesApi.baseUrl,
      headers: {
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().commonHeaders,
        ...IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().linkedServicesApi.headers
      }
    };
  })
);

IocContainer.bind<PayerToPayerApi>(IocTypes.PayerToPayerApi).toConstantValue(new PayerToPayerApi({}, () => IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().payerToPayerApi));

// Linked services + Payer to payer stores
IocContainer.bind<LinkedServicesListStoreType>(IocTypes.LinkedServicesListStore).to(LinkedServicesListStore).inSingletonScope();
IocContainer.bind<interfaces.Newable<LinkedServiceStoreType>>(IocTypes.LinkedServiceStore).toConstructor<LinkedServiceStoreType>(LinkedServiceStore);
IocContainer.bind<PayerToPayerStoreType>(IocTypes.PayerToPayerStore).to(PayerToPayerStore).inSingletonScope();

// Find care store
IocContainer.bind<FindCareStoreType>(IocTypes.FindCareStore).to(FindCareStore).inSingletonScope();
IocContainer.bind<interfaces.Newable<FindCareResultStoreType>>(IocTypes.FindCareResultStore).toConstructor<FindCareResultStoreType>(FindCareResultStore);
IocContainer.bind<interfaces.Newable<FindCareLocationStoreType>>(IocTypes.FindCareLocationStore).toConstructor<FindCareLocationStoreType>(FindCareLocationStore);

//Base store
IocContainer.bind<BaseStoreType>(IocTypes.BaseStore).toDynamicValue((context: interfaces.Context) => new BaseStore());

//Payer stores
IocContainer.bind<PayerDocumentsStoreType>(IocTypes.PayerDocumentsStore).to(PayerDocumentsStore).inSingletonScope();
IocContainer.bind<PayerStoreType>(IocTypes.PayerStore).to(PayerStore).inSingletonScope();
IocContainer.bind<ImageStoreType>(IocTypes.ImageStore).to(ImageStore).inSingletonScope();

// App configuraion store
IocContainer.bind<AppConfigStoreType>(IocTypes.AppConfigStore).to(AppConfigStore).inSingletonScope();

// EOB stores
IocContainer.bind<EOBListStoreType>(IocTypes.EOBListStore).to(EOBListStore).inSingletonScope();
IocContainer.bind<interfaces.Newable<EOBStoreType>>(IocTypes.EOBStore).toConstructor<EOBStoreType>(EOBStore);

// Clinical stores
IocContainer.bind<MedicationRequestStoreType>(IocTypes.MedicationRequestStore).to(MedicationRequestStore).inSingletonScope();

IocContainer.bind<LabObservationStoreType>(IocTypes.LabObservationStore).to(LabObservationStore).inSingletonScope();

IocContainer.bind<ProceduresStoreType>(IocTypes.ProceduresStore).to(ProceduresStore).inSingletonScope();

IocContainer.bind<ConditionsStoreType>(IocTypes.ConditionsStore).to(ConditionsStore).inSingletonScope();

IocContainer.bind<AllergiesStoreType>(IocTypes.AllergiesStore).to(AllergiesStore).inSingletonScope();

IocContainer.bind<EncountersStoreType>(IocTypes.EncountersStore).to(EncountersStore).inSingletonScope();

IocContainer.bind<ImplantableDeviceStoreType>(IocTypes.ImplantableDeviceStore).to(ImplantableDeviceStore).inSingletonScope();

IocContainer.bind<ImmunizationsStoreType>(IocTypes.ImmunizationsStore).to(ImmunizationsStore).inSingletonScope();

IocContainer.bind<ErrorStore>(IocTypes.ErrorStore).to(ErrorStoreType).inSingletonScope();

IocContainer.bind<WhoAmIStoreType>(IocTypes.WhoAmIStore).to(WhoAmIStore).inSingletonScope();

IocContainer.bind<DelegateStoreType>(IocTypes.DelegateStore).to(DelegateStore).inSingletonScope();

IocContainer.bind<ClinicalsOverviewStoreType>(IocTypes.ClinicalsOverviewStore).to(ClinicalsOverviewStore).inSingletonScope();
