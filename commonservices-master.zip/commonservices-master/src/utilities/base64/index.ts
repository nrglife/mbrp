import Hashes from 'jshashes';
import base64 from './base64';

export default base64;

export const generateSHA256String = (str: string) => {
  let SHA256 = new Hashes.SHA256();
  return replaceSpecialCharactersFromBase64String(SHA256.b64(str));
};

export const generateBase64String = (str: string) => replaceSpecialCharactersFromBase64String(base64.encode(str));

const replaceSpecialCharactersFromBase64String = (str: string) => str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
