export const minutesToMilliseconds = (minutes: string | number | undefined | null): number => {
    if (!minutes || !Number(minutes)) {
      return 0;
    }
    return Number(minutes) * 60 * 1000;
  };
  