import {
  formatDate,
  getDateFromDateTime,
  isValidDate,
  sortByDate,
  SortTypes,
} from "../dates";
import { isNumber } from "../Numeric";
import {
  AdjudicationCategories,
  EOB,
  EOBAdjudication,
  EOBCareTeam,
  EOBItem,
  EOBTotal,
  TotalsAmountCategories,
} from "./eob-types";
import {
  getCodeableValue,
  isValidAmount,
  getTotalAmounts,
  getAddressByUseAndType,
} from "./helper";
import {
  CalculatedAmount,
  Coding,
  ContainedResourcesTypes,
  dateTime,
  Money,
  Period,
  Address,
  AddressType,
  AddressUse,
  ContainedReference,
} from "./types";
import { CareTeamRoles } from "./types";

const getSortedCareTeams = (eob: EOB | null) => {
  const sorted = eob.careTeam?.slice().sort((ct1, ct2) => {
    if (ct1 && ct2 && isNumber(ct1.sequence) && isNumber(ct2.sequence)) {
      if (ct1.sequence < ct2.sequence) return -1;
      else if (ct1.sequence > ct2.sequence) return 1;
      else return 0;
    } else if (ct1 && isNumber(ct1.sequence)) return -1;
    else if (ct2 && isNumber(ct2.sequence)) return 1;
    else return 0;
  });

  return sorted;
};

// Get practitioner first reference id from CareTeam object, filtered by specific role
export const getCareTeamReferenceIDByRole = (
  eob: EOB | null,
  roles: string[]
) => {
  const reference =
    eob?.careTeam?.length > 0
      ? eob.careTeam
          ?.slice()
          .sort((ct1, ct2) => {
            const ct1seq =
              ct1 && isNumber(ct1.sequence)
                ? ct1.sequence
                : Number.MAX_SAFE_INTEGER;
            const ct2seq =
              ct2 && isNumber(ct2.sequence)
                ? ct2.sequence
                : Number.MAX_SAFE_INTEGER;
            return ct1seq - ct2seq;
          })
          ?.find((ct) => ct.role && roles.includes(getCodeableValue(ct.role)))
          ?.provider?.reference
      : null;

  return reference ? reference : null;
};

//Get first found Contained resource by references ids list
export const getFirstContainedByReferenceId = (
  eob: EOB | null,
  referenceId: string,
  resourceType: ContainedResourcesTypes | null = null
) => {
  const list = resourceType
    ? getContainedByResourceType(eob, resourceType)
    : eob?.contained;

  const containedItem = list
    ? list?.find((item) => `#${item.id}` === referenceId)
    : null;
  return containedItem;
};

//Get all contained resources filtered by resource type
export const getContainedByResourceType = (
  eob: EOB | null,
  resourceType: ContainedResourcesTypes
) => {
  const contained = eob
    ? eob.contained?.filter((item) => item.resourceType === resourceType)
    : null;

  return contained;
};

//Get all included resources filtered by resource type
export const getIncludedByResourceType = (
  includedResources: ContainedReference[] | null,
  resourceType: ContainedResourcesTypes
) => {
  const included = includedResources
    ? includedResources.filter((item) => item.resourceType === resourceType)
    : null;

  return included;
};

//Get first found Included resource by references ids list
export const getFirstIncludedByReferenceId = (
  includedResources: ContainedReference[] | null,
  referenceId: string,
  resourceType: ContainedResourcesTypes | null = null
) => {
  const list = resourceType
    ? getIncludedByResourceType(includedResources, resourceType)
    : includedResources;
  const refArr = referenceId.split("/");
  const refResourceType = refArr && refArr.length > 1 ? refArr[0] : null;
  const refResourceId = refArr && refArr.length > 1 ? refArr[1] : null;

  const includedItem =
    list && refResourceType && refResourceId
      ? list?.find(
          (item) =>
            item.id.trim().toLowerCase() ===
              refResourceId.trim().toLowerCase() &&
            item.resourceType.trim().toLowerCase() ===
              refResourceType.trim().toLowerCase()
        )
      : null;

  return includedItem;
};

/**
 *
 * @param eob EOB - Explanation Of Benefits
 * @param category Category of type 'TotalsAmountCategories' to filter the amounts by
 * @returns the first item in the list of category relevant amounts
 */
export const getTotalByCategory = (
  eob: EOB,
  category: AdjudicationCategories | TotalsAmountCategories
) => {
  const eobTotal = eob.total;
  if (!eobTotal || eobTotal.length === 0) return null;

  const totalsCategories = eobTotal?.filter((total: EOBTotal) =>
    total.category?.coding.every(
      (codeCategory: Coding) => codeCategory.code === category
    )
  );
  const totalByCategory =
    totalsCategories && totalsCategories.length > 0
      ? totalsCategories.find((total) => isValidAmount(total?.amount))
      : null;
  return totalByCategory?.amount;
};

/**
 *
 * @param item EOBItem - Explanation Of Benefits
 * @param category Category of type 'AdjudicationCategories' to filter the amounts by
 * @returns the first item in the list of category relevant amounts adjudications
 */
export const getAdjudicationValueByCategory = (
  item: EOBItem,
  adjudicationCategory: AdjudicationCategories
) => {
  const adjudications = item.adjudication;
  if (!adjudications || adjudications.length === 0) return null;

  const selectedAdjudications = adjudications?.filter(
    (adjudication: EOBAdjudication) =>
      adjudication.category?.coding.every(
        (codeCategory: Coding) => codeCategory.code === adjudicationCategory
      )
  );

  const adjudicationValueByCategory =
    selectedAdjudications && selectedAdjudications.length > 0
      ? selectedAdjudications.find((item) => isValidAmount(item.amount))
      : null;

  return adjudicationValueByCategory?.amount;
};

/**
 * @param eob EOB - Explanation Of Benefits
 * @returns Summation of all the service lines within an EOB.  Lookalike it would be the Submitted –Benefit.
 */
export const getInsuranceCoveredAmountViaServices = (
  eob: EOB
): CalculatedAmount | null | undefined => {
  if (eob?.item == null || eob?.item.length === 0) return null;

  let coveredAmountPerService = eob.item.map((item) =>
    getAdjudicationValueByCategory(item, AdjudicationCategories.Benefit)
  );

  return getTotalAmounts(coveredAmountPerService);
};

/**
 *
 * @param item EOBItem - Explanation Of Benefits
 * @returns a string with the name of the item = "text (code)" if exist - if not return null
 */
export const getEOBItemName = (item: EOBItem | null | undefined) => {
  if (item == null) return null;

  const code = item.productOrService?.coding[0]?.code
    ? item.productOrService?.coding[0]?.code
    : null;
  const name = item.productOrService?.coding[0]?.display
    ? item.productOrService?.coding[0]?.display
    : null;

  if (name && code) return `${name} (${code})`;
  if (code) return `Code: ${code}`;
  if (name) return `${name}`;
  return null;
};

/**
 *
 * @param item EOBItem - Explanation Of Benefits
 * @returns a string with the date period / date  of the item - "start to end" / "start" if exist - if not return null
 */
export const getEOBItemDateString = (item: EOBItem | null | undefined) => {
  if (item == null) return null;
  let itemDate: string | null = null;

  const servicedPeriod_startDate = isValidDate(item.servicedPeriod?.start);
  const servicedPeriod_endDate = isValidDate(item.servicedPeriod?.end);
  const fullDate = isValidDate(item.servicedDate);

  if (servicedPeriod_startDate && servicedPeriod_endDate)
    itemDate = `${formatDate(item.servicedPeriod?.start)} - ${formatDate(
      item.servicedPeriod?.end
    )}`;
  else if (servicedPeriod_startDate)
    itemDate = formatDate(item.servicedPeriod?.start);
  else if (fullDate) itemDate = formatDate(item.servicedDate);

  return itemDate;
};

/**
 *
 * @param item EOBItem - Explanation Of Benefits
 * @returns a number with the Member Price of the item if exist - if not return null
 */
export const getEOBItemMemberPrice = (item: EOBItem | null | undefined) => {
  if (item == null) return null;
  return item?.net;
};

/**
 *
 * @param eob EOB - Explanation Of Benefits
 * @returns EOB billable period. Both start and end dates. If the are no start AND end dates, then returns null.
 */

export const getEOBBillablePeriod: (eob: EOB) => Period | null = (eob: EOB) => {
  if (!eob || !eob.billablePeriod) return null;

  const startDate =
    eob.billablePeriod.start && isValidDate(eob.billablePeriod.start)
      ? eob.billablePeriod.start
      : null;
  const endDate =
    eob.billablePeriod.end && isValidDate(eob.billablePeriod.end)
      ? eob.billablePeriod.end
      : null;

  // if both null, return null because there is nothing to return.
  if (!startDate && !endDate) return null;

  return {
    start: startDate,
    end: endDate,
  };
};

/**
 *
 * @param eob EOB - Explanation Of Benefits
 * @returns returns EOB's items earliest start date and the latest end date. if there are no service dates return null.
 */
export const getEOBEalriestAndLatestServicedDate: (eob: EOB) => Period | null =
  (eob: EOB) => {
    if (!eob || !eob.item || eob.item.length === 0) return null;

    var earliestDate = Infinity;
    var latestDate = -Infinity;
    var earliestDateString: dateTime | undefined = null;
    var latestDateString: dateTime | undefined = null;

    eob.item.forEach((eobItem: EOBItem) => {
      const servicedDateTimeRaw = eobItem.servicedDate;
      //the string come in format of 2020-06-20T21:55:03 remove time part from the dateTime.
      const servicedDateRaw = getDateFromDateTime(eobItem?.servicedDate);

      if (!!servicedDateRaw && isValidDate(servicedDateRaw)) {
        const serviceDate = new Date(servicedDateRaw).getTime();
        // update the minimum date.
        if (earliestDate >= serviceDate) {
          earliestDate = serviceDate;
          earliestDateString = servicedDateTimeRaw;
        }
        // update the maximum date.
        if (latestDate < serviceDate) {
          latestDate = serviceDate;
          latestDateString = servicedDateTimeRaw;
        }
      }
    });

    // if both null, return null because there is nothing to return.
    if (!earliestDateString && !latestDateString) {
      return null;
    }

    return { start: earliestDateString, end: latestDateString };
  };

/**
 * @summary This function returns EOB's items serviced period start and end dates.
 * @param eobItem EOBItem - Explanation Of Benefits
 * @returns return EOB's items serviced period start and end dates.
 */
const getEOBServicedPeriodDate = (eobItem: EOBItem) => {
  const servicedPeriodRaw = eobItem.servicedPeriod;
  var startDate: dateTime = null;
  var endDate: dateTime = null;

  if (!servicedPeriodRaw) return null;

  if (isValidDate(servicedPeriodRaw.start)) {
    startDate = servicedPeriodRaw.start;
  }

  if (isValidDate(servicedPeriodRaw.end)) {
    endDate = servicedPeriodRaw.end;
  }

  if (!startDate && !endDate) return null;

  return {
    start: startDate,
    end: endDate,
  };
};

/**
 * @summary TThis function returns EOB's items serviced period dates. Where start date is the ealiest and end date is the latest of all.
 * @param eob EOB - Explanation Of Benefits
 * @returns EOB's items serviced period start and end dates.
 */

export const getEOBServicedPeriodEarliestAndLatestDatesRange: (
  eob: EOB
) => Period | null = (eob: EOB) => {
  if (!eob || !eob.item || eob.item.length === 0) return null;

  var minStartDate = Infinity;
  var maxEndDate = -Infinity;
  var minStartDateString: dateTime = null;
  var maxEndDateString: dateTime = null;

  eob.item.forEach((eobItem: EOBItem) => {
    const servicedPeriodRaw = getEOBServicedPeriodDate(eobItem);

    if (servicedPeriodRaw?.start) {
      // convert servicedPeriodRaw.start into a number for the equality
      // servicedPeriodRaw.start is already in format of date without time
      const servicedDateRawStartDate = new Date(
        getDateFromDateTime(servicedPeriodRaw.start) ?? servicedPeriodRaw.start
      ).getTime();
      // save the minimum(=earliest) date
      if (minStartDate > servicedDateRawStartDate) {
        minStartDate = servicedDateRawStartDate;
        minStartDateString = servicedPeriodRaw.start;
      }
      // save the maximum(=latest) date
      if (maxEndDate < servicedDateRawStartDate) {
        maxEndDate = servicedDateRawStartDate;
        maxEndDateString = servicedPeriodRaw.start;
      }
    }
    if (servicedPeriodRaw?.end) {
      // convert servicedPeriodRaw.end into a number for the equalility
      // servicedPeriodRaw.end is already in format of date without time
      const servicedDateRawEndDate = new Date(
        getDateFromDateTime(servicedPeriodRaw.end) ?? servicedPeriodRaw.end
      ).getTime();
      // save the minimum(=latest) date
      if (minStartDate > servicedDateRawEndDate) {
        minStartDate = servicedDateRawEndDate;
        minStartDateString = servicedPeriodRaw.end;
      }

      // save the maximum(=latest) date
      if (maxEndDate < servicedDateRawEndDate) {
        maxEndDate = servicedDateRawEndDate;
        maxEndDateString = servicedPeriodRaw.end;
      }
    }
  });

  // If both does not exist return null.
  if (!minStartDateString && !maxEndDateString) return null;

  return {
    start: minStartDateString,
    end: maxEndDateString,
  };
};

/**
 * @summary Returns EOB's services range dates. if an EOB has billable period dates then return them.
 * else return the earliest of all serviced dates and billable period start dates and the latest of all serviced dates and bollable period end dates.
 * @param eob EOB - Explanation Of Benefitx
 * @returns a range of start and end dates.
 */
export const getEOBsServicesDatesRange: (eob: EOB) => Period | null = (
  eob: EOB
) => {
  const billablePeriod = getEOBBillablePeriod(eob);

  // if there is either start or an end date, return it.
  if (!!billablePeriod?.start) {
    return billablePeriod;
  }

  let startDateToReturn: dateTime = null;
  let endDateToReturn: dateTime = null;
  let startDate: number = Infinity;
  let endDate: number = -Infinity;

  const servicedDate = getEOBEalriestAndLatestServicedDate(eob);
  const servicedPeriod = getEOBServicedPeriodEarliestAndLatestDatesRange(eob);

  // both servicedDate and servicedPeriod are null OR they exist but both start and end dates are null
  if (
    ((!servicedDate && !servicedPeriod) ||
      (!!servicedDate &&
        !servicedDate.start &&
        !!servicedPeriod &&
        !servicedPeriod.start)) &&
    !billablePeriod?.start
  )
    return null;

  if (!!servicedDate) {
    // take serviced start and end dates and save them.
    startDateToReturn = servicedDate.start ? servicedDate.start : null;
    startDate = startDateToReturn
      ? new Date(
          getDateFromDateTime(startDateToReturn) ?? startDateToReturn
        ).getTime()
      : Infinity;
    endDateToReturn = servicedDate.end ? servicedDate.end : null;
    endDate = endDateToReturn
      ? new Date(
          getDateFromDateTime(endDateToReturn) ?? endDateToReturn
        ).getTime()
      : -Infinity;
  }
  if (!!servicedPeriod) {
    // if there is a serviced period dates as well, then, take the earliest start date and the latest end date of the two.
    // servicedPeriod.start is already in format of date without time
    startDateToReturn = !!servicedPeriod.start
      ? startDate >
        new Date(
          getDateFromDateTime(servicedPeriod.start) ?? servicedPeriod.start
        ).getTime()
        ? servicedPeriod.start
        : startDateToReturn
      : startDateToReturn;
    // servicedPeriod.end is already in format of date without time
    endDateToReturn = !!servicedPeriod.end
      ? endDate <
        new Date(
          getDateFromDateTime(servicedPeriod.end) ?? servicedPeriod.end
        ).getTime()
        ? servicedPeriod.end
        : endDateToReturn
      : endDateToReturn;
  }

  // if both does not exit, return null.
  if (!startDateToReturn && !endDateToReturn) return null;

  return {
    start: startDateToReturn,
    end: endDateToReturn,
  };
};

/**
 * @summary This function returns billing address by the following criteria:
 * 1. if there is only one address - return address.
 * 2. if there are multiple addresses:
 * 3. sort them by descending Period start dates and invokes getBillingAddressByPriority function.
 * @param addresses Address
 * @returns billing address.
 */
export const getBillingAddress = (
  addresses: Address[] | null | undefined
): Address | null => {
  try {
    if (!addresses || addresses.length === 0) return null;
    if (addresses.length === 1) return addresses[0];

    const sortedbyLatestAddresses = addresses
      .slice()
      .sort(function sortAddressesDates(a, b) {
        const bDate = b.period?.start ? b.period.start : null;
        const aDate = a.period?.start ? a.period.start : null;
        return sortByDate(aDate, bDate, SortTypes.Descending);
      });

    return getBillingAddressByPriority(sortedbyLatestAddresses);
  } catch (err) {
    console.log("getAddress: failed to filter fullname for addresses");
    return null;
  }
};

/**
 * @summary This function searches for the first address that satisfies the following:
 *    - use="billing" AND (type="postal" OR type="both" OR type="physical") - if not found:
 *      search by:
 *    - use="work" AND (type="postal" OR type="both" OR type="physical") - if not found:
 *      search by:
 *    - use="home" AND (type="postal" OR type="both" OR type="physical") - if not found return null;
 * @param addresses Address
 * @returns billing address.
 */
const getBillingAddressByPriority = (addresses: Address[]) => {
  if (!addresses || addresses.length === 0) return null;
  let firstItemInArray = addresses.length > 0 ? addresses[0] : null;

  const billingAddressUsesPriority = [
    AddressUse.Billing,
    AddressUse.Work,
    AddressUse.Home,
  ];
  for (
    let addressUsesPriorityIndex = 0;
    addressUsesPriorityIndex < billingAddressUsesPriority.length;
    addressUsesPriorityIndex++
  ) {
    const billingAddressTypesPriority = [
      AddressType.Postal,
      AddressType.Both,
      AddressType.Physical,
    ];
    for (
      let addressTypesPriorityIndex = 0;
      addressTypesPriorityIndex < billingAddressTypesPriority.length;
      addressTypesPriorityIndex++
    ) {
      const addressByType = getAddressByUseAndType(
        addresses,
        billingAddressUsesPriority[addressUsesPriorityIndex],
        billingAddressTypesPriority[addressTypesPriorityIndex]
      );
      if (!!addressByType) return addressByType;
    }
  }

  return firstItemInArray;
};
