import { isValidDate, sortByDate, SortTypes } from '../dates';
import { isNumber } from '../Numeric';
import { HumanName as HumanNameWhoAmI } from './../../stores/DelegateStore';
import { DelegateForMember } from './../../stores/WhoAmIStore';
import { Address, CodeableConcept, code, HumanName, ContactPoint, NameUse, ContactPointSystem, AddressType, AddressUse, Money, CalculatedAmount, CurrencyCodes, Reference, Resource } from './types';
import { titleCase, stringReplace } from '../string';

export const getCodeableValue = (item: CodeableConcept, isCode: boolean = true) => {
  try {
    const value = isCode ? item?.coding[0].code : item.text;
    return value;
  } catch (err) {
    console.log('getCodeableValue: failed');
    return null;
  }
};

export const getCodeableDisplayValue = (item: CodeableConcept | null | undefined) => {
  try {
    const value = item?.coding && item?.coding[0]?.display ? item?.coding[0]?.display : null;
    return value;
  } catch (err) {
    console.log('getCodeableDisplayValue: failed');
    return null;
  }
};

export const getCodeableCodeValue = (item: CodeableConcept | null | undefined) => {
  try {
    const value = item?.coding && item?.coding[0]?.code ? item?.coding[0]?.code : null;
    return value;
  } catch (err) {
    console.log('getCodeableCodeValue: failed');
    return null;
  }
};

export const getCodeFormattedDisplayString = (item: code | null | undefined) => {
  let display = null;

  try {
    if (item) {
      display = titleCase(stringReplace(item, '-', ' '));
    }
  } catch (err) {
    console.log('getCodeDisplayString: failed', err);
  }

  return display;
};

export const concatFullName = (data: DelegateForMember | null | undefined) => {
  try {
    if (!data) return null;
    const family = data.family ? data.family.trim() : '';
    const given = data.given ? data.given.trim() : '';
    return given + ' ' + family;
  } catch (err) {
    console.log('concatFullName: failed');
    return null;
  }
};

export const getFullName = (humanName: HumanName[] | HumanName | null | undefined, use: NameUse = NameUse.Usual, getLatest: boolean = true) => {
  const hname = Array.isArray(humanName) ? filterSingleHumanName(humanName, use, getLatest) : humanName;
  return getFullNameFormat(hname);
};

/// Get name by following logic:
/// If getLatest = true => will get the latest used name (period.start)
/// If latest not found, get by use (default= usual),
/// If not found, return the fist in the array
const filterSingleHumanName = (humanNames: HumanName[] | null | undefined, use: NameUse = NameUse.Usual, getLatest: boolean = true) => {
  try {
    if (!humanNames || humanNames.length === 0) return null;
    if (humanNames.length > 1) {
      if (getLatest) {
        let humanNamesArr = humanNames.slice().sort((a, b) => {
          return sortByDate(a.period?.start, b.period?.start, SortTypes.Descending);
        });

        if (humanNamesArr[0].period?.start != null && isValidDate(humanNamesArr[0].period?.start)) return humanNamesArr[0];
      }
      let getByUse = humanNames?.find(name => name.use === use);
      if (getByUse) return getByUse;
    }
    return humanNames[0];
  } catch (err) {
    console.log('filterSingleHumanName: failed');
    return null;
  }
};

//return text if exits, otherwise return the current format: prefix[0] given[0] given[1(first letter)] family suffix[0]
const getFullNameFormat = (humanName: HumanName | null | undefined): string | null => {
  try {
    if (!humanName) return null;
    if (humanName.text && humanName.text.trim() !== '') return humanName.text;

    const family = humanName.family ? humanName.family.trim() : '';
    const given = humanName.given && humanName.given.length > 0 && humanName.given[0] ? humanName.given[0].trim() : '';
    const initial = humanName.given && humanName.given.length > 1 && humanName.given[1] && humanName.given[1].trim().length > 0 ? humanName.given[1].trim()[0] : '';
    const prefix = humanName.prefix && humanName.prefix.length > 0 && humanName.prefix[0] ? humanName.prefix[0].trim() : '';
    const suffix = humanName.suffix && humanName.suffix.length > 0 && humanName.suffix[0] ? humanName.suffix[0].trim() : '';

    if ((family !== '' && family != null) || (given !== '' && given != null)) {
      const nameArr: string[] = [prefix, given, initial, family, suffix];
      const fullName = nameArr.reduce((accumulator, name) => (name != null && name !== '' ? accumulator + ' ' + name : accumulator), '').trim();

      return fullName;
    } else {
      return null;
    }
  } catch (err) {
    console.log('getFullNameFormat: failed');
    return null;
  }
};

// retuns an address where use===addressUse AND type===addressType
export const getAddressByUseAndType = (addresses: Address[], addressUse: AddressUse, addressType: AddressType) =>
  addresses.find((address: Address) => address.use === addressUse && address.type === addressType);

//return address in two lines. First line is the street details from line , second line is <city>, <><>
export const getAddressAs2Lines = (address: Address | null | undefined) => {
  if (!address) return { line1: '', line2: '' };
  const addressLine1 = address?.line && address?.line.length > 0 ? address?.line[0] : null;

  let addressLine2 = address?.city ? address?.city : '';
  addressLine2 = addressLine2 && addressLine2 !== '' && address?.state && address?.state !== '' ? addressLine2 + ', ' + address?.state : addressLine2;
  addressLine2 = addressLine2 && addressLine2 !== '' && address?.postalCode && address?.postalCode !== '' ? addressLine2 + ' ' + address?.postalCode : addressLine2;
  return { line1: addressLine1, line2: addressLine2 };
};

// get telecom for specific system (phone/email..) wit hte hhighest rank.
//If no rank, get  the first
export const getTelecom = (telecom: ContactPoint[], system: ContactPointSystem) => {
  if (!telecom || telecom.length === 0) return null;

  let filteredBySystem = telecom.filter(item => item.system === system);
  if (!filteredBySystem || filteredBySystem.length === 0) return null;
  if (filteredBySystem.length === 1) return filteredBySystem[0];

  const max = filteredBySystem.reduce((prev, current) => (prev.rank != null && current.rank != null ? (prev.rank <= current.rank ? prev : current) : prev.rank == null ? current : prev));

  return max;
};

//TODO: oreng: check if we can change isContainUnknownCurrency &  isForeignCurrencyExist to 1 var
//TODO: oreng: if we can remove isComplete
export const isValidAmount = (amount: Money | null | undefined, isComplete: boolean = true, isContainUnknownCurrency: boolean = false, isForeignCurrencyExist: boolean = false) => {
  return (isContainUnknownCurrency === false || isForeignCurrencyExist === false) && isComplete === true && amount?.value != null && isNumber(amount?.value);
};

export const isEmptyString = (text: string | null | undefined) => {
  return text === null || text === undefined || text === '' || text.length === 0;
};

export const getTotalAmounts = (totalsArr: (Money | null | undefined)[] | null | undefined, isCompleteArr: boolean = true): CalculatedAmount | null => {
  if (totalsArr == null || totalsArr.length === 0) return null;
  //In case there is at least one with USD currency => take these items into calculations
  let foreignCurrency = totalsArr.find(item => isValidAmount(item) && item?.currency?.trim().toUpperCase() !== CurrencyCodes.USD && !isEmptyString(item?.currency));

  let totalsArrUnknownCurrency = totalsArr.filter(item => isValidAmount(item) && isEmptyString(item?.currency));

  let totalsArrUSDCurrency = totalsArr.filter(item => isValidAmount(item) && item?.currency?.trim().toUpperCase() === CurrencyCodes.USD);

  totalsArrUSDCurrency = totalsArrUSDCurrency.concat(totalsArrUnknownCurrency);

  if (totalsArrUSDCurrency != null && totalsArrUSDCurrency.length > 0) {
    let amount = totalsArrUSDCurrency.reduce((acc, item) => {
      return item?.value != null ? acc + item?.value : acc;
    }, 0);

    return {
      amount: { value: amount, currency: CurrencyCodes.USD },
      isComplete: isCompleteArr ? totalsArrUSDCurrency.length === totalsArr.length : false,
      isContainUnknownCurrency: totalsArrUnknownCurrency.length > 0
    };
  }
  //In case there is no USD currency, take the currency from the first existing valid amount with foreign currency
  else {
    let totalsArrForeignCurrency = foreignCurrency && totalsArr.filter(item => isValidAmount(item) && item?.currency?.trim().toUpperCase() === foreignCurrency?.currency?.trim().toUpperCase());
    if (totalsArrForeignCurrency == null || totalsArrForeignCurrency.length == 0) return null;
    else {
      let foreignAmount = totalsArrForeignCurrency.reduce((acc, item) => {
        return item?.value != null ? acc + item?.value : acc;
      }, 0);

      return {
        amount: {
          value: foreignAmount,
          currency: foreignCurrency?.currency?.trim().toUpperCase()
        },
        isComplete: isCompleteArr ? totalsArrForeignCurrency.length === totalsArr.length : false,
        isContainUnknownCurrency: totalsArrUnknownCurrency.length > 0
      };
    }
  }
};

//Get all included resources filtered by resource type
export const getIncludedByResourceType = (includedResources: Resource[] | null, resourceType: string) => {
  const included = resourceType && includedResources ? includedResources.filter(item => item.resourceType && item.resourceType.toLowerCase() === resourceType.toLowerCase()) : null;

  return included;
};

//Get first found Included resource by references ids list
export const getFirstIncludedByReferenceId = (includedResources: Resource[] | null | undefined, referenceId: string, resourceType: string | null = null) => {
  const list = resourceType ? getIncludedByResourceType(includedResources, resourceType) : includedResources;
  const refArr = referenceId && referenceId != '' && referenceId.split('/');
  const refResourceType = refArr && refArr.length > 1 ? refArr[0] : null;
  const refResourceId = refArr && refArr.length > 1 ? refArr[1] : null;

  const includedItem = list && refResourceType && refResourceId ? list?.find(item => item.id.trim() === refResourceId.trim() && item.resourceType.trim() === refResourceType.trim()) : null;

  return includedItem;
};

export const getFullNameFormatWhoAmI = (humanName: HumanNameWhoAmI | null | undefined): string | null => {
  try {
    if (!humanName) return null;
    if (humanName.fullName && humanName.fullName.trim() !== '') return humanName.fullName;

    const family = humanName.family ? humanName.family.trim() : '';
    const given = humanName.given && humanName.given.length > 0 && humanName.given[0] ? humanName.given[0].trim() : '';
    const initial = humanName.given && humanName.given.length > 1 && humanName.given[1] && humanName.given[1].trim().length > 0 ? humanName.given[1].trim()[0] : '';
    const prefix = humanName.prefix && humanName.prefix.length > 0 ? humanName.prefix.trim() : '';
    const suffix = humanName.suffix && humanName.suffix.length > 0 ? humanName.suffix.trim() : '';

    if ((family !== '' && family != null) || (given !== '' && given != null)) {
      const nameArr: string[] = [prefix, given, initial, family, suffix];
      const fullName = nameArr.reduce((accumulator, name) => (name != null && name !== '' ? accumulator + ' ' + name : accumulator), '').trim();

      return fullName;
    } else {
      return null;
    }
  } catch (err) {
    console.log('getFullNameFormat: failed');
    return null;
  }
};
