import {
  Address,
  Attachment,
  AvailableTime,
  BackboneElement,
  base64Binary,
  code,
  CodeableConcept,
  Coding,
  ContactPoint,
  date,
  dateTime,
  decimal,
  Extension,
  HumanName,
  id,
  Identifier,
  Location_HoursOfOperation,
  Location_Position,
  markdown,
  Meta,
  Period,
  Qualification,
  Reference,
  Resource,
  time,
  unsignedInt,
  uri,
  xhtml,
} from "../types";

///ENUMS

export enum FindCareResourcesTypes {
  Practitioner = "Practitioner",
  Location = "Location",
  Organization = "Organization",
  PractitionerRole = "PractitionerRole",
  OrganizationAffiliation = "OrganizationAffiliation",
  HealthcareService = "HealthcareService",
  Network = "Network",
}

///TYPES

export type NewPatients_Extension_DaVinci = {
  id?: string | null;
  extension?: Extension[] | null;
  acceptingPatients?: Extension[] | null;
  fromNetwork?: Extension[] | null;
  characteristics?: Extension[] | null;
  url?: uri;
};

export type DeliveryMethod_Extension_DaVinci = {
  id?: string | null;
  extension?: Extension[] | null;
  type: Extension[] | null; //Accepting Patients.
  virtualModalities?: Extension[] | null;
  url?: uri | null;
};

//Contact for the organization for a certain purpose
export type Contact = {
  purpose?: CodeableConcept | null;
  name?: HumanName | null;
  telecom?: ContactPoint[] | null;
  address?: Address | null;
};

export type Practitioner_Qualification = {
  id?: id | null;
  extention?: Extension | null;
  modifierExtension?: Extension | null;
  identifier?: Identifier[] | null;
  code: code | null;
  period?: Period | null;
  issuer?: Reference | null;
};

export type Narrative = {
  id?: string | null;
  extension?: object[] | null;
  status?: object | null;
  div: xhtml | null;
};

export type HealthcareService_Eligibility = {
  id?: id | null;
  extention?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  code?: CodeableConcept | null;
  comment?: markdown | null;
};

export type HealthcareService_AvailableTime = {
  id?: id | null;
  extention?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  daysOfWeek?: code[] | null;
  allDay?: boolean | null;
  availableStartTime?: time | null;
  availableEndTime?: time | null;
};

export type HealthcareService_NotAvailable = {
  id?: id | null;
  extention?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  description?: string | null;
  during?: Period | null;
};

//A specific set of Roles/Locations/specialties/services that a practitioner may perform at an organization for a period of time.
export interface PractitionerRole {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta?: Meta | null;
  language?: code | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  newpatients?: NewPatients_Extension_DaVinci[] | null;

  network?: Reference[] | null;
  qualification?: Qualification | null;
  active?: boolean | null;
  period?: Period | null;
  practitioner?: Reference | null; // Practitioner
  organization?: Reference | null; //Organization
  code?: CodeableConcept[] | null;
  specialty?: CodeableConcept[] | null;
  location?: Reference[] | null; //Location
  healthcareService?: Reference[] | null; //HealthcareService
  telecom?: ContactPoint[] | null;
  availableTime?: AvailableTime[];
  notAvailable?: {
    id?: string | null;
    extension?: Extension[] | null;
    modifierExtension?: Extension[] | null;
    description?: string | null;
    during?: Period | null;
  } | null;
  availabilityExceptions?: string | null;
}

export interface Organization {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta: Meta | null;
  language?: code | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  qualification?: Qualification | null;
  ["org-description"]?: string | null;
  identifier?: object[] | null;
  active?: boolean | null;
  type?: CodeableConcept[];
  name?: string | null;
  alias?: string[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;

  //Another Location of which this Location is physically a part of.
  partOf: {
    active: boolean;
    name: string;
  };
  contact?: BackboneElement | null;
}

export interface Practitioner {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta: Meta | null;
  implicitRules?: uri | null;
  language?: code | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  ["communication-proficiency"]?: CodeableConcept | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  name?: HumanName[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;
  gender?: object;
  birthDate?: date | null;
  photo?: Attachment[] | null;
  qualification?: Practitioner_Qualification | null;
  communication?: CodeableConcept[];
}

export interface HealthcareService {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta?: Meta | null;
  implicitRules?: uri | null;
  language?: code | null;
  text?: Narrative | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  newpatients?: NewPatients_Extension_DaVinci[] | null;
  ["delivery-method"]?: DeliveryMethod_Extension_DaVinci | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  providedBy?: Reference | null;
  category?: CodeableConcept;
  type?: CodeableConcept[] | null;
  specialty?: CodeableConcept[] | null;
  location?: Reference[] | null;
  name?: string | null;
  comment?: string | null;
  extraDetails?: markdown | null;
  telecom?: ContactPoint[] | null;
  coverageArea?: Reference[] | null;
  eligibility?: HealthcareService_Eligibility[] | null;
  program?: CodeableConcept[] | null;
  characteristic?: CodeableConcept[] | null;
  communication?: CodeableConcept[];
  referralMethod?: CodeableConcept[];
  appointmentRequired?: boolean | null;
  availableTime?: HealthcareService_AvailableTime | null;
  notAvailable?: HealthcareService_NotAvailable | null;
  availabilityExceptions?: string | null;
}
export interface Location {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta: Meta | null;

  contained?: Resource[] | null;
  extension?: Extension[] | null;
  newpatients?: NewPatients_Extension_DaVinci[] | null;
  accessibility?: CodeableConcept[] | null;
  ["location-boundary-geojson"]?: Attachment | null;
  identifier?: Identifier[] | null;
  operationalStatus?: Coding | null;
  name?: string | null;
  alias?: string[] | null;
  address?: Address | null;
  physicalType?: CodeableConcept[];
  position?: Location_Position | null;
  managingOrganization?: Reference | null;
  partOf?: Reference | null;
  hoursOfOperation?: Location_HoursOfOperation | null;
  active?: boolean | null;
  availabilityExceptions?: string | null;
  telecom?: ContactPoint[] | null;
}
//The OrganizationAffiliation resource describes relationships between two or more organizations, including the services one organization provides another, the location(s) where they provide services, the availability of those services, electronic endpoints, and other relevant information.

export interface OrganizationAffiliation {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta: Meta | null;
  language?: code | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  qualification?: Qualification | null;
  active?: boolean | null;
  period?: Period | null;
  organization?: Reference | null;
  participatingOrganization?: Reference | null;
  network?: Reference[] | null;
  code?: CodeableConcept[] | null;
  specialty?: CodeableConcept[] | null;
  location?: Reference[] | null;
  healthcareService?: Reference[] | null;
  telecom?: ContactPoint[] | null;
}

export interface Network {
  resourceType?: FindCareResourcesTypes | null;
  id?: string | null;
  meta: Meta | null;
  language?: code | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  ["location-reference"]?: Reference | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  type?: CodeableConcept[] | null;
  name?: string | null;
  alias?: string[] | null;
  contact?: Contact;
}
