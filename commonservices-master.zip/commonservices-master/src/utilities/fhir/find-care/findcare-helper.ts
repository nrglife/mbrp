
import { Resource } from '../types';
import { FindCareResourcesTypes} from './findcare-types';
//Get first found Contained resource by references ids list
export const getFirstContainedByReferenceId = (list: any[] | null | undefined, referenceId: string | undefined, resourceType: FindCareResourcesTypes | null = null) => {

    if(!list || !referenceId){
        return;
    }

    const containedItem = list ? list?.find(item => `#${item.id}` === referenceId && item.resourceType == resourceType) : null;
    return containedItem;
};

//Get all included resources filtered by resource type
export const getContainedByResourceType = (containedResources:Resource[] | null, resourceType: FindCareResourcesTypes) => {
    return containedResources ? containedResources.filter(item => item.resourceType === resourceType) : null;
  };