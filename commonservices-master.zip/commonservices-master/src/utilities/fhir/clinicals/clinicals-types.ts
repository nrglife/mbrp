import { decimal, Duration, markdown, positiveInt } from '../types';
import { RelationalOperator, StringLiteralLike } from 'typescript';
import {
  Address,
  Age,
  Attachment,
  code,
  CodeableConcept,
  BackboneElement,
  Coding,
  ContactPoint,
  date,
  dateTime,
  Extension,
  Gender,
  HumanName,
  Identifier,
  Location_HoursOfOperation,
  Location_Position,
  Meta,
  Narrative,
  Period,
  Quantity,
  Ratio,
  Reference,
  Resource,
  Timing,
  uri,
  Range,
  base64Binary
} from '../types';
import { Url } from 'url';

///ENUMS

export enum ClinicalsResourcesTypes {
  MedicationRequest = 'MedicationRequest',
  Practitioner = 'Practitioner',
  Medication = 'Medication',
  Location = 'Location',
  Organization = 'Organization',
  PractitionerRole = 'PractitionerRole',
  Patient = 'Patient',
  AllergyIntolerance = 'AllergyIntolerance',
  Condition = 'Condition',
  ImplantableDevice = 'Device',
  Encounter = 'Encounter',
  Procedure = 'Procedure',
  Immunization = 'Immunization',
  Observation = 'Observation'
}

//TYPES - INTERNAL
type PatientExtension = {
  url?: string;
  extension?: {
    url?: string;
    valueCoding?: Coding;
    valueString?: string;
  }[];
};

///TYPES - FHIR

type udiCarrier = {
  id?: string;
  deviceIdentifier: string;
  carrierAIDC?: base64Binary;
  carrierHRF?: string;
};

type DeviceName = {
  id?: string;
  name?: string;
};

type Dosage_DoseAndRate = {
  id?: string;
  extension?: Extension[];
  modifierExtension?: Extension[];
  type?: CodeableConcept;
  doseRange?: Range;
  doseQuantity?: Quantity;
  rateRatio?: Ratio;
  rateRange?: Range;
  rateQuantity?: Quantity;
};

export type Dosage = {
  id?: string;
  extention?: Extension[];
  modifierExtention?: Extension[];
  sequence?: number;
  text?: string;
  additionalInstruction?: CodeableConcept[];
  patientInstruction?: string;
  timing?: Timing;
  //boolean Indicates whether the Medication is only taken when needed within a specific dosing schedule (Boolean option), or it indicates the precondition for taking the Medication (CodeableConcept).
  asNeededBoolean?: boolean;
  asNeededCodeableConcept?: CodeableConcept;
  site?: CodeableConcept;
  route?: CodeableConcept;
  method?: CodeableConcept;
  doseAndRate?: Dosage_DoseAndRate[];
  maxDosePerPeriod?: Ratio;
  maxDosePerAdministration?: Quantity;
  maxDosePerLifetime?: Quantity;
};

export type AllergyIntollerance_Reaction = {
  substance?: CodeableConcept;
  manifestation?: CodeableConcept[];
  description?: string;
  onset?: dateTime;
  severity?: code;
  exposureRoute?: CodeableConcept;
};

export type Encounter_StatusHistory = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  status?: string | null;
  period: Period;
};

export type Encounter_ClassHistory = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  status?: string | null;
  class: Coding | null;
  period: Period | null;
};

export type Encounter_Participant = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  type?: CodeableConcept[] | null; //Role of participant in encounter
  period: Period | null;
  individual?: Reference; // reference to Practitioner reference
};

export type Encounter_Diagnosis = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  status?: string | null;
  class: Coding | null;
  period: Period | null;
};

export type Encounter_Hospitalization = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  preAdmissionIdentifier?: Identifier | null;
  origin?: Reference | null;
  admitSource?: CodeableConcept | null;
  reAdmission?: CodeableConcept | null;
  dietPreference?: CodeableConcept[] | null;
  specialCourtesy?: CodeableConcept[] | null;
  specialArrangement?: CodeableConcept[] | null;
  destination?: Reference | null;
  dischargeDisposition?: CodeableConcept | null;
};

export type Encounter_Location = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  location?: Reference | null;
  status?: string | null;
  physicalType: CodeableConcept | null;
  period: Period | null;
};

export type backboneElement = {
  function?: CodeableConcept | null;
  actor?: Reference | null;
};

export type Annotation = {
  id?: string;
  extention?: Extension[] | null;
  authorReference?: Reference;
  authorString?: string;
  time?: dateTime;
  text?: markdown | null;
};

export type SampledData = {
  id?: string | null;
  extention?: [] | null;
  origin?: Quantity | null;
  period?: number | null;
  factor?: decimal | null;
  lowerLimit?: decimal | null;
  upperLimit?: decimal | null;
  dimensions?: positiveInt | null;
  data?: string | null;
};

export type ReferenceRange = {
  id?: string;
  extension?: Extension;
  modifierExtension?: Extension;
  low?: Quantity;
  high?: Quantity;
  type?: CodeableConcept;
  appliesTo?: CodeableConcept[];
  age?: Range;
  text?: string;
};

// //A specific set of Roles/Locations/specialties/services that a practitioner may perform at an organization for a period of time.
export interface PractitionerRole {
  resourceType?: ClinicalsResourcesTypes | null;
  id?: string | null;
  meta?: Meta | null;
  implicitRules?: uri;
  language?: code | null;
  text?: Narrative | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  period?: Period | null;
  practitioner?: Reference | null; // Practitioner
  organization?: Reference | null; //Organization
  code?: CodeableConcept[] | null;
  specialty?: CodeableConcept[] | null;
  location?: Reference[] | null; //Location
  healthcareService?: Reference[] | null; //HealthcareService
  telecom?: ContactPoint[] | null;
}

export interface Organization {
  resourceType?: ClinicalsResourcesTypes.Organization | null;
  id?: string | null;
  meta: Meta | null;
  implicitRules?: uri;
  language?: code | null;
  text?: Narrative | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  identifier?: object[] | null;
  active?: boolean | null;
  type?: CodeableConcept[];
  name?: string | null;
  alias?: string[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;

  //Another Location of which this Location is physically a part of.
  partOf?: Reference | null;
  contact?: BackboneElement | null;
  endpoint?: Reference[] | null;
}

export interface Practitioner {
  resourceType?: ClinicalsResourcesTypes.Practitioner | null;
  id?: string | null;
  meta: Meta | null;
  implicitRules?: uri | null;
  language?: code | null;
  text?: Narrative | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  name?: HumanName[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;
  gender?: code;
  birthDate?: date | null;
  photo?: Attachment[] | null;
  qualification?: BackboneElement[] | null;
  communication?: CodeableConcept[];
}

export interface Location {
  resourceType?: ClinicalsResourcesTypes.Location | null;
  id?: string | null;
  meta: Meta | null;
  implicitRules?: uri;
  language?: code;
  text?: Narrative;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  status?: code;
  operationalStatus?: Coding | null;
  name?: string | null;
  alias?: string[] | null;
  description?: string;
  mode?: code;
  type?: CodeableConcept[];
  telecom?: ContactPoint[] | null;
  address?: Address | null;
  physicalType?: CodeableConcept[];
  position?: Location_Position | null;
  managingOrganization?: Reference | null;
  partOf?: Reference | null;
  hoursOfOperation?: Location_HoursOfOperation | null;
  active?: boolean | null;
  availabilityExceptions?: string | null;
}

export interface Patient_Communication {
  language?: CodeableConcept;
  preferred?: boolean | null;
}

export interface Patient {
  resourceType?: ClinicalsResourcesTypes.Patient | null;
  id?: string | null;
  extension?: PatientExtension[];
  identifier?: Identifier[] | null;
  name?: HumanName[] | null;
  telecom?: ContactPoint[] | null;
  gender?: Gender;
  birthDate?: date;
  address?: Address[] | null;
  communication?: Patient_Communication[] | null;
}
export interface MedicationRequest {
  resourceType?: ClinicalsResourcesTypes | null;
  id?: string | null;
  status?: code | null;
  intent?: code | null;
  reportedReference: Reference | null; //FHIR:  Patient | Practitioner | PractitionerRole | RelatedPerson | Organization
  medicationReference: Reference | null; // Medication
  subject?: Reference | null; //Patient | Group
  authoredOn: dateTime;
  requester: Reference | null; // FHIR: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device
  dosageInstruction: Dosage[] | null;
}

export interface Medication {
  resourceType?: ClinicalsResourcesTypes.Medication | null;
  id?: string | null;
  status?: code;
  meta?: Meta | null;
  code?: CodeableConcept | null;
  form?: CodeableConcept | null;
}

export interface AllergyIntolerance {
  resourceType?: ClinicalsResourcesTypes.AllergyIntolerance | null;
  id?: string | null;
  meta?: Meta | null;
  identifier?: Identifier[];
  clinicalStatus?: CodeableConcept | null;
  category?: code[] | null;
  verificationStatus?: CodeableConcept | null;
  type?: string;
  criticality?: code;
  code?: CodeableConcept;
  patient?: Reference | null;
  reaction?: AllergyIntollerance_Reaction[];

  onsetDateTime?: dateTime | null;
  onsetAge?: Age | null;
  onsetPeriod?: Period | null;
  onsetRange?: Range | null;
  onsetString?: string;
}

export interface Condition {
  resourceType?: ClinicalsResourcesTypes.Condition | null;
  id?: string | null;
  meta?: Meta | null;
  identifier?: Identifier[];
  clinicalStatus?: CodeableConcept | null;
  verificationStatus?: CodeableConcept | null;
  category?: CodeableConcept[] | null;
  severity?: CodeableConcept | null;
  code?: CodeableConcept;
  subject?: Reference | null;

  abatementDateTime?: dateTime;
  abatementAge?: Age | null;
  abatementPeriod?: Period | null;
  abatementRange?: Range | null;
  abatementString?: string;

  recordedDate?: dateTime;

  onsetDateTime?: dateTime | null;
  onsetAge?: Age | null;
  onsetPeriod?: Period | null;
  onsetRange?: Range | null;
  onsetString?: string;
}

export interface ImplantableDevice {
  resourceType?: ClinicalsResourcesTypes.ImplantableDevice | null;
  id?: string | null;
  udiCarrier?: udiCarrier[] | null;
  distinctIdentifier?: string | null;
  manufactureDate?: dateTime | null;
  expirationDate?: dateTime | null;
  lotNumber?: string | null;
  serialNumber?: string | null;
  DeviceName?: DeviceName | null;
  ModelNumber?: string | null;
  PartNumber?: string | null;
  type: CodeableConcept | null;
  patient: Reference | null; //Patient to whom Device is affixed
}

export interface Encounter {
  resourceType?: ClinicalsResourcesTypes.Encounter | null;
  id?: string | null;
  meta?: Meta | null;
  implicitRules?: uri | null;
  language?: string | null;
  text?: Narrative | null;
  contained?: Resource[] | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  identifier?: Identifier[] | null;
  status: string;
  statusHistory?: Encounter_StatusHistory[] | null;
  class: Coding | null;
  classHistory?: Encounter_ClassHistory[] | null;
  type?: CodeableConcept[] | null;
  serviceType?: CodeableConcept | null;
  priority?: CodeableConcept | null;
  subject: Reference | null; // Patient
  episodeOfCare?: Reference[] | null; // EpisodeOfCare - specific resource type
  participant?: Encounter_Participant[] | null;
  basedOn?: Reference[] | null; // reference to ServiceRequest
  appointment?: Reference[] | null;
  period?: Period | null;
  length?: Duration | null;

  reasonCode?: CodeableConcept[] | null;

  reasonReference?: Reference[] | null;

  //The list of diagnosis relevant to this encounter.
  diagnosis?: Encounter_Diagnosis[] | null;

  //The set of accounts that may be used for billing for this Encounter.
  account?: Reference[] | null;

  //An interaction between a patient and healthcare provider(s) for the purpose of providing healthcare service(s) or assessing the health status of a patient.
  hospitalization?: Encounter_Hospitalization | null;
  //List of locations where the patient has been during this encounter.
  location?: Encounter_Location[] | null; // Location

  serviceProvider?: Reference | null;
  partOf?: Reference | null;
}

export interface Procedure {
  resourceType?: ClinicalsResourcesTypes.Procedure | null;
  id?: string | null;
  status: code | null;
  code: CodeableConcept | null;
  subject: Reference | null; //Patient
  encounter?: Reference | null; //Encounter (created as part of)
  performedPeriod?: Period | null;
  performedDateTime?: dateTime | null;
}

export interface Immunization {
  resourceType?: ClinicalsResourcesTypes.Immunization | null;
  id?: string | null;
  status: string | null;
  statusReason: CodeableConcept | null;
  vaccineCode: CodeableConcept | null;
  patient: Reference | null;
  encounter: Reference | null;
  occurrenceDateTime?: dateTime;
  occurrenceString?: string;
  primarySource?: boolean;
  manufacturer?: Reference | null;
  lotNumber?: string | null;
  expirationDate?: dateTime;
  site?: CodeableConcept | null;
  route?: CodeableConcept | null;
  doseQuantity?: Quantity | null;
  performer?: backboneElement | null;
  note?: Annotation;
}

export interface Observation {
  resourceType?: ClinicalsResourcesTypes.Observation | null;
  id?: string | null;
  status?: code | null;
  category?: CodeableConcept[] | null;
  code?: CodeableConcept | null;
  subject?: Reference | null;
  effectiveDateTime?: string | null;
  effectivePeriod?: Period | null;
  valueQuantity?: Quantity | null;
  valueCodeableConcept?: CodeableConcept | null;
  valueString?: string | null;
  valueBoolean?: boolean;
  valueInteger?: number;
  valueRange?: Range;
  valueRatio?: Ratio;
  valueSampledData?: SampledData;
  valueTime?: string;
  valueDateTime?: string;
  valuePeriod?: Period;
  referenceRange?: ReferenceRange[];
  issued?: string;

  dataAbsentReason?: CodeableConcept | null;

  encounter: Reference | null;
}
