//////////////---------ENUMS
export enum ContainedResourcesTypes {
  Patient = "Patient",
  Practitioner = "Practitioner",
  Location = "Location",
  Coverage = "Coverage",
  Organization = "Organization",
  ExplanationOfBenefit = "ExplanationOfBenefit",
}

export enum CareTeamRoles {
  Performing = "performing",
  Prescribing = "prescribing",
}

export enum NameUse {
  Usual = "usual",
  Official = "official",
  Temp = "temp",
  Nickname = "nickname",
  Anonymous = "anonymous",
  Old = "old",
  Maiden = "maiden",
}

export enum ContactPointSystem {
  Phone = "phone",
  Fax = "fax",
  Email = "email",
  Pager = "pager",
  Url = "url",
  Sms = "sms",
  Other = "other",
}

export enum AddressUse {
  Home = "home",
  Work = "work",
  Temp = "temp",
  Old = "old",
  Billing = "billing",
}

export enum AddressType {
  Postal = "postal",
  Physical = "physical",
  Both = "both",
}

export enum IdentifierCodeType {
  HDC_RECORD_UUID = "HDC_RECORD_UUID",
}

//The units of time for the duration, in UCUM units.
export enum durationUnit {
  s = "s",
  min = "min",
  h = "h",
  d = "d",
  wk = "wk",
  mo = "mo",
  a = "a",
}

export enum Gender {
  male = "male",
  female = "female",
  other = "other",
  unknown = "unknown",
}

export enum ComparatorOptions {
  less = "<",
  lessOrEqual = "<=",
  greaterOrEqual = ">=",
  greater = ">",
}
//////////------------TYPES

//A string which has at least one character and no leading or trailing whitespace and where there is no whitespace other than single spaces in the contents
export type code = string | null;

//String of characters used to identify a name or a resource
export type uri = string | null;

//A date or partial date (e.g. just year or year + month). There is no time zone. The format is a union of the schema types gYear, gYearMonth and date. Dates SHALL be valid dates.
export type date = string | null;

//A date, date-time or partial date (e.g. just year or year + month). If hours and minutes are specified, a time zone SHALL be populated. The format is a union of the schema types gYear, gYearMonth, date and dateTime. Seconds must be provided due to schema type constraints but may be zero-filled and may be ignored. Dates SHALL be valid dates.
export type dateTime = string | null;

//A time during the day, in the format hh:mm:ss. There is no date specified. Seconds must be provided due to schema type constraints but may be zero-filled and may be ignored at receiver discretion. The time "24:00" SHALL NOT be used. A time zone SHALL NOT be present. Times can be converted to a Duration since midnight
export type time = string;

export type base64Binary = string;

export type id = string; //pattern: ^[A-Za-z0-9\-\.]{1,64}$

export type decimal = number;

export type positiveInt = number;

export type unsignedInt = number;

export type instant = string | null;

export type xhtml = string;

//pattern: ^[ \r\n\t\S]+$
//A string that may contain Github Flavored Markdown syntax for optional processing by a mark down presentation engine
export type markdown = string;

export type Bundle_Link = {
  relation?: string | null;
  url?: uri;
};

export type Bundle_Entry = {
  resource?: Resource;
};

export type Bundle = {
  id?: string | null;
  meta?: Meta | null;
  type?: object | null;
  total?: unsignedInt | null;
  link?: Bundle_Link | null;
  entry?: Bundle_Entry[];
};

export type Extension = object;

export type Meta = {
  id?: string;
  extention?: Extension[];
  versionId?: id | null;
  lastUpdated?: instant;
  source?: uri;
  profile?: object[] | null;
  security?: Coding[] | null;
  tag?: Coding[];
};

export type Resource = {
  resourceType?: string;
  id?: id;
  meta?: Meta;
  implicitRules?: uri;
  language?: code;
};

export type Coding = {
  system?: string | null;
  version?: string | null;
  code: code | null;
  display?: string | null;
  userSelected?: boolean | null;
};

export type CodeableConcept = {
  id?: string | null;
  extention?: Extension[] | null;
  coding: Coding[];
  text?: string | null;
};

//Base definition for all elements in a resource.
export type BackboneElement = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  purpose?: CodeableConcept | null;
  name: HumanName;
  telecom?: ContactPoint[] | null;
  address?: Address | null;
};

export type Location_Position = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  longitude?: decimal | null;
  latitude?: decimal | null;
  altitude?: decimal | null;
};

export type Location_HoursOfOperation = {
  id?: string | null;
  extension?: Extension[] | null;
  modifierExtension?: Extension[] | null;
  daysOfWeek?: code[] | null;
  allDay?: boolean | null;
  openingTime?: time | null;
  closingTime?: time | null;
};

export type Attachment = {
  id?: string | null;
  extension?: object[] | null;
  contentType?: code | null;
  language?: code | null;
  data?: base64Binary | null;
  url?: uri;
  size?: unsignedInt | null;
  hash?: base64Binary | null;
  title?: string | null;
  creation?: dateTime | null;
};

export type Narrative = {
  id?: string | null;
  extension?: object[] | null;
  status?: object | null;
  div: xhtml | null;
};

export type Range = {
  id?: string;
  extension?: Extension[];
  low?: Quantity;
  high?: Quantity;
};

export type Duration = {
  id?: string;
  extension?: Extension[];
  value?: number;
  comparator?: string;
  unit?: string;
  system?: uri;
  code?: code;
};

export type Timing_Repeat = {
  id?: string;
  extension?: Extension[];
  modifierExtension?: Extension[];
  hoursDuration?: Duration;
  hoursRange?: Range;
  boundsPeriod?: Period;
  count?: number;
  countMax?: number;
  duration?: number;
  durationMax?: number;
  durationUnit?: durationUnit;
  frequency?: number;
  frequencyMax?: number;
  period?: number;
  periodMax?: number;
  periodUnit?: durationUnit;
  dayOfWeek?: code[];
  timeOfDay?: time[];
  when: time[];
  offset?: number;
  code?: CodeableConcept;
};

export type Timing = {
  id?: string;
  extension?: Extension[];
  modifierExtension?: Extension[];
  event?: dateTime[];
  repeat?: Timing_Repeat;
  code?: CodeableConcept;
};

export type Ratio = {
  id?: string;
  extension?: Extension[];
  numerator?: Quantity;
  denominator?: Quantity;
};

export type availableContent = {
  url?: uri | null;
  value?: code | null;
};

export type AvailableTime = {
  daysOfWeek?: availableContent[] | null;
  allDay?: availableContent | null;
  availableStartTime?: availableContent | null;
  availableEndTime?: availableContent | null;
  uri?: uri | null;
};

export type Period = {
  id?: string | null;
  extention?: Extension[] | null;
  start?: dateTime;
  end?: dateTime;
};

export type Address = {
  id?: string | null;
  extention?: Extension[] | null;
  use?: string | null;
  type?: string | null;
  text?: string | null;
  // This component contains the house number, apartment number, street name, street direction, P.O. Box number, delivery hints, and similar address information.
  line?: string[] | null;
  city?: string | null;
  district?: string | null;
  state?: string | null;
  postalCode?: string | null;
  country?: string | null;
  period?: Period | null;
};

export type Money = {
  value?: decimal | null;
  currency?: code | null;
};

export type Reference = {
  id?: string | null;
  extention?: Extension[] | null;
  reference: string;
  type?: uri | null;
  identifier?: [] | object | null;
  display?: string | null;
};

export type Identifier = {
  id?: string | null;
  extention?: object[] | null;
  use?: string | null;
  type?: CodeableConcept | null;
  system?: string | null;
  value?: string | null;
  period?: Period | null;
  assigner?: Reference | null;
};

export type Quantity = {
  value?: number | null;
  comparator?: string | null;
  unit?: string | null;
  system?: uri | null;
  code?: code | null;
};

export type HumanName = {
  id?: string | null;
  extension: object[] | null;
  use?: code | null;
  text?: string | null;
  family?: string | null;
  given?: string[] | null;
  prefix?: string[] | null;
  suffix?: string[] | null;
  period?: Period | null;
};

export type Qualification = {
  id?: id | null;
  extention?: Extension | null;
  identifier?: Identifier | null;
  period?: Period | null;
  issuer?: Reference | null;
  code: code;
  uri?: uri;
};

export type ContactPoint = {
  system?: code | null; //phone | fax | email | pager | url | sms | other
  value?: string | null; //The actual contact point details
  use?: code | null; //home | work | temp | old | mobile - purpose of this contact point
  rank?: number; // Positive int, Specify preferred order of use (1 = highest)
  period?: Period | null;
};

export type ContainedReference =
  | ContainedResource_Patient
  | ContainedResource_Practitioner
  | ContainedResource_Location
  | ContainedResource_Coverage
  | ContainedResource_Organization;

export type ContainedResource_Patient = {
  resourceType: ContainedResourcesTypes;
  id: id;
  identifier?: Identifier[] | null;
  name?: HumanName[] | null;
  telecom?: ContactPoint[] | null;
  gender?: code | null;
  birthDate?: date | null;
  deceasedBoolean?: boolean | null;
  deceasedDateTime?: dateTime | null;
  address?: Address[] | null;
  maritalStatus?: CodeableConcept | null;
  communication?: {
    language?: CodeableConcept | null;
    preffered?: boolean | null;
  }[];
  extension?: Extension | null;
};

export type ContainedResource_Practitioner = {
  resourceType: ContainedResourcesTypes;
  id: id;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  name?: HumanName[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;
  gender?: code | null;
  birthDate?: date | null;
  qualification?: Qualification | null;
  communication?: CodeableConcept[] | null;
};

export type ContainedResource_Organization = {
  resourceType: ContainedResourcesTypes;
  id: id;
  identifier?: Identifier[] | null;
  active?: boolean | null;
  type?: CodeableConcept[] | null;
  name?: string | null;
  alias?: string[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address[] | null;
  partOf?: Reference | null;
  contact?: {
    purpose?: CodeableConcept | null;
    name?: HumanName | null;
    telecom?: ContactPoint[];
    address?: Address | null;
  }[];
  endPoint?: Reference[] | null;
};

export type ContainedResource_Location = {
  resourceType: ContainedResourcesTypes;
  id: id;
  identifier?: Identifier[] | null;
  status?: code | null;
  operationalStatus?: Coding | null;
  name?: string | null;
  alias?: string[] | null;
  description?: string | null;
  mode?: code | null;
  type?: CodeableConcept[] | null;
  telecom?: ContactPoint[] | null;
  address?: Address | null;
  physicalType?: CodeableConcept | null;
  position?: {
    longitude?: decimal | null;
    latitude?: decimal | null;
    altitude?: decimal | null;
  };
  managingOrganization?: Reference | null;

  partOf?: Reference;
  hoursOfOperation?:
    | {
        daysOfWeek?: code | null; //mon | tue | wed | thu | fri | sat | sun
        allDay?: boolean | null;
        openingTime?: time | null;
        closingTime?: time | null;
      }[]
    | null;
  availabilityExceptions?: string | null;
  endPoint?: Reference[] | null;
};

export type ContainedResource_Coverage = {
  resourceType: ContainedResourcesTypes;
  id: id;
  identifier?: Identifier[] | null;
  status?: code | null;
  type?: CodeableConcept[] | null;
  policyHolder?: Reference | null;
  subscriber?: Reference | null;
  subscriberId?: string | null;
  beneficiary?: Reference | null;
  dependent?: string | null;
  relationship?: CodeableConcept | null;
  period?: Period | null;
  payor?: Reference[] | null;
  class?: {
    type?: CodeableConcept | null;
    value?: string | null;
    name?: string | null;
  }[];
  order?: positiveInt | null;
  network?: string | null;
  costToBeneficiary?: {
    type?: CodeableConcept | null;
    valueMoney?: Money | null;
    exception?: { type?: CodeableConcept | null; period?: Period | null }[];
  }[];
  subrogation?: boolean | null;
  contract?: Reference | null;
};

export type Age = {
  id?: string | null;
  extension?: Extension[];
  value?: decimal;
  comparator?: ComparatorOptions;
  unit?: string;
  system?: uri;
  code?: code;
};
///  Types for Internal Use

export type CalculatedAmount = {
  amount: Money | null | undefined;
  isComplete: boolean;
  isContainUnknownCurrency: boolean;
};

export enum CurrencyCodes {
  AED = "AED", //	United Arab Emirates dirham
  AFN = "AFN", //	Afghan afghani
  ALL = "ALL", //	Albanian lek
  AMD = "AMD", //	Armenian dram
  ANG = "ANG", //	Netherlands Antillean guilder
  AOA = "AOA", //	Angolan kwanza
  ARS = "ARS", //	Argentine peso
  AUD = "AUD", //	Australian dollar
  AWG = "AWG", //	Aruban florin
  AZN = "AZN", //	Azerbaijani manat
  BAM = "BAM", //	Bosnia and Herzegovina convertible mark
  BBD = "BBD", //	Barbados dollar
  BDT = "BDT", //	Bangladeshi taka
  BGN = "BGN", //	Bulgarian lev
  BHD = "BHD", //	Bahraini dinar
  BIF = "BIF", //	Burundian franc
  BMD = "BMD", //	Bermudian dollar
  BND = "BND", //	Brunei dollar
  BOB = "BOB", //	Boliviano
  BOV = "BOV", //	Bolivian Mvdol (funds code)
  BRL = "BRL", //	Brazilian real
  BSD = "BSD", //	Bahamian dollar
  BTN = "BTN", //	Bhutanese ngultrum
  BWP = "BWP", //	Botswana pula
  BYN = "BYN", //	Belarusian ruble
  BZD = "BZD", //	Belize dollar
  CAD = "CAD", //	Canadian dollar
  CDF = "CDF", //	Congolese franc
  CHE = "CHE", //	WIR Euro (complementary currency)
  CHF = "CHF", //	Swiss franc
  CHW = "CHW", //	WIR Franc (complementary currency)
  CLF = "CLF", //	Unidad de Fomento (funds code)
  CLP = "CLP", //	Chilean peso
  CNY = "CNY", //	Renminbi (Chinese) yuan[8]
  COP = "COP", //	Colombian peso
  COU = "COU", //	Unidad de Valor Real (UVR) (funds code)[9]
  CRC = "CRC", //	Costa Rican colon
  CUC = "CUC", //	Cuban convertible peso
  CUP = "CUP", //	Cuban peso
  CVE = "CVE", //	Cape Verde escudo
  CZK = "CZK", //	Czech koruna
  DJF = "DJF", //	Djiboutian franc
  DKK = "DKK", //	Danish krone
  DOP = "DOP", //	Dominican peso
  DZD = "DZD", //	Algerian dinar
  EGP = "EGP", //	Egyptian pound
  ERN = "ERN", //	Eritrean nakfa
  ETB = "ETB", //	Ethiopian birr
  EUR = "EUR", //	Euro
  FJD = "FJD", //	Fiji dollar
  FKP = "FKP", //	Falkland Islands pound
  GBP = "GBP", //	Pound sterling
  GEL = "GEL", //	Georgian lari
  GGP = "GGP", //	Guernsey Pound
  GHS = "GHS", //	Ghanaian cedi
  GIP = "GIP", //	Gibraltar pound
  GMD = "GMD", //	Gambian dalasi
  GNF = "GNF", //	Guinean franc
  GTQ = "GTQ", //	Guatemalan quetzal
  GYD = "GYD", //	Guyanese dollar
  HKD = "HKD", //	Hong Kong dollar
  HNL = "HNL", //	Honduran lempira
  HRK = "HRK", //	Croatian kuna
  HTG = "HTG", //	Haitian gourde
  HUF = "HUF", //	Hungarian forint
  IDR = "IDR", //	Indonesian rupiah
  ILS = "ILS", //	Israeli new shekel
  IMP = "IMP", //	Isle of Man Pound
  INR = "INR", //	Indian rupee
  IQD = "IQD", //	Iraqi dinar
  IRR = "IRR", //	Iranian rial
  ISK = "ISK", //	Icelandic króna
  JEP = "JEP", //	Jersey Pound
  JMD = "JMD", //	Jamaican dollar
  JOD = "JOD", //	Jordanian dinar
  JPY = "JPY", //	Japanese yen
  KES = "KES", //	Kenyan shilling
  KGS = "KGS", //	Kyrgyzstani som
  KHR = "KHR", //	Cambodian riel
  KMF = "KMF", //	Comoro franc
  KPW = "KPW", //	North Korean won
  KRW = "KRW", //	South Korean won
  KWD = "KWD", //	Kuwaiti dinar
  KYD = "KYD", //	Cayman Islands dollar
  KZT = "KZT", //	Kazakhstani tenge
  LAK = "LAK", //	Lao kip
  LBP = "LBP", //	Lebanese pound
  LKR = "LKR", //	Sri Lankan rupee
  LRD = "LRD", //	Liberian dollar
  LSL = "LSL", //	Lesotho loti
  LYD = "LYD", //	Libyan dinar
  MAD = "MAD", //	Moroccan dirham
  MDL = "MDL", //	Moldovan leu
  MGA = "MGA", //	Malagasy ariary
  MKD = "MKD", //	Macedonian denar
  MMK = "MMK", //	Myanmar kyat
  MNT = "MNT", //	Mongolian tögrög
  MOP = "MOP", //	Macanese pataca
  MRU = "MRU", //	Mauritanian ouguiya
  MUR = "MUR", //	Mauritian rupee
  MVR = "MVR", //	Maldivian rufiyaa
  MWK = "MWK", //	Malawian kwacha
  MXN = "MXN", //	Mexican peso
  MXV = "MXV", //	Mexican Unidad de Inversion (UDI) (funds code)
  MYR = "MYR", //	Malaysian ringgit
  MZN = "MZN", //	Mozambican metical
  NAD = "NAD", //	Namibian dollar
  NGN = "NGN", //	Nigerian naira
  NIO = "NIO", //	Nicaraguan córdoba
  NOK = "NOK", //	Norwegian krone
  NPR = "NPR", //	Nepalese rupee
  NZD = "NZD", //	New Zealand dollar
  OMR = "OMR", //	Omani rial
  PAB = "PAB", //	Panamanian balboa
  PEN = "PEN", //	Peruvian Sol
  PGK = "PGK", //	Papua New Guinean kina
  PHP = "PHP", //	Philippine piso[13]
  PKR = "PKR", //	Pakistani rupee
  PLN = "PLN", //	Polish złoty
  PYG = "PYG", //	Paraguayan guaraní
  QAR = "QAR", //	Qatari riyal
  RON = "RON", //	Romanian leu
  RSD = "RSD", //	Serbian dinar
  RUB = "RUB", //	Russian ruble
  RWF = "RWF", //	Rwandan franc
  SAR = "SAR", //	Saudi riyal
  SBD = "SBD", //	Solomon Islands dollar
  SCR = "SCR", //	Seychelles rupee
  SDG = "SDG", //	Sudanese pound
  SEK = "SEK", //	Swedish krona/kronor
  SGD = "SGD", //	Singapore dollar
  SHP = "SHP", //	Saint Helena pound
  SLL = "SLL", //	Sierra Leonean leone
  SOS = "SOS", //	Somali shilling
  SRD = "SRD", //	Surinamese dollar
  SSP = "SSP", //	South Sudanese pound
  STN = "STN", //	São Tomé and Príncipe dobra
  SVC = "SVC", //	Salvadoran colón
  SYP = "SYP", //	Syrian pound
  SZL = "SZL", //	Swazi lilangeni
  THB = "THB", //	Thai baht
  TJS = "TJS", //	Tajikistani somoni
  TMT = "TMT", //	Turkmenistan manat
  TND = "TND", //	Tunisian dinar
  TOP = "TOP", //	Tongan paʻanga
  TRY = "TRY", //	Turkish lira
  TTD = "TTD", //	Trinidad and Tobago dollar
  TVD = "TVD", //	Tuvalu Dollar
  TWD = "TWD", //	New Taiwan dollar
  TZS = "TZS", //	Tanzanian shilling
  UAH = "UAH", //	Ukrainian hryvnia
  UGX = "UGX", //	Ugandan shilling
  USD = "USD", //	United States dollar
  USN = "USN", //	United States dollar (next day) (funds code)
  UYI = "UYI", //	Uruguay Peso en Unidades Indexadas (URUIURUI) (funds code)
  UYU = "UYU", //	Uruguayan peso
  UZS = "UZS", //	Uzbekistan som
  VEF = "VEF", //	Venezuelan bolívar
  VND = "VND", //	Vietnamese đồng
  VUV = "VUV", //	Vanuatu vatu
  WST = "WST", //	Samoan tala
  XAF = "XAF", //	CFA franc BEAC
  XAG = "XAG", //	Silver (one troy ounce)
  XAU = "XAU", //	Gold (one troy ounce)
  XBA = "XBA", //	European Composite Unit (EURCO) (bond market unit)
  XBB = "XBB", //	European Monetary Unit (E.M.U.-6) (bond market unit)
  XBC = "XBC", //	European Unit of Account 9 (E.U.A.-9) (bond market unit)
  XBD = "XBD", //	European Unit of Account 17 (E.U.A.-17) (bond market unit)
  XCD = "XCD", //	East Caribbean dollar
  XDR = "XDR", //	Special drawing rights
  XOF = "XOF", //	CFA franc BCEAO
  XPD = "XPD", //	Palladium (one troy ounce)
  XPF = "XPF", //	CFP franc (franc Pacifique)
  XPT = "XPT", //	Platinum (one troy ounce)
  XSU = "XSU", //	SUCRE
  XTS = "XTS", //	Code reserved for testing purposes
  XUA = "XUA", //	ADB Unit of Account
  XXX = "XXX", //	No currency
  YER = "YER", //	Yemeni rial
  ZAR = "ZAR", //	South African rand
  ZMW = "ZMW", //	Zambian kwacha
  ZWL = "ZWL", //	Zimbabwean dollar A/10
}
