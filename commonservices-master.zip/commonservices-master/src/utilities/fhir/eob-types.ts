import { code, date, unsignedInt, CodeableConcept, Identifier, Period, Reference, Address, Quantity, Money, ContainedReference, positiveInt, dateTime, decimal } from './types';

/// ---------- ENUMS
export enum TotalsAmountCategories {
  Patient_Pay_Amount = 'patientpayamount',
  Submitted_Amount = 'submittedamount',
  Payment_Amount = 'paymentamount',
  Eligible = 'eligible'
  //submittedamount, allowedamount, deductibleamount, coinsuranceamount, copayamount, noncoveredamount, cobamount, paymentamount, patientpayamount - from XSD (currently not used)
}

export enum AdjudicationCategories {
  Member_Liability = 'memberliability',
  Copay = 'copay',
  Submitted = 'submitted',
  Benefit = 'benefit',
  Eligible = 'eligible'
}

/// ------------ TYPES

export type eobBundleEntry = {
  resource: EOB | ContainedReference;
  search?: object;
};

export type EOBPayee = {
  type: CodeableConcept | null;
  party: Reference | null; //Referenced to ContainedResource_Practitioner or ContainedResource_Patient or ContainedResource_Organization
};

export type EOBCareTeam = {
  sequence?: positiveInt | null;
  provider?: Reference | null; // Referenced to ContainedResource_Practitioner or ContainedResource_Organization
  responsible?: boolean | null;
  role: CodeableConcept | null;
  qualification?: CodeableConcept | null;
};
export type EOBDiagnosis = {
  sequence?: positiveInt | null;
  diagnosisCodeableConcept?: CodeableConcept | null;
  type?: CodeableConcept[];
};
export type EOBProcedure = {
  sequence?: positiveInt;
  type?: CodeableConcept[] | null;
  date?: dateTime;
  procedureCodeableConcept?: CodeableConcept | null;
};
export type EOBInsurance = {
  focal?: boolean | null;
  coverage?: Reference | null;
  preAuthRef?: string[] | null;
};

export type EOBAdjudication = {
  category?: CodeableConcept | null;
  reason?: CodeableConcept | null;
  amount?: Money | null;
  value?: decimal | null;
};

export type EOBTotal = {
  category?: CodeableConcept | null;
  amount?: Money | null;
};

export type EOBPayment = {
  identifier?: Identifier | null;
  type?: CodeableConcept | null;
  adjustment?: Money | null;
  adjustmentReason?: CodeableConcept | null;
  date?: date;
  amount?: Money | null;
};

export type EOBProcessNote = {
  number?: positiveInt | null;
  type?: code | null;
  text?: string | null;
  language?: CodeableConcept | null;
};

export type EOBItem = {
  sequence?: positiveInt | null;
  careTeamSequence?: number[] | null;
  diagnosisSequence?: number[] | null;
  procedureSequence?: number[] | null;
  servicedDate?: string | null;
  servicedPeriod?: Period | null;
  locationCodeableConcept?: CodeableConcept | null;
  locationAddress?: Address | null;
  quantity?: Quantity | null;
  unitPrice?: Money | null;
  net?: Money | null;
  adjudication?: EOBAdjudication[] | null;
  productOrService?: CodeableConcept | null;
};

export type EOBBenefitBalance = {
  category?: CodeableConcept | null;
  excluded?: boolean | null;
  name?: string | null;
  description?: string | null;
  network?: CodeableConcept | null;
  unit?: CodeableConcept | null;
  term?: CodeableConcept | null;
  financial?:
    | {
        type?: CodeableConcept | null;
        allowedUnsignedInt?: unsignedInt | null;
        allowedString?: string | null;
        allowedMoney?: Money | null;
        usedUnsignedInt?: unsignedInt | null;
        usedMoney?: Money | null;
      }[]
    | null;
};

export interface EOB {
  id: string;
  resourceType: string;
  identifier?: Identifier[] | null;
  contained?: ContainedReference[] | null;
  status?: string | null;
  type: CodeableConcept | null;
  use?: code;
  patient: Reference | null; // Referenced to ContainedResource_Patient
  billablePeriod?: Period | null;
  created?: dateTime;
  insurer?: Reference | null; // Referenced to ContainedResource_Organization
  provider: Reference | null; // Referenced to ContainedResource_Practitioner or ContainedResource_Organization
  outcome?: code | null;
  //Reference from the Insurer which is used in later communications which refers to this adjudication.
  preAuthRef?: string[] | null;
  preAuthRefPeriod?: Period[] | null;
  precedence?: number | null;
  processNote?: EOBProcessNote[] | null;
  benefitPeriod?: Period | null;
  benefitBalance?: EOBBenefitBalance | null;
  payee?: EOBPayee | null;
  facility?: Reference | null;
  disposition?: string | null;
  careTeam?: EOBCareTeam[] | null;
  diagnosis?: EOBDiagnosis[] | null;
  procedure?: EOBProcedure[] | null;
  insurance?: EOBInsurance[] | null;
  item?: EOBItem[] | null;
  adjudication?: EOBAdjudication[] | null;
  total?: EOBTotal[] | null;
  payment?: EOBPayment | null;
}

export const emptyEOB: EOB = {
  id: '',
  resourceType: '',
  identifier: null,
  contained: null,
  status: null,
  type: null,
  use: '',
  patient: null,
  billablePeriod: null,
  created: '',
  insurer: null,
  provider: null,
  outcome: '',
  //Reference from the Insurer which is used in later communications which refers to this adjudication.
  preAuthRef: null,
  preAuthRefPeriod: null,
  precedence: null,
  benefitPeriod: null,
  payee: null,
  facility: null,
  disposition: null,
  careTeam: null,
  diagnosis: null,
  procedure: null,
  insurance: null,
  item: null,
  adjudication: null,
  total: null,
  payment: null
};

//Internal Use

export type ServicesItem = {
  sortByDate: string | null | undefined;
  name: string | null;
  date: string | null;
  memberPrice: Money | null | undefined;
  insurancePaid: Money | null | undefined;
  estimatedBalance: Money | null | undefined;
};
