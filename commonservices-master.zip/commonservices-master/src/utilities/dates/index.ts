import moment from 'moment';
import { Money } from '../fhir/types';

export enum SortTypes {
  Ascending,
  Descending
}

export const FULL_DATE_FORMAT = 'MMMM DD, YYYY';
export const MONTH3L_DATE_FORMAT = 'MMM DD, YYYY';
export const SHORT_DATE_FORMAT = 'M/D/YYYY';

export const INVALID_DATE = 'Invalid Date';

export const isNowDateBetween = (start, end, format) => {
  if (start) {
    const momentStart = moment(start, format);

    if (momentStart.isValid() && momentStart.isAfter(moment())) {
      return false;
    }
  }
  if (end) {
    const momentEnd = moment(end, format);

    if (momentEnd.isValid() && momentEnd.isBefore(moment())) {
      return false;
    }
  }
  return true;
};

export const isValidDate = (date: Date | string | number | undefined | null, supportDateFormat = ALLOWED_DATE_FORMATS) => !!date && isValidDateFormat(date, supportDateFormat);

export const formatDate = (date: string | number | undefined | null, dateFormat: string = FULL_DATE_FORMAT, includeUTC: boolean = false) => {
  try {
    if (!date || !isValidDate(date, [dateFormat])) return INVALID_DATE;

    const momentDate = includeUTC ? moment(new Date(date)) : moment(date, 'YYYY-MM-DD');
    return momentDate.format(dateFormat);
  } catch (err) {
    console.log('Error in formatDate function ', err);
    return null;
  }
};

export const getDateFromDateTime = (dateTimeParameter: string | null | undefined) => {
  //the string come in format of 2020-06-20T21:55:03 remove time part from the dateTime.
  let datePart = dateTimeParameter?.split('T') && dateTimeParameter?.split('T').length > 0 ? dateTimeParameter?.split('T')[0] : dateTimeParameter;
  return datePart;
};

export const sortByDate = (a: string | null | undefined, b: string | null | undefined, sortType: SortTypes = SortTypes.Ascending) => {
  const returnValue = sortType === SortTypes.Ascending ? 1 : -1;

  //the string come in format of 2020-06-20T21:55:03 remove time part from the dateTime.
  a = getDateFromDateTime(a);
  b = getDateFromDateTime(b);

  const aDate = !a || !isValidDate(a) ? null : a;
  const bDate = !b || !isValidDate(b) ? null : b;

  if (aDate === bDate) return 0;
  else if (!aDate) return 1;
  else if (!bDate) return -1;
  return new Date(aDate).getTime() < new Date(bDate).getTime() ? -1 * returnValue : returnValue;
};

export const sortByMemberPrice = (a: Money | null | undefined, b: Money | null | undefined, sortType: SortTypes = SortTypes.Ascending) => {
  const returnValue = sortType === SortTypes.Ascending ? 1 : -1;

  const aValue = a?.value;
  const bValue = b?.value;

  if (aValue === bValue) return 0;
  else if (!aValue) return 1;
  else if (!bValue) return -1;
  return aValue < bValue ? -1 * returnValue : returnValue;
};

const ALLOWED_DATE_FORMATS = ['YYYY-MM-DD', moment.ISO_8601, 'MMMM DD, YYYY'];
const isValidDateFormat = (date: string | number | Date, supportDateFormat: any = ALLOWED_DATE_FORMATS) => moment(date, [...ALLOWED_DATE_FORMATS, ...supportDateFormat], true).isValid();

export const getDateDiffInHoursFromNow = (toDate: string) => {
  let now = moment(new Date());
  let date = moment(toDate);
  let duration = moment.duration(now.diff(date));
  return duration.asHours();
};
