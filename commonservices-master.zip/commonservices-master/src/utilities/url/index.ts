export const constractUri = (url: string, queryParamsObject: object) => {
  const query = Object.keys(queryParamsObject)
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(queryParamsObject[k])}`)
    .join('&');
  return `${url}?${query}`;
};
