import 'core-js/features/object/assign';
import { DEFAULT_OPTIONS, INVALID_NAMESPACE, INVALID_STORAGE, DefalutOptionsInterface } from './modules/constants';
import { iterateStorage } from './modules/helpers';
import { isValidStorage, isValidString, serialize, deserialize } from './modules/utilities';

class WebStorageManager {
  config: { storage: any; namespace: string; created: Date } | null;

  // set access to storage
  storage: Storage | null;

  // set namespace prefix
  namespace: string | null;

  constructor(options: DefalutOptionsInterface | object = {}) {
    this.config = null;
    this.storage = null;
    this.namespace = null;
    this.configure(options);
  }

  /**
   * Configures the store instance
   * @param {Object} options
   */
  configure(options: DefalutOptionsInterface | object) {
    // merge options
    options = { ...DEFAULT_OPTIONS, ...options };

    // validate configuration options
    const { storage, namespace } = options as DefalutOptionsInterface;

    if (storage === null) {
      return console.log('reference to a supported storage type was null');
    }

    if (!isValidStorage(storage)) {
      throw new Error(INVALID_STORAGE);
    }

    if (!isValidString(namespace)) {
      throw new Error(INVALID_NAMESPACE);
    }

    // save current configuration properties
    this.config = { storage, namespace: namespace.trim(), created: new Date() };

    // set access to storage
    this.storage = storage;

    // set namespace prefix
    this.namespace = `${namespace.trim()}.`;

    return this;
  }

  // PRIVATE METHODS
  _getNamespacedKey(key: string) {
    return `${this.namespace}${key.trim()}`;
  }

  _getOriginalKey(namespacedKey: string) {
    if (!this.namespace) return namespacedKey;
    return namespacedKey.replace(this.namespace, '');
  }

  _getKeys(namespaced = false) {
    const keys: any[] = [];
    const callback = (key: string) => keys.push(key);
    this.iterator(callback, namespaced);

    return keys;
  }

  _removeKeys() {
    const namespaced = true;
    this._getKeys(namespaced).forEach(key => {
      try {
        this.storage?.removeItem(key);
      } catch (err) {}
    });
  }

  // PUBLIC API

  /**
   * Applies the given function to each member
   * @param {Function} callback
   * @param {Boolean} namespaced Whether the key should include the namespace. Defaults to false
   */
  iterator(callback: (_key: string, value: any) => void, namespaced: boolean = false) {
    iterateStorage(this, (key: string, value: any) => {
      const _key = namespaced ? key : this._getOriginalKey(key);
      return callback(_key, value);
    });
  }

  /**
   * Inserts or updates key with the provided value
   * @param {string} key
   * @param {Object | string | number | null } value
   */
  add(key: string, value: any): void {
    const namespacedKey = this._getNamespacedKey(key);
    const val = serialize(value) as string;

    try {
      this.storage?.setItem(namespacedKey, val);
    } catch (err) {}
  }

  /**
   * Inserts key with the provided value when key does not already exist
   * @param {string} key
   * @param {Object | string | number | null } value
   */
  addIfNotPresent(key: string, value: any) {
    if (!this.getValue(key)) {
      this.add(key, value);
      return true;
    }

    return false;
  }

  /**
   * Returns key for given index, or null
   * @param {number} index
   */
  getKey(index: number) {
    let key: string | null | undefined;
    try {
      key = this.storage?.key(index);
    } catch (err) {}

    if (key) {
      return this._getOriginalKey(key);
    }

    return key;
  }

  /**
   * Returns the value for the given key, or null when not found
   * @param {string} key
   */
  getValue(key: string) {
    const namespacedKey = this._getNamespacedKey(key);
    let value: any;
    try {
      value = this.storage?.getItem(namespacedKey);
    } catch (err) {}

    return deserialize(value);
  }

  /**
   * Returns all data stored in the current namespace as a list of key/value pairs
   */
  getData() {
    const data: any[] = [];
    const callback = (key: string, value: any) => data.push({ key, value });
    this.iterator(callback);

    return data;
  }

  /**
   * Removes value for given key stored in the current namespace
   * @param {string} key
   */
  remove(key: string) {
    const namespacedKey = this._getNamespacedKey(key);

    try {
      this.storage?.removeItem(namespacedKey);
    } catch (err) {}
  }

  /**
   * Removes all keys and values stored in the current namespace
   */
  clear() {
    this._removeKeys();
  }

  /**
   * Returns list of keys stored in the current namespace
   */
  keys() {
    return this._getKeys();
  }

  /**
   * Returns the total number of objects stored in the current namespace
   */
  size() {
    return this.keys().length;
  }
}

const instance = new WebStorageManager({ storage: navigator.cookieEnabled ? sessionStorage : null });

export default instance;
export { WebStorageManager };
