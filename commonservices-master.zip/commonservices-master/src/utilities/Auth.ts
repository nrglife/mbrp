import jwtDecode from 'jwt-decode';
import { POSSIBLE_RANDOM_STRING } from '../stores/constants/auth';

export const generateRandomNonce: (length: number) => string = (length: number) => {
  var text = '';
  for (var i = 0; i < length; i++) {
    text += POSSIBLE_RANDOM_STRING.charAt(Math.floor(Math.random() * POSSIBLE_RANDOM_STRING.length));
  }
  return text;
};

export const tokenDecoder = (token?: string) => {
  try {
    if (!token) return null;
    const decoded: ID_TOKEN_TYPE = jwtDecode(token);
    return decoded;
  } catch (err) {
    return null;
  }
};

export type APPS = {
  cmdbid: string;
  id: string;
  name: string;
  uri: string;
  client_id: string;
};

export type COMPANY = {
  name: string;
  id: string;
};

export type PHONE_NUMBERES = {
  number: string;
  type: string;
};

export type ADDRESS = {
  city: string;
  line1: string;
  line2: string;
  state: string;
  zip: string;
};

export type ID_TOKEN_TYPE = {
  address: ADDRESS;
  nonce: string;
  iat: any;
  exp: any;
  sub: string;
  aud: string;
  jti: string;
  iss: string;
  phone_numbers: PHONE_NUMBERES;
  roles: string;
  photo: string;
  company: COMPANY;
  given_name: string;
  uuid: string;
  family_name: string;
  email: string;
  apps: APPS[] | APPS;
  auth_time: number;
  at_hash: string;
};
