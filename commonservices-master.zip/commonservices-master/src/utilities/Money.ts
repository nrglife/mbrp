// Helper methods taken from Project X
export const addCommasToNumber = str => {
    return (str + '').replace(/\b(\d+)((\.\d+)*)\b/g, function (a, b, c) {
      return (b.charAt(0) > 0 && !(c || '.').lastIndexOf('.') ? b.replace(/(\d)(?=(\d{3})+$)/g, '$1,') : b) + c;
    });
  };
  
  export const roundFloatToHundredths: (float: number) => string = (float: number) => (Math.round(float * 100) / 100).toFixed(2);
  
  export const floatToDollarString = (float: number) => `$${addCommasToNumber(roundFloatToHundredths(float))}`;
  
  export const setNumberPreview = (num: number | string | null | undefined, fractionDigits: number = 2) => {
    if (!num || !Number(num)) {
      return Number(0).toLocaleString(navigator.language, { minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits });
    }
    return Number(num).toLocaleString(navigator.language, { minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits });
  };
  