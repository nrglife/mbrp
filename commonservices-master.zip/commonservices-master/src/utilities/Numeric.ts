export const isNumber = (num: number | string | null) => {
  if (
    num == null ||
    (num !== 0 && isNaN(+num)) ||
    (typeof num === "string" && num.trim() === "")
  )
    return false;
  return true;
};
