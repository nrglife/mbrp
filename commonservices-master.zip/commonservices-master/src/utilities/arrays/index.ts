import { isValidDate } from "../dates";

export const sortDates = (firstDate: any, secondDate: any) => {
  // create new date references
  let aTimeObject = new Date(firstDate.title);
  let bTimeObject = new Date(secondDate.title);

  // sort the dates
  return bTimeObject.getTime() - aTimeObject.getTime();
};

const sortTitleDates = (firstDate: any, secondDate: any) => {
  // create new date references
  let aTimeObject = new Date(firstDate.title);
  let bTimeObject = new Date(secondDate.title);

  // sort the dates
  return bTimeObject.getTime() - aTimeObject.getTime();
};

const sortByProperties = (properties: ISortByProperties) => (
  firstItem: any,
  secondItem: any
) => {
  if (!properties || Object.keys(properties).length === 0) return;
  for (let property in properties) {
    const { isPropertyDateTimeFormat: isDateTime = false, isDesc = false } =
      properties[property] || {};

    const firstItemValue = getPropByString(firstItem, property);
    const secondItemValue = getPropByString(secondItem, property);

    let result = 0;
    if (!isDateTime) {
      if (firstItemValue === secondItemValue) {
        if (Object.keys(properties).length === 1) return 0;
        continue;
      } else if (!firstItemValue) return 1;
      else if (!secondItemValue) return -1;
      else if (!isDesc) {
        return firstItemValue < secondItemValue ? -1 : 1;
      } else {
        return firstItemValue < secondItemValue ? 1 : -1;
      }
    } else {
      const firstItemDate = isValidDate(firstItemValue)
        ? new Date(firstItemValue).getTime()
        : 0; // 0 => milliseconds since Jan 1, 1970, 00:00:00.000 GMT
      const secondItemDate = isValidDate(secondItemValue)
        ? new Date(secondItemValue).getTime()
        : 0; //0 => milliseconds since Jan 1, 1970, 00:00:00.000 GMT
      result = isDesc
        ? secondItemDate - firstItemDate
        : firstItemDate - secondItemDate;
    }

    return result;
  }
};

export interface ISortByProperties {
  [propName: string]: { isPropertyDateTimeFormat?: boolean; isDesc?: boolean };
}
export const sortBy = (arr: any, properties: ISortByProperties) => {
  if (!arr) return [];
  if (!properties || Object.keys(properties).length === 0) return arr;

  const sortByFunction = sortByProperties(properties);
  return arr.sort(sortByFunction);
};

// Support search in array props
export const getPropByString = (obj: any, propString: string) => {
  if (!propString) return -1;

  let prop;
  const props = propString.split(".");
  let i;
  for (i = 0; i < props.length - 1; i++) {
    prop = props[i];

    if (prop.includes("[")) {
      let arrProps = prop.substring(0, prop.length - 3);
      let arrIndex = prop.substring(prop.length - 3, prop.length);
      let index = arrIndex.substring(1, arrIndex.length - 1);
      //get array index related data
      if (!obj[arrProps]) break;
      obj = obj[arrProps];
      if (!obj[index]) break;
      obj = obj[index];
    } else {
      if (!obj[prop]) break;
      obj = obj[prop];
    }
  }

  return !isNaN(Number(obj[props[i]])) ? Number(obj[props[i]]) : obj[props[i]];
};
