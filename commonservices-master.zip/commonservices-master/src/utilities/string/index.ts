export const uppercaseFirstLetter = (str?: string | undefined) => {
  if (str && str.length > 1) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  } else if (str && str.length > 0) {
    return str.charAt(0).toUpperCase();
  }
  return str;
};

export const titleCase = str => {
  if (!str) {
    return str;
  }
  const splitStr = str.toLowerCase().split(' ');
  for (var i = 0; i < splitStr.length; i++) {
    splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
  }
  return splitStr.join(' ');
};

export const upperCase = str => {
  if (!str) {
    return str;
  }

  return str.toUpperCase();
};

export const stringReplace = (originalString: string, match: string, replace: string) => {
  return originalString.replace(new RegExp(match, 'g'), () => replace);
};
