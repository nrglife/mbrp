export enum failureSource {
  //Enrollment
  Enrollment_Get_Invitation = 'EGI',
  Enrollment_Post_Invitation = 'EPI',
  Enrollment_Post_Otp_Phone = 'EPOTPP',
  Enrollment_Post_Otp = 'EPOTP',
  Enrollment_Post_Email = 'EPE',
  Enrollment_Post_Identity = 'EPID',
  Enrollment_Post_Password = 'EPPAS',
  Enrollment_Get_Enrollment = 'EGE',

  //T&C
  TC_Get_Contract = 'TCGC',
  TC_Get_Consent = 'TCGCNS',
  TC_Post_Consent = 'TCPCNS',

  //EOB
  EOB_Get = 'EOBG',

  //WHOAMI
  Whoami_Get_Basic = 'WGB',
  Whoami_Get_PayerInfo = 'WGPYR',
  Whoami_Get_DelegatesForMember = 'WGDFM',
  Whoami_Get_MembersForDelegate = 'WGMFD',

  //Linked Servies

  AppRegistry_Get_AllApplicationRequests = 'ARGAPPR',
  PTP_GET_PAYERS = 'PTPGPYRS',
  PTP_GET_RECORDS = 'PTPGRCD',
  PTP_GET_payerAuthURL = 'PTPGPURL',
  PTP_GET_PAYER = 'PTPGPYR',
  PTP_POST_REQUEST = 'PTPPREQ',
  PTP_GET_REQUESTS = 'PTPGREQS',

  //CIAM errors should be also mapped

  //Common
  Page_Not_found = 'PNF',

  DataServices_Get_Preference_List_By_Payer_Id = 'DSPR',
  DataServices_Get_Payer_Config_By_Payer_Id = 'DSPCFG',
  DataServices_Get_Payer_Images_By_Category = 'DSPIMG',
  DataServices_Get_Payer_Settings_By_Payer_Id = 'DSPS',
  DataServices_Get_Payer_Config_By_Name = 'DSPCFGN',
  DataServices_Get_Payer_Config_By_Payer_Id_Return_Null = 'DSPCFGRN',
  DataServices_Get_Payer_SETTINGS = 'DSGPS',
  DataServices_Get_Payer_Documents_By_Category = 'DSPDOC',

  AppConfiguration_Get_App_Configuration = 'ACFG',

  AppLocales_Get_Locales = 'ALCL',

  //Clinicals
  Clinical_Get_Patient = 'CLPAT',

  Clinical_Get_Medication_Requests = 'CLMED',
  Clinical_Invalid_Medication_Requests = 'CLINVMED',

  Clinical_Get_Allergy_Intolerances = 'CLALER',
  Clinical_Invalid_Allergy_Intolerances = 'CLINVALER',

  Clinical_Get_Conditions = 'CLCOND',
  Clinical_Invalid_Conditions = 'CLINVCON',

  Clinical_Get_Procedure = 'CLPRO',
  Clinical_Invalid_Procedure = 'CLINVPRO',

  Clinical_Get_ImmunizationProfile = 'CLIMN',
  Clinical_Invalid_ImmunizationProfile = 'CLINVIMN',

  Clinical_Get_ImplantableDevice = 'CLIMPL',
  Clinical_Invalid_ImplantableDevice = 'CLINVIMPL',

  Clinical_Get_LaboratoryResultObservation = 'CLLAB',
  Clinical_Invalid_LaboratoryResultObservation = 'CLINVLAB',

  Clinical_Get_ObservationSmokingStatus = 'CLOB',

  Clinical_Get_Encounter = 'CLENC',
  Clinical_Invalid_Encounter = 'CLINVENC',

  Provider_Directory_Get_Endpoint = 'PDE',
  Provider_Directory_Get_Endpoint_By_ID = 'PDEID',
  Provider_Directory_Get_Healthcare_Service = 'PDHS',
  Provider_Directory_Get_Healthcare_Service_By_ID = 'PDHSID',
  Provider_Directory_Get_Insurance_Plan = 'PDIP',
  Provider_Directory_Get_Insurance_Plan_By_ID = 'PDIPID',
  Provider_Directory_Get_Location = 'PDLOC',
  Provider_Directory_Get_Location_By_ID = 'PDLOCID',
  Provider_Directory_Get_Network = 'PDN',
  Provider_Directory_Get_Network_By_ID = 'PDNID',
  Provider_Directory_Get_Organization = 'PDORG',
  Provider_Directory_Get_Organization_By_ID = 'PDORGID',
  Provider_Directory_Get_Organization_Affiliation = 'PDORGA',
  Provider_Directory_Get_Organization_Affiliation_By_Id = 'PDORGAID',
  Provider_Directory_Get_Practitioner = 'PDPRA',
  Provider_Directory_Get_Practitioner_By_Id = 'PDPRAID',
  Provider_Directory_Get_Practitioner_Role = 'PDPR',
  Provider_Directory_Get_Practitioner_Role_By_Id = 'PDPRID',

  CIAM = 'CIAM'
}
