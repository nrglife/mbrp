export enum ErrorCode_Enrollment_Get_Enrollment {
  //Enrollment
  GENERAL = 450, //Get Enrollment General Error
  DIFFERENT_PAYER = 451, //Registered to different payer
  PAYER_NOT_FOUND = 452, //Enrolled but we didn't found payer (maybe Not Authorized)
  NOT_ENROLLED = 453 //User is not Enrolled
}

export enum ErrorCode_TC_Get_Consent {
  GENERAL = 450 //Consent General Erro
}

export enum ErrorCode_CIAM {
  NO_HASHPARAMS = 451, //CIAM with no hashParams
  NO_TOKEN = 452, //CIAM with no token
  VALIDATE_NONCE = 453, //CIAM validateNonce
  VALIDATE_AUDIENCE_CLAIM = 454, //CIAM validateAudienceClaim
  VALIDATE_ISSUER_CLAIM = 455, //CIAM validateIssuerClaim
  IS_VALID_APP = 456 //CIAM isValidApp
}
