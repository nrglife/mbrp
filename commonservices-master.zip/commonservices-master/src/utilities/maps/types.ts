export type Point = {
    lat: number;
    lng: number;
}