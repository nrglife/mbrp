import { Point } from "./types";

export const calculateDistanceInMiles = (point1: Point, point2: Point) => {
    var R = 3958.8; // Radius of the Earth in miles
    var rlat1 = point1.lat * (Math.PI/180); // Convert degrees to radians
    var rlat2 = point2.lat * (Math.PI/180); // Convert degrees to radians
    var difflat = rlat2-rlat1; // Radian difference (latitudes)
    var difflon = (point2.lng-point1.lng) * (Math.PI/180); // Radian difference (longitudes)

    var d = 2 * R * Math.asin(Math.sqrt(Math.sin(difflat/2)*Math.sin(difflat/2)+Math.cos(rlat1)*Math.cos(rlat2)*Math.sin(difflon/2)*Math.sin(difflon/2)));

    return d;
}

export const calculateDistanceInMeters = (point1: Point, point2: Point) => {
    let d = calculateDistanceInMiles(point1, point2);
    let distanceInMeters =  d / 0.00062137; // Convert to meters
    return distanceInMeters;
}

// TEST
// let p1 = new Point();
// p1.lat = 31.601558390858234;
// p1.lng = 34.759325228894596;

// let p2 = new Point();
// p2.lat = 31.60380650928663;
// p2.lng =  34.75939839418678;

// // result in meters
// console.log(calculateDistanceInMiles(p1,p2))