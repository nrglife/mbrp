export const Test = (a: number, b: number) => a + b;
