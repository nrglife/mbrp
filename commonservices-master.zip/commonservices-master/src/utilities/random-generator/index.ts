export const generateRandomID = () =>
  `${Math.random()
    .toString(36)
    .replace("0.", "uuid_" || "")}_${Date.now().toString()}`;
