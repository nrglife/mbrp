export interface IStorageService {
  getValueByKey: (key: string) => string;
  setItem: (key: string, value: any) => void;
  removeItemByKey: (key: string) => void;
}
