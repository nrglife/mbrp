import { injectable } from 'inversify';
import { IocContainer, IocTypes } from '../../../inversify.config';
import { commonFHIRSearchFields } from '../../../stores/clinicals/types';
import { failureSource } from '../../../utilities/consts/failureSource';
import { Bundle_Entry, Bundle } from '../../../utilities/fhir/types';
import { ApiCallParamsBase, BaseApi, BaseResponse, HTTP_STATUS_CODES, Method } from '../base-api';
import { ApiConfigProviderSpecific } from '../base-config';
import { ClinicalApiConfig } from './clinical-config';

@injectable()
export class ClinicalApi extends BaseApi<ClinicalApiConfig> {
  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<ClinicalApiConfig>) {
    super({ 'Content-Type': 'application/json', Accept: 'application/json' }, apiConfigProvider);
  }

  /* public getMedications(params: ClinicalApiData.GetMedications.Params) {
    return this.call({
      url: "/medication",
      method: Method.GET,
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetMedications.StatusCodes,
    });
  }*/

  /*  public getMedication(params: ClinicalApiData.GetMedication.Params) {
    return this.call({
      url: "/medication/" + params.medicationId,
      method: Method.GET,
      auth: true,

      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetMedication.StatusCodes,
    });
  }*/

  public getAllergyIntolerances(params: ClinicalApiData.GetAllergyIntolerances.Params): Promise<ClinicalApiData.GetAllergyIntolerances.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/AllergyIntolerance',
      method: Method.GET,
      apiFailureSource: failureSource.Clinical_Get_Allergy_Intolerances,
      isNextPage: false,
      includeUserId: true,
      auth: true,
      queryParams: params.withIncluded
        ? {
            _include: ['AllergyIntolerance:patient'],
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetAllergyIntolerances.StatusCodes
    });
  }

  public getMedicationRequests(params: ClinicalApiData.GetMedicationRequests.Params): Promise<ClinicalApiData.GetMedicationRequests.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/MedicationRequest',
      method: Method.GET,
      isNextPage: false,
      includeUserId: true,
      apiFailureSource: failureSource.Clinical_Get_Medication_Requests,
      auth: true,
      queryParams: {
        ...(params.withIncluded
          ? {
              _include: ['MedicationRequest:medication', 'MedicationRequest:requester', 'MedicationRequest:subject'],
              _count: this.apiConfigProvider().maxItems
            }
          : null)
      },
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetMedicationRequests.StatusCodes
    });
  }

  public getConditions(params: ClinicalApiData.GetConditions.Params): Promise<ClinicalApiData.GetConditions.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/Condition',
      method: Method.GET,
      auth: true,
      apiFailureSource: failureSource.Clinical_Get_Conditions,
      isNextPage: false,
      includeUserId: true,
      queryParams: params.withIncluded
        ? {
            _include: ['Condition:subject'],
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  public getEncounter(params: ClinicalApiData.GetEncounter.Params): Promise<ClinicalApiData.GetEncounter.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/Encounter',
      method: Method.GET,
      auth: true,
      apiFailureSource: failureSource.Clinical_Get_Encounter,
      isNextPage: false,
      includeUserId: true,
      queryParams: params.withIncluded
        ? {
            _include: ['Encounter:location', 'Encounter:participant'],
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  public getImplantableDevice(params: ClinicalApiData.GetImplantableDevice.Params): Promise<ClinicalApiData.GetImplantableDevice.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/ImplantableDevice',
      method: Method.GET,
      auth: true,
      queryParams: params.withIncluded
        ? {
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      apiFailureSource: failureSource.Clinical_Get_ImplantableDevice,
      isNextPage: false,
      includeUserId: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  public getProcedure(params: ClinicalApiData.GetProcedure.Params): Promise<ClinicalApiData.GetProcedure.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/Procedure',
      method: Method.GET,
      auth: true,
      queryParams: params.withIncluded
        ? {
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      apiFailureSource: failureSource.Clinical_Get_Procedure,
      isNextPage: false,
      includeUserId: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  public getImmunizationProfile(params: ClinicalApiData.GetImmunizationProfile.Params): Promise<ClinicalApiData.GetImmunizationProfile.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: '/Immunization',
      method: Method.GET,
      auth: true,
      queryParams: params.withIncluded
        ? {
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      apiFailureSource: failureSource.Clinical_Get_ImmunizationProfile,
      isNextPage: false,
      includeUserId: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  public getPatientData(): Promise<ClinicalApiData.GetPatient.Response> {
    return this.call({
      sortBy: {
        descending: true,
        fieldName: commonFHIRSearchFields.LastUpdated
      },
      url: '/Patient',
      method: Method.GET,
      auth: true,
      queryParams: {
        _count: 1
      },
      apiFailureSource: failureSource.Clinical_Get_Patient,
      isNextPage: false,
      includeUserId: true,
      allowedStatusCodes: ClinicalApiData.GetPatient.StatusCodes
    });
  }

  public getObservationSmokingStatus(): Promise<ClinicalApiData.GetObservationSmokingStatus.Response> {
    return this.call({
      sortBy: {
        descending: true,
        fieldName: commonFHIRSearchFields.LastUpdated
      },
      url: '/ObservationSmokingStatus',
      method: Method.GET,
      auth: true,
      queryParams: {
        _count: 1,
        status: 'final',
        code: '72166-2'
      },

      apiFailureSource: failureSource.Clinical_Get_ObservationSmokingStatus,
      isNextPage: false,
      includeUserId: true,

      allowedStatusCodes: ClinicalApiData.GetObservationSmokingStatus.StatusCodes
    });
  }

  public getLaboratoryResultObservation(params: ClinicalApiData.GetLaboratoryResultObservation.Params): Promise<ClinicalApiData.GetLaboratoryResultObservation.Response> {
    return this.call({
      sortBy: params.sortBy,
      url: `/ObservationLab`,
      method: Method.GET,
      auth: true,
      queryParams: params.withIncluded
        ? {
            _count: this.apiConfigProvider().maxItems
          }
        : null,
      apiFailureSource: failureSource.Clinical_Get_LaboratoryResultObservation,
      isNextPage: false,
      includeUserId: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetConditions.StatusCodes
    });
  }

  /*https://sandbox.apis.changehealthcare.com/CMSPatientAccess/clinical/v1/Condition?*/

  /*public getMedicationRequest(
    params: ClinicalApiData.GetMedicationRequest.Params
  ) {
    return this.call({
      url: "/MedicationRequest/" + params.medicationRequestId,
      method: Method.GET,
      auth: true,

      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: ClinicalApiData.GetMedicationRequest.StatusCodes,
    });
  }*/
}

export namespace ClinicalApiData {
  /* export namespace GetMedications {
    export interface Params extends ApiCallParamsBase {}
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.FORBIDDEN,
    ];
  }*/

  /* export namespace GetMedication {
    export interface Params extends ApiCallParamsBase {
      medicationId: number;
    }
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.FORBIDDEN,
      HTTP_STATUS_CODES.NOT_FOUND,
    ];
  }*/

  export namespace GetMedicationRequests {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }
    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }

  export namespace GetAllergyIntolerances {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }
    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }

  export namespace GetConditions {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }
  export namespace GetEncounter {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }
  export namespace GetImplantableDevice {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }
  export namespace GetProcedure {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }
  export namespace GetPatient {
    export interface Params extends ApiCallParamsBase {}

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }

  export namespace GetObservationSmokingStatus {
    export interface Params extends ApiCallParamsBase {}

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }

  export namespace GetLaboratoryResultObservation {
    export interface Params extends ApiCallParamsBase {
      code?: string;
      withIncluded?: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }
  export namespace GetImmunizationProfile {
    export interface Params extends ApiCallParamsBase {
      withIncluded: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN];
  }

  /* export namespace GetMedicationRequest {
    export interface Params extends ApiCallParamsBase {
      medicationRequestId: number;
    }
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.FORBIDDEN,
      HTTP_STATUS_CODES.NOT_FOUND,
    ];
  }*/
}
