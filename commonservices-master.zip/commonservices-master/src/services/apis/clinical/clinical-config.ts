import { ApiConfigBase } from "../base-config";

export interface ClinicalApiConfig extends ApiConfigBase {
  maxItems: number;
}
