import { injectable } from 'inversify';
import { failureSource } from '../../../utilities/consts/failureSource';
import { Bundle } from '../../../utilities/fhir/types';

import { ApiCallParamsBase, BaseApi, BaseResponse, HTTP_STATUS_CODES, Method } from '../base-api';
import { ApiConfigBase, ApiConfigProviderSpecific } from '../base-config';

@injectable()
export class WhoAmIApi extends BaseApi<ApiConfigBase> {
  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<ApiConfigBase>) {
    super(
      {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      apiConfigProvider
    );
  }

  public getBasicInfo(params: WhoAmIApiData.GetBasicInfo.Params) {
    return this.call({
      sortBy: params.sortBy,
      url: '/basic',
      method: Method.GET,
      includeUserId: true,
      isNextPage: false,
      apiFailureSource: failureSource.Whoami_Get_Basic,
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: WhoAmIApiData.GetBasicInfo.StatusCodes
    });
  }

  public getPayerInfo(params: WhoAmIApiData.GetPayerInfo.Params) {
    return this.call({
      sortBy: params.sortBy,
      url: '/payerinfo',
      includeUserId: true,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Whoami_Get_PayerInfo,
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: WhoAmIApiData.GetPayerInfo.StatusCodes
    });
  }

  public getDelegatesForMember(params: WhoAmIApiData.GetDelegatesForMember.Params) {
    return this.call({
      sortBy: params.sortBy,
      url: '/delegatesForMember',
      method: Method.GET,
      isNextPage: false,
      includeUserId: true,
      apiFailureSource: failureSource.Whoami_Get_DelegatesForMember,
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: WhoAmIApiData.GetDelegatesForMember.StatusCodes
    });
  }

  public getMembersForDelegate(params: WhoAmIApiData.GetMembersForDelegate.Params) {
    return this.call({
      sortBy: params.sortBy,
      url: '/membersForDelegate',
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Whoami_Get_MembersForDelegate,
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: WhoAmIApiData.GetMembersForDelegate.StatusCodes
    });
  }
}

export namespace WhoAmIApiData {
  export namespace GetBasicInfo {
    export interface Params extends ApiCallParamsBase {
      defaultUser: boolean;
    }

    export interface Response extends BaseResponse {
      data: Bundle;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.FORBIDDEN,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.INVALID_LOCKED
    ];
  }

  export namespace GetPayerInfo {
    export interface Params extends ApiCallParamsBase {}

    export interface Response extends BaseResponse {
      data: Bundle;
    }
    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN, HTTP_STATUS_CODES.INVALID_LOCKED];
  }

  export namespace GetDelegatesForMember {
    export interface Params extends ApiCallParamsBase {}

    export interface Response extends BaseResponse {}
    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.FORBIDDEN, HTTP_STATUS_CODES.INVALID_LOCKED];
  }

  export namespace GetMembersForDelegate {
    export interface Params extends ApiCallParamsBase {}

    export interface Response extends BaseResponse {
      data: Bundle;
    }
    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.INVALID_LOCKED];
  }
}
