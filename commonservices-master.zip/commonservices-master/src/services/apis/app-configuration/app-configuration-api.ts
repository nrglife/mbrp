import { injectable } from "inversify";
import { failureSource } from "../../../utilities/consts/failureSource";
import {
  ApiCallParamsBase,
  BaseApi,
  BaseResponse,
  HTTP_STATUS_CODES,
  Method,
} from "../base-api";
import { ApiConfigBase, ApiConfigProviderSpecific } from "../base-config";

export interface AppConfigurationConfig extends ApiConfigBase {
  apikey: string;
}

@injectable()
export class AppConfigurationApi extends BaseApi<AppConfigurationConfig> {
  constructor(
    defaultHeaders: object,
    apiConfigProvider: ApiConfigProviderSpecific<AppConfigurationConfig>
  ) {
    super(
      {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      apiConfigProvider
    );
  }

  public getAppConfiguration(params: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/appConfiguration`,
      method: Method.GET,
      apiFailureSource: failureSource.AppConfiguration_Get_App_Configuration,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      isNextPage: false,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
}

// interface Api {
//     [key: string]: VersionStatus
// }
//
// type appVersions = Api & {
//     latestVersion: VersionStatus;
// }
// export type VersionStatus = 'allowed' | 'deprecated'
//
//
// export declare namespace GetAppConfiguration {
//     export interface Response extends BaseResponse {
//
//         data: {
//             success: boolean
//             message: string
//             status: number
//             data: {
//                 appVersions: appVersions
//                 appSupportDetails: {
//                     appSupportNames: string []
//                     appSupportEmails: string[]
//                     appSupportPhoneNumbers: string[]
//                 },
//                 surveyURL: string
//                 filterFindCareByLocation: boolean
//                 hideFindCare: boolean
//                 showMessagingPlatform: boolean
//                 smileCDRRevokeURL: string
//
//             }
//         }
//     }
//
//
// }
