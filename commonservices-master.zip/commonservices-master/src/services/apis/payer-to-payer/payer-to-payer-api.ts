import { injectable } from 'inversify';
import { failureSource } from '../../../utilities/consts/failureSource';
import { ApiCallParamsBase, BaseApi, BaseResponse, HTTP_STATUS_CODES, Method } from '../base-api';
import { ApiConfigBase, ApiConfigProviderSpecific } from '../base-config';
import { HumanName } from '../../../stores/DelegateStore';

@injectable()
export class PayerToPayerApi extends BaseApi<ApiConfigBase> {
  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<ApiConfigBase>) {
    super(
      {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      apiConfigProvider
    );
  }

  public getAllPayers(params: ApiCallParamsBase = {}) {
    return this.call({
      xAuthorization:true,
      sortBy: params.sortBy,
      auth: true,
      url: 'payertopayer/payer',
      method: Method.GET,
      isNextPage: false,
      includeUserId: false,
      apiFailureSource: failureSource.PTP_GET_PAYERS,
      queryParams: {},
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.FORBIDDEN,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.INVALID_LOCKED // 422 Data setup issue.
      ]
    });
  }

  public getPayerAuthURL(params: GetPayerAuthURL.Params): Promise<GetPayerAuthURL.Response> {
    return this.call({
      xAuthorization:true,
      sortBy: params.sortBy,
      auth: true,
      url: `payertopayer/payerAuthURL/${params.payerId}?platformType=${params.platformType}`,
      method: Method.GET,
      isNextPage: false,
      includeUserId: false,
      apiFailureSource: failureSource.PTP_GET_payerAuthURL,
      queryParams: {},
      allowedStatusCodes: GetPayerAuthURL.StatusCodes
    });
  }

  public postRequestHistoricalDataFromPayer(params: PostRequestHistoricalDataFromPayer.Params): Promise<PostRequestHistoricalDataFromPayer.Response> {
    return this.call({
      xAuthorization:true,
      sortBy: params.sortBy,
      auth: true,
      url: `payertopayer/createAccessToken/${params.payerId}`,
      method: Method.POST,
      isNextPage: false,
      includeUserId: true,
      apiFailureSource: failureSource.PTP_POST_REQUEST,
      queryParams: {},
      data: {
        authCode: params.authCode,
        platformType: params.platformType
      },
      allowedStatusCodes: PostRequestHistoricalDataFromPayer.StatusCodes
    });
  }

  public getPayerRecords(params: GetPayerRecords.Params): Promise<GetPayerRecords.Response> {
    return this.call({
      xAuthorization:true,
      sortBy: params.sortBy,
      auth: true,
      url: `payertopayer/request/${params.payerId}`,
      method: Method.GET,
      isNextPage: false,
      includeUserId: true,
      apiFailureSource: failureSource.PTP_GET_RECORDS,
      queryParams: {},
      allowedStatusCodes: GetPayerRecords.StatusCodes
    });
  }
}

export namespace GetPayerRecords {
  export interface Params extends ApiCallParamsBase {
    payerId: string;
  }

  export interface Response extends BaseResponse {
    data: { data: Request_Record[] };
  }

  export const StatusCodes = [
    HTTP_STATUS_CODES.SUCCESS,
    HTTP_STATUS_CODES.BAD_REQUEST,
    HTTP_STATUS_CODES.UNAUTHORIZED,
    HTTP_STATUS_CODES.FORBIDDEN,
    HTTP_STATUS_CODES.NOT_FOUND,
    HTTP_STATUS_CODES.INVALID_LOCKED
  ];
}
export namespace GetPayerAuthURL {
  export interface Params extends ApiCallParamsBase {
    payerId: string;
    platformType: PlatformType;
  }

  export interface Response extends BaseResponse {
    data: { data: { authorize_uri: string } };
  }

  export const StatusCodes = [
    HTTP_STATUS_CODES.SUCCESS,
    HTTP_STATUS_CODES.BAD_REQUEST,
    HTTP_STATUS_CODES.UNAUTHORIZED,
    HTTP_STATUS_CODES.FORBIDDEN,
    HTTP_STATUS_CODES.NOT_FOUND,
    HTTP_STATUS_CODES.INVALID_LOCKED
  ];
}

export namespace PostRequestHistoricalDataFromPayer {
  export interface Params extends ApiCallParamsBase {
    payerId: string;
    authCode: string;
    platformType: PlatformType;
  }

  export interface Response extends BaseResponse {}

  export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS];
}

export declare interface Request_Record {
  requestId: string;
  humanName: HumanName;
  payerId: string;
  requestDate: string;
  status: 'received' | 'pending';
}



export enum PlatformType {
  WEB = 'web',
  MOBILE = 'mobile'
}

export enum REDIRECT_URI {
  MOBILE = 'healthapp://p2pauth',
  WEB = 'http://localhost:5020"'
}
