import { injectable } from 'inversify';
import { failureSource } from '../../../utilities/consts/failureSource';
import { ApiCallParamsBase, BaseApi, BaseResponse, HTTP_STATUS_CODES, Method } from '../base-api';
import { ApiConfigBase, ApiConfigProviderSpecific } from '../base-config';
import { PayerPayerConfigFeatureIds } from '../../../stores/PayerStore';

export interface DataServicesConfig extends ApiConfigBase {
  XCHCClientId: string;
}

@injectable()
export class DataServicesApi extends BaseApi<DataServicesConfig> {
  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<DataServicesConfig>) {
    super({}, () => ({
      ...apiConfigProvider(),
      ...{
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'X-CHC-ClientId': apiConfigProvider().XCHCClientId
        }
      }
    }));
  }

  // Get the payer's theme (colors and font)
  public getPreferenceListByPayerId({
    payerId,
    stage,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPreferenceListByPayerId.Params): Promise<DataServicesApiData.GetPreferenceListByPayerId.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/preference/list/${payerId}/${stage}`,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Preference_List_By_Payer_Id,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPreferenceListByPayerId.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  // Get the payer's images (landing page's background, logos, etc..)
  public getPayerImagesByCategory({
    metadata,
    payerId,
    stage,
    category,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPayerImagesByCategory.Params): Promise<DataServicesApiData.GetPayerImagesByCategory.Response> {
    const url = metadata == true ? `/images/download/${payerId}/${stage}/${category}?metadata` : `/images/download/${payerId}/${stage}/${category}`;
    try {
      return this.call({
        sortBy: sortBy,
        url,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Payer_Images_By_Category,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerImagesByCategory.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  public getPayerConfigByPayerId({
    payerId,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPayerConfigByPayerId.Params): Promise<DataServicesApiData.GetPayerConfigByPayerId.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/payerConfig/${payerId}`,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Payer_Config_By_Payer_Id,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerConfigByPayerId.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  public getPayerSettingsByPayerId({
    payerId,
    stage,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPayerSettingsByPayerId.Params): Promise<DataServicesApiData.GetPayerSettingsByPayerId.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/settings/${payerId}/${stage}/contactinfo`,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Payer_Settings_By_Payer_Id,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerSettingsByPayerId.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  public getPayerConfigByName({
    payerShortName,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy: sortBy
  }: DataServicesApiData.GetPayerConfigByName.Params): Promise<DataServicesApiData.GetPayerConfigByName.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/payerConfig?shortName=${payerShortName}`,
        method: Method.GET,
        isNextPage: false,
        apiFailureSource: failureSource.DataServices_Get_Payer_Config_By_Name,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerConfigByName.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  public getPayerConfigByPayerIdReturnNull({
    payerId,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPayerConfigByPayerIdReturnNull.Params): Promise<DataServicesApiData.GetPayerConfigByPayerIdReturnNull.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/payerConfig/${payerId}`,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Payer_Config_By_Payer_Id_Return_Null,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerConfigByPayerIdReturnNull.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  // Get the payer's documents: custome strings usually used in the landing page.
  public getPayerDocumentsByCategory({
    metadata,
    payerId,
    stage,
    category,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy: sortBy
  }: DataServicesApiData.GetPayerDocumentsByCategory.Params): Promise<any> {
    const url = metadata === true ? `/documents/download/${payerId}/${stage}/${category}?metadata` : `/documents/download/${payerId}/${stage}/${category}`;

    try {
      return this.call({
        sortBy: sortBy,
        url,
        method: Method.GET,
        isNextPage: false,
        apiFailureSource: failureSource.DataServices_Get_Payer_Documents_By_Category,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerDocumentsByCategory.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }

  public getPayerSettings({
    payerId,
    successHandlerParam,
    errorHandlerParam,
    precallHandlerParam,
    sortBy
  }: DataServicesApiData.GetPayerSettings.Params): Promise<DataServicesApiData.GetPayerSettings.Response> {
    try {
      return this.call({
        sortBy: sortBy,
        url: `/settings/${payerId}`,
        method: Method.GET,
        apiFailureSource: failureSource.DataServices_Get_Payer_SETTINGS,
        isNextPage: false,
        successHandlerParam: successHandlerParam,
        errorHandlerParam: errorHandlerParam,
        precallHandlerParam: precallHandlerParam,
        allowedStatusCodes: DataServicesApiData.GetPayerSettings.StatusCodes
      });
    } catch (e) {
      console.error(e);
    }
  }
}

export namespace DataServicesApiData {
  export namespace GetPreferenceListByPayerId {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
      stage: string;
    }

    export interface Response extends BaseResponse {
      data: {
        colors: Record<ColorsPreferences, Record<Categories, string>>;
        font: Record<Categories, string>;
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.SERVER_ERROR];
  }

  export namespace GetPayerConfigByPayerId {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
    }

    export interface Response extends BaseResponse {
      data: {
        customer_internal_id?: string;
        customer_id?: string;
        tax_id?: string;
        customer_name?: string;
        short_name?: string;
        federated_id?: string;
        mdm_id?: string;
        sftp_test?: string;
        sftp_preprod?: string;
        sftp_prod?: string;
        member_url?: string;
        member_test_url?: string;
        payer_url?: string;
        payer_test_url?: string;
        customer_type?: number;
        customer_fhir_base?: string;
        customer_fhir_base_pharm?: string;
        customer_email_address?: string;
        customer_logo_url?: string;
        globalscape_mailbox_id?: string;
        globalscape_credential?: string;
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.NOT_FOUND, HTTP_STATUS_CODES.SERVER_ERROR];
  }

  export namespace GetPayerImagesByCategory {
    export interface Response extends BaseResponse {
      data: {
        Key: string;
        LastModified: string;
        Size: number;
        tags: [{ Key: string; value: string }];
        category: string;
        stage: string;
        body: string;
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.NOT_FOUND, HTTP_STATUS_CODES.SERVER_ERROR];

    export interface Params extends ApiCallParamsBase {
      payerId: string;
      stage: string;
      metadata: boolean;
      category: string;
    }
  }

  export namespace GetPayerSettingsByPayerId {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
      stage: string;
    }

    export interface Response extends BaseResponse {
      data: {
        payerName: string;
        payerId: string;
        phoneNumbers: IPhoneNumber[];
        emailAddresses: IEmailAddress[];
        publicName: string;
        address: string;
        url: string;
      };
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.SERVER_TIMEOUT,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.ALREADY_IN_USE,
      HTTP_STATUS_CODES.SERVER_ERROR,
      HTTP_STATUS_CODES.TIME_OUT,
      HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED
    ];
  }

  export namespace GetPayerSettings {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
    }

    export interface Response extends BaseResponse {
      data: {
        urls: {
          connectedHealth: {
            test: {
              published: string;
            };
          };
          fileUpload: {
            test: {
              published: string;
            };
          };
        };
        federatedLogins: {
          [key: string]: {
            active: boolean;
            selected: {
              draft: any;
              published: boolean;
            };
          };
        };
        'navigation-menu': {
          [feature: string]: {
            id: PayerPayerConfigFeatureIds;
            active: {
              draft: any;
              published: boolean;
            };
          };
        };
        legal: {
          copyright: {
            id: string;
            draft: string;
            published: string;
          };
        };
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.SERVER_ERROR];
  }

  export namespace GetPayerConfigByName {
    export interface Params extends ApiCallParamsBase {
      payerShortName: string;
    }

    export interface Response extends BaseResponse {
      data: {
        customer_internal_id?: string;
        customer_id?: string;
        tax_id?: string;
        customer_name?: string;
        short_name?: string;
        federated_id?: string;
        mdm_id?: string;
        sftp_test?: string;
        sftp_preprod?: string;
        sftp_prod?: string;
        member_url?: string;
        member_test_url?: string;
        payer_url?: string;
        payer_test_url?: string;
        customer_type?: number;
        customer_fhir_base?: string;
        customer_fhir_base_pharm?: string;
        customer_email_address?: string;
        customer_logo_url?: string;
        globalscape_mailbox_id?: string;
        globalscape_credential?: string;
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.NOT_FOUND, HTTP_STATUS_CODES.SERVER_ERROR];
  }
  export namespace GetPayerConfigByPayerIdReturnNull {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
    }

    export interface Response extends BaseResponse {
      data: {
        customer_internal_id?: string;
        customer_id?: string;
        tax_id?: string;
        customer_name?: string;
        short_name?: string;
        federated_id?: string;
        mdm_id?: string;
        sftp_test?: string;
        sftp_preprod?: string;
        sftp_prod?: string;
        member_url?: string;
        member_test_url?: string;
        payer_url?: string;
        payer_test_url?: string;
        customer_type?: number;
        customer_fhir_base?: string;
        customer_fhir_base_pharm?: string;
        customer_email_address?: string;
        customer_logo_url?: string;
        globalscape_mailbox_id?: string;
        globalscape_credential?: string;
      };
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.NOT_FOUND, HTTP_STATUS_CODES.SERVER_ERROR];
  }
  export namespace GetPayerDocumentsByCategory {
    export interface Params extends ApiCallParamsBase {
      payerId: string;
      stage: string;
      metadata: boolean;
      category: string;
    }

    export const StatusCodes = [HTTP_STATUS_CODES.SUCCESS, HTTP_STATUS_CODES.BAD_REQUEST, HTTP_STATUS_CODES.UNAUTHORIZED, HTTP_STATUS_CODES.NOT_FOUND, HTTP_STATUS_CODES.SERVER_ERROR];
  }
}

export type Categories = Category.Published;

export interface IPhoneNumber {
  primary: boolean;
  description: string;
  number: string;
}

export interface IEmailAddress {
  primary: boolean;
  email: string;
}

export type ColorsPreferences = 'actionDark' | 'actionLight' | 'actionMedium' | 'backgroundDark' | 'backgroundLight' | 'backgroundMedium';

enum Category {
  //  Draft = 'draft',
  Published = 'published'
}
