import { injectable } from "inversify";
import { failureSource } from "../../../utilities/consts/failureSource";
import {
  ApiCallParamsBase,
  BaseApi,
  BaseResponse,
  CallParams,
  HTTP_STATUS_CODES,
  Method,
} from "../base-api";
import { ApiConfigProviderSpecific } from "../base-config";
import { EnrollmentConfig } from "./enrollment-config";

@injectable()
export class EnrollmentApi extends BaseApi<EnrollmentConfig> {
  constructor(
    defaultHeaders: object,
    apiConfigProvider: ApiConfigProviderSpecific<EnrollmentConfig>
  ) {
    super(
      {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      apiConfigProvider
    );
  }

  public getInvitationCode(
    params: EnrollmentApiData.GetInvitationCode.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Get_Invitation,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.GetInvitationCode.StatusCodes,
    });
  }

  public postPersonalInfo(
    params: EnrollmentApiData.PostPersonalInfo.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}`,
      method: Method.POST,
      apiFailureSource: failureSource.Enrollment_Post_Invitation,
      isNextPage: false,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      data: params.data,
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostPersonalInfo.StatusCodes,
    });
  }

  public postRequestOtpCode(
    params: EnrollmentApiData.PostRequestOtpCode.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/otp/${params.phoneNumber}`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Post_Otp_Phone,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostRequestOtpCode.StatusCodes,
    });
  }

  public postRequestOtpCodeDefault(
    params: EnrollmentApiData.PostRequestOtpCodeDefault.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/otp/XXXX`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Post_Otp_Phone,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      xAuthorization: false,
      allowedStatusCodes:
        EnrollmentApiData.PostRequestOtpCodeDefault.StatusCodes,
    });
  }

  public postOtpPassCode(
    params: EnrollmentApiData.PostOtpPassCode.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/otp`,
      method: Method.POST,
      apiFailureSource: failureSource.Enrollment_Post_Otp,
      isNextPage: false,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      data: {
        passCode: params.passCode,
      },
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostOtpPassCode.StatusCodes,
    });
  }

  public postRequestOtpEmailCode(
    params: EnrollmentApiData.PostRequestOtpEmailCode.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/email`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Post_Email,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      data: {
        emailAddress: params.email,
      },
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostRequestOtpEmailCode.StatusCodes,
    });
  }

  public postOtpEmailPassCode(
    params: EnrollmentApiData.PostOtpEmailPassCode.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/identity`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Post_Identity,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      data: {
        emailOtp: params.passCode,
        idp: params.idp,
        ciamFederationId: params.ciamFederationId,
        token: params.token,
      },
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostOtpEmailPassCode.StatusCodes,
    });
  }

  public postPassword(
    params: EnrollmentApiData.PostPassword.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      headers: { apikey: `CIAM-${this.apiConfigProvider().apikey}` },
      url: `/invitation/${params.code}/password/${params.userId}`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Post_Password,
      queryParams: {},
      auth: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      data: { password: params.password },
      xAuthorization: false,
      allowedStatusCodes: EnrollmentApiData.PostPassword.StatusCodes,
    });
  }

  public getEnrollment(
    params: EnrollmentApiData.GetEnrollment.Params
  ): Promise<BaseResponse> {
    return this.call({
      sortBy: params.sortBy,
      url: `/enrollment`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Enrollment_Get_Enrollment,
      queryParams: {},
      auth: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      xAuthorization: true,
      callScopeAuthToken: params.callScopeAuthToken,
      allowedStatusCodes: EnrollmentApiData.GetEnrollment.StatusCodes,
    });
  }
}

export namespace EnrollmentApiData {
  export namespace GetInvitationCode {
    export interface Params extends ApiCallParamsBase {
      code: string;
    }
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostPersonalInfo {
    export interface Params extends ApiCallParamsBase {
      data: any;
      code: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostRequestOtpCode {
    export interface Params extends ApiCallParamsBase {
      phoneNumber: string;
      code: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostRequestOtpCodeDefault {
    export interface Params extends ApiCallParamsBase {
      code: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostOtpPassCode {
    export interface Params extends ApiCallParamsBase {
      code: string;
      passCode: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostRequestOtpEmailCode {
    export interface Params extends ApiCallParamsBase {
      email: string;
      code: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostOtpEmailPassCode {
    export interface Params extends ApiCallParamsBase {
      code: string;
      passCode: string;
      idp: string;
      ciamFederationId: string;
      token: string;
    }

    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MISSING_INFO,
      HTTP_STATUS_CODES.ALREADY_IN_USE,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace PostPassword {
    export interface Params extends ApiCallParamsBase {
      code: string;
      userId: string;
      password: string;
    }
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.INVALID_LOCKED,
      HTTP_STATUS_CODES.BAD_REQUEST,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.CONFLICT,
      HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
      HTTP_STATUS_CODES.NOT_FOUND,
      HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
    ];
  }

  export namespace GetEnrollment {
    export interface Params extends ApiCallParamsBase {
      callScopeAuthToken?: string;
    }
    export const StatusCodes = [
      HTTP_STATUS_CODES.SUCCESS,
      HTTP_STATUS_CODES.UNAUTHORIZED,
      HTTP_STATUS_CODES.NOT_FOUND,
    ];
  }
}
