import { ApiConfigBase } from "../base-config";
import { ApiError, BaseResponse } from "../base-api";

export interface EnrollmentConfig extends ApiConfigBase {
  apikey: string;
}
