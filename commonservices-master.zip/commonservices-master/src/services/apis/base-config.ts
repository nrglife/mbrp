import { ApiError, BaseResponse, CallParams } from './base-api';
import { EobsApiConfig } from './eobs/eobs-config';
import { ConsentConfig } from './consent/consent-config';
import { EnrollmentConfig } from './enrollment/enrollment-config';
import { AppConfigurationConfig } from './app-configuration/app-configuration-api';
import { AppLocalesApiConfig } from './app-locales/app-locales-api';
import { DataServicesConfig } from './data-services/data-services-api';
import { ClinicalApiData } from './clinical/clinical-api';
import { ClinicalApiConfig } from './clinical/clinical-config';

export type ApiErrorHandler = (error: ApiError, errorHandlerParam: any) => BaseResponse;
export type ApiSuccessHandler = (response: BaseResponse, sucessHandlerParam: any) => BaseResponse;
export type ApiPreCallHandler = (params: CallParams) => void;

interface ConnectionCheckConfig {
  url: string;
  status: number;
  timeout: number;
  callback: () => void;
  retries: number;
}

interface ApiConfigs {
  commonHeaders: object;
  connectionCheck: ConnectionCheckConfig | null;
  eobsApi: EobsApiConfig;
  whoAmIapi: ApiConfigBase;
  enrollmentApi: EnrollmentConfig;
  linkedServicesApi: ApiConfigBase;
  payerToPayerApi: ApiConfigBase;
  consentApi: ConsentConfig;
  clinicalApi?: ClinicalApiConfig;
  appConfigurationApi: AppConfigurationConfig;
  appLocalesApi: AppLocalesApiConfig;
  dataServicesApi: DataServicesConfig;
  providerDirectoryServicesApi: ApiConfigBase;
}

interface ErrorStoreConfig {
  disableLogging: boolean;
}

export interface ApiConfigBase {
  baseUrl: string;
  headers?: object;
  errorHandler?: ApiErrorHandler | null;
  successHandler?: ApiSuccessHandler | null;
  precallHandler?: ApiPreCallHandler | null;
}

export type ErrorStoreConfigProvider = () => ErrorStoreConfig;

export type ApiConfigsProvider = () => ApiConfigs;
export type ApiConfigProviderSpecific<T extends ApiConfigBase> = () => T;
export type AuthProvider = () => string;
export type ConsentDateProvider = () => string;
export type AlertProvider = (text: string) => void;
