import { injectable } from 'inversify';
import { failureSource } from '../../../utilities/consts/failureSource';
import { ApiCallParamsBase, BaseApi, HTTP_STATUS_CODES, Method } from '../base-api';
import { ApiConfigBase, ApiConfigProviderSpecific } from '../base-config';

@injectable()
export class LinkedServicesApi extends BaseApi<ApiConfigBase> {
  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<ApiConfigBase>) {
    super(
      {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      apiConfigProvider
    );
  }

  public getAllApplications(params: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: true,
      url: '/getAllApplicationRequests',
      method: Method.GET,
      isNextPage: false,
      includeUserId: false,
      apiFailureSource: failureSource.AppRegistry_Get_AllApplicationRequests,
      queryParams: {
        attestOnVulnerabilities: true,
        attestOnCARINPolicies: true,
        status: 2
      },
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED
      ]
    });
  }
}
