import { injectable } from "inversify";
import { failureSource } from "../../../utilities/consts/failureSource";
import {
  ApiCallParamsBase,
  BaseApi,
  HTTP_STATUS_CODES,
  Method,
} from "../base-api";
import { ApiConfigProviderSpecific, ApiConfigBase } from "../base-config";

@injectable()
export class ProviderDirectoryServicesApi extends BaseApi<ApiConfigBase> {
  constructor(
    defaultHeaders: object,
    apiConfigProvider: ApiConfigProviderSpecific<ApiConfigBase>
  ) {
    super(
      {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      apiConfigProvider
    );
  }

  public getEndpoint(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/Endpoint",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Endpoint,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getEndpointByID(params: ProviderDirectoryApiGetEndpointByIDParams) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/Endpoint/${params.endpointId}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Endpoint_By_ID,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getHealthcareService(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/HealthcareService",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Healthcare_Service,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getHealthcareServiceByID(
    params: ProviderDirectoryApiGetHealthcareServiceByIDParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/HealthcareService/${params.resourceId}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Healthcare_Service_By_ID,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getInsurancePlan(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/InsurancePlan",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Insurance_Plan,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getInsurancePlanByID(
    params: ProviderDirectoryApiGetInsurancePlanByIDParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/InsurancePlan/${params.resourceId}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Insurance_Plan_By_ID,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getLocation(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/Location",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Location,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getLocationByID(params: ProviderDirectoryApiGetLocationByIDParams) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/InsurancePlan/${params.id}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Location_By_ID,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getNetwork(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/Network",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Network,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getNetworkByID(params: ProviderDirectoryApiGetNetworkByIDParams) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/Network/${params.resourceId}`,
      method: Method.GET,
      apiFailureSource: failureSource.Provider_Directory_Get_Network_By_ID,
      isNextPage: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getOrganization(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/Organization",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Organization,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getOrganizationByID(
    params: ProviderDirectoryApiGetOrganizationByIDParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/Organization/${params.id}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Organization_Affiliation,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getOrganizationAffiliation(
    params?: ProviderDirectoryApiGetOrganizationAffiliationParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url:
        "/OrganizationAffiliation" + (params?.query && params.query !== "")
          ? `?{${params.query}}`
          : "",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Organization_Affiliation,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getOrganizationAffiliationById(
    params: ProviderDirectoryApiGetOrganizationAffiliationByIdParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/OrganizationAffiliation/${params.id}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Organization_Affiliation_By_Id,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getPractitioner(params?: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: "/Practitioner",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Practitioner,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getPractitionerById(
    params: ProviderDirectoryApiGetPractitionerByIdParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/Practitioner/${params.id}`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Practitioner_By_Id,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getPractitionerRole(
    params?: ProviderDirectoryApiGetPractitionerRoleParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url:
        "/PractitionerRole" + (params?.query && params.query !== "")
          ? `?{${params.query}}`
          : "",
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.Provider_Directory_Get_Practitioner_Role,
      successHandlerParam: params?.successHandlerParam,
      errorHandlerParam: params?.errorHandlerParam,
      precallHandlerParam: params?.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }

  public getPractitionerRoleById(
    params: ProviderDirectoryApiGetPractitionerRoleByIdParams
  ) {
    return this.call({
      sortBy: params.sortBy,
      auth: false,
      url: `/PractitionerRole/${params.id}`,
      method: Method.GET,
      apiFailureSource:
        failureSource.Provider_Directory_Get_Practitioner_Role_By_Id,
      isNextPage: false,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
}

export interface ProviderDirectoryApiGetEndpointByIDParams
  extends ApiCallParamsBase {
  endpointId: string;
}

export interface ProviderDirectoryApiGetHealthcareServiceByIDParams
  extends ApiCallParamsBase {
  resourceId: string;
}

export interface ProviderDirectoryApiGetInsurancePlanByIDParams
  extends ApiCallParamsBase {
  resourceId: string;
}

export interface ProviderDirectoryApiGetLocationByIDParams
  extends ApiCallParamsBase {
  id: string;
}

export interface ProviderDirectoryApiGetNetworkByIDParams
  extends ApiCallParamsBase {
  resourceId: string;
}
export interface ProviderDirectoryApiGetOrganizationByIDParams
  extends ApiCallParamsBase {
  id: string;
}

export interface ProviderDirectoryApiGetOrganizationAffiliationParams
  extends ApiCallParamsBase {
  query: string;
}

export interface ProviderDirectoryApiGetOrganizationAffiliationByIdParams
  extends ApiCallParamsBase {
  id: string;
}

export interface ProviderDirectoryApiGetPractitionerByIdParams
  extends ApiCallParamsBase {
  id: string;
}

export interface ProviderDirectoryApiGetPractitionerRoleParams
  extends ApiCallParamsBase {
  query: string;
}

export interface ProviderDirectoryApiGetPractitionerRoleByIdParams
  extends ApiCallParamsBase {
  id: string;
}
