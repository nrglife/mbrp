import {ApiConfigBase} from "../base-config";

export interface ConsentConfig extends ApiConfigBase{
    REACT_APP_ID_CONSENT:string
}
export interface PostConsentData  {
    contractId: string | null
    consentFlag: boolean
}
