import { injectable } from "inversify";
import { IocContainer, IocTypes } from "../../../inversify.config";
import { failureSource } from "../../../utilities/consts/failureSource";
import {
  ApiCallParamsBase,
  BaseApi,
  HTTP_STATUS_CODES,
  Method,
} from "../base-api";
import { ApiConfigProviderSpecific, AuthProvider } from "../base-config";
import { ConsentConfig, PostConsentData } from "./consent-config";

@injectable()
export class ConsentApi extends BaseApi<ConsentConfig> {
  constructor(
    defaultHeaders: object,
    apiConfigProvider: ApiConfigProviderSpecific<ConsentConfig>
  ) {
    super(
      {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      apiConfigProvider
    );
  }

  public postConsent(params: ConsentApiPostConsent) {
    return this.call({
      sortBy: params.sortBy,
      url: `/consent?applicationId=${
        this.apiConfigProvider().REACT_APP_ID_CONSENT
      }`,
      method: Method.POST,
      isNextPage: false,
      apiFailureSource: failureSource.TC_Post_Consent,
      auth: true,
      data: params.consentData,
      xAuthorization: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
  public getConsent(params: ConsentApiGetConsent) {
    return this.call({
      sortBy: params.sortBy,
      url: `/consent?applicationId=${
        this.apiConfigProvider().REACT_APP_ID_CONSENT
      }`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.TC_Get_Consent,
      auth: true,
      xAuthorization: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      callScopeAuthToken: params.callScopeAuthToken,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
  public getContract(params: ApiCallParamsBase) {
    return this.call({
      sortBy: params.sortBy,
      url: `/contract?applicationId=${
        this.apiConfigProvider().REACT_APP_ID_CONSENT
      }`,
      method: Method.GET,
      isNextPage: false,
      apiFailureSource: failureSource.TC_Get_Contract,
      auth: true,
      xAuthorization: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,
      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
}

interface ConsentApiPostConsent extends ApiCallParamsBase {
  consentData: PostConsentData;
}

interface ConsentApiGetConsent extends ApiCallParamsBase {
  callScopeAuthToken?: string;
}
