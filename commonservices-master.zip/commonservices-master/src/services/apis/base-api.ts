import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { injectable } from 'inversify';
import { type } from 'os';
import { IocContainer, IocTypes } from '../../inversify.config';
//import { URL, URLSearchParams } from "react-native-url-polyfill";
import qs from 'qs';
import { ApiConfigBase, ApiConfigProviderSpecific, ApiConfigsProvider, AuthProvider } from './base-config';
import { failureSource } from '../../utilities/consts/failureSource';
import { ErrorStoreType, DelegateStore } from '../../stores';

export enum HTTP_STATUS_CODES {
  SUCCESS = 200,
  SUCCESS_CREATED = 201,
  INVALID_LOCKED = 422, //An invalid invitation code state. Code is expired, locked or user already enrolled.
  BAD_REQUEST = 400, // Bad request.
  UNAUTHORIZED = 401, // Unauthorized,
  FORBIDDEN = 403,
  SERVER_TIMEOUT = 408, // Server Timeout
  CONFLICT = 409, // Conflict. A request to this endpoint is made prior to the 'validate invitation code' step.
  EXCEEDED_ATTEMPTS = 419, //Exceeded the allowed time to finish the validation steps for enrollment.
  NOT_FOUND = 404,
  MISSING_INFO = 412, // User's record is missing required information to enroll.
  ALREADY_IN_USE = 428, // The selected account is already used by another user.
  SERVER_ERROR = 500,
  TIME_OUT = 503,
  RECAPTCHA_SERVER_ERROR = 530,
  MEMBER_ALREADY_ENROLLED = 406,
  NO_INTERNET = 1000
}

export class ApiError {
  statusCode: number;
  message?: string;
  responseData: object;

  constructor(statusCode: number, message?: string, responseData?: object) {
    this.statusCode = statusCode;
    this.message = message;
    this.responseData = responseData;
  }
}

export enum Method {
  GET = 'get',
  POST = 'post'
}

interface ReqData {
  headers?: object;
  queryParams?: object;
}

interface SortParam {
  fieldName: String;
  descending: boolean;
}

type IngressInterceptor = (data: ReqData) => ReqData;

export interface BaseResponse {
  status: number;
  statusText: string;
  data: any;
  nextPageKey: string;
}

export interface ApiCallParamsBase {
  errorHandlerParam?: any;
  successHandlerParam?: any;
  precallHandlerParam?: any;
  numberOfRetries?: number;
  sortBy?: SortParam;
}

export interface CallParams {
  url: string;
  method: Method;
  headers?: object;
  queryParams?: object;
  queryParamsOrigNextPage?: object;
  auth?: boolean;
  errorHandlerParam?: any;
  successHandlerParam?: any;
  precallHandlerParam?: any;
  data?: any;
  xAuthorization?: boolean;
  callScopeAuthToken?: string;
  allowedStatusCodes: HTTP_STATUS_CODES[];
  numberOfRetries?: number;
  apiFailureSource: failureSource;
  isNextPage: boolean;
  includeUserId?: boolean;
  sortBy: SortParam;
}

export interface NextCallParams {
  origUrl: string;
  queryParams?: object;
  url: string;
  method: Method;
  headers?: object;
  auth?: boolean;
  xAuthorization?: boolean;
  allowedStatusCodes: HTTP_STATUS_CODES[];
  apiFailureSource: failureSource;
}

@injectable()
export class BaseApi<T extends ApiConfigBase> {
  protected readonly instance: AxiosInstance;

  private nextCallMap: { [id: string]: NextCallParams };

  private ingressInterceptors: IngressInterceptor[];
  protected apiConfigProvider: ApiConfigProviderSpecific<T>;
  private defaultHeaders;

  constructor(defaultHeaders: object, apiConfigProvider: ApiConfigProviderSpecific<T>) {
    this.instance = axios.create({
      timeout: 120000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    this.apiConfigProvider = apiConfigProvider;
    this.ingressInterceptors = [];
    this.defaultHeaders = defaultHeaders;
    this.nextCallMap = {};

    this.instance.interceptors.request.use(
      (config: AxiosRequestConfig) => {
        // Do something before request is sent
        this.ingressInterceptors.forEach(interceptor => {
          const { headers, queryParams } = interceptor({
            headers: {
              ...config.headers[config.method],
              ...config.headers.common
            },
            queryParams: config.params
          });
          config.headers.common = headers;
          config.headers[config.method] = null;
          config.params = queryParams;
        });
        return config;
      },
      function (error) {
        // Do something with request error
        return Promise.reject(error);
      }
    );
    this.instance.defaults.paramsSerializer = params => {
      return qs.stringify(params, { indices: false, encode: false });
    };
  }

  async checkConnection() {
    const connectionCheckConfig = IocContainer.get<ApiConfigsProvider>(IocTypes.ApiConfigsProvider)().connectionCheck;
    if (connectionCheckConfig == null) {
      return true;
    }

    let numberOfRetriesLeft = connectionCheckConfig.retries;

    do {
      numberOfRetriesLeft--;
      try {
        const res = await this.fetchWithTimeout(
          connectionCheckConfig.url,
          {
            method: 'GET',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json'
            }
          },
          connectionCheckConfig.timeout
        );
        if (res.status === connectionCheckConfig.status) {
          return true;
        }
      } catch (exception) {
        console.log(exception);
      }
    } while (numberOfRetriesLeft);

    connectionCheckConfig.callback();
    return false;
  }

  async fetchWithTimeout(url, options: RequestInit, timeout: number) {
    return new Promise<Response>((resolve, reject) => {
      const timeoutId = setTimeout(reject, timeout);
      fetch(url, options)
        .then(res => {
          resolve(res);
        })
        .catch(err => {
          reject(err);
        })
        .finally(() => {
          clearTimeout(timeoutId);
        });
    });
  }

  public useIngressInterceptor(interceptor: IngressInterceptor) {
    this.ingressInterceptors.push(interceptor);
  }

  private getQueryParamsFromUrl(url) {
    let queryString = url.split('?')[1];
    let obj = {};
    if (queryString) {
      queryString = queryString.split('#')[0];
      let arr = queryString.split('&');

      for (let i = 0; i < arr.length; i++) {
        let a = arr[i].split('=');
        let paramName = a[0];
        let paramValue = typeof a[1] === 'undefined' ? true : a[1];
        paramName = paramName.toLowerCase();
        if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();
        if (paramName.match(/\[(\d+)?\]$/)) {
          let key = paramName.replace(/\[(\d+)?\]/, '');
          if (!obj[key]) obj[key] = [];

          if (paramName.match(/\[\d+\]$/)) {
            let index = /\[(\d+)\]/.exec(paramName)[1];
            obj[key][index] = paramValue;
          } else {
            obj[key].push(paramValue);
          }
        } else {
          if (!obj[paramName]) {
            // if it doesn't exist, create property
            obj[paramName] = paramValue;
          } else if (obj[paramName] && typeof obj[paramName] === 'string') {
            // if property does exist and it's a string, convert it to an array
            obj[paramName] = [obj[paramName]];
            obj[paramName].push(paramValue);
          } else {
            // otherwise add the property
            obj[paramName].push(paramValue);
          }
        }
      }
    }

    return obj;
  }

  public async getNextPage(key: string, params: ApiCallParamsBase): Promise<BaseResponse> {
    let obj = this;
    return new Promise((resolve, reject) => {
      if (!obj.nextCallMap[key]) {
        reject('could not find call');
      }
      let callParams: CallParams = {
        url: obj.nextCallMap[key].url,
        headers: obj.nextCallMap[key].headers,
        auth: obj.nextCallMap[key].auth,
        xAuthorization: obj.nextCallMap[key].xAuthorization,
        errorHandlerParam: params.errorHandlerParam,
        successHandlerParam: params.successHandlerParam,
        precallHandlerParam: params.precallHandlerParam,
        numberOfRetries: params.numberOfRetries,
        allowedStatusCodes: obj.nextCallMap[key].allowedStatusCodes,
        method: obj.nextCallMap[key].method,
        isNextPage: true,
        queryParamsOrigNextPage: obj.nextCallMap[key].queryParams,
        apiFailureSource: obj.nextCallMap[key].apiFailureSource,
        sortBy: null
      };

      const origUrl = obj.nextCallMap[key].origUrl;
      const url = obj.nextCallMap[key].url;
      const origParams = obj.nextCallMap[key].queryParams;

      /* let index = callParams.url.indexOf("_getpages=");
      index += "_getpages=".length;
      callParams.url =
        callParams.url.substr(0, index) +
        "ffff" +
        callParams.url.substr(index + 4);*/

      obj
        .call(callParams)
        .then(res => {
          delete obj.nextCallMap[key];
          resolve(res);
        })
        .catch(err => {
          callParams.url = origUrl;
          callParams.queryParams = { ...origParams };
          const urlParams = this.getQueryParamsFromUrl(url);
          callParams.queryParams['_count'] = urlParams['_count'];
          callParams.queryParams['_getpagesoffset'] = urlParams['_getpagesoffset'];
          obj
            .call(callParams)
            .then(res => {
              delete obj.nextCallMap[key];
              resolve(res);
            })
            .catch(err => {
              reject(err);
            });
        });
    });
  }

  protected async call(params: CallParams): Promise<BaseResponse> {
    const {
      url,
      method,
      headers = {},
      queryParams,
      queryParamsOrigNextPage,
      auth,
      xAuthorization,
      callScopeAuthToken,
      allowedStatusCodes,
      numberOfRetries = 1,
      apiFailureSource,
      isNextPage,
      sortBy
    } = params;

    let callKey = url + new Date().getTime().toString();
    if (this.apiConfigProvider().precallHandler) {
      this.apiConfigProvider().precallHandler(params);
    }

    const queryParamsUpdated = {
      ...queryParams,
      ...(params.includeUserId && IocContainer.get<DelegateStore>(IocTypes.DelegateStore).selectedDelegateId
        ? {
            'user-id': IocContainer.get<DelegateStore>(IocTypes.DelegateStore).selectedDelegateId
          }
        : null),
      ...(sortBy ? { _sort: (sortBy.descending ? '-' : '') + sortBy.fieldName } : null)
    };

    IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).clearError(apiFailureSource);
    try {
      if (auth) {
        const authToken = callScopeAuthToken || IocContainer.get<AuthProvider>(IocTypes.AuthProvider)();
        if (authToken && authToken.length > 0) {
          headers['Authorization'] = `Bearer ${authToken}`;
        }
      }
      if (xAuthorization) {
        const authToken = callScopeAuthToken || IocContainer.get<AuthProvider>(IocTypes.AuthProvider)();
        if (authToken && authToken.length > 0) {
          headers['X-Authorization'] = `${authToken}`;
        }
      }
      this.instance.defaults.baseURL = this.apiConfigProvider().baseUrl;
      this.instance.defaults.headers = {
        ...this.defaultHeaders,
        ...this.apiConfigProvider().headers
      };

      let numberOfRetriesLeft = numberOfRetries;
      let retryNeeded = false;
      let ret = null;

      do {
        retryNeeded = false;
        numberOfRetriesLeft--;
        try {
          ret = await this.instance({
            url: url,
            method: method,
            headers: headers,
            params: queryParamsUpdated,
            data: params.data
          });
        } catch (exception) {
          console.error('call failed', exception);

          if (numberOfRetriesLeft > 0) {
            retryNeeded = true;
          } else {
            throw exception;
          }
        }
      } while (retryNeeded);

      let nextUrl = BaseApi.getNextPageUrl(ret.data);

      if (nextUrl) {
        this.nextCallMap[callKey] = {
          origUrl: url.substr(0, url.indexOf('?') != -1 ? url.indexOf('?') : url.length),
          url: nextUrl,
          auth: auth,
          headers: headers,
          method: method,
          xAuthorization: xAuthorization,
          allowedStatusCodes: allowedStatusCodes,
          queryParams: {
            ...queryParamsUpdated,
            ...(queryParamsOrigNextPage ? queryParamsOrigNextPage : {})
          },
          apiFailureSource: apiFailureSource
        };
      }

      const res: BaseResponse = {
        status: ret.status,
        statusText: ret.statusText,
        data: ret.data,
        nextPageKey: nextUrl ? callKey : null
      };
      if (this.apiConfigProvider().successHandler) {
        this.apiConfigProvider().successHandler(res, params.successHandlerParam);
      }
      return res;
    } catch (error) {
      console.log('error', error);
      let statusCode = 999;
      let message = '';
      let responseData = {};

      if (error.response) {
        statusCode = error.response.status ? error.response.status : 500;
        message = error.response.statusText ? error.response.statusText : '';
        error.response.data && (responseData = error.response.data);
      } else if (error.request) {
        statusCode = 500;
        message = 'Internal Error. The request was made but no response was received';
      } else {
        statusCode = 500;
        message = error.message ? error.message : 'Something happened in setting up the request that triggered an Error';
      }

      if (!error.response) {
        const connRes = await this.checkConnection();
        if (!connRes) {
          statusCode = HTTP_STATUS_CODES.NO_INTERNET;
          message = '';
        }
      }
      IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).setError(apiFailureSource, statusCode, isNextPage);

      if (statusCode != HTTP_STATUS_CODES.NO_INTERNET) {
        IocContainer.get<ErrorStoreType>(IocTypes.ErrorStore).setError(apiFailureSource, statusCode, isNextPage);
      }

      const apiError = new ApiError(statusCode, message, responseData);
      let statusCodeAllowed = false;
      allowedStatusCodes.forEach(code => {
        if (code == statusCode) {
          statusCodeAllowed = true;
        }
      });
      if (statusCodeAllowed && this.apiConfigProvider().errorHandler) {
        return this.apiConfigProvider().errorHandler(apiError, params.errorHandlerParam);
      } else {
        throw apiError;
      }
    }
  }

  public static isNextPageAvailable(data: any) {
    let ret = false;
    if (data.link && Array.isArray(data.link)) {
      data.link.forEach(elem => {
        if (elem.relation && elem.relation == 'next') {
          ret = true;
        }
      });
    }
    return ret;
  }

  public static getNextPageUrl(data: any) {
    let ret = null;
    if (data.link && Array.isArray(data.link)) {
      data.link.forEach(elem => {
        if (elem.relation && elem.relation == 'next') {
          ret = elem.url;
        }
      });
    }

    return ret;
  }
}
