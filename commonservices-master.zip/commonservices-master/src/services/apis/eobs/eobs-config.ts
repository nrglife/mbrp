import { ApiConfigBase } from "../base-config";

export interface EobsApiConfig extends ApiConfigBase{
    maxEobs:number
  }
  