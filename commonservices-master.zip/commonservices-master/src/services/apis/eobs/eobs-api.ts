import { injectable } from "inversify";
import { IocContainer, IocTypes } from "../../../inversify.config";
import { failureSource } from "../../../utilities/consts/failureSource";
import {
  ApiCallParamsBase,
  BaseApi,
  HTTP_STATUS_CODES,
  Method,
} from "../base-api";
import { ApiConfigProviderSpecific } from "../base-config";
import { EobsApiConfig } from "./eobs-config";

export interface EOBSapiGetExplanationOfBenefitParams
  extends ApiCallParamsBase {
  withIncluded: boolean;
}
@injectable()
export class EOBSapi extends BaseApi<EobsApiConfig> {
  constructor(
    defaultHeaders: object,
    apiConfigProvider: ApiConfigProviderSpecific<EobsApiConfig>
  ) {
    super(
      { "Content-Type": "application/json", Accept: "application/json" },
      apiConfigProvider
    );
  }

  public getExplanationOfBenefit(params: EOBSapiGetExplanationOfBenefitParams) {
    return this.call({
      sortBy: params.sortBy,
      url: "/ExplanationOfBenefit",
      isNextPage: false,
      apiFailureSource: failureSource.EOB_Get,
      method: Method.GET,
      queryParams: params.withIncluded
        ? {
            _include: [
              "ExplanationOfBenefit:patient",
              "ExplanationOfBenefit:care-team",
              "ExplanationOfBenefit:provider",
              "ExplanationOfBenefit:facility",
            ],
            _count: this.apiConfigProvider().maxEobs,
          }
        : null,
      auth: true,
      includeUserId: true,
      successHandlerParam: params.successHandlerParam,
      errorHandlerParam: params.errorHandlerParam,
      precallHandlerParam: params.precallHandlerParam,

      allowedStatusCodes: [
        HTTP_STATUS_CODES.SUCCESS,
        HTTP_STATUS_CODES.INVALID_LOCKED,
        HTTP_STATUS_CODES.BAD_REQUEST,
        HTTP_STATUS_CODES.UNAUTHORIZED,
        HTTP_STATUS_CODES.SERVER_TIMEOUT,
        HTTP_STATUS_CODES.CONFLICT,
        HTTP_STATUS_CODES.EXCEEDED_ATTEMPTS,
        HTTP_STATUS_CODES.NOT_FOUND,
        HTTP_STATUS_CODES.MISSING_INFO,
        HTTP_STATUS_CODES.ALREADY_IN_USE,
        HTTP_STATUS_CODES.SERVER_ERROR,
        HTTP_STATUS_CODES.TIME_OUT,
        HTTP_STATUS_CODES.RECAPTCHA_SERVER_ERROR,
        HTTP_STATUS_CODES.MEMBER_ALREADY_ENROLLED,
      ],
    });
  }
}
