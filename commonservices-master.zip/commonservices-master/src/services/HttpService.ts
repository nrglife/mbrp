export interface IHttpService {
    get: (url: string, customizeHeaders?: object, ciamToken?: string | null) => Promise<any>;    
    post : (url: string, data: object, customizeHeaders: object, ciamToken: string | null) => Promise<any>;
}