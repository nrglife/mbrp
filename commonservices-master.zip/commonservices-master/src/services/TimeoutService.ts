import { injectable } from "inversify";
export interface ITimeoutService {
  addTimeout: (timeoutGroup: string, timeoutId: NodeJS.Timeout) => void;
  setTimeout: (
    timeoutGroup: string,
    callback: () => void,
    time?: number
  ) => NodeJS.Timeout;
  isTimeoutGroupExists: (timeoutGroup: string) => boolean;
  isTimeoutIdExists: (
    timeoutGroup: string,
    timeoutId: NodeJS.Timeout
  ) => boolean;
  clearTimeout: (timeoutGroup: string, timeoutId: NodeJS.Timeout) => void;
  clearAllTimeoutsByGroup: (timeoutGroup: string) => void;
  clearAllTimeouts: () => void;
}

interface ITimeouts {
  [key: string]: NodeJS.Timeout[];
}
@injectable()
class TimeoutService implements ITimeoutService {
  private timeouts: ITimeouts = {};

  constructor() {}

  isTimeoutGroupExists(timeoutGroup: string) {
    return Object.keys(this.timeouts).indexOf(timeoutGroup) !== -1;
  }

  addTimeout(timeoutGroup: string, timeoutId: NodeJS.Timeout) {
    if (this.isTimeoutGroupExists(timeoutGroup)) {
      if (this.isTimeoutIdExists(timeoutGroup, timeoutId)) {
        this.clearTimeout(timeoutGroup, timeoutId);
      }
      this.timeouts[timeoutGroup].push(timeoutId);
    } else {
      this.timeouts[timeoutGroup] = [timeoutId];
    }
  }

  setTimeout(
    timeoutGroup: string,
    callback: () => void,
    time: number = 0
  ): NodeJS.Timeout {
    const timeoutId = setTimeout(() => {
      callback();

      this.clearTimeout(timeoutGroup, timeoutId);
    }, time);

    this.addTimeout(timeoutGroup, timeoutId);

    return timeoutId;
  }

  isTimeoutIdExists(timeoutGroup: string, timeoutId: NodeJS.Timeout) {
    let isThere = false;
    if (this.isTimeoutGroupExists(timeoutGroup)) {
      isThere =
        this.timeouts[timeoutGroup].length > 0 &&
        this.timeouts[timeoutGroup].indexOf(timeoutId) !== -1;
    }
    return isThere;
  }

  clearTimeout(timeoutGroup: string, timeoutId: NodeJS.Timeout) {
    if (
      this.isTimeoutGroupExists(timeoutGroup) &&
      this.isTimeoutIdExists(timeoutGroup, timeoutId)
    ) {
      const indexOfTimeoutIdToClear = this.timeouts[timeoutGroup].indexOf(
        timeoutId
      );
      if (indexOfTimeoutIdToClear !== -1) {
        clearTimeout(this.timeouts[timeoutGroup][indexOfTimeoutIdToClear]);
        this.timeouts[timeoutGroup] = this.timeouts[timeoutGroup].filter(
          (id) => id !== timeoutId
        );

        if (this.timeouts[timeoutGroup].length === 0) {
          delete this.timeouts[timeoutGroup];
        }
      }
    }
  }

  clearAllTimeoutsByGroup(timeoutGroup: string) {
    if (this.isTimeoutGroupExists(timeoutGroup))
      this.timeouts[timeoutGroup].forEach((key: NodeJS.Timeout, _) => {
        this.clearTimeout(timeoutGroup, key);
      });
  }

  clearAllTimeouts() {
    Object.keys(this.timeouts).forEach((group: string, _) => {
      this.clearAllTimeoutsByGroup(group);
    });
  }
}

export default new TimeoutService();
export { TimeoutService as TimeoutServiceType };
