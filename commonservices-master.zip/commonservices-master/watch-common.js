const fs = require("fs");
const fse = require("fs-extra");
const path = require("path");
const { spawn } = require("child_process");

let rebuildInProgress = false

const CurrentWatchedDirectoryLocation = __dirname;
const packageName = "connected-health-common-services";
const targetProjectNames = ["web-enrollment-poc", "connectedhealthapp"];
const targetProjectPackageLocations = targetProjectNames.map((targetProjectName) =>
  path.join(
    __dirname,
    "..",
    targetProjectName,
    "node_modules",
    "@healthcareapp",
    packageName)
);

const flatten = (lists) => {
  return lists.reduce((a, b) => a.concat(b), []);
};

//get paths to all dirs in src_path (not the sub dirs - only the ones that in the first level - located at src_path)
const getDirectories = (src_path) => {
  return fs
    .readdirSync(src_path)
    .map((file) => path.join(src_path, file))
    .filter((path) => fs.statSync(path).isDirectory());
};

//get paths to all sub dirs in src_path
const getDirectoriesRecursive = (src_path) => {
  return [
    src_path,
    ...flatten(getDirectories(src_path).map(getDirectoriesRecursive)),
  ];
};

//filter dirs for the ones that needed to be watch
const dirsForWatch = getDirectoriesRecursive(CurrentWatchedDirectoryLocation).filter(
  (dir) =>
    dir.indexOf(".git") === -1 &&
    dir.indexOf("node_modules") === -1 &&
    dir.indexOf("dist") === -1
);

const buildCommonPackage = () => {
  return new Promise((resolve, reject) => {
    try {
      console.log("\x1b[34m", `try removing old build at dist folder`);
      const nodeVersion = process.version.replace("v", "").split(".")[0];
      parseInt(nodeVersion) >= 12
        ? fs.rmdirSync(path.join(__dirname, "dist"), { recursive: true })
        : fse.remove(path.join(__dirname, "dist"));
      console.log("\x1b[32m", `dist folder was removed successfully`);
      console.log("\x1b[34m", `start create new build`);
      const sp = spawn("npm", ["run", "build"]);

      sp.stdout.on("data", (data) => {
        console.log(` stdout: ${data}`);
      });

      sp.stderr.on("data", (data) => {
        console.log(` stderr: ${data}`);
      });

      sp.on("error", (error) => {
        console.log(`error: ${error.message}`);
      });

      sp.on("close", (code) => {
        console.log("\x1b[34m", `child process exited with code ${code}`);
        if (code === 0) {
          console.log("\x1b[32m", `create new build finished successfully`);
          resolve()
        } else {
          reject()
        }

      })
    } catch (error) {
      console.log("\x1b[31m", `error: ${error}`);
    }
  })

};

//copy the dist package to location in our project node_modules we specify in
const copyNewCommonPackageDistToProjectLocation = () => {
  console.log("\x1b[34m", `start replace ${packageName} dist`);

  try {
    targetProjectPackageLocations.forEach(targetProjectPackageLocation => {

      const targetDirectory = path.join(targetProjectPackageLocation, "dist");
      const sourceDirectory = path.join(CurrentWatchedDirectoryLocation, "dist");

      console.log(
        "\x1b[34m",
        `try removing old dist from ${targetProjectPackageLocation}`
      );
      const nodeVersion = process.version.replace("v", "").split(".")[0];
      parseInt(nodeVersion) >= 12
        ? fs.rmdirSync(path.join(targetDirectory, "dist"), { recursive: true })
        : fse.removeSync(path.join(targetDirectory, "dist"));
      console.log("\x1b[32m", `${packageName} dist was removed successfully`);
      console.log(
        "\x1b[34m",
        `try copying new dist folder to ${packageName} at node_modules`
      );
      fse.copySync(sourceDirectory, targetDirectory, { overwrite: true });
      console.log("\x1b[32m", `${packageName} dist copy new dist successfully`);

    });


  } catch (error) {
    console.log("\x1b[31m", `error: ${error}`);
  }
};

//implement watch action on the filtered dirs needed to be watch

for (const dir of dirsForWatch) {
  console.log("\x1b[32m", `Watching for file changes on ${dir} dirctory`);
  fs.watch(dir, (event, filename) => {
    if (filename) {
      if (rebuildInProgress) {
        return;
      }
      rebuildInProgress = true;

      console.log("\x1b[33m", `\n${filename} file Changed\n`);
      buildCommonPackage().then(() => {
        copyNewCommonPackageDistToProjectLocation();
      }).finally(() => {
        rebuildInProgress = false
      })
    }
  });
}

console.log("");
