var shell = require('shelljs');

shell.rm('-R', 'dist/misc');
shell.cp('-R', 'src/misc', 'dist/misc');
