import { install } from "source-map-support";

import { ExplanationOfBenefitController } from "./controllers/explanationOfBenefit.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const explanationOfBenefit = createHandler(
    ExplanationOfBenefitController.getExplanationOfBenefit
);
