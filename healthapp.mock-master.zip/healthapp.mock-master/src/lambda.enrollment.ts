import { install } from "source-map-support";

import { EnrollmentController } from "./controllers/enrollment.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const postUserData = createHandler(EnrollmentController.postUserData);

export const postInvitationCodeOtp = createHandler(EnrollmentController.postInvitationCodeOtp);

export const postInvitationCodeAndPasscodeOtp = createHandler(EnrollmentController.postInvitationCodeAndPasscodeOtp);

export const postInvitationVerificationEmail = createHandler(EnrollmentController.postInvitationVerificationEmail);

export const postIdentity = createHandler(EnrollmentController.postIdentity);

export const postSetPassword = createHandler(EnrollmentController.postSetPassword)