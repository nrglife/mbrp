import { install } from "source-map-support";

import { TrueViewController } from "./controllers/trueview.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const searchProviderServiceGroups = createHandler(TrueViewController.searchProviderServiceGroups);
export const searchProviders = createHandler(TrueViewController.searchProviders);
export const searchPrescriptions = createHandler(TrueViewController.searchPrescriptions);
export const getProviderServiceGroups = createHandler(TrueViewController.getProviderServiceGroups);
export const getMedicationCosts = createHandler(TrueViewController.getMedicationCosts);


