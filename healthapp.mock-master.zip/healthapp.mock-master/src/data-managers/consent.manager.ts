import { MainDataManager } from "./data-manager-helpers";

const CONSENT_PATH = "/consentApi/consent";

export class ConsentManager extends MainDataManager {
  public updateConsent(data: any) {
    const { consentFlag } = data;

    this.write(CONSENT_PATH, {
      consentFlag,
      consentedAt: new Date().toISOString(),
    });
  }
}
