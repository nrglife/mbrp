export interface IDataManager {
  read(path: string, params?: { [name: string]: string } | null): any;
  write(path: string, data: any): boolean;
  checkHttpSettings(urlPath: string, httpMethod: string): any;
}
