import { MainDataManager } from "./data-manager-helpers";

const PLAN_BENEFITS_PATH = "/apigee/plan_benefits";
export class PlanBenefitsManager extends MainDataManager {
    public getPlanBenefits(externalMemberId: string) {
        return this.read(`${PLAN_BENEFITS_PATH}/${externalMemberId}`);
    }
}
