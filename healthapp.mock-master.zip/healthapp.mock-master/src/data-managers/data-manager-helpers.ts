import { IDataManager } from "./data-manager";
import { FSDataManager } from "./fs-data-manager";

export const MainDataManager: new () => IDataManager = FSDataManager;
