import { MainDataManager } from "./data-manager-helpers";
import {AppError, AppErrorWithData} from "../models/app-error";

const ENROLLMENT_PATH = "/apigee/enrollmentApi/invitation";

export class EnrollmentManager extends MainDataManager {

  public checkHeaders(path: string,headers: any) {

    const tokenJson = this.read('/apip/auth/v2/token');

    if (headers.Authorization !== `Bearer ${tokenJson['access_token']}`) {
      throw new AppErrorWithData(
          new AppError(401, ""),
          "Missing or incorrect required header, Authorization"
      );
    }
    if (path.match(/\/apigee\/enrollmentApi\/invitation\/[0-9-]*\/identity$/)
        || path.match(/\/apigee\/enrollmentApi\/invitation\/[0-9-]*\/password\/[0-9-]*$/)) {
      if (headers['X-Ciam-Api-Token'] !== tokenJson['access_token']) {
        throw new AppErrorWithData(
            new AppError(401, ""),
            "Missing or incorrect required header, X-Ciam-Api-Token"
        );
      }
    }
    if (headers['Content-Type'] !== 'application/json') {
      throw new AppErrorWithData(
          new AppError(400, ""),
          "Missing or incorrect required header, Content-Type"
      );
    }
  }

  public postUserData(invitationCode: string) {
    return this.read(
      `${ENROLLMENT_PATH}/${invitationCode}/post/${invitationCode}`
    );
  }

  public postInvitationCodeOtp(invitationCode: string) {
    return this.read(`${ENROLLMENT_PATH}/${invitationCode}/otp`);
  }

  public postInvitationCodeAndPasscodeOtp(
    invitationCode: string,
    passcode: string
  ) {
    return this.read(`${ENROLLMENT_PATH}/${invitationCode}/otp/${passcode}`);
  }


  public postIdentity(
      invitationCode: string,
      body: string
  ) {
    return this.read(`${ENROLLMENT_PATH}/${invitationCode}/identity`);
  }

  public postSetPassword(
      invitationCode: string,
      userId: string,
      body: string
  ) {
    return this.read(`${ENROLLMENT_PATH}/${invitationCode}/password/${userId}`);
  }


  public postInvitationVerificationEmailSchema(
      invitationCode: string,
      body: string
  ) {
    return this.read(`${ENROLLMENT_PATH}/${invitationCode}/email`);
  }
}
