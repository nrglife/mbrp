import { AppError } from "../models/app-error";
import { IDataManager } from "./data-manager";

interface IInMemoryData {
  [path: string]: any;
}

export class InMemoryDataManager implements IDataManager {
  public data: IInMemoryData = {
    "obligationsApi/obligations": {
      grandTotalNetDue: "506.21",
      grandTotalPastDue: "76.54",
      pastDueDaySetting: 30,
      obligations: [
        {
          id: "obl1",
          name: "Obligation",
        },
      ],
    },
    "obligationsApi/obligations/obligationId": {
      id: "obl1",
      name: "Obligation",
    },
  };

  public checkHttpSettings() {}

  public read(path: string) {
    if (path.charAt(0) === "/") {
      path = path.substring(1);
    }

    const data = this.data[path];

    if (!data) {
      throw AppError.ObjectDoesNotExist;
    }

    return data;
  }

  public write(path: string, data: any) {
    return true;
  }
}
