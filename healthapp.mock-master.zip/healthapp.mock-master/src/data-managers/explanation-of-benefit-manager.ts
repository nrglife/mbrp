import { MainDataManager } from "./data-manager-helpers";

const PLAN_BENEFITS_PATH = "/CMSPatientAccess/explanationofbenefit/v1/eob";
export class ExplanationOfBenefitManager extends MainDataManager {
    public getExplanationOfBenefit() {
        return this.read(`${PLAN_BENEFITS_PATH}`);
    }
}
