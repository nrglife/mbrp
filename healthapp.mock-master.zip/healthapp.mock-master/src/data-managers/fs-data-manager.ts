import fs from "fs";
import pathPackage from "path";
import { AppError, AppErrorWithData } from "../models/app-error";
import { IDataManager } from "./data-manager";

const httpSettingsPath = "mock-db/httpSettings.json";
const successCode = 200;
const createdCode = 201;

export class FSDataManager implements IDataManager {
  // check in httpSettings.json if the requsetis needed to failed by specific error
  // for ex - "/consentApi/healthcheck": {"code": 404, "type": "GET"}
  // for ex - "/consentApi/healthcheck": {"code": 500, "type": "POST"}
  public async checkHttpSettings(urlPath: string, httpMethod: string) {
    // key for the json
    const key = urlPath.trim();
    const filePath = pathPackage.resolve(
      pathPackage.normalize(httpSettingsPath)
    );

    // check setting json exist
    if (!fs.existsSync(filePath)) {
      throw new AppErrorWithData(
        AppError.ObjectDoesNotExist,
        `httpSettings.json dosn't exist at ${httpSettingsPath}`
      );
    }

    const json = fs.readFileSync(filePath, { encoding: "utf-8" });
    let settings = null;

    try {
      settings = JSON.parse(json);
    } catch (e) {
      throw new AppErrorWithData(
        AppError.ErrorPerformingAction,
        `httpSettings.json format isn't correct, please check the file at ${httpSettingsPath}`
      );
    }

    //check if needed to "wait" for the server
    settings &&
      settings[key] &&
      settings[key].sleep &&
      !isNaN(settings[key].sleep) &&
      (await this.sleep(Number(settings[key].sleep)));

    //check if needed to mock error form the server
    if (
      settings &&
      settings[key] &&
      settings[key].code !== successCode &&
      //TODO oreng: maybe is better to check code between 200 to 299 (success) as function
      settings[key].code !== createdCode &&
      settings[key].type === httpMethod
    ) {
      throw new AppErrorWithData(
        new AppError(settings[key].code, ""),
        settings[key].body
      );
    }

    if (settings && settings[key] && settings[key].code) {
      return settings[key].code;
    }
    //return success
    return successCode;
  }

  private sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  public read(urlPath: string, params?: { [name: string]: string } | null) {
    if (
      params &&
      params._getpagesoffset != undefined &&
      params._getpagesoffset != "0"
    ) {
      urlPath += "_" + params._getpagesoffset;
    }

    const filePath = pathPackage.resolve(
      pathPackage.normalize(`mock-db${urlPath}.json`)
    );

    if (fs.existsSync(filePath)) {
      const json = fs.readFileSync(filePath, { encoding: "utf-8" });
      let data = null;

      try {
        data = JSON.parse(json);
      } catch (e) {
        throw new AppErrorWithData(AppError.ErrorPerformingAction, e);
      }
      return data;
    } else {
      throw AppError.ObjectDoesNotExist;
    }
  }

  public write(path: string, data: any) {
    const filePath = pathPackage.resolve(
      pathPackage.normalize(`mock-db${path}.json`)
    );

    data = JSON.stringify(data, null, 2);

    fs.writeFileSync(filePath, data, { encoding: "utf-8" });

    return true;
  }
}
