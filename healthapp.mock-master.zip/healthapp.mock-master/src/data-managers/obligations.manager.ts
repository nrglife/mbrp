import { MainDataManager } from "./data-manager-helpers";

const OBLIGATIONS_PATH = "/apigee/consumerView/v1/obligations";

export class ObligationsManager extends MainDataManager {
  public updateObligationStates(data: any) {
    try {
      const allObligations = this.read(`${OBLIGATIONS_PATH}`);

      if (allObligations && allObligations.obligations) {
        allObligations.obligations.forEach((obligation: any) => {
          if (obligation.obligationId === data.obligationId) {
            Object.assign(obligation, data);
          }
        });

        this.write(OBLIGATIONS_PATH, allObligations);
      }
    } catch (e) {}

    try {
      const obligationByIdPath = `${OBLIGATIONS_PATH}/${data.obligationId}`;
      const obligationById = this.read(obligationByIdPath);

      Object.assign(obligationById, data);

      this.write(obligationByIdPath, obligationById);
    } catch (e) {}
  }
}
