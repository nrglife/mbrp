import { MainDataManager } from "./data-manager-helpers";

const TRUEVIEW_SEARCH_PATH = "/apigee/trueViewApi/search";
const TRUEVIEW_PROVIDER_SERVICE_GROUPS_PATH = "/apigee/trueViewApi/providerServiceGroups"
const TRUEVIEW_MEDICATIONS_PATH = "/apigee/trueViewApi/rxBrands"

export class TrueViewManager extends MainDataManager {

    public searchProviderServiceGroups(query: string, page:string) {
        return this.read(`${TRUEVIEW_SEARCH_PATH}/${query}/services/${page}`);
    }

    public searchProviders(query: string, page:string) {
        console.log("get data from:" ,`${TRUEVIEW_SEARCH_PATH}/${query}/providers/${page}`);
        return this.read(`${TRUEVIEW_SEARCH_PATH}/${query}/providers/${page}`);
    }

    public searchPrescriptions(query: string, page:string) {
        return this.read(`${TRUEVIEW_SEARCH_PATH}/${query}/rxbrands/${page}`);
    }

    public getProviderServiceGroups(serviceGroupId: string, specialty:string, ratingFilter:string, reviewFilter:string) {  

      let ratingFilterValue = (ratingFilter && ratingFilter !="-1") ? ratingFilter:"None";
      let reviewFilterValue = ( reviewFilter && reviewFilter!="-1") ? reviewFilter:"None";
      let serviceApi= `${TRUEVIEW_PROVIDER_SERVICE_GROUPS_PATH}/${serviceGroupId}`;
      let ratingApi = `/reviewFilter_ratingFilter/${reviewFilterValue}_${ratingFilterValue}`;


    
        if (!specialty){
            let path= serviceApi +`/costs`;
            if (ratingFilterValue != "None" ||  reviewFilterValue != "None"){
                path = serviceApi + ratingApi +`/costs`;
            }
            
            console.log("get data from:" ,path);
            return this.read(path);
        }
        else {
            
            let path = serviceApi +`/Specialty/${specialty}/costs`;
            if (ratingFilterValue != "None" ||  reviewFilterValue != "None"){
                path = serviceApi + `/Specialty/${specialty}` + ratingApi +`/costs`;
            }
            console.log("get data from:" ,path);
            return this.read(path);
        }
    }
    public getMedicationCosts(rxBrandId:string,rxDosageId:string,quantity:string,frequency:string) {  

        let path= `${TRUEVIEW_MEDICATIONS_PATH}/${rxBrandId}/dosages/${rxDosageId}_${quantity}_${frequency}/costs`;
       
        console.log("get data from:" ,path);
        return this.read(path);
     
      }

    
  
}
