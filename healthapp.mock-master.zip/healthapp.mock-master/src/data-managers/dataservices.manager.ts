import { MainDataManager } from "./data-manager-helpers";

const DATASERVICES_PATH = "/anon/dataservices/payerservice/v1/payerconfig";

export class DataServicesManager extends MainDataManager {
  public getPayerConfigByName(payerName: string) {
    if (payerName) {
      return this.read(`${DATASERVICES_PATH}/${payerName}`);
    }
    return this.read(`${DATASERVICES_PATH}`);
  }
}
