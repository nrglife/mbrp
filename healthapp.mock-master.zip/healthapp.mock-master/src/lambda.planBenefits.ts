import { install } from "source-map-support";

import { PlanBenefitsController } from "./controllers/planBenefits.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const planBenefits = createHandler(
    PlanBenefitsController.getPlanBenefits
);
