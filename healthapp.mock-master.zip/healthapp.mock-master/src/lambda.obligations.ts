import { install } from "source-map-support";

import { ObligationsController } from "./controllers/obligations.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const obligationStates = createHandler(
  ObligationsController.updateObligationStates
);
