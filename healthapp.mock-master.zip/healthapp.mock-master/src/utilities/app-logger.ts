enum LogLevel {
  Error = "error",
  Warning = "warning",
  Info = "info",
  Debug = "debug",
}

export class AppLogger {
  public static instance: AppLogger = null;

  private traceId: string = "";
  private memberId: string = "";

  constructor() {
    if (!AppLogger.instance) {
      AppLogger.instance = this;
    }

    return AppLogger.instance;
  }

  public setTraceId(traceId: string) {
    this.traceId = traceId || this.traceId;
  }

  public setMemberId(memberId: string) {
    this.memberId = memberId || this.memberId;
  }

  public info(message?: string, data?: any) {
    switch (process.env.logLevel) {
      case LogLevel.Debug:
      case LogLevel.Info:
        this.log(message, data, LogLevel.Info);
    }
  }

  public warning(message?: string, data?: any) {
    switch (process.env.logLevel) {
      case LogLevel.Debug:
      case LogLevel.Info:
      case LogLevel.Warning:
        this.log(message, data, LogLevel.Warning);
    }
  }

  public error(message?: string, data?: any) {
    this.log(message, data, LogLevel.Error);
  }

  public debug(message?: string, data?: any) {
    if (process.env.logLevel === LogLevel.Debug) {
      this.log(message, data, LogLevel.Debug);
    }
  }

  public log(
    message?: string,
    data?: any,
    level: LogLevel = process.env.logLevel as LogLevel
  ) {
    console.log(
      `\x1b[36mHEALTHAPP.SVC - ${new Date().toISOString()} - ${level.toUpperCase()}\x1b[37m`
    );

    switch (level.toLowerCase()) {
      case LogLevel.Info:
      case LogLevel.Debug:
        data
          ? (console.log(message), console.log(this.stringifyData(data)))
          : console.log(message);
        break;
      case LogLevel.Warning:
        data
          ? (console.warn(message), console.warn(this.stringifyData(data)))
          : console.warn(message);
        break;
      case LogLevel.Error:
        data
          ? (console.error(message), console.error(this.stringifyData(data)))
          : console.error(message);
        break;
      default:
        data
          ? (console.log(message), console.log(this.stringifyData(data)))
          : console.log(message);
    }
  }

  private stringifyData(data: any) {
    let stringified = null;

    try {
      stringified = JSON.stringify(data);
    } catch (e) {
      stringified = data.message ? data.message : JSON.stringify({});
    }

    return stringified;
  }
}

const appLogger = new AppLogger();

export default appLogger;
