import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import middy, { Middy } from "middy";
import {
  httpEventNormalizer,
  httpHeaderNormalizer,
  jsonBodyParser,
  validator
} from "middy/middlewares";

import {
  errorHandler,
  responseNormalizer
} from ".";

type LambdaEventHandlerArgs = [APIGatewayEvent, Context, Callback];

export const withCommonMiddlewares = (
  middyHandler: Middy<APIGatewayEvent, any>
) =>
  middyHandler
    .use(httpHeaderNormalizer())
    .use(jsonBodyParser())
    .use(httpEventNormalizer())
    .use(responseNormalizer())
    .use(errorHandler());

const withAuthorization = (middyHandler: Middy<APIGatewayEvent, any>) =>
  middyHandler;

const withValidator = (
  middyHandler: Middy<APIGatewayEvent, any>,
  inputSchema: any
) => middyHandler.use(validator({ inputSchema }));

export const createHandler = (
  controller: () => {
    handler: (
      event: APIGatewayEvent,
      context?: Context,
      callback?: Callback
    ) => any;
    inputSchema?: any;
  },
  isWithAuthorization = true
) => {
  const { handler, inputSchema } = controller();

  return (...args: LambdaEventHandlerArgs) => {
    let finalHandler = withCommonMiddlewares(middy(handler));

    if (inputSchema) {
      finalHandler = withValidator(finalHandler, inputSchema);
    }

    if (isWithAuthorization) {
      finalHandler = withAuthorization(finalHandler);
    }

    return finalHandler(...args);
  };
};
