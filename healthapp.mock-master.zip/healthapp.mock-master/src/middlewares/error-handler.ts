import { APIGatewayEvent } from "aws-lambda";
import { HttpError } from "http-errors";
import { HandlerLambda } from "middy";

import { AppError, AppErrorWithData, StatusCode } from "../models/app-error";
import appLogger from "../utilities/app-logger";

export class ErrorWithStatus extends Error {
  statusCode: number;
  meta: object;

  constructor(statusCode: number, errorDescription: string, meta: object) {
    super(errorDescription);
    this.statusCode = statusCode;
    this.meta = meta;
  }
}

export const errorHandler = () => {
  var isErrorWithStatus = (
    anError: Error | ErrorWithStatus
  ): anError is ErrorWithStatus => {
    return (anError as ErrorWithStatus).statusCode !== undefined;
  };

  return {
    onError: (handler: HandlerLambda<APIGatewayEvent>, next: any) => {
      const { event } = handler;

      if (event.httpMethod === "OPTIONS") {
        return next();
      }

      const e = handler.error;
      let error: AppError;
      let meta: any = null;

      if (e instanceof AppError) {
        error = e;
      } else if (e instanceof AppErrorWithData) {
        error = e.error;
        meta = e.data;
      } else if (e.name === "BadRequestError" && (e as HttpError).details) {
        error = AppError.RequestValidation;
        meta = (e as HttpError).details;
      } else if (e instanceof Error) {
        var appErrorWithData = new AppErrorWithData(
          new AppError(
            isErrorWithStatus(e)
              ? e.statusCode
              : StatusCode.InternalServerError,
            e.message
          ),
          isErrorWithStatus(e) ? e.meta : e.message
        );
        error = appErrorWithData.error;
        meta = appErrorWithData.data;
      } else {
        error = AppError.ErrorPerformingAction;

        if (!meta) {
          meta = e;
        }
      }

      appLogger.error(`System exception\n\t${event.path}\n`, e);

      //change message to exceptionMessage
      if (meta && meta.message) {
        meta.exceptionMessage = meta.message;
        delete meta.message;
      }

      handler.response = {
        statusCode: error.statusCode,
        body: JSON.stringify(meta),
      };

      next();
    },
  };
};
