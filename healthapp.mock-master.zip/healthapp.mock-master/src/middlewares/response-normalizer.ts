import { APIGatewayEvent, APIGatewayProxyEvent } from "aws-lambda";
import { HandlerLambda } from "middy";

export const responseNormalizer = () => ({
  after: (handler: HandlerLambda<APIGatewayEvent>, next: any) => {


    let statusCode = 200;
    if((<any>handler.response) && (<any>handler.response).statusCode)
    {
      statusCode = (<any>handler.response).statusCode;
      //we add this just for assign param and don't need to send is as data to user.
      delete (<any>handler.response).statusCode;
    }

    handler.response = {
      statusCode: statusCode, 
      body: JSON.stringify(handler.response),
    };

    next();
  },
});
