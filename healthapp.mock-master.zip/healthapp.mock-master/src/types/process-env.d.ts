// tslint:disable-next-line:no-namespace
declare namespace NodeJS {
  // tslint:disable-next-line:interface-name
  interface ProcessEnv {
    env: string;
    servicePort: string;
    logLevel: string;
    appName: string;
    baseUrl: string;
    IS_OFFLINE?: string;
  }
}
