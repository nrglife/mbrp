// tslint:disable-next-line:interface-name
declare interface Date {
    getAge: () => number;
}
