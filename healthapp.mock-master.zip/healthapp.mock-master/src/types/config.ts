export interface IConfiguration {
    servicePort: string;
    logLevel: string;
}
