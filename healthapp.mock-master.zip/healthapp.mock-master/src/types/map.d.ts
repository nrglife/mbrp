// tslint:disable-next-line:interface-name
declare interface Map<K, V> {
    toArray(): V[];
}
