declare class ObjectConstructor {
    public nullOrUndefined(object: any): boolean;
}
