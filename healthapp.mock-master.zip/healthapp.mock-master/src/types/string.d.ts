// tslint:disable-next-line:interface-name
declare interface String {
  isEmail(): boolean;

  toRegex(): RegExp;

  searchToRegex(removeSpecialCharacters?: boolean, start?: boolean, end?: boolean): RegExp;

  padStart(padWith: string, length: number): string;

  padEnd(padWith: string, length: number): string;

  parseJson(): any;

  isMongoId(): boolean;

  encodeHtml(): string;

  decodeHtml(): string;
}

// tslint:disable-next-line:interface-name
declare interface StringConstructor {
  emailRegex: RegExp;

  randomString(length?: number, includeLowercase?: boolean, includeUppercase?: boolean, includeDashes?: boolean, includeSpecialCharacters?: boolean): string;
  randomStringByCharacters(length?: number, allowedCharacters?: string): string;
}
