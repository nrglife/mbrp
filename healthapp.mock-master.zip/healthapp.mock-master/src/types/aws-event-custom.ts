// declare module "aws-lambda" {
//   // tslint:disable-next-line:interface-name
//   interface APIGatewayProxyEvent {
//   }
// }
