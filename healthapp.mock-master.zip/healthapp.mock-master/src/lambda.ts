import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { install } from "source-map-support";

import { HealthCheckController } from "./controllers/healthcheck.controller";
import { MainDataManager } from "./data-managers/data-manager-helpers";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const healthCheck = createHandler(
  HealthCheckController.performHealthCheck
);

export const genericGet = createHandler(() => ({
  handler: async (
    event: APIGatewayEvent,
    context: Context,
    callback: Callback
  ) => {
    const dataManager = new MainDataManager();

    await dataManager.checkHttpSettings(event.path, event.httpMethod);

    const response = dataManager.read(event.path, event.queryStringParameters);

    callback(null, response);
  },
}));

export const genericPost = createHandler(() => ({
  handler: async (
    event: APIGatewayEvent,
    context: Context,
    callback: Callback
  ) => {
    const dataManager = new MainDataManager();

    await dataManager.checkHttpSettings(event.path, event.httpMethod);

    const pathArray = event.path.split("/");
    const lastElment = pathArray.pop();
    const mockPostPath = [...pathArray, "post", lastElment].join("/");

    const response = dataManager.read(
      mockPostPath,
      event.queryStringParameters
    );

    callback(null, response);
  },
}));
