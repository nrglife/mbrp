export enum StatusCode {
  Success = 200,

  Created = 201,
  NoContent = 203,

  BadRequest = 400,
  Unauthorized = 401,
  Forbidden = 403,
  NotFound = 404,
  MethodNotAllowed = 405,
  Conflict = 409,
  Gone = 410,
  UnsupportedMediaType = 415,
  UpgradeRequired = 426,

  InternalServerError = 500,
  NotImplemented = 501,
  ServiceUnavailable = 503,
}

export class AppError {
  constructor(public statusCode: number, public errorDescription: string) {}

  public static Success = new AppError(StatusCode.Success, "Success");

  public static ErrorPerformingAction = new AppError(
    StatusCode.InternalServerError,
    "Error performing action"
  );

  public static NoData = new AppError(
    StatusCode.InternalServerError,
    "No data received from remote server"
  );

  public static ObjectDoesNotExist = new AppError(
    StatusCode.NotFound,
    "Object doesn't exist"
  );

  public static ObjectExists = new AppError(
    StatusCode.Conflict,
    "Object already exists"
  );

  public static NotAuthenticated = new AppError(
    StatusCode.Unauthorized,
    "Not authenticated/authorized"
  );

  public static Unauthorized = new AppError(
    StatusCode.Unauthorized,
    "Unauthorized"
  );

  public static RequestValidation = new AppError(
    StatusCode.BadRequest,
    "Request validation error"
  );

  public static ActionNotAllowed = new AppError(
    StatusCode.MethodNotAllowed,
    "Action is not allowed"
  );
}

// tslint:disable-next-line max-classes-per-file
export class AppErrorWithData {
  constructor(public error: AppError, public data: any) {}
}
