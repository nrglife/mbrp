import { install } from "source-map-support";

import { DataServicesController } from "./controllers/dataServices.controller";
import { createHandler } from "./middlewares/create-lambda-handler";

install();

export const getPayerConfigByName = createHandler(
    DataServicesController.getPayerConfigByName
);
