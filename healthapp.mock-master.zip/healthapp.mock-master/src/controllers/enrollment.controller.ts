import {APIGatewayEvent, Callback, Context} from "aws-lambda";
import {EnrollmentManager} from "../data-managers/enrollment.manager";
import {ErrorWithStatus} from "../middlewares/error-handler"
import {StatusCode} from "../models/app-error"

export class EnrollmentController {


    public static postUserData() {
        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const dm = new EnrollmentManager();
                await dm.checkHttpSettings(event.path, event.httpMethod);
                const invitationCode = event.pathParameters.invitationCode;
                const res = dm.postUserData(invitationCode);

                callback(null, res);
            },
        };
    }

    public static postSetPassword() {

        const inputSchema = {
            type: "object",
            properties: {
                body: {
                    type: "object",
                    properties: {
                        password: {
                            type: "string"
                        }
                    },
                    required: ['password'],
                    additionalProperties: false
                },
                pathParameters: {
                    type: "object",
                    properties: {
                        invitationCode: {
                            type: "string",
                        },
                        userId: {
                            type: "string",
                        },
                    },
                    required: ["invitationCode", "userId"],
                }
            },
            required: ['body']

        }


        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const dm = new EnrollmentManager();
                dm.checkHeaders(event.path, event.headers)
                await dm.checkHttpSettings(event.path, event.httpMethod);
                const res = dm.postSetPassword(
                    event.pathParameters.invitationCode,
                    event.pathParameters.userId,
                    event.body
                );

                callback(null, res);
            },
            inputSchema
        };

    }

    //THIS IS THE ONE
    public static postInvitationCodeOtp() {

        const inputSchema = {
            type: "object",
            properties: {
                body: {
                    type: "object",
                    properties: {
                        passCode: {
                            type: "string"
                        }
                    },
                    required: ['passCode'],
                    additionalProperties: false
                },
                pathParameters: {
                    type: "object",
                    properties: {
                        invitationCode: {
                            type: "string"
                        }
                    },
                    required: ["invitationCode"],
                },
            },
        };



        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const dm = new EnrollmentManager();
                dm.checkHeaders(event.path, event.headers)
                await dm.checkHttpSettings(event.path, event.httpMethod);
                const invitationCode = event.pathParameters.invitationCode;
                const res = dm.postInvitationCodeOtp(invitationCode);

                callback(null, res);
            },
            inputSchema
        };
    }


    public static postIdentity() {

        const inputSchema = {
            type: "object",
            properties: {
                body: {
                    type: "object",
                    properties: {
                        idp: {
                            type: "string",
                        },
                        ciamFederationId: {
                            type: "string",
                        },
                        token: {
                            type: "string",
                        },
                        emailOtp: {
                            type: "string",
                        }
                    },
                    required: ["idp", "ciamFederationId", "token", "emailOtp"],
                    additionalProperties: false
                },
                pathParameters: {
                    type: "object",
                    properties: {
                        invitationCode: {
                            type: "string",
                        },
                    },
                    required: ["invitationCode"],
                },
            },
        };


        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {


                const dm = new EnrollmentManager();
                dm.checkHeaders(event.path, event.headers)
                let statusCode = await dm.checkHttpSettings(event.path, event.httpMethod);

                const res = dm.postIdentity(
                    event.pathParameters.invitationCode,
                    event.body
                );
                res.statusCode = statusCode;    
                callback(null, res);
            },
            inputSchema
        };

    }

    public static postInvitationCodeAndPasscodeOtp() {

        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const dm = new EnrollmentManager();
                await dm.checkHttpSettings(event.path, event.httpMethod);
                const res = dm.postInvitationCodeAndPasscodeOtp(
                    event.pathParameters.invitationCode,
                    event.pathParameters.passcode
                );

                callback(null, res);
            }
        };
    }

    public static postInvitationVerificationEmail() {


        const postInvitationVerificationEmailSchema = {
            type: "object",
            properties: {
                body: {
                    type: "object",
                    properties: {
                        emailAddress: {
                            type: "string"
                        }
                    },
                    required: ['emailAddress'],
                    additionalProperties: false
                },
                pathParameters: {
                    type: "object",
                    properties: {
                        invitationCode: {
                            type: "string",
                        },
                    },
                    required: ["invitationCode"],
                }
            },
            required: ['body']
        }

        return {
            handler: async (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const dm = new EnrollmentManager();
                dm.checkHeaders(event.path, event.headers)
                await dm.checkHttpSettings(event.path, event.httpMethod);
                const res = dm.postInvitationVerificationEmailSchema(
                    event.pathParameters.invitationCode,
                    event.body
                );

                callback(null, res);
            },
            inputSchema: postInvitationVerificationEmailSchema

        };
    }
}
