import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { TrueViewManager } from "../data-managers/trueview.manager";

export class TrueViewController {
  public static searchProviderServiceGroups() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new TrueViewManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        const query = event.queryStringParameters.query;
        const page = event.queryStringParameters.page;
        const res = dm.searchProviderServiceGroups(query, page);

        callback(null, res);
      },
    };
  }

  public static searchProviders() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new TrueViewManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);
        const query = event.queryStringParameters.query;
        const page = event.queryStringParameters.page;
        const res = dm.searchProviders(query, page);

        callback(null, res);
      },
    };
  }

  public static searchPrescriptions() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new TrueViewManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        const query = event.queryStringParameters.query;
        const page = event.queryStringParameters.page;
        const res = dm.searchPrescriptions(query, page);

        callback(null, res);
      },
    };
  }

  public static getProviderServiceGroups() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new TrueViewManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        const serviceGroupId = event.pathParameters.serviceGroupId;
        const specialty = event.queryStringParameters.specialty;
        const ratingFilter = event.queryStringParameters.ratingFilter;
        const reviewFilter = event.queryStringParameters.reviewFilter;

        const res = dm.getProviderServiceGroups(
          serviceGroupId,
          specialty,
          ratingFilter,
          reviewFilter
        );

        callback(null, res);
      },
    };
  }

  public static getMedicationCosts() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new TrueViewManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        const rxBrandId = event.pathParameters.rx_brand_id;
        const rxDosageId = event.pathParameters.rx_dosage_id;

        const quantity = event.queryStringParameters.quantity;
        const frequency = event.queryStringParameters.frequency;

        const res = dm.getMedicationCosts(
          rxBrandId,
          rxDosageId,
          quantity,
          frequency
        );

        callback(null, res);
      },
    };
  }
}
