import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { PlanBenefitsManager } from "../data-managers/plan-benefits.manager";

export class PlanBenefitsController {
    public static getPlanBenefits() {
        return {
            handler: (
                event: APIGatewayEvent,
                context: Context,
                callback: Callback
            ) => {
                const externalMemberId = event.headers["X-User-Key"];
                const dm = new PlanBenefitsManager();
                const fileContent = dm.getPlanBenefits(externalMemberId);

                callback(null, fileContent);
            },
        };
    }
}