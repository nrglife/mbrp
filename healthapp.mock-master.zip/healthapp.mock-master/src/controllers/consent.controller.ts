import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { ConsentManager } from "../data-managers/consent.manager";

export class ConsentController {
  public static updateConsent() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new ConsentManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        dm.updateConsent(event.body);

        callback(null);
      },
    };
  }
}
