import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { ObligationsManager } from "../data-managers/obligations.manager";

export class ObligationsController {
  public static updateObligationStates() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new ObligationsManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        dm.updateObligationStates(event.body);

        callback(null);
      },
    };
  }
}
