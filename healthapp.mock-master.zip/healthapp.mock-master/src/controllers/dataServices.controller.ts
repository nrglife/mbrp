import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { DataServicesManager } from "../data-managers/dataservices.manager";

export class DataServicesController {
  public static getPayerConfigByName() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        const dm = new DataServicesManager();

        await dm.checkHttpSettings(event.path, event.httpMethod);

        const payerName = event.queryStringParameters.shortName;
   
        const res = dm.getPayerConfigByName(payerName);

       

        callback(null, res);
      },
    };
  }
}
