import { APIGatewayEvent, Callback, Context } from "aws-lambda";

export class HealthCheckController {
  public static performHealthCheck() {
    return {
      handler: async (
        event: APIGatewayEvent,
        context: Context,
        callback: Callback
      ) => {
        callback(null, {
          data: {},
        });
      },
    };
  }
}
