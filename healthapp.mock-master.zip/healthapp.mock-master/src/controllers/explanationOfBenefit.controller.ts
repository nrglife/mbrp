import { APIGatewayEvent, Callback, Context } from "aws-lambda";
import { ExplanationOfBenefitManager } from "../data-managers/explanation-of-benefit-manager";

export class ExplanationOfBenefitController {
    
    
    
    public static getExplanationOfBenefit() {
        return {
          handler: async (
            event: APIGatewayEvent,
            context: Context,
            callback: Callback
          ) => {
            const dm = new ExplanationOfBenefitManager();
    
            await dm.checkHttpSettings(event.path, event.httpMethod);
            const res = dm.getExplanationOfBenefit();
    
            callback(null, res);
          },
        };
      }
  
}