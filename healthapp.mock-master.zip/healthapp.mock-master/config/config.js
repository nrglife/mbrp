const dotenv = require("dotenv");
const dotenvExpand = require("dotenv-expand");

const loadedEnvironment = dotenv.config({
  path: `config/.env${process.env.NODE_ENV ? "." + process.env.NODE_ENV : ""}`
});
dotenvExpand(loadedEnvironment);

module.exports.env = () => loadedEnvironment.parsed;
